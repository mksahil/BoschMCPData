import os
import requests
from dotenv import load_dotenv
from fastmcp import FastMCP, Context

# Load environment variables
load_dotenv()

# Initialize FastMCP
mcp = FastMCP("Bosch Community Server")

# Proxy configuration (read from environment variables)
proxies = {
    "http": os.getenv("http_proxy"),
    "https": os.getenv("https_proxy")
}

@mcp.tool(
    name="get_community_list",
    description="Fetch the list of all available communities, including their descriptions, active member counts, and available location IDs."
)
def get_communities() -> str:
    """Gets the list of communities from the Bosch Associate Arena."""
    
    url = "https://dev.boschassociatearena.com/api/CommunityPlanet/GetCommunityList"

    response = requests.get(
        url,
        proxies=proxies,
        timeout=30,
        verify=False
    )

    return response.text


@mcp.tool(
    name="register_user_to_community",
    description="Register a user to a specific community. Requires CommunityId and LocationId. Uses only the existing authorization and content-type headers. Call get_community_list first if you need to find the correct IDs."
)
def join_community(community_id: int, location_id: int, ctx: Context) -> str:
    """Posts a registration request using the user's token from the request context."""

    headers_dict = ctx.request_context.headers
    auth_header = headers_dict.get("authorization") or headers_dict.get("Authorization")

    if not auth_header:
        return '{"IsSuccess": false, "Message": "No Authorization header found in request context."}'

    url = "https://dev.boschassociatearena.com/api/CommunityTile/SaveCommunityRegistration"

    api_headers = {
        "authorization": auth_header,
        "content-type": "application/json"
    }

    payload = {
        "CommunityId": community_id,
        "LocationId": location_id
    }

    response = requests.post(
        url,
        headers=api_headers,
        json=payload,
        proxies=proxies,
        timeout=30,
        verify=False
    )

    return response.text


if __name__ == "__main__":

    host = os.getenv("MCP_HOST", "0.0.0.0")
    port = int(os.getenv("MCP_PORT", "8002"))

    mcp.run(
        transport="streamable-http",
        host=host,
        port=port,
    )