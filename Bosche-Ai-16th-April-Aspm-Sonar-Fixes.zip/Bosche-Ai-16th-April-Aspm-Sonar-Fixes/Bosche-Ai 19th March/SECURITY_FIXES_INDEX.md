# Security Fixes Index
**Branch:** 19th March → merged into 16th April base  
**Total fixes:** 16  
**Standard comment format in code:** `// [FIX #N | Rule SXXXX - Label]: Description`

---

## Fix #1 — Rule S5144 (SSRF)
**File:** `backend/server.js`  
**What:** Added `extractBearerToken()` function that validates Authorization headers using a strict RFC 6750 regex before forwarding the token. Malformed or injected values return `null`, breaking the SSRF taint chain at the source.  
**Why:** Without sanitization, a crafted Authorization header could be used to perform Server-Side Request Forgery against internal services.

---

## Fix #2 — Rule S2083 (Path Traversal)
**Files:** `backend/server.js` — POST `/api/logs`, GET `/api/logs`, GET `/api/logs/download`  
**What:** Added `sessionId` and `date` format validation (strict regex), plus `path.resolve()` containment checks to ensure resolved file paths stay within `logsDir`/`sessionsDir`. Requests with paths that escape the allowed directory return 403.  
**Why:** Without these checks, a crafted `sessionId` like `../../etc/passwd` could read or write arbitrary files on the server.

---

## Fix #3 — Issue #8 (Hardcoded Secret)
**File:** `backend/mcp-client-stdio.js`  
**What:** Removed hardcoded database password. `DB_PASSWORD` now reads exclusively from the environment variable (`process.env.DB_PASSWORD`). No fallback value.  
**Why:** Hardcoded credentials in source code are exposed to anyone with repo access and violate secret management policies.

---

## Fix #4 — Rule S5869 (Regex — Unicode Grapheme Clusters)
**File:** `backend/intelligent-canteen.js`  
**What:** Replaced emoji characters inside regex character classes (e.g. `/[*🍽️]/`) with non-capturing alternation groups (e.g. `/(?:\*|🍽️)/`). Applied to all three menu-type regexes (breakfast, lunch, snacks).  
**Why:** Multi-codepoint emoji inside `[...]` character classes cause undefined behavior — the regex engine matches individual Unicode code points rather than the full grapheme, leading to false matches and potential ReDoS.

---

## Fix #5 — Issue #23 (Module Loading)
**File:** `backend/services/bosch-auth-service.js`  
**What:** Moved `crypto` module `require()` to the top-level imports instead of lazy-loading it inside a function.  
**Why:** Lazy-loading security-critical modules can cause race conditions and makes it harder to audit which modules are loaded at startup.

---

## Fix #6 — Rule S5144 (SSRF)
**File:** `backend/services/bosch-auth-service.js`  
**What:** Added `ALLOWED_API_HOSTS` allowlist and `validateTargetUrl()` function to reject requests to non-whitelisted hosts before any HTTP call is made. Added `sanitizeOAuthToken()` to strip non-token characters from OAuth tokens before they are used in Authorization headers.  
**Why:** Without host validation, the auth service could be coerced into forwarding tokens to attacker-controlled servers.

---

## Fix #7 — Rule S2083 (Path Injection)
**File:** `backend/services/bosch-auth-service.js`  
**What:** Replaced string concatenation for API endpoint URLs with `new URL(path, base).href` to ensure path segments cannot escape the intended base URL via directory traversal sequences (`../`).  
**Why:** String-concatenated URLs are vulnerable to path injection if any user-controlled input reaches the path segment.

---

## Fix #8 — Issue #9 (Hardcoded Secret)
**File:** `backend/services/bosch-auth-service.js`  
**What:** Removed hardcoded device token fallback value. Token now comes exclusively from `process.env.DEVICE_TOKEN`.  
**Why:** Same as Fix #3 — hardcoded secrets must not exist in source code.

---

## Fix #9 — Rule S6544 (Promise Conditional Check)
**File:** `frontend/src/services/azureAuthService.ts`  
**What:** Introduced `msalInitialized` boolean flag. The MSAL `initialize()` promise is only created once; the flag is set to `true` inside `.then()` so subsequent calls skip re-initialization correctly.  
**Why:** Checking `!msalInitializePromise` is unreliable — if the promise is pending, a second call creates a duplicate initialization. The flag ensures the check is against a settled state.

---

## Fix #10 — Rule S3786 (Class Definition Inside Component)
**File:** `frontend/src/components/AnimatedBackground.tsx`  
**What:** Moved the `Particle` class definition from inside the React functional component to the module scope (top of file).  
**Why:** Defining a class inside a component body causes it to be re-created on every render, breaking identity checks and wasting memory. SonarQube flags this as a class definition with potential `this` context issues.

---

## Fix #11 — Rule S2245 (Insecure PRNG)
**File:** `frontend/src/components/AnimatedBackground.tsx`  
**What:** Replaced `Math.random()` with `crypto.getRandomValues()` for generating particle properties in the animation canvas.  
**Why:** `Math.random()` is not cryptographically secure. While animation values are not security-sensitive, using CSPRNG satisfies the SonarQube rule and prevents the pattern from being copy-pasted into security-sensitive contexts.

---

## Fix #12 — Rule S1082 (Missing Keyboard Listener)
**Files:** `frontend/src/components/CommunityCard.tsx`, `frontend/src/components/InsightsStrip.tsx`, `frontend/src/components/SolarSystem.tsx`  
**What:** Added `onKeyDown` handlers (Enter/Space keys) alongside existing `onClick` handlers on interactive elements. Added `tabIndex={0}` and `role="button"` where missing.  
**Why:** Elements with `onClick` but no keyboard equivalent are inaccessible to keyboard-only users and screen readers, violating WCAG 2.1 Success Criterion 2.1.1.

---

## Fix #13 — Rule S6819 (ARIA — Missing Keyboard Role)
**File:** `frontend/src/components/DashboardCard.tsx`  
**What:** Added `onKeyDown` event handler, `role="button"`, and `tabIndex={0}` to the card's interactive container div.  
**Why:** Divs with `onClick` are not keyboard-focusable by default. Without explicit role and keyboard handling, the element is invisible to assistive technologies.

---

## Fix #14 — Issue #17 (Hardcoded URL / Insecure Transmission)
**File:** `frontend/src/pages/Admin.tsx`  
**What:** Replaced all hardcoded `http://localhost:3001` references with `import.meta.env.VITE_API_URL` environment variable (5 occurrences).  
**Why:** Hardcoded `localhost` URLs break in any non-local environment and expose the assumption that the backend is unencrypted HTTP, which is insecure in production.

---

## Fix #15 — Rule S3923 (All Branches Identical / Redundant Condition)
**File:** `frontend/src/pages/Admin.tsx`  
**What:** Removed a redundant `else if` branch whose condition was always evaluated identically to the preceding `if`, making the logic dead code.  
**Why:** Redundant conditions are a code smell that indicates either a logic bug or dead code. SonarQube flags this to prevent future misunderstanding of control flow.

---

## Fix #16 — Rule S6816 (Missing `scope` on Table Header)
**Files:** `frontend/src/pages/AnalyticsViewer.tsx`, `frontend/src/pages/LogViewer.tsx`  
**What:** Added `scope="col"` attribute to all `<th>` elements in data tables.  
**Why:** Table headers without a `scope` attribute cannot be correctly associated with their data cells by screen readers, violating WCAG 1.3.1 (Info and Relationships).

---

## Fix #17 — Rule S5256 (Missing Table Header Structure)
**File:** `frontend/src/components/ui/table.tsx`  
**What:** Added `scope={props.scope ?? "col"}` as a default to the `TableHead` component's `<th>` element. Callers can still override with `scope="row"` where needed; column headers default to `"col"` automatically.  
**Why:** SonarQube S5256 requires every `<table>` to contain properly scoped headers. Without `scope`, screen readers cannot associate header cells with their corresponding data cells, violating WCAG 1.3.1 (Info and Relationships).

---

## Fix #18 — Rule S5527 (TLS Hostname Verification Disabled)
**File:** `frontend/test-seat-E.mjs`  
**What:** Changed `rejectUnauthorized: false` to `rejectUnauthorized: true` in the HTTPS request options.  
**Why:** `rejectUnauthorized: false` disables all SSL/TLS certificate and hostname verification, allowing man-in-the-middle attackers to intercept traffic by presenting any certificate. Restoring it to `true` enforces valid certificate chain and hostname matching on every HTTPS request.

---

## Fix #19 — Rule S5527 (TLS Certificate Validation Explicitly Disabled)
**File:** `frontend/test-seat-G.mjs`  
**What:** Changed `rejectUnauthorized: false` to `rejectUnauthorized: true` in the HTTPS request options.  
**Why:** Same as Fix #18. This file had explicitly opted out of the Node.js default (which is `true`), fully breaking the trust model of HTTPS. Any credentials or tokens sent in the request body could be intercepted. Restored certificate validation to enforce secure connections.

---

## Fix #20 — Rule S2083 (Path Injection — Conversation Context Service)
**File:** `backend/services/conversation-context-service.js`  
**Lines affected:** 121 (`saveContext`), 132 (`loadContext`), 82 (`initializeContext` propagation)  
**What:** Introduced a private `_buildSafeFilePath(employeeNumber, sessionId)` helper that applies two layers of defence before constructing any file path: (1) a strict allowlist regex — `employeeNumber` must be 6–12 digits, `sessionId` must be 1–128 alphanumeric/dash/underscore characters; (2) a `path.resolve()` containment check that confirms the resolved path starts with `this.dataDir`. Both `saveContext` and `loadContext` now call this helper instead of directly using `path.join` with raw user input. If validation fails, the operation is aborted and a warning is logged — no error detail is returned to the caller. The propagation issue at line 82 (`initializeContext → loadContext`) is resolved automatically because validation now occurs at the sink functions.  
**Why:** `employeeNumber` and `sessionId` arrive directly from the HTTP request body (`/api/chat`). Without validation, an attacker could supply values like `../../etc/passwd` or `..\\..\\.env` to read arbitrary files (`loadContext`) or overwrite them (`saveContext`), constituting a CWE-22 path traversal vulnerability.

---

## Fix #21 — Rule S2083 (Path Injection — Entry-Point Sanitization in initializeContext)
**File:** `backend/services/conversation-context-service.js`  
**Lines affected:** `initializeContext` entry (new validation block), internal `saveContext` call in `loadContext`  
**What:** Added input validation at the very top of `initializeContext` — the earliest point where `sessionId` and `employeeNumber` arrive from `req.body` before being used anywhere. `sessionId` is checked against `/^[a-zA-Z0-9_-]{1,128}$/`; if invalid, a safe anonymous context object is returned immediately with no Map or disk access. `employeeNumber` is checked against `/^\d{6,12}$/`; if invalid it is nulled out so the function skips all disk I/O. Also added a clarifying comment on the internal `saveContext` call inside `loadContext` to document that both values are already validated before reaching that point, and that `saveContext` applies `_buildSafeFilePath` validation again as a second layer.  
**Why:** FIX #20 added sink-level validation inside `saveContext` and `loadContext`, but SonarQube's taint analysis still flagged two flows: (1) `getContext(sessionId)` in `initializeContext` — the Map key usage occurred before any sanitization; (2) the internal `saveContext(employeeNumber, sessionId, activeMessages)` call inside `loadContext` — SonarQube did not track through the `_buildSafeFilePath` helper to confirm those variables were already clean. Sanitizing at the entry point of `initializeContext` breaks the taint chain at the source and satisfies SonarQube's data-flow analysis for all downstream uses.

---

## Fix #22 — Rule S5527 (TLS Certificate & Hostname Verification Disabled)
**File:** `frontend/test-system-instruction.mjs`  
**What:** Changed `rejectUnauthorized: false` to `rejectUnauthorized: true`.  
**Why:** Same issue as FIX #18 and #19. This test file was missed in the earlier sweep. `rejectUnauthorized: false` disables both SSL certificate validation (CWE-295) and hostname verification (CWE-297), allowing man-in-the-middle attackers to intercept HTTPS traffic by presenting any certificate. Restored to `true` to enforce the full TLS trust chain.

---

## How to find a fix in the code

Search for `[FIX #N` in the codebase:
```
# Example: find all Fix #2 occurrences
grep -rn "\[FIX #2" backend/ frontend/src/
```
