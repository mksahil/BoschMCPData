import https from 'https';
import fs from 'fs';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-H',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-H',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-H',
        // CANDIDATE H nests user_data inside auth
        user_data: {
          employee_id: '34835634',
          name: 'Manjunath',
          email: 'manjunath@bosch.com'
        }
      },
      employee_id: '34835634',
      user_id: '34835634',
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      booking_mode: 'seat',
      travel_mode: 'seat'
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
};

console.log('Calling A2A Seat Booking Agent (Candidate H nested auth)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-H.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-H.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
