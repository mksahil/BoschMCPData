import https from 'https';
import fs from 'fs';

const employeeId = '34835634';
const name = 'Manjunath';
const email = 'manjunath@bosch.com';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-N',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-N',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-N'
      },
      // Candidate N: CamelCase Metadata
      booking_mode: 'seat',
      travel_mode: 'seat',
      employeeId: employeeId,
      userId: employeeId,
      userName: name,
      userEmail: email
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
};

console.log('Calling A2A Seat Booking Agent (Candidate N CamelCase)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-N.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-N.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
