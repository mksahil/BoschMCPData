import { render, screen, act, waitFor, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Index from '@/pages/Index';
import { AuthProvider } from '@/context/AuthContext';
import logger from '@/lib/logger';

// Sub-components are rendered as-is (fetch and logger are mocked)


describe('Index Page', () => {
  beforeEach(() => {
    sessionStorage.clear();
    spyOn(logger, 'logPageView');
    spyOn(logger, 'logNavigation');
    // Mock fetch for SolarSystem which might still be rendered if not fully mocked
    spyOn(window, 'fetch').and.returnValue(Promise.resolve({
       ok: true,
       json: () => Promise.resolve({ services: [] })
    } as Response));
  });

  const renderIndex = () => {
    return render(
      <AuthProvider>
        <MemoryRouter>
          <Index />
        </MemoryRouter>
      </AuthProvider>
    );
  };

  it('renders correctly on home section by default', async () => {
    await act(async () => {
      renderIndex();
    });
    
    expect(screen.getByText(/My Universe/i)).toBeTruthy();
    expect(logger.logPageView).toHaveBeenCalledWith('Dashboard Home', jasmine.any(Object));
  });

  it('renders the navigation and footer', async () => {
    await act(async () => {
      renderIndex();
    });
    
    // Check navigation specific text (scoped to navigation role)
    const nav = screen.getByRole('navigation');
    expect(within(nav).getByText(/MyBGSW.Ai/i)).toBeTruthy();
    
    // Check footer specific text (using within footer to be specific)
    const footer = screen.getByRole('contentinfo');
    expect(within(footer).getByText(/myBGSW/i)).toBeTruthy();
  });


  it('displays the ChatWindow when on home section', async () => {
     await act(async () => {
      renderIndex();
    });
    
    expect(screen.getByPlaceholderText(/Ask me anything/i)).toBeTruthy();
  });
});

