import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import NotFound from '@/pages/NotFound';

describe('NotFound (404 page)', () => {
  beforeEach(() => {
    // Suppress the intentional console.error logged by the component
    spyOn(console, 'error');
  });

  it('renders the 404 heading', () => {
    render(
      <MemoryRouter>
        <NotFound />
      </MemoryRouter>
    );
    expect(screen.getByText('404')).toBeTruthy();
  });

  it('shows "Page not found" message', () => {
    render(
      <MemoryRouter>
        <NotFound />
      </MemoryRouter>
    );
    expect(screen.getByText(/page not found/i)).toBeTruthy();
  });

  it('renders a home link pointing to "/"', () => {
    render(
      <MemoryRouter>
        <NotFound />
      </MemoryRouter>
    );
    const link = screen.getByRole('link', { name: /return to home/i });
    expect(link).toBeTruthy();
    expect((link as HTMLAnchorElement).getAttribute('href')).toBe('/');
  });

  it('logs a 404 console error on mount', () => {
    render(
      <MemoryRouter initialEntries={['/some/missing/route']}>
        <NotFound />
      </MemoryRouter>
    );
    expect(console.error).toHaveBeenCalled();
  });
});
