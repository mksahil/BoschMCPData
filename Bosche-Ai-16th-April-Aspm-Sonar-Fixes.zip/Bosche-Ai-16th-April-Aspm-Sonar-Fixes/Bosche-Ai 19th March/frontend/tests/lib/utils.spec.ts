import { cn, generateUUID, renderMarkdown } from '@/lib/utils';

// ─── cn() ────────────────────────────────────────────────────────────────────
describe('cn()', () => {
  it('merges a single class string', () => {
    expect(cn('foo')).toBe('foo');
  });

  it('merges multiple class strings', () => {
    const result = cn('foo', 'bar');
    expect(result).toContain('foo');
    expect(result).toContain('bar');
  });

  it('ignores falsy values', () => {
    expect(cn('base', false && 'hidden')).toBe('base');
  });

  it('handles object conditional syntax (truthy)', () => {
    expect(cn({ active: true })).toContain('active');
  });

  it('handles object conditional syntax (falsy)', () => {
    expect(cn({ disabled: false })).toBe('');
  });

  it('deduplicates conflicting Tailwind utilities (last wins)', () => {
    expect(cn('p-4', 'p-2')).toBe('p-2');
  });

  it('returns empty string when called with no args', () => {
    expect(cn()).toBe('');
  });
});

// ─── generateUUID() ──────────────────────────────────────────────────────────
describe('generateUUID()', () => {
  it('returns a string', () => {
    expect(typeof generateUUID()).toBe('string');
  });

  it('matches UUID v4 format', () => {
    const uuid = generateUUID();
    const uuidV4Regex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    expect(uuidV4Regex.test(uuid)).toBeTrue();
  });

  it('generates unique values on successive calls', () => {
    expect(generateUUID()).not.toBe(generateUUID());
  });
});

// ─── renderMarkdown() ────────────────────────────────────────────────────────
describe('renderMarkdown()', () => {
  it('returns empty string for empty input', () => {
    expect(renderMarkdown('')).toBe('');
  });

  it('escapes & to &amp;', () => {
    expect(renderMarkdown('cats & dogs')).toContain('&amp;');
  });

  it('escapes < to &lt;', () => {
    expect(renderMarkdown('<tag>')).toContain('&lt;');
  });

  it('escapes > to &gt;', () => {
    expect(renderMarkdown('a > b')).toContain('&gt;');
  });

  it('converts **text** to <strong>', () => {
    expect(renderMarkdown('**bold**')).toContain('<strong>bold</strong>');
  });

  it('converts *text* to <em>', () => {
    expect(renderMarkdown('*italic*')).toContain('<em>italic</em>');
  });

  it('converts `code` to <code>', () => {
    const result = renderMarkdown('`snippet`');
    expect(result).toContain('<code');
    expect(result).toContain('snippet');
  });

  it('does not interpret script tags (escapes them)', () => {
    const result = renderMarkdown('<script>evil()</script>');
    expect(result).not.toContain('<script>');
  });
});
