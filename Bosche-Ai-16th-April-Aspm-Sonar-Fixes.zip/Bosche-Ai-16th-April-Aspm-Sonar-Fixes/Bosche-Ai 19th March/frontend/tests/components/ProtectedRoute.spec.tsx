import { render, screen, act } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';

// Helper: build a valid mock user object stored in sessionStorage
function seedValidUser() {
  const user = {
    employeeNumber: 'EMP001',
    name: 'Test User',
    accessToken: 'mock-token',
    tokenType: 'Bearer',
    entityId: '1',
    entityName: 'BGSW',
    isTemporaryPassword: false,
    loginTimestamp: new Date().toISOString(),
    ntid: 'testntid',
    expiresIn: 3600,
    issuedAt: new Date().toISOString(),
    // expiresAt 1 hour in the future — session is valid
    expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
    loginMethod: 'credential' as const,
  };
  sessionStorage.setItem('mybgsw_user', JSON.stringify(user));
}

describe('ProtectedRoute', () => {
  beforeEach(() => sessionStorage.clear());
  afterEach(() => sessionStorage.clear());

  it('renders children when the user session is valid', async () => {
    seedValidUser();

    await act(async () => {
      render(
        <AuthProvider>
          <MemoryRouter initialEntries={['/dashboard']}>
            <Routes>
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <div>Protected Content</div>
                </ProtectedRoute>
              } />
              <Route path="/login" element={<div>Login Page</div>} />
            </Routes>
          </MemoryRouter>
        </AuthProvider>
      );
    });

    expect(screen.getByText('Protected Content')).toBeTruthy();
  });

  it('does NOT render children when the user is unauthenticated', async () => {
    // sessionStorage is empty — no user

    await act(async () => {
      render(
        <AuthProvider>
          <MemoryRouter initialEntries={['/dashboard']}>
            <Routes>
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <div>Protected Content</div>
                </ProtectedRoute>
              } />
              <Route path="/login" element={<div>Login Page</div>} />
            </Routes>
          </MemoryRouter>
        </AuthProvider>
      );
    });

    expect(screen.queryByText('Protected Content')).toBeNull();
    expect(screen.getByText('Login Page')).toBeTruthy();
  });

  it('does NOT render children for an expired session', async () => {
    // Expired user — expiresAt in the past
    const expiredUser = {
      employeeNumber: 'EMP002',
      name: 'Expired User',
      accessToken: 'old-token',
      tokenType: 'Bearer',
      entityId: '2',
      entityName: 'BGSW',
      isTemporaryPassword: false,
      loginTimestamp: new Date().toISOString(),
      ntid: 'expiredntid',
      expiresIn: 3600,
      issuedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() - 1000).toISOString(), // expired
      loginMethod: 'credential' as const,
    };
    sessionStorage.setItem('mybgsw_user', JSON.stringify(expiredUser));

    await act(async () => {
      render(
        <AuthProvider>
          <MemoryRouter initialEntries={['/dashboard']}>
            <Routes>
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <div>Protected Content</div>
                </ProtectedRoute>
              } />
              <Route path="/login" element={<div>Login Page</div>} />
            </Routes>
          </MemoryRouter>
        </AuthProvider>
      );
    });

    expect(screen.queryByText('Protected Content')).toBeNull();
    expect(screen.getByText('Login Page')).toBeTruthy();
  });
});
