import { render, screen, fireEvent, act, waitFor } from '@testing-library/react';
import { SolarSystem } from '@/components/SolarSystem';
import { AuthProvider } from '@/context/AuthContext';
import logger from '@/lib/logger';

// ─── Mocks ───────────────────────────────────────────────────────────────────
// Mock scrollIntoView
window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

describe('SolarSystem', () => {
  const mockUser = {
    employeeNumber: 'EMP001',
    name: 'John Doe',
    accessToken: 'test-token',
    entityName: 'BGSW',
  };

  beforeEach(() => {
    sessionStorage.clear();
    spyOn(window, 'fetch').and.returnValue(Promise.resolve({
      ok: true,
      json: () => Promise.resolve({ services: [{ id: 'cafeteria' }, { id: 'travel' }] })
    } as Response));
    spyOn(logger, 'logButtonClick');
  });

  const renderSolarSystem = (props = {}) => {
    return render(
      <AuthProvider>
        <SolarSystem {...props} />
      </AuthProvider>
    );
  };

  it('renders the central Sun (User Profile)', () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    renderSolarSystem();
    
    expect(screen.getByText('John Doe')).toBeTruthy();
    expect(screen.getByText(/ID: EMP001/)).toBeTruthy();
  });

  it('renders orbit rings', () => {
    const { container } = renderSolarSystem();
    // There are 4 orbit rings defined in the component
    const orbits = container.querySelectorAll('.border-border\\/20');
    expect(orbits.length).toBe(4);
  });

  it('fetches active services on mount', async () => {
    renderSolarSystem();
    
    await waitFor(() => {
      expect(window.fetch).toHaveBeenCalledWith('http://localhost:3001/api/services');
    });
  });

  it('displays planet names on hover', async () => {
    renderSolarSystem();
    
    // Wait for services to be rendered
    const planets = await screen.findAllByRole('button');
    const bobPlanet = planets.find(p => p.textContent?.includes('Benefits')) || planets[0];
    
    fireEvent.mouseEnter(bobPlanet);
    
    // Label should be visible (regex match to handle "Coming Soon" suffix if state hasn't updated)
    expect(await screen.findByText(/Benefits/i)).toBeTruthy();
  });

  it('opens planet detail portal on click', async () => {
    renderSolarSystem();
    
    // Wait for services to load and state to update
    await waitFor(() => {
      expect(window.fetch).toHaveBeenCalled();
    });

    // Find the 'Travel' planet - wait for it to be present and NOT disabled/not-allowed
    const travelPlanet = await screen.findByText('Travel');
    const planetButton = travelPlanet.closest('[role="button"]');
    expect(planetButton).toBeTruthy();
    
    await act(async () => {
      fireEvent.click(planetButton!);
    });

    // Portal button has 'bg-destructive' class
    await waitFor(() => {
      const closeBtn = document.body.querySelector('.bg-destructive');
      if (!closeBtn) {
        // Log to help debug if it fails again
        console.log('Body HTML:', document.body.innerHTML);
      }
      expect(closeBtn).toBeTruthy();
    }, { timeout: 2000 });
  });

  it('closes detail portal when clicking the close button', async () => {
    renderSolarSystem();
    
    await waitFor(() => {
      expect(window.fetch).toHaveBeenCalled();
    });

    const travelPlanet = await screen.findByText('Travel');
    const planetButton = travelPlanet.closest('[role="button"]');
    
    await act(async () => {
      fireEvent.click(planetButton!);
    });

    // Find and click close button
    const closeBtn = await waitFor(() => {
      const btn = document.body.querySelector('.bg-destructive');
      expect(btn).toBeTruthy();
      return btn;
    });
    
    await act(async () => {
      fireEvent.click(closeBtn!);
    });
    
    // Portal should be removed from document.body
    await waitFor(() => {
      expect(document.body.querySelector('.bg-destructive')).toBeNull();
    });
  });
});




