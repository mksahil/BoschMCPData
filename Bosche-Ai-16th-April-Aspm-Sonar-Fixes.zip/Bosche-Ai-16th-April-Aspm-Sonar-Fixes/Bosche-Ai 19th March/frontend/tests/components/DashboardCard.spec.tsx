import { render, screen, fireEvent } from '@testing-library/react';
import { DashboardCard } from '@/components/DashboardCard';
import { Home } from 'lucide-react';
import logger from '@/lib/logger';

describe('DashboardCard', () => {
  const defaultProps = {
    title: 'Test Card',
    icon: Home,
    children: <div>Card Content</div>,
  };

  beforeEach(() => {
    // Mock logger methods used in DashboardCard
    spyOn(logger, 'logFeatureUsage');
    spyOn(logger, 'log');
  });

  it('renders correctly with required props', () => {
    render(<DashboardCard {...defaultProps} />);
    
    expect(screen.getByText('Test Card')).toBeTruthy();
    expect(screen.getByText('Card Content')).toBeTruthy();
  });

  it('logs feature usage on mount', () => {
    render(<DashboardCard {...defaultProps} />);
    
    expect(logger.logFeatureUsage).toHaveBeenCalledWith('dashboard-card-test-card', jasmine.any(Object));
  });

  it('logs click interaction when clicked', () => {
    render(<DashboardCard {...defaultProps} />);
    
    const card = screen.getByRole('button');
    fireEvent.click(card);
    
    expect(logger.log).toHaveBeenCalledWith('dashboard_card_click', jasmine.objectContaining({
      cardTitle: 'Test Card'
    }));
  });

  it('logs click interaction on Enter key press', () => {
    render(<DashboardCard {...defaultProps} />);
    
    const card = screen.getByRole('button');
    fireEvent.keyDown(card, { key: 'Enter', code: 'Enter' });
    
    expect(logger.log).toHaveBeenCalledWith('dashboard_card_click', jasmine.objectContaining({
      cardTitle: 'Test Card'
    }));
  });

  it('logs click interaction on Space key press', () => {
    render(<DashboardCard {...defaultProps} />);
    
    const card = screen.getByRole('button');
    fireEvent.keyDown(card, { key: ' ', code: 'Space' });
    
    expect(logger.log).toHaveBeenCalledWith('dashboard_card_click', jasmine.objectContaining({
      cardTitle: 'Test Card'
    }));
  });

  it('applies accent class when accent prop is true', () => {
    const { container } = render(<DashboardCard {...defaultProps} accent={true} />);
    const cardDiv = container.firstChild as HTMLElement;
    
    expect(cardDiv.className).toContain('bg-gradient-subtle');
  });

  it('renders action element if provided', () => {
    render(<DashboardCard {...defaultProps} action={<button>Action</button>} />);
    
    expect(screen.getByText('Action')).toBeTruthy();
  });
});
