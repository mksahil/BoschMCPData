import { render, screen } from '@testing-library/react';
import { Footer } from '@/components/Footer';

describe('Footer component', () => {
  it('renders a <footer> element', () => {
    render(<Footer />);
    const footer = document.querySelector('footer');
    expect(footer).not.toBeNull();
  });

  it('shows the process owner text', () => {
    render(<Footer />);
    expect(
      screen.getByText(/Inside myBGSW page Process Owner/i)
    ).toBeTruthy();
  });

  it('shows the BD\/APA-IN attribution', () => {
    render(<Footer />);
    expect(screen.getByText(/BD\/APA-IN/i)).toBeTruthy();
  });
});
