import { render, screen, fireEvent, act } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { Navigation } from '@/components/Navigation';
import { AuthProvider } from '@/context/AuthContext';
import * as router from 'react-router-dom';

// ── Mock router hooks if needed ─────────────────────────────────────────────
// (We usually wrap in MemoryRouter, but for logout/navigate we might need spies)

describe('Navigation', () => {
  const mockUser = {
    employeeNumber: 'EMP123',
    name: 'John Doe',
    accessToken: 'test-token',
    entityName: 'BGSW',
  };

  beforeEach(() => {
    sessionStorage.clear();
  });

  const renderNav = (props = {}) => {
    return render(
      <AuthProvider>
        <MemoryRouter>
          <Navigation {...props} />
        </MemoryRouter>
      </AuthProvider>
    );
  };

  it('renders logo and application title', async () => {
    await act(async () => {
      renderNav();
    });
    
    expect(screen.getByAltText('MyBGSW Logo')).toBeTruthy();
    expect(screen.getByText('MyBGSW.Ai')).toBeTruthy();
  });

  it('renders custom context title if provided', async () => {
    await act(async () => {
      renderNav({ contextTitle: 'Custom Portal' });
    });
    
    expect(screen.getByText('Custom Portal')).toBeTruthy();
  });

  it('renders navigation items', async () => {
    await act(async () => {
      renderNav();
    });
    
    expect(screen.getByText('Home')).toBeTruthy();
    expect(screen.getByText('Insights')).toBeTruthy();
    expect(screen.getByText('Actions')).toBeTruthy();
  });

  it('calls onSectionChange when a nav item is clicked', async () => {
    const onSectionChange = jasmine.createSpy('onSectionChange');
    await act(async () => {
      renderNav({ onSectionChange });
    });
    
    fireEvent.click(screen.getByText('Insights'));
    expect(onSectionChange).toHaveBeenCalledWith('insights');
  });

  it('displays user initials correctly', async () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    await act(async () => {
      renderNav();
    });

    // John Doe -> JD
    expect(screen.getByText('JD')).toBeTruthy();
  });

  it('displays employee ID badge when user is logged in', async () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    await act(async () => {
      renderNav();
    });

    expect(screen.getByText(/ID: EMP123/)).toBeTruthy();
  });

  it('shows user initials from employee number if name is missing', async () => {
     sessionStorage.setItem('mybgsw_user', JSON.stringify({
      employeeNumber: 'EM555',
      accessToken: 'tok',
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    await act(async () => {
      renderNav();
    });

    // EMP555 -> EM
    expect(screen.getByText('EM')).toBeTruthy();
  });
});
