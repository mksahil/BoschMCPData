import { render, screen, fireEvent, act, waitFor } from '@testing-library/react';
import { ChatWindow } from '@/components/ChatWindow';
import { AuthProvider } from '@/context/AuthContext';
import logger from '@/lib/logger';

// ─── Mocks ───────────────────────────────────────────────────────────────────
window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

describe('ChatWindow', () => {
  const mockUser = {
    employeeNumber: 'EMP001',
    name: 'John Doe',
    accessToken: 'test-token',
  };

  const onToggle = jasmine.createSpy('onToggle');

  beforeEach(() => {
    sessionStorage.clear();
    onToggle.calls.reset();
    spyOn(window, 'fetch').and.returnValue(Promise.resolve({
      ok: true,
      json: () => Promise.resolve({ response: 'AI response', service: 'general' })
    } as Response));
    spyOn(logger, 'logChatMessage');
  });

  const renderChat = (isOpen = true) => {
    return render(
      <AuthProvider>
        <ChatWindow isOpen={isOpen} onClose={onToggle} />
      </AuthProvider>
    );
  };

  it('renders nothing when closed (height 0)', () => {
    const { container } = renderChat(false);
    const chatContainer = container.querySelector('.h-0');
    expect(chatContainer).toBeTruthy();
  });

  it('renders chat interface when open', () => {
    renderChat(true);
    expect(screen.getByText(/Ask MyBGSW.AI/i)).toBeTruthy();
    expect(screen.getByPlaceholderText(/Ask me anything/i)).toBeTruthy();
  });

  it('calls onToggle when close button is clicked', () => {
    renderChat(true);
    // There's an X button in the header
    const closeBtn = screen.getAllByRole('button').find(b => b.querySelector('.lucide-x'));
    fireEvent.click(closeBtn!);
    expect(onToggle).toHaveBeenCalled();
  });

  it('sends a message and displays response', async () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    renderChat(true);
    const input = screen.getByPlaceholderText(/Ask me anything/i);
    const sendBtn = screen.getByTitle('Send message');

    await act(async () => {
      fireEvent.change(input, { target: { value: 'Hello' } });
      fireEvent.click(sendBtn);
    });

    expect(window.fetch).toHaveBeenCalled();
    expect(logger.logChatMessage).toHaveBeenCalledWith('Hello', true, jasmine.any(Object));
    
    await waitFor(() => {
      expect(screen.getByText('AI response')).toBeTruthy();
    });
  });

  it('handles feedback clicks', async () => {
    // Mock feedback API
    (window.fetch as jasmine.Spy).and.callFake((url: string) => {
       if (url.includes('chat/feedback')) return Promise.resolve({ ok: true } as Response);
       return Promise.resolve({ ok: true, json: () => Promise.resolve({ response: 'AI Response', conversationId: 123 }) } as Response);
    });

    renderChat(true);
    const input = screen.getByPlaceholderText(/Ask me anything/i);
    const sendBtn = screen.getByTitle('Send message');

    await act(async () => {
      fireEvent.change(input, { target: { value: 'feedback test' } });
      fireEvent.click(sendBtn);
    });

    // Wait for AI response to appear with feedback buttons
    const thumbsUp = await screen.findByTitle('Helpful');
    fireEvent.click(thumbsUp);

    expect(window.fetch).toHaveBeenCalledWith(jasmine.stringMatching(/feedback/), jasmine.any(Object));
  });
});

