/**
 * Mock replacement for @/services/azureAuthService
 * Used during Karma tests via webpack alias to avoid importing @azure/msal-browser.
 * This file ONLY exists for the test build — production code is unaffected.
 */

export const initializeMsal = () => ({});
export const getMsalInstance = () => ({});
export const loginWithAzureAD = async () => null;
export const getAccessTokenSilently = async () => null;
export const getAccessToken = async () => null;
export const handleSSORedirectCallback = async () => null;
export const getCurrentAccount = async () => null;
export const exchangeAzureTokenForArenaToken = async (_token: string) => ({});
export const performSSO = async () => null;
export const logoutAzureAD = async () => {};
