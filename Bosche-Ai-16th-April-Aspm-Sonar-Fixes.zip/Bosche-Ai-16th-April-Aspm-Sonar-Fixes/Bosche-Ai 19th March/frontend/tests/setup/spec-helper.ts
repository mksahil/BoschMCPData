// Global test bootstrap — runs before all specs
// No imports needed; standard Jasmine globals are available
