import { render, screen, act } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/context/AuthContext';

// ─── Helper: mock fetch ───────────────────────────────────────────────────────
function mockFetch(body: object, status = 200) {
  spyOn(window, 'fetch').and.returnValue(
    Promise.resolve(
      new Response(JSON.stringify(body), {
        status,
        headers: { 'Content-Type': 'application/json' },
      })
    )
  );
}

// ─── Helper: capture auth context value ──────────────────────────────────────
function AuthCapture({ onCapture }: { onCapture: (ctx: ReturnType<typeof useAuth>) => void }) {
  onCapture(useAuth());
  return null;
}

// ─── Helper: valid Arena token response ──────────────────────────────────────
const futureDate = new Date(Date.now() + 3_600_000).toISOString();
const mockArenaToken = {
  userName: 'EMP001',
  Name: 'Test User',
  access_token: 'access-token',
  token_type: 'Bearer',
  EntityId: '1',
  EntityName: 'BGSW',
  IsTemporaryPassword: 'False',
  LoginTimeStamp: new Date().toISOString(),
  NTID: 'ntid001',
  expires_in: 3600,
  '.issued': new Date().toISOString(),
  '.expires': futureDate,
};

// ─────────────────────────────────────────────────────────────────────────────
describe('AuthContext', () => {
  beforeEach(() => sessionStorage.clear());
  afterEach(() => sessionStorage.clear());

  // ── AuthProvider renders children ──
  it('AuthProvider renders its children', async () => {
    await act(async () => {
      render(
        <AuthProvider>
          <div>Child Element</div>
        </AuthProvider>
      );
    });
    expect(screen.getByText('Child Element')).toBeTruthy();
  });

  // ── Session restore ──
  it('restores a valid user from sessionStorage on mount', async () => {
    const validUser = {
      employeeNumber: 'EMP001', name: 'Test', accessToken: 'tok',
      tokenType: 'Bearer', entityId: '1', entityName: 'E',
      isTemporaryPassword: false, loginTimestamp: new Date().toISOString(),
      ntid: 'n', expiresIn: 3600, issuedAt: new Date().toISOString(),
      expiresAt: futureDate, loginMethod: 'credential',
    };
    sessionStorage.setItem('mybgsw_user', JSON.stringify(validUser));

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    expect(captured.isAuthenticated).toBeTrue();
    expect(captured.user?.employeeNumber).toBe('EMP001');
  });

  // ── Expired session is cleared ──
  it('clears an expired user from sessionStorage on mount', async () => {
    const expiredUser = {
      employeeNumber: 'EMP002', name: 'Old', accessToken: 'x',
      tokenType: 'Bearer', entityId: '2', entityName: 'E',
      isTemporaryPassword: false, loginTimestamp: new Date().toISOString(),
      ntid: 'n', expiresIn: 1, issuedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() - 1000).toISOString(), // expired
      loginMethod: 'credential',
    };
    sessionStorage.setItem('mybgsw_user', JSON.stringify(expiredUser));

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    expect(captured.isAuthenticated).toBeFalse();
    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── ssoLogin success ──
  it('ssoLogin sets user and returns success for valid token data', async () => {
    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    let result: any;
    await act(async () => {
      result = await captured.ssoLogin(mockArenaToken);
    });

    expect(result.success).toBeTrue();
    expect(captured.isAuthenticated).toBeTrue();
    expect(captured.user?.name).toBe('Test User');
    expect(captured.user?.loginMethod).toBe('sso');
  });

  // ── ssoLogin with null returns error ──
  it('ssoLogin returns failure when no token data provided', async () => {
    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    let result: any;
    await act(async () => {
      result = await captured.ssoLogin(null as any);
    });

    expect(result.success).toBeFalse();
    expect(result.error).toBeTruthy();
  });

  // ── login success ──
  it('login returns success and sets user on valid API response', async () => {
    mockFetch(mockArenaToken, 200);

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    let result: any;
    await act(async () => {
      result = await captured.login('EMP001', 'password');
    });

    expect(result.success).toBeTrue();
    expect(captured.isAuthenticated).toBeTrue();
    expect(captured.user?.loginMethod).toBe('credential');
  });

  // ── login failure (non-OK response) ──
  it('login returns failure on non-OK API response', async () => {
    mockFetch({ error: 'Invalid credentials' }, 401);

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    let result: any;
    await act(async () => {
      result = await captured.login('EMP001', 'wrong');
    });

    expect(result.success).toBeFalse();
    expect(result.error).toContain('Invalid credentials');
  });

  // ── login network error ──
  it('login returns network error when fetch throws', async () => {
    const errorSpy = spyOn(console, 'error');
    spyOn(window, 'fetch').and.returnValue(Promise.reject(new Error('Network down')));

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    let result: any;
    await act(async () => {
      result = await captured.login('EMP001', 'x');
    });

    expect(result.success).toBeFalse();
    expect(result.error).toContain('Network error');
  });

  // ── logout clears user (credential login — no MSAL needed) ──
  it('logout clears user state for credential login', async () => {
    const validUser = {
      employeeNumber: 'EMP001', name: 'Test', accessToken: 'tok',
      tokenType: 'Bearer', entityId: '1', entityName: 'E',
      isTemporaryPassword: false, loginTimestamp: new Date().toISOString(),
      ntid: 'n', expiresIn: 3600, issuedAt: new Date().toISOString(),
      expiresAt: futureDate, loginMethod: 'credential',
    };
    sessionStorage.setItem('mybgsw_user', JSON.stringify(validUser));

    let captured: any;
    await act(async () => {
      render(
        <AuthProvider>
          <AuthCapture onCapture={(c) => { captured = c; }} />
        </AuthProvider>
      );
    });

    await act(async () => {
      await captured.logout();
    });

    expect(captured.isAuthenticated).toBeFalse();
    expect(captured.user).toBeNull();
  });
});
