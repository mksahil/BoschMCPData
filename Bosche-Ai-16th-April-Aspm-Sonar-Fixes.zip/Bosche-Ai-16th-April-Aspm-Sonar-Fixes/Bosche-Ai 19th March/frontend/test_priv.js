function isQueryAboutOtherPerson(query) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    const personalDataKeywords = ['travel', 'booking', 'trip', 'flight', 'hotel', 'itinerary', 'destination', 'booked', 'book', 'expense', 'settlement', 'reimbursement'];
    const hasPersonalData = personalDataKeywords.some(kw => q.includes(kw));
    if (!hasPersonalData) return false;

    const hasSelfRef = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i\sam)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i.test(q);

    // Bulk requests
    if (/\b(all\s+(?:travel|trip|booking|expense)|every\s*one|everybody|team\s+travel|who\s+(?:all\s+)?(?:travel|booked|went)|list\s+(?:all|every)|show\s+(?:all|every|each)\s+(?:employee|people|person|staff|member))\b/i.test(q)) {
      return { blocked: true, reason: 'bulk/collective request' };
    }

    if (hasColleagueWord) {
      return { blocked: true, reason: 'colleague word + travel data' };
    }

    if (/\b(his|her|their|them|him)\b/i.test(q)) {
      return { blocked: true, reason: 'third-person pronoun' };
    }

    // Possessive name: "Rahul's travel"
    const possessives = [...original.matchAll(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g)];
    if (possessives.length > 0) {
      return { blocked: true, reason: `possessive name: ${possessives[0][1]}` };
    }

    // "of/for <Name>"
    const safeTargets = new Set(['me','myself','today','yesterday','tomorrow','monday','tuesday','wednesday',
      'thursday','friday','saturday','sunday','week','month','year','bangalore','coimbatore','bosch','india',
      'delhi','mumbai','chennai','hyderabad','pune','kolkata','goa','business','personal','leisure',
      'official','work','home','office','free','approval','review','nothing','lunch','dinner','breakfast',
      'building','block','floor','zone','wing','cabin','cabins','workspace','workstation','room',
      'seat','desk','booking','march','april','may','june','july','august','september',
      'october','november','december','january','february','full','half','day','first','second',
      'raise','book','plan','create','cancel','modify','update','submit','apply','request',
      'snacks','snack','menu','food','canteen','bus','cab','train','stay','flight','hotel','trip',
      'return','oneway','roundtrip','travel','expense','settlement','reimbursement',
      'jan','feb','mar','apr','jun','jul','aug','sep','oct','nov','dec','the','same','dates','location','destination','coming','next','last','this','past','previous','current']);
    const ofForMatches = [...q.matchAll(/\b(?:of|for)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\b/gi)];
    for (const m of ofForMatches) {
      const nameLC = m[1].toLowerCase();
      const words = nameLC.split(/\s+/);
      const allSafe = words.every(w => safeTargets.has(w));
      if (!allSafe) {
        return { blocked: true, reason: `of/for name: ${m[1]}` };
      }
    }

    // Capitalized name near travel data (no self-ref)
    if (!hasSelfRef) {
      const nonNames = new Set(['the','what','when','where','how','show','get','tell','give','today',
        'yesterday','tomorrow','monday','tuesday','wednesday','thursday','friday','saturday','sunday',
        'january','february','march','april','may','june','july','august','september',
        'october','november','december','bangalore','coimbatore','india','bosch',
        'delhi','mumbai','chennai','hyderabad','pune','kolkata','goa',
        'week','month','year','total','average','please','thanks','hello','time','times',
        'travel','trip','flight','hotel','booking','booked','itinerary','destination','expense',
        'can','could','would','should','will','need','want','like','check','see','view','look',
        'all','any','some','this','that','these','those','last','next','first','second',
        'cancel','system','context','current','date','ist','settlement','reimbursement',
        'raise','book','plan','create','modify','update','submit','apply','request','display',
        'provide','retrieve','generate','calculate','summarize','return',
        'building','block','wing','cabin','cabins','workspace','room','floor','half',
        'snacks','snack','menu','food','canteen','bus','cab','train','stay','oneway','roundtrip',
        'jan','feb','mar','apr','jun','jul','aug','sep','oct','nov','dec',
        'detailed','complete','full','specific','exact','accurate','recent','comprehensive',
        'monthly','daily','weekly','annual','yearly','summary','period','range','between','during','coming']);
        
      const allCapNames = [...original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)];
      for (const m of allCapNames) {
        if (!nonNames.has(m[1].toLowerCase()) && m[1].length > 3) {
          return { blocked: true, reason: `capitalized name: ${m[1]}` };
        }
      }
    }

    return { blocked: false, reason: '' };
}

console.log(isQueryAboutOtherPerson("23rd april to 25th april from pune to Hyderabad travel mode is air and no accommodation required"));
