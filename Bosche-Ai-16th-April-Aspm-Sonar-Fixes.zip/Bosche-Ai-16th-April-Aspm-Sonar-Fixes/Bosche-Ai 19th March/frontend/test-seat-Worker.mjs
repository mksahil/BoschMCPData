import https from 'https';
import fs from 'fs';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-Worker',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-Worker',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-Worker' 
      },
      employee_id: '34835634',
      user_id: '34835634',
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      booking_mode: 'seat',
      travel_mode: 'seat',
      user_data: {
        employee_id: '34835634',
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      }
    }
  }
});

const options = {
  // USING THE URL FROM THE AGENT CARD
  hostname: 'seatbookingagent.thankfulground-23b51839.centralindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
};

console.log('Calling A2A Seat Booking Worker Agent (Direct)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-Worker.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-Worker.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
