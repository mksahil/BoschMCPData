// analytics-dashboard.ts - Real-time analytics calculations

interface SessionAnalytics {
  sessionId: string;
  startTime: Date;
  totalActions: number;
  pageViews: number;
  chatMessages: number;
  buttonClicks: number;
  activeDuration: number;
  mostVisitedPage: string;
  averageTimePerPage: number;
}

interface UserBehaviorMetrics {
  commonPaths: Array<{path: string[], count: number}>;
  peakActivityTimes: Array<{hour: number, count: number}>;
  popularFeatures: Array<{feature: string, count: number}>;
}

export class AnalyticsDashboard {
  private static instance: AnalyticsDashboard;
  
  private constructor() {}
  
  static getInstance(): AnalyticsDashboard {
    if (!this.instance) {
      this.instance = new AnalyticsDashboard();
    }
    return this.instance;
  }

  // Calculate session analytics
  calculateSessionAnalytics(logs: any[]): SessionAnalytics[] {
    const sessions = this.groupBySession(logs);
    
    return Object.entries(sessions).map(([sessionId, sessionLogs]) => {
      const startTime = new Date(sessionLogs[0].timestamp);
      const endTime = new Date(sessionLogs[sessionLogs.length - 1].timestamp);
      const duration = endTime.getTime() - startTime.getTime();
      
      const pageViews = sessionLogs.filter(log => log.action === 'page_view').length;
      const chatMessages = sessionLogs.filter(log => log.action === 'chat_message').length;
      const buttonClicks = sessionLogs.filter(log => log.action === 'button_click').length;
      
      const pageTimes = this.calculatePageTimes(sessionLogs);
      const mostVisited = this.getMostVisitedPage(sessionLogs);
      
      return {
        sessionId,
        startTime,
        totalActions: sessionLogs.length,
        pageViews,
        chatMessages,
        buttonClicks,
        activeDuration: duration,
        mostVisitedPage: mostVisited,
        averageTimePerPage: pageTimes.average
      };
    });
  }

  // Group logs by session
  private groupBySession(logs: any[]): Record<string, any[]> {
    return logs.reduce((acc, log) => {
      if (!acc[log.sessionId]) {
        acc[log.sessionId] = [];
      }
      acc[log.sessionId].push(log);
      return acc;
    }, {} as Record<string, any[]>);
  }

  // Calculate time spent on each page
  private calculatePageTimes(logs: any[]): {average: number, byPage: Record<string, number>} {
    const pageVisits: Record<string, number[]> = {};
    let lastPageView: any = null;
    
    logs.forEach(log => {
      if (log.action === 'page_view') {
        if (lastPageView) {
          const duration = new Date(log.timestamp).getTime() - new Date(lastPageView.timestamp).getTime();
          const page = lastPageView.page || 'unknown';
          
          if (!pageVisits[page]) pageVisits[page] = [];
          pageVisits[page].push(duration);
        }
        lastPageView = log;
      }
    });
    
    const allDurations = Object.values(pageVisits).flat();
    const average = allDurations.length > 0 
      ? allDurations.reduce((a, b) => a + b, 0) / allDurations.length 
      : 0;
    
    const byPage = Object.entries(pageVisits).reduce((acc, [page, durations]) => {
      acc[page] = durations.reduce((a, b) => a + b, 0) / durations.length;
      return acc;
    }, {} as Record<string, number>);
    
    return { average, byPage };
  }

  // Get most visited page
  private getMostVisitedPage(logs: any[]): string {
    const pageCounts: Record<string, number> = {};
    
    logs.filter(log => log.action === 'page_view').forEach(log => {
      const page = log.page || 'unknown';
      pageCounts[page] = (pageCounts[page] || 0) + 1;
    });
    
    return Object.entries(pageCounts).sort(([,a], [,b]) => b - a)[0]?.[0] || 'home';
  }


  // Find common navigation paths
  findCommonPaths(logs: any[], minLength: number = 3): Array<{path: string[], count: number}> {
    const sessions = this.groupBySession(logs);
    const paths: Record<string, number> = {};
    
    Object.values(sessions).forEach(sessionLogs => {
      const pageLogs = sessionLogs
        .filter(log => log.action === 'page_view')
        .map(log => log.page);
      
      // Extract paths of minimum length
      for (let i = 0; i <= pageLogs.length - minLength; i++) {
        const path = pageLogs.slice(i, i + minLength);
        const pathKey = path.join(' → ');
        paths[pathKey] = (paths[pathKey] || 0) + 1;
      }
    });
    
    return Object.entries(paths)
      .filter(([, count]) => count > 1)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([pathStr, count]) => ({
        path: pathStr.split(' → '),
        count
      }));
  }

  // Calculate peak activity times
  calculatePeakActivityTimes(logs: any[]): Array<{hour: number, count: number}> {
    const hourCounts: Record<number, number> = {};
    
    logs.forEach(log => {
      const hour = new Date(log.timestamp).getHours();
      hourCounts[hour] = (hourCounts[hour] || 0) + 1;
    });
    
    return Object.entries(hourCounts)
      .map(([hour, count]) => ({ hour: Number(hour), count }))
      .sort((a, b) => a.hour - b.hour);
  }

  // Get popular features
  getPopularFeatures(logs: any[]): Array<{feature: string, count: number}> {
    const featureCounts: Record<string, number> = {};
    
    logs
      .filter(log => log.action === 'feature_usage' || log.action === 'button_click')
      .forEach(log => {
        const feature = log.details?.featureName || log.details?.buttonText || 'Unknown';
        featureCounts[feature] = (featureCounts[feature] || 0) + 1;
      });
    
    return Object.entries(featureCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 20)
      .map(([feature, count]) => ({ feature, count }));
  }

  // Export analytics report
  generateReport(logs: any[]): {
    summary: any;
    sessions: SessionAnalytics[];
    behavior: UserBehaviorMetrics;
  } {
    const sessions = this.calculateSessionAnalytics(logs);
    
    const summary = {
      totalSessions: sessions.length,
      totalActions: logs.length,
      averageSessionDuration: sessions.reduce((acc, s) => acc + s.activeDuration, 0) / sessions.length,
      averageActionsPerSession: logs.length / sessions.length,
      uniquePages: new Set(logs.filter(l => l.action === 'page_view').map(l => l.page)).size,
      totalChatMessages: logs.filter(l => l.action === 'chat_message').length,
      totalButtonClicks: logs.filter(l => l.action === 'button_click').length
    };
    
    const behavior: UserBehaviorMetrics = {
      commonPaths: this.findCommonPaths(logs),
      peakActivityTimes: this.calculatePeakActivityTimes(logs),
      popularFeatures: this.getPopularFeatures(logs)
    };
    
    return { summary, sessions, behavior };
  }
}

export default AnalyticsDashboard.getInstance();
