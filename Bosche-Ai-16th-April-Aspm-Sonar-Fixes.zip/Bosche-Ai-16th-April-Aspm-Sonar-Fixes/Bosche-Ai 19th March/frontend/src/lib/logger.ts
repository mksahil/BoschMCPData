// logger.ts - Comprehensive logging utility for user activities

import { API_ENDPOINTS } from '@/config';

interface LogDetails {
  [key: string]: any;
}

interface LogEntry {
  sessionId: string;
  timestamp: string;
  action: string;
  page: string;
  details?: LogDetails;
}

export class Logger {
  private static instance: Logger;
  private sessionId: string;
  private logQueue: LogEntry[] = [];
  private isOnline: boolean = navigator.onLine;
  private apiUrl: string = API_ENDPOINTS.logs;

  constructor() {
    this.sessionId = this.getOrCreateSessionId();
    this.setupEventListeners();
    this.flushLogsIfOnline();
  }

  // Generate or retrieve session ID
  private getOrCreateSessionId(): string {
    let sessionId = sessionStorage.getItem('sessionId');
    if (!sessionId) {
      sessionId = `emp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('sessionId', sessionId);
      sessionStorage.setItem('sessionStartTime', new Date().toISOString());
    }
    return sessionId;
  }

  // Setup global event listeners
  private setupEventListeners(): void {
    // Network status
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.flushLogsIfOnline();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
    });

    // Page unload - try to send remaining logs
    window.addEventListener('beforeunload', () => {
      this.flushLogsSync();
    });
  }

  // Main logging method
  public log(action: string, details?: LogDetails): void {
    // Filter out unwanted events
    const blockedActions = ['mouse_activity', 'scroll_behavior', 'hover_event', 'scroll_depth'];
    if (blockedActions.includes(action)) {
      return; // Don't log these events
    }

    const logEntry: LogEntry = {
      sessionId: this.sessionId,
      timestamp: new Date().toISOString(),
      action,
      page: window.location.pathname,
      details: {
        ...details,
        userAgent: navigator.userAgent,
        screenResolution: `${window.screen.width}x${window.screen.height}`,
        windowSize: `${window.innerWidth}x${window.innerHeight}`
      }
    };

    if (this.isOnline) {
      this.sendLog(logEntry);
    } else {
      this.queueLog(logEntry);
    }
  }

  // Send log to server
  private async sendLog(logEntry: LogEntry): Promise<void> {
    try {
      await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(logEntry),
      });
    } catch (error) {
      console.error('Failed to send log:', error);
      this.queueLog(logEntry);
    }
  }

  // Queue log for later sending
  private queueLog(logEntry: LogEntry): void {
    this.logQueue.push(logEntry);
    sessionStorage.setItem('logQueue', JSON.stringify(this.logQueue));
  }

  // Flush queued logs when online
  private async flushLogsIfOnline(): Promise<void> {
    if (!this.isOnline) return;

    const savedQueue = sessionStorage.getItem('logQueue');
    if (savedQueue) {
      this.logQueue = JSON.parse(savedQueue);
    }

    for (const log of this.logQueue) {
      await this.sendLog(log);
    }

    this.logQueue = [];
    sessionStorage.removeItem('logQueue');
  }

  // Synchronous flush for page unload
  private flushLogsSync(): void {
    if (this.logQueue.length === 0) return;

    const blob = new Blob([JSON.stringify(this.logQueue)], { type: 'application/json' });
    navigator.sendBeacon(this.apiUrl + '/batch', blob);
  }

  // Specific logging methods
  public logPageView(pageName: string, metadata?: LogDetails): void {
    this.log('page_view', { pageName, ...metadata });
  }

  public logButtonClick(buttonId: string, buttonText: string, metadata?: LogDetails): void {
    this.log('button_click', { buttonId, buttonText, ...metadata });
  }

  public logChatMessage(message: string, isUserMessage: boolean, metadata?: LogDetails): void {
    this.log('chat_message', { 
      message, 
      isUserMessage, 
      messageLength: message.length,
      ...metadata 
    });
  }

  public logFormSubmit(formId: string, formData: any, metadata?: LogDetails): void {
    this.log('form_submit', { 
      formId, 
      fieldCount: Object.keys(formData).length,
      ...metadata 
    });
  }

  public logError(error: Error, context: string, metadata?: LogDetails): void {
    this.log('error', { 
      errorMessage: error.message,
      errorStack: error.stack,
      context,
      ...metadata 
    });
  }

  public logFeatureUsage(featureName: string, metadata?: LogDetails): void {
    this.log('feature_usage', { featureName, ...metadata });
  }

  public logSearch(searchQuery: string, resultsCount: number, metadata?: LogDetails): void {
    this.log('search', { 
      searchQuery, 
      resultsCount,
      queryLength: searchQuery.length,
      ...metadata 
    });
  }

  public logNavigation(from: string, to: string, metadata?: LogDetails): void {
    this.log('navigation', { from, to, ...metadata });
  }

  // Get session info
  public getSessionInfo(): { sessionId: string; startTime: string | null } {
    return {
      sessionId: this.sessionId,
      startTime: sessionStorage.getItem('sessionStartTime')
    };
  }
}

// Create singleton instance
const logger = new Logger();

export default logger;
export type { LogDetails, LogEntry };
