import { useState } from 'react';
import { performSSO, logoutAzureAD } from '@/services/azureAuthService';

interface UseAzureSSOLoginReturn {
  ssoLogin: () => Promise<{ success: boolean; data?: any; error?: string }>;
  ssoLogout: () => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

/**
 * Custom hook for Azure AD SSO login flow
 * Handles the complete flow: Azure AD login → Token exchange → Arena token
 */
export const useAzureSSOLogin = (): UseAzureSSOLoginReturn => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ssoLogin = async (): Promise<{
    success: boolean;
    data?: any;
    error?: string;
  }> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('Starting SSO login flow...');
      const arenaTokenData = await performSSO();

      // Redirect flow may navigate away before token exchange can happen in this cycle.
      if (!arenaTokenData) {
        return {
          success: true,
        };
      }

      if (!arenaTokenData) {
        throw new Error('No token data received from exchange');
      }

      console.log('SSO login successful');
      return {
        success: true,
        data: arenaTokenData,
      };
    } catch (err: any) {
      const errorMessage =
        err?.message || 'SSO login failed. Please try again.';
      console.error('SSO login error:', errorMessage);
      setError(errorMessage);

      return {
        success: false,
        error: errorMessage,
      };
    } finally {
      setIsLoading(false);
    }
  };

  const ssoLogout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      await logoutAzureAD();
      console.log('SSO logout successful');
    } catch (err: any) {
      const errorMessage =
        err?.message || 'SSO logout failed. Please try again.';
      console.error('SSO logout error:', errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    ssoLogin,
    ssoLogout,
    isLoading,
    error,
  };
};
