import { useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import logger from '../lib/logger';

// Hook for automatic logging in components
export const useLogger = (componentName: string) => {
  const location = useLocation();
  const navigate = useNavigate();

  // Log page view on mount
  useEffect(() => {
    logger.logPageView(componentName, {
      path: location.pathname,
      search: location.search,
    });
  }, [componentName, location]);

  // Wrapped navigation function that logs
  const loggedNavigate = useCallback((to: string | number) => {
    if (typeof to === 'string') {
      logger.logNavigation(location.pathname, to);
    }
    navigate(to as any);
  }, [location.pathname, navigate]);

  // Click handler wrapper
  const logClick = useCallback((
    elementId: string,
    elementText: string,
    onClick?: () => void,
    metadata?: any
  ) => {
    return (event: React.MouseEvent) => {
      logger.logButtonClick(elementId, elementText, {
        ...metadata,
        timestamp: new Date().toISOString(),
      });
      if (onClick) onClick(event);
    };
  }, []);

  // Input change logger
  const logInputChange = useCallback((
    inputId: string,
    inputType: string,
    metadata?: any
  ) => {
    return (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      logger.log('input_change', {
        inputId,
        inputType,
        valueLength: event.target.value.length,
        ...metadata,
      });
    };
  }, []);

  return {
    logClick,
    logInputChange,
    loggedNavigate,
    logger,
  };
};

// HOC for automatic component logging
export const withLogging = <P extends object>(
  Component: React.ComponentType<P>,
  componentName: string
) => {
  return (props: P) => {
    useLogger(componentName);
    return <Component {...props} />;
  };
};
