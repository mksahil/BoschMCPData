import { Coffee, UtensilsCrossed, Moon } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { API_ENDPOINTS } from "@/config";

interface MenuData {
  breakfast: string;
  lunch: string;
  snacks: string;
}

export const CafeteriaCard = () => {
  const [loading, setLoading] = useState(false);
  const [menuData, setMenuData] = useState<MenuData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null);

  useEffect(() => {
    // Don't auto-fetch menu, wait for location selection
    if (selectedLocation !== null) {
      fetchTodaysMenu(selectedLocation);
    }
  }, [selectedLocation]);

  const fetchTodaysMenu = async (locationId: number) => {
    try {
      setLoading(true);
      setError(null);

      // Get user from sessionStorage for auth
      const storedUser = sessionStorage.getItem('mybgsw_user');
      const userData = storedUser ? JSON.parse(storedUser) : null;

      const response = await fetch(API_ENDPOINTS.canteenQuery, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': userData?.accessToken ? `Bearer ${userData.accessToken}` : '',
          'X-Employee-Number': userData?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: "today's menu",
          locationId: locationId,
          employeeNumber: userData?.employeeNumber || ''
        })
      });

      const data = await response.json();

      if (response.ok) {
        if (data.menuData) {
          // Use the structured menu data directly from backend
          setMenuData(data.menuData);
        } else if (data.success && data.response) {
          // Check if the response indicates no menu is available
          const responseText = data.response.toLowerCase();
          if (responseText.includes('no menu found') ||
            responseText.includes('menu not available') ||
            responseText.includes("isn't available") ||
            responseText.includes('not available') ||
            responseText.includes('not found') ||
            responseText.includes('no data') ||
            responseText.includes('not published')) {
            setError("Menu not updated for today");
          } else {
            // Fallback: Try to parse from natural language response
            const parsed = parseMenuFromResponse(data.response);
            if (parsed) {
              setMenuData(parsed);
            } else {
              setError("Menu not updated for today");
            }
          }
        } else {
          setError(data.error || "Menu not updated for today");
        }
      } else {
        setError(data.error || "Menu not updated for today");
      }
    } catch (err) {
      console.error('Failed to fetch menu:', err);
      setError("Failed to fetch menu");
    } finally {
      setLoading(false);
    }
  };

  const parseMenuFromResponse = (response: string): MenuData | null => {
    // Extract menu items from the natural language response
    // Look for patterns like "Breakfast:", "Lunch:", "Snacks:"
    const lines = response.split('\n');
    const menu: Partial<MenuData> = {};

    for (const line of lines) {
      // More flexible matching for breakfast
      if (line.toLowerCase().includes('breakfast')) {
        const match = line.match(/(?:breakfast)[:\s]*(.+)/i);
        if (match) menu.breakfast = match[1].replace(/\*+/g, '').trim();
      }
      // More flexible matching for lunch
      else if (line.toLowerCase().includes('lunch')) {
        const match = line.match(/(?:lunch)[:\s]*(.+)/i);
        if (match) menu.lunch = match[1].replace(/\*+/g, '').trim();
      }
      // More flexible matching for snacks
      else if (line.toLowerCase().includes('snack')) {
        const match = line.match(/(?:snacks?)[:\s]*(.+)/i);
        if (match) menu.snacks = match[1].replace(/\*+/g, '').trim();
      }
    }

    // Check if we found any menu items
    if (menu.breakfast || menu.lunch || menu.snacks) {
      // Default empty strings for missing meals
      return {
        breakfast: menu.breakfast || "No breakfast service",
        lunch: menu.lunch || "No lunch service",
        snacks: menu.snacks || "No snacks service"
      };
    }

    return null;
  };

  const parseMenuItems = (menuString: string): string[] => {
    if (!menuString || menuString === "No breakfast service" ||
      menuString === "No lunch service" || menuString === "No snacks service") {
      return [];
    }
    // Split by comma and clean up each item
    return menuString.split(',').map(item => item.trim()).filter(item => item);
  };

  // Show location selection if no location is selected
  if (selectedLocation === null) {
    return (
      <DashboardCard title="Today's Menu" icon={UtensilsCrossed}>
        <div className="flex flex-col items-center justify-center h-64 space-y-6">
          <p className="text-lg font-semibold text-foreground">Select Your Location</p>
          <div className="flex gap-4">
            <button
              onClick={() => setSelectedLocation(1)}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Bangalore
            </button>
            <button
              onClick={() => setSelectedLocation(2)}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Coimbatore
            </button>
          </div>
        </div>
      </DashboardCard>
    );
  }

  if (loading) {
    return (
      <DashboardCard title="Today's Menu" icon={UtensilsCrossed}>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
      </DashboardCard>
    );
  }

  if (error || !menuData) {
    const locationName = selectedLocation === 1 ? "Bangalore" : "Coimbatore";
    return (
      <DashboardCard title={`Today's Menu - ${locationName}`} icon={UtensilsCrossed}>
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <p className="text-muted-foreground">{error || "Menu not available"}</p>
          <div className="flex gap-4">
            <button
              onClick={() => fetchTodaysMenu(selectedLocation)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm"
            >
              Retry
            </button>
            <button
              onClick={() => {
                setSelectedLocation(null);
                setMenuData(null);
                setError(null);
              }}
              className="px-4 py-2 bg-secondary text-foreground rounded-lg hover:bg-secondary/80 transition-colors text-sm"
            >
              Change Location
            </button>
          </div>
        </div>
      </DashboardCard>
    );
  }

  const locationName = selectedLocation === 1 ? "Bangalore" : "Coimbatore";

  return (
    <DashboardCard
      title={`Today's Menu - ${locationName}`}
      icon={UtensilsCrossed}
      action={
        <button
          onClick={() => {
            setSelectedLocation(null);
            setMenuData(null);
            setError(null);
          }}
          className="text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          Change Location
        </button>
      }
    >
      <div className="space-y-4">
        {/* Breakfast */}
        <div className="p-3 bg-secondary rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Coffee className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Breakfast (7:30 - 9:30 AM)</h4>
          </div>
          <ul className="text-xs text-muted-foreground space-y-1 ml-6">
            {parseMenuItems(menuData.breakfast).length > 0 ? (
              parseMenuItems(menuData.breakfast).map((item, index) => (
                <li key={index}>• {item}</li>
              ))
            ) : (
              <li className="text-muted-foreground/60">No breakfast menu available</li>
            )}
          </ul>

        </div>

        {/* Lunch */}
        <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <UtensilsCrossed className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Lunch (12:30 - 2:30 PM)</h4>
          </div>
          <ul className="text-xs text-muted-foreground space-y-1 ml-6">
            {parseMenuItems(menuData.lunch).length > 0 ? (
              parseMenuItems(menuData.lunch).map((item, index) => (
                <li key={index}>• {item}</li>
              ))
            ) : (
              <li className="text-muted-foreground/60">No lunch menu available</li>
            )}
          </ul>

        </div>

        {/* Snacks */}
        <div className="p-3 bg-secondary rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Coffee className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Snacks (4:00 - 6:00 PM)</h4>
          </div>
          <ul className="text-xs text-muted-foreground space-y-1 ml-6">
            {parseMenuItems(menuData.snacks).length > 0 ? (
              parseMenuItems(menuData.snacks).map((item, index) => (
                <li key={index}>• {item}</li>
              ))
            ) : (
              <li className="text-muted-foreground/60">No snacks menu available</li>
            )}
          </ul>

        </div>

      </div>
    </DashboardCard>
  );
};
