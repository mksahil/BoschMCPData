import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";

interface ActionCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onClick?: () => void;
}

export const ActionCard = ({ icon: Icon, title, description, onClick }: ActionCardProps) => {
  return (
    <button
      onClick={() => {
        logger.logButtonClick(`action-card-${title.toLowerCase().replace(/\s+/g, '-')}`, title, {
          description,
          timestamp: new Date().toISOString()
        });
        onClick?.();
      }}
      className={cn(
        "w-full text-left p-4 rounded-lg border border-border bg-card",
        "hover:border-primary hover:bg-gradient-subtle transition-all duration-300",
        "hover:shadow-elevated group"
      )}
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-secondary group-hover:bg-gradient-primary rounded-lg flex items-center justify-center transition-all duration-300 group-hover:shadow-glow">
          <Icon className="w-5 h-5 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-foreground mb-1">{title}</h4>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
    </button>
  );
};
