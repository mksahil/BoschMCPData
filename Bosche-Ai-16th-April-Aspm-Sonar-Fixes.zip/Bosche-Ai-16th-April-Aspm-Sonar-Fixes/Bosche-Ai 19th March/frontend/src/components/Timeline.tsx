import { Calendar, Clock, TrendingUp, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface TimelineItem {
  id: string;
  time: string;
  title: string;
  type: "meeting" | "task" | "reminder" | "success";
  priority?: "high" | "medium" | "low";
}

const todaySchedule: TimelineItem[] = [
  { id: "1", time: "8:30 AM", title: "Shuttle to Office", type: "reminder", priority: "medium" },
  { id: "2", time: "9:30 AM", title: "Team Standup", type: "meeting", priority: "high" },
  { id: "3", time: "11:00 AM", title: "Submit BoB Bills", type: "task", priority: "high" },
  { id: "4", time: "2:00 PM", title: "Project Review", type: "meeting", priority: "medium" },
  { id: "5", time: "4:30 PM", title: "1:1 with Manager", type: "meeting", priority: "high" },
];

const pendingActions = [
  { id: "1", title: "Complete Effort Booking (37/42 hrs)", priority: "high" },
  { id: "2", title: "Submit Fuel Bill (₹2,400)", priority: "high" },
  { id: "3", title: "Review JKL Course", priority: "medium" },
];

export const Timeline = () => {
  return (
    <div className="w-80 bg-card border-r border-border h-[calc(100vh-4rem)] overflow-y-auto overflow-x-hidden">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-xl font-bold text-foreground mb-2">My Timeline</h2>
          <p className="text-sm text-muted-foreground">Your personalized day planner</p>
        </div>

        {/* Today's Schedule */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Today's Schedule</h3>
          </div>
          <div className="space-y-3">
            {todaySchedule.map((item, index) => (
              <div
                key={item.id}
                className={cn(
                  "relative pl-6 pb-3",
                  index !== todaySchedule.length - 1 && "border-l-2 border-border"
                )}
              >
                <div className="absolute left-0 top-0 -translate-x-1/2">
                  <div className={cn(
                    "w-3 h-3 rounded-full",
                    item.priority === "high" ? "bg-primary ring-4 ring-primary/20" :
                    item.priority === "medium" ? "bg-accent ring-4 ring-accent/20" :
                    "bg-muted-foreground ring-4 ring-muted/20"
                  )}></div>
                </div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">{item.time}</p>
                    <p className="text-sm font-medium text-foreground">{item.title}</p>
                  </div>
                  {item.type === "meeting" && (
                    <Clock className="w-4 h-4 text-primary flex-shrink-0" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Actions */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-5 h-5 text-destructive" />
            <h3 className="font-semibold text-foreground">Pending Actions</h3>
          </div>
          <div className="space-y-2">
            {pendingActions.map((action) => (
              <div
                key={action.id}
                className="p-3 rounded-lg bg-secondary hover:bg-primary/10 transition-colors duration-200 cursor-pointer group"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-200 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">{action.title}</p>
                    {action.priority === "high" && (
                      <span className="text-xs text-destructive font-medium">Urgent</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Smart Nudges */}
        <div className="p-4 rounded-lg bg-gradient-primary/10 border border-primary/20">
          <div className="flex items-start gap-2">
            <TrendingUp className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-primary mb-1">AI Nudge</p>
              <p className="text-sm text-foreground">
                You're 5 hrs short this week. Auto-fill effort for Friday?
              </p>
              <div className="flex gap-2 mt-2">
                <button className="text-xs px-3 py-1 bg-primary text-primary-foreground rounded-md hover:bg-primary-light transition-colors">
                  Yes, do it
                </button>
                <button className="text-xs px-3 py-1 bg-secondary text-foreground rounded-md hover:bg-muted transition-colors">
                  Later
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
