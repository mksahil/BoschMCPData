import { useState, useRef, useEffect } from "react";
import { Plane, Send, Sparkles } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { API_ENDPOINTS } from "@/config";
import { useAuth } from "@/context/AuthContext";
import { cn, generateUUID, renderMarkdown } from "@/lib/utils";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export const TravelCard = () => {
  const { user } = useAuth();
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Hi! I'm your AI Travel Assistant. I can help you with:\n\n• Plan business trips and book travel\n• Check travel expense status\n• Submit settlement for completed trips\n• View travel history and upcoming trips\n\nWhat would you like to do today?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => `travel-${generateUUID()}`);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSendMessage = async () => {
    if (!chatInput.trim() || isLoading) return;

    const userMessage = chatInput.trim();
    setChatMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setChatInput("");
    setIsLoading(true);

    // Build conversation history for context
    const conversationHistory = chatMessages.slice(1).map(msg => ({
      role: msg.role,
      content: `travel: ${msg.content}` // Prefix both user and assistant
    }));

    try {
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: `travel: I am providing details for my own travel booking: ${userMessage}`,
          service: "travel", // Explicit service hint
          sessionId,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name || '',
          conversationHistory
        })
      });

      const data = await response.json();
      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: data.response || "I couldn't process that request. Please try again." 
      }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: "Sorry, I'm having trouble connecting. Please try again." 
      }]);
    }

    setIsLoading(false);
  };

  return (
    <DashboardCard title="Business Travel" icon={Plane}>
      <div className="space-y-4">
        {/* AI Chat Interface */}
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-foreground">AI Travel Assistant</span>
        </div>

        {/* Chat Messages */}
        <div className="h-48 overflow-y-auto space-y-2 p-2 bg-secondary/50 rounded-lg">
          {chatMessages.map((msg, idx) => (
            <div key={idx} className={cn(
              "text-xs p-2 rounded-lg max-w-[85%]",
              msg.role === "user" 
                ? "bg-primary text-primary-foreground ml-auto" 
                : "bg-card text-foreground"
            )}>
              <p className="whitespace-pre-line" dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />
            </div>
          ))}
          {isLoading && (
            <div className="bg-card text-foreground text-xs p-2 rounded-lg max-w-[85%]">
              <span className="animate-pulse">Thinking...</span>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Chat Input */}
        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask about travel..."
            className="flex-1 px-3 py-2 text-xs bg-secondary rounded-lg border border-border focus:outline-none focus:ring-1 focus:ring-primary"
            disabled={isLoading}
          />
          <button
            onClick={handleSendMessage}
            disabled={!chatInput.trim() || isLoading}
            className="p-2 bg-gradient-primary text-primary-foreground rounded-lg disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </DashboardCard>
  );
};
