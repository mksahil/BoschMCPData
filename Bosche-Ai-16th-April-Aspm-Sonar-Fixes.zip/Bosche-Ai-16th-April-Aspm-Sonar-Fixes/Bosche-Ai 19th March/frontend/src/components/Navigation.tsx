import { Home, Lightbulb, Zap, Users, GraduationCap, Heart, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { DarkModeToggle } from "./DarkModeToggle";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

interface NavigationProps {
  activeSection?: string;
  onSectionChange?: (section: string) => void;
  contextTitle?: string;
}

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "insights", label: "Insights", icon: Lightbulb },
  { id: "actions", label: "Actions", icon: Zap },
  { id: "mentorship", label: "Mentorship", icon: Users },
  { id: "learning", label: "Learning", icon: GraduationCap },
  { id: "wellness", label: "Wellness", icon: Heart },
];

export const Navigation = ({ activeSection = "home", onSectionChange, contextTitle }: NavigationProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Get initials from name or employee number
  const getInitials = () => {
    if (user?.name && user.name.trim()) {
      const names = user.name.trim().split(' ');
      if (names.length >= 2) {
        return `${names[0][0]}${names[1][0]}`.toUpperCase();
      }
      return names[0].substring(0, 2).toUpperCase();
    }
    return user?.employeeNumber?.substring(0, 2) || 'U';
  };

  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border shadow-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-3">
              <img src="/bgsw-logo.png" alt="MyBGSW Logo" className="w-10 h-10 object-contain" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">
                {contextTitle || "MyBGSW.Ai"}
              </h1>
              <p className="text-xs text-muted-foreground">Your AI Companion</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange?.(item.id)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300",
                    isActive
                      ? "bg-primary text-primary-foreground shadow-elevated"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-4">
            {/* Employee Number Badge */}
            {user && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-full">
                <span className="text-xs font-medium text-primary">
                  ID: {user.employeeNumber}
                </span>
              </div>
            )}

            <DarkModeToggle />

            {/* User Menu Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-10 h-10 bg-gradient-accent rounded-full flex items-center justify-center cursor-pointer hover:shadow-glow transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  <span className="text-accent-foreground font-semibold text-sm">
                    {getInitials()}
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span className="font-semibold">
                      {user?.name?.trim() || 'User'}
                    </span>
                    <span className="text-xs text-muted-foreground font-normal">
                      Employee: {user?.employeeNumber}
                    </span>
                    {user?.entityName && (
                      <span className="text-xs text-muted-foreground font-normal">
                        Entity: {user.entityName}
                      </span>
                    )}
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleLogout}
                  className="text-destructive focus:text-destructive cursor-pointer"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Bosch Rainbow Border */}
      <div className="w-full h-1.5 relative overflow-hidden">
        <img
          src="/bosch-rainbow.svg"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>
    </nav>
  );
};
