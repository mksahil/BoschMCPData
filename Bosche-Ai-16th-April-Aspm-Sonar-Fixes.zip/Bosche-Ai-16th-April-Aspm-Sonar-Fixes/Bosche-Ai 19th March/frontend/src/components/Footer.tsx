export const Footer = () => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 z-50 w-full py-4 px-4 border-t border-border bg-card/80 backdrop-blur-sm">
      <div className="container mx-auto">
        <p className="text-center text-xs text-muted-foreground">
          Inside myBGSW page Process Owner - BGSW/BDO. Brought to you by BD/APA-IN
        </p>
      </div>
    </footer>
  );
};
