import { Calendar, Clock } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const MeetingsCard = () => {
  return (
    <DashboardCard title="Meetings Today" icon={Calendar}>
      <div className="space-y-3">
        <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-foreground">Team Standup</h4>
            <span className="text-xs px-2 py-1 bg-primary/20 text-primary rounded-full flex items-center gap-1">
              <Clock className="w-3 h-3" />
              9:30 AM
            </span>
          </div>
          <p className="text-xs text-muted-foreground">Daily sync with engineering team</p>
          <p className="text-xs text-accent mt-1">📍 Conference Room A</p>
        </div>
        <div className="p-3 bg-secondary rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-foreground">Project Review</h4>
            <span className="text-xs px-2 py-1 bg-secondary text-muted-foreground rounded-full flex items-center gap-1">
              <Clock className="w-3 h-3" />
              2:00 PM
            </span>
          </div>
          <p className="text-xs text-muted-foreground">Q4 milestone discussion</p>
          <p className="text-xs text-accent mt-1">📍 Virtual - Teams</p>
        </div>
        <div className="p-3 bg-secondary rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-foreground">1:1 with Manager</h4>
            <span className="text-xs px-2 py-1 bg-secondary text-muted-foreground rounded-full flex items-center gap-1">
              <Clock className="w-3 h-3" />
              4:30 PM
            </span>
          </div>
          <p className="text-xs text-muted-foreground">Career development talk</p>
          <p className="text-xs text-accent mt-1">📍 Manager's Office</p>
        </div>
      </div>
    </DashboardCard>
  );
};
