import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import {
  User, Sparkles, DollarSign, Briefcase, BookOpen, Coffee, Plane, FileText,
  Calendar, Award, MessageSquare, GraduationCap, Music, Armchair, Phone,
  LogIn, Gift, Dumbbell, Navigation as NavigationIcon, Car, Eye, Megaphone, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";
import { BoBCard } from "./BoBCard";
import { LeaveCard } from "./LeaveCard";
import { EffortBookingCard } from "./EffortBookingCard";
import { JKLCard } from "./JKLCard";
import { TravelCard } from "./TravelCard";
import { CafeteriaCard } from "./CafeteriaCard";
import { PayslipCard } from "./PayslipCard";
import { ProjectsCard } from "./ProjectsCard";
import { MeetingsCard } from "./MeetingsCard";
import { CoursesCard } from "./CoursesCard";
import { CertificationsCard } from "./CertificationsCard";
import { CommunityCard } from "./CommunityCard";
import { MusicCard } from "./MusicCard";
import { SeatBookingCard } from "./SeatBookingCard";
import { VitalContactsCard } from "./VitalContactsCard";
import { EntryExitCard } from "./EntryExitCard";
import { HolidayCalendarCard } from "./HolidayCalendarCard";
import { GymCard } from "./GymCard";
import { WayFinderCard } from "./WayFinderCard";
import { BlogsCard } from "./BlogsCard";
import { ParkingCard } from "./ParkingCard";
import { WatchlistCard } from "./WatchlistCard";
import { BannersCard } from "./BannersCard";

interface Planet {
  id: string;
  name: string;
  color: string;
  size: number;
  orbitRadius: number;
  orbitDuration: number;
  angle: number;
  icon: any;
}

const planets: Planet[] = [
  // Inner Orbit - Finance & Benefits (4 planets)
  { id: 'bob', name: 'Benefits', color: 'hsl(205 100% 40%)', size: 60, orbitRadius: 220, orbitDuration: 20, angle: 0, icon: DollarSign },
  { id: 'payslip', name: 'Payslip', color: 'hsl(280 70% 50%)', size: 55, orbitRadius: 220, orbitDuration: 20, angle: 180, icon: FileText },
  { id: 'cafeteria', name: 'Cafeteria', color: '#fe0000', size: 55, orbitRadius: 220, orbitDuration: 20, angle: 90, icon: Coffee },

  // Second Orbit - Work & Productivity (6 planets)
  { id: 'effort', name: 'Effort', color: 'hsl(142 76% 45%)', size: 58, orbitRadius: 300, orbitDuration: 28, angle: 0, icon: Briefcase },
  { id: 'projects', name: 'Projects', color: 'hsl(30 85% 50%)', size: 56, orbitRadius: 300, orbitDuration: 28, angle: 60, icon: Briefcase },
  { id: 'meetings', name: 'Meetings', color: 'hsl(200 75% 50%)', size: 54, orbitRadius: 300, orbitDuration: 28, angle: 120, icon: Calendar },
  { id: 'travel', name: 'Travel', color: 'hsl(60 85% 50%)', size: 52, orbitRadius: 300, orbitDuration: 28, angle: 180, icon: Plane },
  { id: 'entryexit', name: 'Entry/Exit', color: 'hsl(160 75% 50%)', size: 50, orbitRadius: 300, orbitDuration: 28, angle: 240, icon: LogIn },
  { id: 'parking', name: 'Parking', color: 'hsl(240 75% 55%)', size: 48, orbitRadius: 300, orbitDuration: 28, angle: 300, icon: Car },

  // Third Orbit - Learning & Personal (6 planets)
  { id: 'jkl', name: 'JKL', color: 'hsl(260 80% 55%)', size: 60, orbitRadius: 380, orbitDuration: 36, angle: 0, icon: GraduationCap },
  { id: 'courses', name: 'Courses', color: 'hsl(320 75% 55%)', size: 56, orbitRadius: 380, orbitDuration: 36, angle: 60, icon: BookOpen },
  { id: 'certifications', name: 'Badges', color: 'hsl(40 90% 55%)', size: 54, orbitRadius: 380, orbitDuration: 36, angle: 120, icon: Award },
  { id: 'blogs', name: 'Blogs', color: 'hsl(100 70% 50%)', size: 52, orbitRadius: 380, orbitDuration: 36, angle: 180, icon: FileText },
  { id: 'watchlist', name: 'Watchlist', color: 'hsl(180 75% 50%)', size: 50, orbitRadius: 380, orbitDuration: 36, angle: 240, icon: Eye },
  { id: 'music', name: 'Music', color: 'hsl(340 80% 55%)', size: 48, orbitRadius: 380, orbitDuration: 36, angle: 300, icon: Music },

  // Outer Orbit - Facilities & Wellness (6 planets)
  { id: 'seatbooking', name: 'Seat', color: 'hsl(220 75% 55%)', size: 58, orbitRadius: 460, orbitDuration: 44, angle: 0, icon: Armchair },
  { id: 'gym', name: 'Gym', color: 'hsl(10 80% 55%)', size: 56, orbitRadius: 460, orbitDuration: 44, angle: 60, icon: Dumbbell },
  { id: 'community', name: 'Community', color: 'hsl(160 70% 50%)', size: 54, orbitRadius: 460, orbitDuration: 44, angle: 120, icon: MessageSquare },
  { id: 'wayfinder', name: 'WayFinder', color: 'hsl(120 70% 50%)', size: 52, orbitRadius: 460, orbitDuration: 44, angle: 180, icon: NavigationIcon },
  { id: 'holidays', name: 'Holidays', color: 'hsl(280 75% 55%)', size: 50, orbitRadius: 460, orbitDuration: 44, angle: 240, icon: Gift },
  { id: 'banner', name: 'News/Snippets', color: 'hsl(20 85% 55%)', size: 48, orbitRadius: 460, orbitDuration: 44, angle: 300, icon: Megaphone },
];

export const SolarSystem = ({ isShifted = false, onPlanetSelect }: { isShifted?: boolean; onPlanetSelect?: () => void }) => {
  const { user } = useAuth();
  const [selectedPlanet, setSelectedPlanet] = useState<string | null>(null);
  const [planetAngles, setPlanetAngles] = useState<{ [key: string]: number }>({});
  const [isHovered, setIsHovered] = useState(false);
  const [activePlanets, setActivePlanets] = useState<string[]>([]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await fetch('http://localhost:3001/api/services');
        const data = await response.json();
        if (data.services) {
          const activeIds = data.services.map((s: any) => s.id);
          setActivePlanets(activeIds);
        }
      } catch (error) {
        console.error("Failed to fetch services:", error);
        setActivePlanets(['cafeteria', 'entryexit', 'community', 'travel', 'seatbooking', 'banner']);
      }
    };
    fetchServices();
  }, []);

  const displayName = user?.name || `Employee ${user?.employeeNumber || ''}`;
  const employeeId = user?.employeeNumber || '';
  const entityName = user?.entityName || 'Bosch';

  useEffect(() => {
    const initialAngles: { [key: string]: number } = {};
    planets.forEach(planet => {
      initialAngles[planet.id] = planet.angle;
    });
    setPlanetAngles(initialAngles);
  }, []);

  useEffect(() => {
    if (selectedPlanet || isHovered) return;

    const interval = setInterval(() => {
      setPlanetAngles(prev => {
        const newAngles = { ...prev };
        planets.forEach(planet => {
          newAngles[planet.id] = (prev[planet.id] || planet.angle) + (360 / (planet.orbitDuration * 60));
        });
        return newAngles;
      });
    }, 1000 / 60);

    return () => clearInterval(interval);
  }, [selectedPlanet, isHovered]);

  // Lock background scroll when a planet popup is open
  useEffect(() => {
    if (selectedPlanet) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedPlanet]);

  const renderPlanetCard = () => {
    switch (selectedPlanet) {
      case 'bob': return <BoBCard />;
      case 'leave': return <LeaveCard />;
      case 'effort': return <EffortBookingCard />;
      case 'jkl': return <JKLCard />;
      case 'travel': return <TravelCard />;
      case 'cafeteria': return <CafeteriaCard />;
      case 'payslip': return <PayslipCard />;
      case 'projects': return <ProjectsCard />;
      case 'meetings': return <MeetingsCard />;
      case 'courses': return <CoursesCard />;
      case 'certifications': return <CertificationsCard />;
      case 'community': return <CommunityCard />;
      case 'music': return <MusicCard />;
      case 'seatbooking': return <SeatBookingCard />;
      case 'contacts': return <VitalContactsCard />;
      case 'entryexit': return <EntryExitCard />;
      case 'holidays': return <HolidayCalendarCard />;
      case 'gym': return <GymCard />;
      case 'wayfinder': return <WayFinderCard />;
      case 'blogs': return <BlogsCard />;
      case 'parking': return <ParkingCard />;
      case 'watchlist': return <WatchlistCard />;
      case 'banner': return <BannersCard />;
      default: return null;
    }
  };

  return (
    <div className={cn(
      "relative w-full min-h-screen flex items-center justify-center py-20 overflow-hidden transition-transform duration-500",
      isShifted && "-translate-x-48"
    )}>
      {/* Stars background */}
      <div className="absolute inset-0 opacity-20">
        {[...Array(150)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-foreground animate-pulse"
            style={{
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animationDelay: Math.random() * 2 + 's',
              animationDuration: Math.random() * 3 + 2 + 's',
            }}
          />
        ))}
      </div>

      {/* Solar System Container */}
      <div className="relative" style={{ width: '1000px', height: '1000px' }}>
        {/* Orbit rings */}
        {[220, 300, 380, 460].map((radius) => (
          <div
            key={radius}
            className="absolute top-1/2 left-1/2 border border-border/20 rounded-full"
            style={{
              width: radius * 2 + 'px',
              height: radius * 2 + 'px',
              transform: 'translate(-50%, -50%)',
            }}
          />
        ))}

        {/* Sun - User Profile */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-primary rounded-full blur-3xl opacity-60 animate-pulse"
              style={{ width: '200px', height: '200px', transform: 'translate(-25%, -25%)' }}></div>

            <div className="relative w-32 h-32 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow border-4 border-primary-glow animate-pulse-glow">
              <User className="w-16 h-16 text-primary-foreground" />
              <div className="absolute -top-2 -right-2 w-10 h-10 bg-accent rounded-full flex items-center justify-center animate-pulse-glow">
                <Sparkles className="w-5 h-5 text-accent-foreground" />
              </div>
            </div>

            <div className="absolute top-full mt-4 left-1/2 -translate-x-1/2 text-center whitespace-nowrap">
              <h2 className="text-2xl font-bold text-foreground mb-1">{displayName}</h2>
              <p className="text-sm text-muted-foreground">ID: {employeeId}</p>
              <p className="text-xs text-muted-foreground mt-1">{entityName} • Bangalore</p>
            </div>
          </div>
        </div>

        {/* Planets */}
        {planets.map((planet) => {
          const angle = (planetAngles[planet.id] || planet.angle) * (Math.PI / 180);
          const x = Math.cos(angle) * planet.orbitRadius;
          const y = Math.sin(angle) * planet.orbitRadius;
          const isActive = activePlanets.includes(planet.id) || (planet.id === 'canteen' && activePlanets.includes('cafeteria')) || (planet.id === 'cafeteria' && activePlanets.includes('canteen'));

          const Icon = planet.icon;

          return (
            <div
              key={planet.id}
              className={cn(
                "absolute top-1/2 left-1/2 group z-10",
                isActive ? "cursor-pointer" : "cursor-not-allowed"
              )}
              style={{
                transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                opacity: isActive ? 1 : 0.6,
              }}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              onClick={() => {
                if (!isActive) return;
                logger.logButtonClick(`planet-${planet.id}`, planet.name, {
                  planetId: planet.id,
                  planetName: planet.name,
                  action: 'planet-click'
                });
                setSelectedPlanet(planet.id);
                if (onPlanetSelect) {
                  onPlanetSelect();
                }
              }}
              // [FIX #12 | Rule S1082 - Keyboard Access]: Keyboard listener added for planet selection
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  if (!isActive) return;
                  setSelectedPlanet(planet.id);
                  if (onPlanetSelect) onPlanetSelect();
                }
              }}
              tabIndex={isActive ? 0 : -1}
              role="button"
            >
              <div
                className={cn(
                  "absolute inset-0 rounded-full blur-xl transition-opacity",
                  isActive ? "opacity-40 group-hover:opacity-70" : "opacity-20"
                )}
                style={{
                  backgroundColor: isActive ? planet.color : 'hsl(220 10% 30%)',
                  width: planet.size + 'px',
                  height: planet.size + 'px',
                  transform: 'translate(-20%, -20%)',
                }}
              />

              <div
                className={cn(
                  "relative rounded-full flex items-center justify-center transition-all duration-300",
                  isActive && "group-hover:scale-125",
                  "shadow-elevated",
                  selectedPlanet === planet.id && isActive && "ring-4 ring-primary scale-125"
                )}
                style={{
                  backgroundColor: isActive ? planet.color : 'hsl(220 10% 30%)',
                  width: planet.size + 'px',
                  height: planet.size + 'px',
                }}
              >
                <Icon className="w-6 h-6 text-white" />
              </div>

              <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                <span className={cn(
                  "text-xs font-medium bg-card px-2 py-1 rounded-md shadow-card",
                  isActive ? "text-foreground" : "text-muted-foreground"
                )}>
                  {planet.name}
                  {!isActive && " (Coming Soon)"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {selectedPlanet && createPortal(
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-[200] p-4"
          onClick={() => setSelectedPlanet(null)}
          // [FIX #12 | Rule S1082 - Keyboard Access]: Keyboard listener for modal close (Escape key)
          onKeyDown={(e) => e.key === 'Escape' && setSelectedPlanet(null)}
        >
          <div
            className="relative max-w-2xl w-full max-h-[85vh] overflow-y-auto animate-scale-in pb-10 custom-scrollbar"
            onClick={(e) => e.stopPropagation()}
            // [FIX #12 | Rule S1082 - Keyboard Access]: Keyboard listener propagates event stoppage
            onKeyDown={(e) => e.stopPropagation()}
            role="presentation"
          >
            <div className="sticky top-2 right-2 z-20 flex justify-end px-2 pointer-events-none mb-[-2rem]">
              <button
                onClick={() => setSelectedPlanet(null)}
                className="w-8 h-8 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:scale-110 transition-transform pointer-events-auto shadow-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {renderPlanetCard()}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};
