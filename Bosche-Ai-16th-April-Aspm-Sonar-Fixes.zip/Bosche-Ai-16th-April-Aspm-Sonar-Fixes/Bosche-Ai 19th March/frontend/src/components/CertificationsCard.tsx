import { Award, Medal } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const CertificationsCard = () => {
  return (
    <DashboardCard title="Certifications" icon={Award}>
      <div className="space-y-3">
        <div className="p-3 bg-gradient-accent/10 border border-accent/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Award className="w-5 h-5 text-accent" />
            <h4 className="text-sm font-semibold text-foreground">AWS Solutions Architect</h4>
          </div>
          <p className="text-xs text-muted-foreground">Earned: Oct 2025</p>
          <p className="text-xs text-accent mt-1">⭐ Professional Level</p>
        </div>
        <div className="p-3 bg-secondary rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Medal className="w-5 h-5 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Scrum Master</h4>
          </div>
          <p className="text-xs text-muted-foreground">Earned: Aug 2025</p>
          <p className="text-xs text-accent mt-1">⭐ Certified</p>
        </div>
        <div className="text-center p-3 bg-primary/10 rounded-lg">
          <p className="text-3xl font-bold text-foreground">5</p>
          <p className="text-xs text-muted-foreground">Total Badges Earned</p>
          <p className="text-xs text-accent mt-1">🏆 Top 10% in team</p>
        </div>
      </div>
    </DashboardCard>
  );
};
