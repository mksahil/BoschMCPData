import React from "react";
import { Hammer } from "lucide-react";
import { cn } from "@/lib/utils";

interface InProgressOverlayProps {
    children: React.ReactNode;
    className?: string;
    message?: string;
}

export const InProgressOverlay = ({
    children,
    className,
    message = "This section is currently under development"
}: InProgressOverlayProps) => {
    return (
        <div className={cn("relative w-full h-full", className)}>
            {/* Content - blurred and disabled */}
            <div className="w-full h-full opacity-40 grayscale pointer-events-none select-none blur-[2px]">
                {children}
            </div>

            {/* Overlay */}
            <div className="absolute inset-0 flex items-center justify-center z-20">
                <div className="bg-card/90 backdrop-blur-md border border-border/50 shadow-elevated rounded-2xl p-8 max-w-md text-center transform hover:scale-105 transition-transform duration-300">
                    <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow shadow-glow-sm">
                        <Hammer className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">Work In Progress 🚧</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                        {message}
                    </p>
                    <div className="mt-6 flex justify-center gap-2">
                        <span className="inline-block w-2 h-2 rounded-full bg-primary animate-bounce delay-0"></span>
                        <span className="inline-block w-2 h-2 rounded-full bg-primary animate-bounce delay-150"></span>
                        <span className="inline-block w-2 h-2 rounded-full bg-primary animate-bounce delay-300"></span>
                    </div>
                </div>
            </div>
        </div>
    );
};
