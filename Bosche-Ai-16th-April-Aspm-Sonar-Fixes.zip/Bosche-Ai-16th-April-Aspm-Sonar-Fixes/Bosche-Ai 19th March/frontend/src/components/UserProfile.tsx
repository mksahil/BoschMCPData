import { User, Briefcase, MapPin, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";

export const UserProfile = () => {
  const { user } = useAuth();
  
  // Get display name - use API name, or format employee number
  const displayName = user?.name || `Employee ${user?.employeeNumber || ''}`;
  const employeeId = user?.employeeNumber || '';
  const entityName = user?.entityName || 'Bosch';
  
  return (
    <div className="relative">
      {/* Glow effect */}
      <div className="absolute inset-0 bg-gradient-primary rounded-2xl blur-xl opacity-30 animate-pulse"></div>
      
      {/* Profile Card */}
      <div className="relative bg-card rounded-2xl p-8 shadow-elevated border border-border hover:shadow-glow transition-all duration-300">
        <div className="flex flex-col items-center text-center">
          {/* Avatar with AI indicator */}
          <div className="relative mb-4">
            <div className="w-24 h-24 bg-gradient-accent rounded-full flex items-center justify-center">
              <User className="w-12 h-12 text-accent-foreground" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center animate-pulse-glow">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
          </div>

          {/* User Info */}
          <h2 className="text-2xl font-bold text-foreground mb-1">{displayName}</h2>
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Briefcase className="w-4 h-4" />
            <span>ID: {employeeId}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <MapPin className="w-4 h-4" />
            <span>{entityName} • Bangalore</span>
          </div>

          {/* Status Indicator */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-xs font-medium text-primary">AI Assistant Active</span>
          </div>


        </div>
      </div>
    </div>
  );
};
