import { useState } from "react";
import { Send, Mic, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";

interface ConversationalInputProps {
  onSend: (message: string) => void;
  placeholder?: string;
  onClick?: () => void;
}

export const ConversationalInput = ({ onSend, placeholder = "Ask me anything...", onClick }: ConversationalInputProps) => {
  const [input, setInput] = useState("");
  const [isListening, setIsListening] = useState(false);

  const handleSend = () => {
    if (input.trim()) {
      logger.log('conversational_input_send', {
        message: input.trim(),
        messageLength: input.trim().length,
        method: 'button',
        timestamp: new Date().toISOString()
      });
      onSend(input.trim());
      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputClick = () => {
    // Open chat window when clicking on input
    if (onClick) {
      onClick();
    }
  };

  const toggleVoice = () => {
    const newState = !isListening;
    setIsListening(newState);
    logger.logButtonClick('voice-input-toggle', newState ? 'Start Voice' : 'Stop Voice', {
      isListening: newState
    });
    // Voice recognition would be implemented here
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-gradient-to-t from-background via-background to-transparent pt-8 pb-4">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="relative">
          {/* AI Glow Effect */}
          <div className="absolute inset-0 bg-gradient-primary rounded-2xl blur-xl opacity-20 animate-pulse-glow"></div>

          <div className="relative bg-card rounded-2xl border-2 border-primary/20 shadow-elevated hover:border-primary/40 transition-all duration-300">
            <div className="flex items-end gap-3 p-4">
              {/* AI Indicator */}
              <div className="flex-shrink-0 w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
                <Sparkles className="w-5 h-5 text-primary-foreground animate-pulse" />
              </div>

              {/* Input Area */}
              <div className="flex-1">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  onClick={handleInputClick}
                  placeholder={placeholder}
                  rows={1}
                  className={cn(
                    "w-full bg-transparent border-0 outline-none resize-none cursor-text",
                    "text-foreground placeholder:text-muted-foreground",
                    "text-sm leading-relaxed max-h-32 overflow-y-auto"
                  )}
                  style={{
                    height: 'auto',
                    minHeight: '24px'
                  }}
                  onInput={(e) => {
                    const target = e.target as HTMLTextAreaElement;
                    target.style.height = 'auto';
                    target.style.height = Math.min(target.scrollHeight, 128) + 'px';
                  }}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={toggleVoice}
                  className={cn(
                    "w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-300",
                    isListening
                      ? "bg-destructive text-destructive-foreground shadow-glow"
                      : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-primary/10"
                  )}
                  title={isListening ? "Stop listening" : "Voice input"}
                >
                  <Mic className={cn("w-4 h-4", isListening && "animate-pulse")} />
                </button>

                <button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className={cn(
                    "w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-300",
                    input.trim()
                      ? "bg-gradient-primary text-primary-foreground shadow-glow hover:shadow-elevated"
                      : "bg-secondary text-muted-foreground cursor-not-allowed"
                  )}
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-center gap-2 mt-3">
          {["Apply Leave", "Book Shuttle", "Submit Bills", "View Effort"].map((action) => (
            <button
              key={action}
              title="Coming Soon"
              className="text-xs px-3 py-1.5 rounded-full bg-[hsl(220_10%_30%)] text-white/50 cursor-not-allowed transition-all duration-200"
            >
              {action}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
