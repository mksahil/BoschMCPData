import { Eye, Star, TrendingUp, Clock } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const WatchlistCard = () => {
  return (
    <DashboardCard title="My Watchlist" icon={Eye}>
      <div className="space-y-4">
        {/* Currently Watching */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-4 h-4 text-accent" />
            <h4 className="text-sm font-semibold text-foreground">Currently Watching</h4>
          </div>
          <h5 className="text-sm font-bold text-foreground mb-2">
            The Future of AI in Enterprise
          </h5>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">Episode 3 of 8</span>
          </div>
          <div className="w-full bg-background rounded-full h-2">
            <div className="bg-gradient-accent h-2 rounded-full" style={{ width: '37.5%' }}></div>
          </div>
        </div>

        {/* Watchlist Items */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">Up Next</h4>
          
          <div className="p-3 bg-secondary rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <h5 className="text-sm font-medium text-foreground">Cloud Architecture Masterclass</h5>
              <span className="text-xs px-2 py-1 bg-primary/20 text-primary rounded-full">New</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>6h 30m</span>
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>12 episodes</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-secondary rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <h5 className="text-sm font-medium text-foreground">DevOps Best Practices</h5>
              <span className="text-xs px-2 py-1 bg-accent/20 text-accent rounded-full">Popular</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>4h 15m</span>
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>8 episodes</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-foreground">8</p>
            <p className="text-xs text-muted-foreground">Watching</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-success">24</p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-primary">52h</p>
            <p className="text-xs text-muted-foreground">Watched</p>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
