import { FileText, TrendingUp, MessageCircle, Eye } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const BlogsCard = () => {
  return (
    <DashboardCard title="My Blogs" icon={FileText}>
      <div className="space-y-4">
        {/* Latest Blog */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Latest Post</h4>
          </div>
          <h5 className="text-sm font-bold text-foreground mb-2">
            Building Scalable Microservices with Kubernetes
          </h5>
          <p className="text-xs text-muted-foreground mb-3">
            A deep dive into containerization and orchestration...
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              <span>1.2k views</span>
            </div>
            <div className="flex items-center gap-1">
              <MessageCircle className="w-3 h-3" />
              <span>24 comments</span>
            </div>
          </div>
        </div>

        {/* Recent Posts */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">Recent Posts</h4>
          
          <div className="p-3 bg-secondary rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-1">
              Understanding React Server Components
            </h5>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>Dec 10</span>
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>856</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-secondary rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-1">
              TypeScript Best Practices 2025
            </h5>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>Dec 5</span>
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>1.5k</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-foreground">12</p>
            <p className="text-xs text-muted-foreground">Posts</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-primary">8.4k</p>
            <p className="text-xs text-muted-foreground">Views</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg text-center">
            <p className="text-lg font-bold text-success">142</p>
            <p className="text-xs text-muted-foreground">Followers</p>
          </div>
        </div>

        <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all text-sm">
          Write New Post
        </button>
      </div>
    </DashboardCard>
  );
};
