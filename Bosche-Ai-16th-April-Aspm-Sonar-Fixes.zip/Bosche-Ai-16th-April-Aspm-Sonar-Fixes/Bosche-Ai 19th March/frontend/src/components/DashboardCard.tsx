import { ReactNode, useEffect } from "react";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";

interface DashboardCardProps {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
  className?: string;
  accent?: boolean;
  action?: ReactNode;
}

export const DashboardCard = ({ title, icon: Icon, children, className, accent, action }: DashboardCardProps) => {
  useEffect(() => {
    // Log when card is viewed
    logger.logFeatureUsage(`dashboard-card-${title.toLowerCase().replace(/\s+/g, '-')}`, {
      cardTitle: title,
      isAccent: accent || false,
      timestamp: new Date().toISOString()
    });
  }, [title, accent]);

  return (
    <div
      // [FIX #13 | Rule S6819 - ARIA Keyboard]: Added keyboard listener and ARIA roles for accessibility
      role="button"
      tabIndex={0}
      onClick={() => {
        // Log card interactions
        logger.log('dashboard_card_click', {
          cardTitle: title,
          isAccent: accent || false
        });
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          logger.log('dashboard_card_click', {
            cardTitle: title,
            isAccent: accent || false
          });
        }
      }}
      className={cn(
        "bg-card rounded-xl p-6 shadow-card hover:shadow-elevated transition-all duration-300 border border-border",
        accent && "bg-gradient-subtle",
        className
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center",
            accent ? "bg-gradient-primary shadow-glow" : "bg-secondary"
          )}>
            <Icon className={cn(
              "w-5 h-5",
              accent ? "text-primary-foreground" : "text-primary"
            )} />
          </div>
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        </div>
        {action && <div>{action}</div>}
      </div>
      <div className="space-y-3">
        {children}
      </div>
    </div>
  );
};
