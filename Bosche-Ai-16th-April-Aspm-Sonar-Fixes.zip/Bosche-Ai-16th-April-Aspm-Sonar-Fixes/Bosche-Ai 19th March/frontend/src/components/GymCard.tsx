import { Dumbbell, TrendingUp, Flame, Target } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const GymCard = () => {
  return (
    <DashboardCard title="Gym & Fitness" icon={Dumbbell}>
      <div className="space-y-4">
        {/* Today's Workout */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Flame className="w-4 h-4 text-destructive" />
            <h4 className="text-sm font-semibold text-foreground">Today's Session</h4>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Booked Slot</span>
              <span className="text-sm font-bold text-foreground">6:00 - 7:00 PM</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Activity</span>
              <span className="text-sm font-medium text-primary">Strength Training</span>
            </div>
          </div>
        </div>

        {/* This Week Stats */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">This Week</h4>
          
          <div className="grid grid-cols-3 gap-2">
            <div className="p-2 bg-secondary rounded-lg text-center">
              <p className="text-lg font-bold text-foreground">4</p>
              <p className="text-xs text-muted-foreground">Sessions</p>
            </div>
            <div className="p-2 bg-secondary rounded-lg text-center">
              <p className="text-lg font-bold text-destructive">1.2k</p>
              <p className="text-xs text-muted-foreground">Calories</p>
            </div>
            <div className="p-2 bg-secondary rounded-lg text-center">
              <p className="text-lg font-bold text-success">320</p>
              <p className="text-xs text-muted-foreground">Minutes</p>
            </div>
          </div>
        </div>

        {/* Goals */}
        <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-accent" />
            <h4 className="text-sm font-semibold text-foreground">Weekly Goal</h4>
          </div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">4/5 sessions</span>
          </div>
          <div className="w-full bg-background rounded-full h-2">
            <div className="bg-gradient-accent h-2 rounded-full" style={{ width: '80%' }}></div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button className="py-2 px-3 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all text-xs">
            Book Slot
          </button>
          <button className="py-2 px-3 bg-secondary hover:bg-secondary/80 text-foreground rounded-lg transition-all text-xs">
            View Classes
          </button>
        </div>
      </div>
    </DashboardCard>
  );
};
