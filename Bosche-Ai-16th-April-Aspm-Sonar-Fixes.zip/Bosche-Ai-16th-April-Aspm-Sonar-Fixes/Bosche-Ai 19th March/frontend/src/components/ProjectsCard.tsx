import { Briefcase } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const ProjectsCard = () => {
  return (
    <DashboardCard title="My Projects" icon={Briefcase}>
      <div className="space-y-3">
        <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <h4 className="text-sm font-semibold text-foreground mb-1">AI Platform v2.0</h4>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">68%</span>
          </div>
          <div className="w-full bg-background rounded-full h-2">
            <div className="bg-gradient-primary h-2 rounded-full" style={{ width: '68%' }}></div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Due: Dec 31, 2025</p>
        </div>
        <div className="p-3 bg-secondary rounded-lg">
          <h4 className="text-sm font-semibold text-foreground mb-1">IoT Dashboard</h4>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">42%</span>
          </div>
          <div className="w-full bg-background rounded-full h-2">
            <div className="bg-gradient-accent h-2 rounded-full" style={{ width: '42%' }}></div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Due: Jan 15, 2026</p>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2 bg-secondary rounded text-center">
            <p className="font-bold text-foreground">12</p>
            <p className="text-muted-foreground">Active Tasks</p>
          </div>
          <div className="p-2 bg-secondary rounded text-center">
            <p className="font-bold text-success">94%</p>
            <p className="text-muted-foreground">On-time</p>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
