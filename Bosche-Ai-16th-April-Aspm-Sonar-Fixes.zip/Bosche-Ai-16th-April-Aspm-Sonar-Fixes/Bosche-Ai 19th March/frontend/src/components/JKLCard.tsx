import { GraduationCap, Upload, TrendingUp, Award } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const JKLCard = () => {
  const totalBudget = 10000;
  const spent = 3500;
  const remaining = totalBudget - spent;
  const percentage = (spent / totalBudget) * 100;

  return (
    <DashboardCard title="JKL - Learning Budget" icon={GraduationCap}>
      <div className="space-y-4">
        {/* Budget Overview */}
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center w-32 h-32">
            {/* Background Circle */}
            <svg className="w-32 h-32 transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="56"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                className="text-secondary"
              />
              <circle
                cx="64"
                cy="64"
                r="56"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 56}`}
                strokeDashoffset={`${2 * Math.PI * 56 * (1 - percentage / 100)}`}
                className="text-primary transition-all duration-500"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-2xl font-bold text-foreground">₹{remaining.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Remaining</p>
            </div>
          </div>
        </div>

        {/* Budget Breakdown */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-primary/10 rounded-lg text-center">
            <p className="text-xs text-muted-foreground">Total Budget</p>
            <p className="text-lg font-bold text-foreground">₹{totalBudget.toLocaleString()}</p>
          </div>
          <div className="p-3 bg-secondary rounded-lg text-center">
            <p className="text-xs text-muted-foreground">Spent</p>
            <p className="text-lg font-bold text-foreground">₹{spent.toLocaleString()}</p>
          </div>
        </div>

        {/* Courses Status */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-foreground">Your Progress:</p>
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Courses Completed</span>
            <span className="font-semibold text-success">3</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Pending Reimbursements</span>
            <span className="font-semibold text-warning">₹2,800</span>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm">
            <Upload className="w-4 h-4" />
            Submit Invoice
          </button>
          <button className="w-full py-2 px-4 bg-secondary hover:bg-gradient-accent hover:text-accent-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm text-foreground">
            <Award className="w-4 h-4" />
            AI Course Recommendations
          </button>
        </div>

        {/* AI Suggestion */}
        <div className="p-3 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-start gap-2">
            <TrendingUp className="w-4 h-4 text-primary mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-foreground">AI Suggestion</p>
              <p className="text-xs text-muted-foreground">Advanced Python for Data Science - ₹1,999</p>
            </div>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
