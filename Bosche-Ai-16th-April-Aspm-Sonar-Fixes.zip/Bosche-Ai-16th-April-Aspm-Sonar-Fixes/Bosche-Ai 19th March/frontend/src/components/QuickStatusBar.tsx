import { Battery, Brain, Heart, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatusItem {
  id: string;
  label: string;
  icon: React.ElementType;
  value: number;
  color: string;
}

const statusItems: StatusItem[] = [
  { id: "wellness", label: "Wellness", icon: Heart, value: 85, color: "text-success" },
  { id: "focus", label: "Focus", icon: Brain, value: 92, color: "text-primary" },
  { id: "social", label: "Social", icon: TrendingUp, value: 78, color: "text-accent" },
  { id: "energy", label: "Energy", icon: Battery, value: 65, color: "text-destructive" },
];

export const QuickStatusBar = () => {
  return (
    <div className="flex items-center gap-4">
      {statusItems.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.id}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors duration-200 cursor-pointer group"
            title={`${item.label}: ${item.value}%`}
          >
            <Icon className={cn("w-4 h-4", item.color, "group-hover:scale-110 transition-transform duration-200")} />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">{item.label}</span>
              <div className="flex items-center gap-1">
                <div className="w-12 h-1 bg-border rounded-full overflow-hidden">
                  <div
                    className={cn("h-full rounded-full transition-all duration-300", 
                      item.value >= 80 ? "bg-success" : 
                      item.value >= 60 ? "bg-primary" : 
                      "bg-destructive"
                    )}
                    style={{ width: `${item.value}%` }}
                  ></div>
                </div>
                <span className="text-xs font-medium text-foreground">{item.value}%</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
