import { useState, useEffect } from "react";
import { LogIn, Clock, User, CheckCircle, XCircle, Loader2, RefreshCw } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { useAuth } from "@/context/AuthContext";
import { API_BASE_URL } from "@/config";

interface EmployeeStatus {
  name: string;
  status: 'IN' | 'OUT' | 'unknown';
  lastSwipe: string | null;
  location: string | null;
}

export const EntryExitCard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [employeeData, setEmployeeData] = useState<EmployeeStatus>({
    name: 'Loading...',
    status: 'unknown',
    lastSwipe: null,
    location: null
  });

  const fetchEmployeeData = async () => {
    setLoading(true);
    setError(null);
    
    const employeeNumber = user?.employeeNumber || '34835634';
    
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Employee-Number': employeeNumber
    };
    
    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }

    try {
      // Fetch employee name and current status in parallel
      const [nameResponse, statusResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/api/time-tracking/employee-name`, { headers }),
        fetch(`${API_BASE_URL}/api/time-tracking/current-status`, { headers })
      ]);

      const nameData = await nameResponse.json();
      const statusData = await statusResponse.json();

      setEmployeeData({
        name: nameData.success ? nameData.name : 'Unknown',
        status: statusData.success ? statusData.status : 'unknown',
        lastSwipe: statusData.success ? statusData.lastSwipe : null,
        location: statusData.success ? statusData.location : null
      });
    } catch (err) {
      console.error('Error fetching employee data:', err);
      setError('Failed to load data');
      setEmployeeData({
        name: user?.name || 'Unknown',
        status: 'unknown',
        lastSwipe: null,
        location: null
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeeData();
  }, [user]);

  const formatLastSwipe = (swipeTime: string | null) => {
    if (!swipeTime) return 'N/A';
    try {
      const date = new Date(swipeTime);
      return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
    } catch {
      return swipeTime;
    }
  };

  const isCheckedIn = employeeData.status === 'IN';
  const statusColor = isCheckedIn ? 'text-success' : 'text-destructive';
  const statusBgColor = isCheckedIn ? 'bg-success/20' : 'bg-destructive/20';
  const StatusIcon = isCheckedIn ? CheckCircle : XCircle;

  return (
    <DashboardCard title="Entry & Exit" icon={LogIn}>
      <div className="space-y-4">
        {/* Employee Info & Status */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-primary" />
              <h4 className="text-sm font-semibold text-foreground">Employee Info</h4>
            </div>
            <button 
              onClick={fetchEmployeeData}
              disabled={loading}
              className="p-1 hover:bg-secondary rounded transition-colors"
              title="Refresh"
            >
              <RefreshCw className={`w-3 h-3 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          
          {loading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
            </div>
          ) : error ? (
            <div className="text-center py-2">
              <p className="text-xs text-destructive">{error}</p>
              <button 
                onClick={fetchEmployeeData}
                className="text-xs text-primary hover:underline mt-1"
              >
                Try again
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Employee Name */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Name</span>
                </div>
                <span className="text-sm font-bold text-foreground">{employeeData.name}</span>
              </div>
              
              {/* Current Status */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <StatusIcon className={`w-4 h-4 ${statusColor}`} />
                  <span className="text-xs text-muted-foreground">Status</span>
                </div>
                <span className={`text-xs px-2 py-1 ${statusBgColor} ${statusColor} rounded-full font-semibold`}>
                  {employeeData.status === 'IN' ? 'Checked In' : 
                   employeeData.status === 'OUT' ? 'Checked Out' : 'Unknown'}
                </span>
              </div>
              
              {/* Last Swipe */}
              {employeeData.lastSwipe && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Last Swipe</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {formatLastSwipe(employeeData.lastSwipe)}
                  </span>
                </div>
              )}
              
              {/* Location */}
              {employeeData.location && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <LogIn className="w-4 h-4 text-accent" />
                    <span className="text-xs text-muted-foreground">Location</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">{employeeData.location}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Status Indicator */}
        <div className={`p-3 rounded-lg ${statusBgColor} border ${isCheckedIn ? 'border-success/30' : 'border-destructive/30'}`}>
          <div className="flex items-center justify-center gap-2">
            <StatusIcon className={`w-5 h-5 ${statusColor}`} />
            <span className={`text-sm font-semibold ${statusColor}`}>
              {loading ? 'Loading...' : 
               isCheckedIn ? 'You are currently IN office' : 
               employeeData.status === 'OUT' ? 'You have checked OUT' : 
               'Status unavailable'}
            </span>
          </div>
        </div>

      </div>
    </DashboardCard>
  );
};
