import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Loader2, User, Lock, Eye, EyeOff, LogIn } from 'lucide-react';
import { DarkModeToggle } from '@/components/DarkModeToggle';
import { useAzureSSOLogin } from '@/hooks/useAzureSSOLogin';
import { handleSSORedirectCallback } from '@/services/azureAuthService';

export const Login = () => {
  const [employeeNumber, setEmployeeNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isPreEncrypted, setIsPreEncrypted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isProcessingRedirect, setIsProcessingRedirect] = useState(true);
  const { login, ssoLogin: contextSSO } = useAuth();
  const navigate = useNavigate();
  const { ssoLogin, isLoading: isSSOLoading } = useAzureSSOLogin();

  useEffect(() => {
    let cancelled = false;

    const processRedirect = async () => {
      try {
        const arenaTokenData = await handleSSORedirectCallback();

        if (!arenaTokenData || cancelled) {
          return;
        }

        const authResult = await contextSSO(arenaTokenData);
        if (authResult.success) {
          toast.success('SSO Login successful!');
          navigate('/');
        } else {
          toast.error(authResult.error || 'Failed to set user session');
        }
      } catch (error: unknown) {
        console.error('SSO redirect processing error:', error);
        toast.error('Failed to process SSO callback');
      } finally {
        if (!cancelled) {
          setIsProcessingRedirect(false);
        }
      }
    };

    processRedirect();

    return () => {
      cancelled = true;
    };
  }, [contextSSO, navigate]);

  const handleSSOSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const result = await ssoLogin();

      if (result.success && result.data) {
        // Exchange was successful, save token to sessionStorage immediately
        sessionStorage.setItem('mybgsw_user', JSON.stringify({
          employeeNumber: result.data.userName,
          name: result.data.Name?.trim() || result.data.userName,
          accessToken: result.data.access_token,
          tokenType: result.data.token_type,
          entityId: result.data.EntityId,
          entityName: result.data.EntityName,
          isTemporaryPassword: result.data.IsTemporaryPassword === 'True',
          loginTimestamp: result.data.LoginTimeStamp,
          ntid: result.data.NTID,
          expiresIn: result.data.expires_in,
          issuedAt: result.data['.issued'],
          expiresAt: result.data['.expires'],
          sessionId: result.data.sessionId,
          loginMethod: 'sso',
        }));

        // Set the user with the Arena token
        const authResult = await contextSSO(result.data);
        if (authResult.success) {
          toast.success('SSO Login successful!');
          navigate('/');
        } else {
          toast.error(authResult.error || 'Failed to set user session');
        }
      } else if (result.success) {
        // Redirect-based SSO started, browser will navigate to Azure AD.
        return;
      } else {
        toast.error(result.error || 'SSO login failed');
      }
    } catch (error: any) {
      console.error('SSO error:', error);
      toast.error(error?.message || 'An error occurred during SSO login');
    }
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!employeeNumber.trim()) {
      toast.error('Please enter your employee number');
      return;
    }

    if (!password.trim()) {
      toast.error('Please enter your password');
      return;
    }

    setIsSubmitting(true);

    const result = await login(employeeNumber.trim(), password, isPreEncrypted);

    if (result.success) {
      toast.success('Login successful!');
      navigate('/');
    } else {
      toast.error(result.error || 'Login failed');
    }

    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20 flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />
      </div>

      {/* Dark mode toggle */}
      <div className="absolute top-4 right-4">
        <DarkModeToggle />
      </div>

      <Card className="w-full max-w-md relative z-10 shadow-2xl border-border/50 backdrop-blur-sm bg-card/95">
        <CardHeader className="text-center space-y-4">
          {/* Logo */}
          <div className="mx-auto flex items-center justify-center p-2 mb-2">
            <img
              src="/bgsw-logo.png"
              alt="MyBGSW Logo"
              className="h-20 w-auto object-contain"
            />
          </div>

          <div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              MyBGSW.AI
            </CardTitle>
            <CardDescription className="text-muted-foreground mt-1">
              Your AI Companion - Sign in to continue
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Employee Number */}
            <div className="space-y-2">
              <Label htmlFor="employeeNumber" className="text-sm font-medium">
                Employee Number
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="employeeNumber"
                  type="text"
                  placeholder="Enter your employee number"
                  value={employeeNumber}
                  onChange={(e) => setEmployeeNumber(e.target.value)}
                  className="pl-10 h-11"
                  disabled={isSubmitting}
                  autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10 h-11"
                  disabled={isSubmitting}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Pre-encrypted password checkbox */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="preEncrypted"
                checked={isPreEncrypted}
                onChange={(e) => setIsPreEncrypted(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                disabled={isSubmitting}
              />
              <Label htmlFor="preEncrypted" className="text-sm text-muted-foreground cursor-pointer">
                Password is pre-encrypted (for service accounts)
              </Label>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full h-11 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity"
              disabled={isSubmitting || isProcessingRedirect}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </Button>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">
                  Or continue with
                </span>
              </div>
            </div>

            {/* SSO Button */}
            <Button
              onClick={handleSSOSubmit}
              type="button"
              variant="outline"
              className="w-full h-11 border-border hover:bg-secondary"
              disabled={isSubmitting || isSSOLoading || isProcessingRedirect}
            >
              {isSSOLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in with Azure AD...
                </>
              ) : (
                <>
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign In with Azure AD
                </>
              )}
            </Button>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              Use your Bosch Associate Arena credentials
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Branding footer */}
      <div className="absolute bottom-4 text-center">
        <p className="text-xs text-muted-foreground">
          © 2025 Bosch. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Login;
