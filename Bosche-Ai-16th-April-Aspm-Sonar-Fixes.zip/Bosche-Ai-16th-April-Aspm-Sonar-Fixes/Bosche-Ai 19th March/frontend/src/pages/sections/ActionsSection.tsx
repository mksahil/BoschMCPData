import { FileText, Plane, Calendar, Bus, Coffee, UserPlus, GraduationCap, Heart, Ticket, Settings } from "lucide-react";
import { ActionCard } from "@/components/ActionCard";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export const ActionsSection = () => {
  const { toast } = useToast();
  const [selectedAction, setSelectedAction] = useState<string | null>(null);

  const handleAction = (action: string) => {
    setSelectedAction(action);
    toast({
      title: "Action Initiated",
      description: `Opening ${action}...`,
    });
    setTimeout(() => setSelectedAction(null), 1000);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Quick Actions ⚡
        </h2>
        <p className="text-muted-foreground">
          Take control of your workplace activities with one-click actions
        </p>
      </div>

      {/* HR & Leave */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-primary rounded-full"></div>
          HR & Leave Management
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            icon={FileText}
            title="Apply for Leave"
            description="Request vacation, sick leave, or personal days"
            onClick={() => handleAction("Leave Application")}
          />
          <ActionCard
            icon={Calendar}
            title="View Leave Balance"
            description="Check your remaining leave days and quota"
            onClick={() => handleAction("Leave Balance")}
          />
          <ActionCard
            icon={Ticket}
            title="Track Requests"
            description="Monitor status of your pending applications"
            onClick={() => handleAction("Request Tracker")}
          />
        </div>
      </section>

      {/* Travel & Mobility */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-accent rounded-full"></div>
          Travel & Mobility
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            icon={Plane}
            title="Plan Business Travel"
            description="Book flights, hotels, and manage itineraries"
            onClick={() => handleAction("Travel Planner")}
          />
          <ActionCard
            icon={Bus}
            title="Book Office Shuttle"
            description="Reserve your seat on the daily commute"
            onClick={() => handleAction("Shuttle Booking")}
          />
          <ActionCard
            icon={Coffee}
            title="Cafeteria Menu & Booking"
            description="View today's menu and pre-order meals"
            onClick={() => handleAction("Cafeteria")}
          />
        </div>
      </section>

      {/* Learning & Growth */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-primary rounded-full"></div>
          Learning & Development
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            icon={GraduationCap}
            title="Explore Learning Paths"
            description="Discover courses and skill development programs"
            onClick={() => handleAction("Learning Catalog")}
          />
          <ActionCard
            icon={UserPlus}
            title="Find a Mentor"
            description="Connect with leaders and experienced colleagues"
            onClick={() => handleAction("Mentor Search")}
          />
          <ActionCard
            icon={Settings}
            title="Career Development"
            description="Set goals and track your professional growth"
            onClick={() => handleAction("Career Planning")}
          />
        </div>
      </section>

      {/* Wellness */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-accent rounded-full"></div>
          Wellness & Support
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            icon={Heart}
            title="Wellness Check-in"
            description="Track health goals and get activity reminders"
            onClick={() => handleAction("Wellness Dashboard")}
          />
          <ActionCard
            icon={Calendar}
            title="Book Wellness Sessions"
            description="Schedule yoga, meditation, or fitness classes"
            onClick={() => handleAction("Wellness Booking")}
          />
          <ActionCard
            icon={UserPlus}
            title="Support Resources"
            description="Access mental health and counseling services"
            onClick={() => handleAction("Support Center")}
          />
        </div>
      </section>
    </div>
  );
};
