import { Brain, TrendingUp, Target, Lightbulb, AlertCircle } from "lucide-react";
import { DashboardCard } from "@/components/DashboardCard";

export const InsightsSection = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          AI-Powered Insights 🧠
        </h2>
        <p className="text-muted-foreground">
          Personalized recommendations and intelligence to optimize your workday
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Performance Trends */}
        <DashboardCard title="Performance Trends" icon={TrendingUp} accent>
          <div className="space-y-4">
            <div className="p-4 bg-gradient-primary rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-primary-foreground/80">Productivity Score</span>
                <span className="text-2xl font-bold text-primary-foreground">87%</span>
              </div>
              <div className="w-full bg-primary-foreground/20 rounded-full h-2">
                <div className="bg-primary-foreground h-2 rounded-full" style={{ width: "87%" }}></div>
              </div>
              <p className="text-xs text-primary-foreground/60 mt-2">+5% from last month</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground">Tasks Completed</p>
                <p className="text-xl font-bold text-foreground">42</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground">On-Time Rate</p>
                <p className="text-xl font-bold text-foreground">94%</p>
              </div>
            </div>
          </div>
        </DashboardCard>

        {/* Goal Progress */}
        <DashboardCard title="Goal Progress" icon={Target}>
          <div className="space-y-3">
            <div className="p-3 bg-secondary/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Complete IoT Certification</p>
                <span className="text-xs text-accent">75%</span>
              </div>
              <div className="w-full bg-background rounded-full h-2">
                <div className="bg-gradient-accent h-2 rounded-full" style={{ width: "75%" }}></div>
              </div>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Lead 3 Team Workshops</p>
                <span className="text-xs text-accent">67%</span>
              </div>
              <div className="w-full bg-background rounded-full h-2">
                <div className="bg-gradient-accent h-2 rounded-full" style={{ width: "67%" }}></div>
              </div>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Mentor 2 Junior Engineers</p>
                <span className="text-xs text-success">100%</span>
              </div>
              <div className="w-full bg-background rounded-full h-2">
                <div className="bg-gradient-primary h-2 rounded-full" style={{ width: "100%" }}></div>
              </div>
            </div>
          </div>
        </DashboardCard>

        {/* AI Recommendations */}
        <DashboardCard title="Smart Recommendations" icon={Lightbulb}>
          <div className="space-y-3">
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex gap-2">
                <Lightbulb className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Time Block Your Mornings</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    You're most productive 9-11 AM. Reserve this time for deep work.
                  </p>
                </div>
              </div>
            </div>
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex gap-2">
                <Lightbulb className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Connect with Sarah Chen</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    She has expertise in ML that aligns with your learning path.
                  </p>
                </div>
              </div>
            </div>
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex gap-2">
                <Lightbulb className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Take a Wellness Break</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    You've been at your desk for 3 hours. Time for a 10-min walk.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </DashboardCard>

        {/* Alerts & Attention */}
        <DashboardCard title="Needs Your Attention" icon={AlertCircle}>
          <div className="space-y-3">
            <div className="p-3 bg-accent/5 border border-accent/20 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Leave Request Pending</p>
                  <p className="text-xs text-muted-foreground mt-1">Your Dec 20-22 leave needs manager approval</p>
                </div>
              </div>
            </div>
            <div className="p-3 bg-accent/5 border border-accent/20 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Course Deadline Approaching</p>
                  <p className="text-xs text-muted-foreground mt-1">Complete "Advanced ML" module by Friday</p>
                </div>
              </div>
            </div>
            <div className="p-3 bg-accent/5 border border-accent/20 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-accent mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-foreground">Travel Booking Required</p>
                  <p className="text-xs text-muted-foreground mt-1">Berlin conference in 2 weeks - book flights now</p>
                </div>
              </div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  );
};
