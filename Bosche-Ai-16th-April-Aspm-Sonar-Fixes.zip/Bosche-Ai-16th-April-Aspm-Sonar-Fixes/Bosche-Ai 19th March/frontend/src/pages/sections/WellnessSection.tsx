import { Heart, Activity, Brain, Utensils, Moon, TrendingUp } from "lucide-react";
import { DashboardCard } from "@/components/DashboardCard";
import { ActionCard } from "@/components/ActionCard";

export const WellnessSection = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Wellness & Health 💚
        </h2>
        <p className="text-muted-foreground">
          Your holistic well-being matters - track health, manage stress, and stay balanced
        </p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ActionCard
          icon={Activity}
          title="Log Activity"
          description="Record your daily exercise and movement"
        />
        <ActionCard
          icon={Brain}
          title="Mindfulness Session"
          description="Start a guided meditation or breathing exercise"
        />
        <ActionCard
          icon={Utensils}
          title="Nutrition Tracker"
          description="Log meals and track your eating habits"
        />
      </div>

      {/* Today's Wellness */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard title="Steps Today" icon={Activity} accent>
          <div className="p-4 bg-gradient-primary rounded-lg">
            <p className="text-3xl font-bold text-primary-foreground">8,432</p>
            <p className="text-xs text-primary-foreground/60 mt-1">Goal: 10,000</p>
            <div className="w-full bg-primary-foreground/20 rounded-full h-2 mt-3">
              <div className="bg-primary-foreground h-2 rounded-full" style={{ width: "84%" }}></div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Active Minutes" icon={Heart}>
          <div className="p-4 bg-gradient-accent rounded-lg">
            <p className="text-3xl font-bold text-accent-foreground">45</p>
            <p className="text-xs text-accent-foreground/60 mt-1">Goal: 60 min</p>
            <div className="w-full bg-accent-foreground/20 rounded-full h-2 mt-3">
              <div className="bg-accent-foreground h-2 rounded-full" style={{ width: "75%" }}></div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Sleep Score" icon={Moon}>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-3xl font-bold text-foreground">82</p>
            <p className="text-xs text-success mt-1">Good • 7h 20m</p>
          </div>
        </DashboardCard>

        <DashboardCard title="Stress Level" icon={Brain}>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-3xl font-bold text-foreground">Low</p>
            <p className="text-xs text-muted-foreground mt-1">Better than usual</p>
          </div>
        </DashboardCard>
      </div>

      {/* Weekly Progress */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-primary rounded-full"></div>
          This Week's Progress
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <DashboardCard title="Activity Trends" icon={TrendingUp}>
            <div className="space-y-3">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Workouts Completed</span>
                  <span className="text-lg font-bold text-foreground">4/5</span>
                </div>
                <div className="w-full bg-background rounded-full h-2">
                  <div className="bg-gradient-primary h-2 rounded-full" style={{ width: "80%" }}></div>
                </div>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Meditation Sessions</span>
                  <span className="text-lg font-bold text-foreground">3/7</span>
                </div>
                <div className="w-full bg-background rounded-full h-2">
                  <div className="bg-gradient-accent h-2 rounded-full" style={{ width: "43%" }}></div>
                </div>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Avg Sleep Quality</span>
                  <span className="text-lg font-bold text-success">85%</span>
                </div>
                <div className="w-full bg-background rounded-full h-2">
                  <div className="bg-gradient-primary h-2 rounded-full" style={{ width: "85%" }}></div>
                </div>
              </div>
            </div>
          </DashboardCard>

          <DashboardCard title="Wellness Insights" icon={Brain}>
            <div className="space-y-3">
              <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex gap-2">
                  <Heart className="w-4 h-4 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Great Progress!</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      You've been consistently active this week. Keep it up!
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-3 bg-accent/5 border border-accent/20 rounded-lg">
                <div className="flex gap-2">
                  <Moon className="w-4 h-4 text-accent mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Sleep Reminder</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Try going to bed 30 minutes earlier for optimal recovery.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex gap-2">
                  <Brain className="w-4 h-4 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Stress Management</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      You've been at your desk for 2 hours. Time for a quick break!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </DashboardCard>
        </div>
      </section>

      {/* Upcoming Wellness Activities */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-accent rounded-full"></div>
          Upcoming Wellness Activities
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-card border border-border rounded-lg hover:shadow-elevated transition-all duration-300">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Yoga Session</p>
                <p className="text-xs text-muted-foreground">Today, 5:30 PM</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Wellness Center • 60 minutes</p>
          </div>

          <div className="p-4 bg-card border border-border rounded-lg hover:shadow-elevated transition-all duration-300">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Mindfulness Workshop</p>
                <p className="text-xs text-muted-foreground">Tomorrow, 12:00 PM</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Conference Room B • 45 minutes</p>
          </div>

          <div className="p-4 bg-card border border-border rounded-lg hover:shadow-elevated transition-all duration-300">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Health Checkup</p>
                <p className="text-xs text-muted-foreground">Friday, 10:00 AM</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Medical Center • 30 minutes</p>
          </div>
        </div>
      </section>
    </div>
  );
};
