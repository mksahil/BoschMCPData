import { GraduationCap, BookOpen, Award, TrendingUp, Clock, Target } from "lucide-react";
import { DashboardCard } from "@/components/DashboardCard";
import { ActionCard } from "@/components/ActionCard";

export const LearningSection = () => {
  const courses = [
    {
      title: "Advanced Machine Learning with TensorFlow",
      progress: 45,
      duration: "12 hours",
      level: "Advanced",
      category: "AI/ML"
    },
    {
      title: "Cloud Architecture Fundamentals",
      progress: 0,
      duration: "8 hours",
      level: "Intermediate",
      category: "Cloud"
    },
    {
      title: "Leadership & Team Management",
      progress: 80,
      duration: "6 hours",
      level: "All Levels",
      category: "Soft Skills"
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Learning & Development 📚
        </h2>
        <p className="text-muted-foreground">
          Accelerate your career with personalized learning paths and skill development
        </p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ActionCard
          icon={BookOpen}
          title="Browse Catalog"
          description="Explore 500+ courses and learning resources"
        />
        <ActionCard
          icon={Target}
          title="Set Learning Goals"
          description="Define your skill development objectives"
        />
        <ActionCard
          icon={Award}
          title="My Certifications"
          description="View earned badges and certificates"
        />
      </div>

      {/* Active Courses */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-primary rounded-full"></div>
          My Active Courses
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {courses.map((course, idx) => (
            <div
              key={idx}
              className="bg-card rounded-xl p-6 shadow-card hover:shadow-elevated transition-all duration-300 border border-border"
            >
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                    {course.category}
                  </span>
                  <span className="text-xs px-2 py-1 bg-secondary text-muted-foreground rounded-full">
                    {course.level}
                  </span>
                </div>
                <h4 className="font-semibold text-foreground mb-2">{course.title}</h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{course.duration}</span>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">Progress</span>
                  <span className="text-xs font-medium text-foreground">{course.progress}%</span>
                </div>
                <div className="w-full bg-background rounded-full h-2">
                  <div 
                    className="bg-gradient-accent h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${course.progress}%` }}
                  ></div>
                </div>
              </div>

              <button className="w-full py-2 bg-secondary hover:bg-gradient-primary hover:text-primary-foreground rounded-lg transition-all duration-300">
                {course.progress > 0 ? "Continue Learning" : "Start Course"}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Learning Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard title="Learning Hours" icon={Clock}>
          <div className="p-4 bg-gradient-primary rounded-lg">
            <p className="text-3xl font-bold text-primary-foreground">42h</p>
            <p className="text-xs text-primary-foreground/60 mt-1">This quarter</p>
          </div>
        </DashboardCard>

        <DashboardCard title="Courses Completed" icon={GraduationCap}>
          <div className="p-4 bg-gradient-accent rounded-lg">
            <p className="text-3xl font-bold text-accent-foreground">8</p>
            <p className="text-xs text-accent-foreground/60 mt-1">+3 this month</p>
          </div>
        </DashboardCard>

        <DashboardCard title="Certifications" icon={Award}>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-3xl font-bold text-foreground">5</p>
            <p className="text-xs text-muted-foreground mt-1">Earned badges</p>
          </div>
        </DashboardCard>

        <DashboardCard title="Skill Growth" icon={TrendingUp}>
          <div className="p-4 bg-secondary rounded-lg">
            <p className="text-3xl font-bold text-success">+24%</p>
            <p className="text-xs text-muted-foreground mt-1">Proficiency gain</p>
          </div>
        </DashboardCard>
      </div>

      {/* Recommended Learning Paths */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-accent rounded-full"></div>
          Recommended for You
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg hover:shadow-elevated transition-all duration-300">
            <h4 className="font-semibold text-foreground mb-2">AI Engineering Path</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Master AI development with this curated 6-month learning journey
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">8 courses • 60 hours</span>
              <button className="text-sm text-primary hover:underline">Explore Path →</button>
            </div>
          </div>
          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg hover:shadow-elevated transition-all duration-300">
            <h4 className="font-semibold text-foreground mb-2">Technical Leadership</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Develop skills to lead engineering teams and drive innovation
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">6 courses • 40 hours</span>
              <button className="text-sm text-primary hover:underline">Explore Path →</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
