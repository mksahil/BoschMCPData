
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ArrowLeft, Plus, Trash2, Save, Server, ExternalLink, Sparkles, Loader2, ShieldCheck, Settings, Globe, Zap, Tag, Plane, Armchair, Users, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Service {
    id: string;
    name: string;
    baseUrl: string;
    description: string;
    keywords: string[];
}

interface CoreService {
    name: string;
    description: string;
    keywords: string[];
}

interface KeywordConfig {
    privacyDetection: {
        personalDataKeywords: string[];
        colleaguePatternWords: string[];
        bulkPatternPhrases: string[];
        impersonationSkipWords: string[];
        aiRewriteVerbs: string[];
    };
    travelService: {
        travelDataKeywords: string[];
        travelEntities: string[];
    };
    seatBookingService: {
        seatKeywords: string[];
    };
    communityService: {
        communityDetectionKeywords: string[];
        communityNames: string[];
        joinIntentKeywords: string[];
        listIntentPhrases: string[];
    };
    entryExitService: {
        entryExitDataKeywords: string[];
    };
}

interface FullConfig {
    coreServices: Record<string, CoreService>;
    privacyConfig: {
        nonNames: string[];
    };
    routingConfig: {
        greetingKeywords: string[];
        followUpPatterns: Record<string, string>;
        subjectKeywords: string[];
        topicKeywords: Record<string, string[]>;
    };
    keywordConfig?: KeywordConfig;
}

const Admin = () => {
    const [services, setServices] = useState<Service[]>([]);
    const [loading, setLoading] = useState(true);
    const [isAdding, setIsAdding] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);
    const [newService, setNewService] = useState<Service>({
        id: '',
        name: '',
        baseUrl: '',
        description: '',
        keywords: []
    });
    const [keywordsInput, setKeywordsInput] = useState('');
    
    // Global Config State
    const [fullConfig, setFullConfig] = useState<FullConfig | null>(null);
    const [privacyInput, setPrivacyInput] = useState('');
    const [routingInput, setRoutingInput] = useState<any>(null);
    const [savingConfig, setSavingConfig] = useState(false);

    // Keyword Config State (per-field comma strings for textareas)
    const [kwPrivacy, setKwPrivacy] = useState({
        personalDataKeywords: '',
        colleaguePatternWords: '',
        bulkPatternPhrases: '',
        impersonationSkipWords: '',
        aiRewriteVerbs: '',
    });
    const [kwTravel, setKwTravel] = useState({
        travelDataKeywords: '',
        travelEntities: '',
    });
    const [kwSeatBooking, setKwSeatBooking] = useState({ seatKeywords: '' });
    const [kwCommunity, setKwCommunity] = useState({ communityDetectionKeywords: '', communityNames: '', joinIntentKeywords: '', listIntentPhrases: '' });
    const [kwEntryExit, setKwEntryExit] = useState({ entryExitDataKeywords: '' });
    const [savingKeywords, setSavingKeywords] = useState<string | null>(null); // which section is saving
    const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);

    const { toast } = useToast();
    const navigate = useNavigate();

    const availablePlanets = [
        { id: 'gym', name: 'Gym' },
        { id: 'parking', name: 'Parking' },
        { id: 'effort', name: 'Effort' },
        { id: 'projects', name: 'Projects' },
        { id: 'meetings', name: 'Meetings' },
        { id: 'courses', name: 'Courses' },
        { id: 'certifications', name: 'Badges' },
        { id: 'blogs', name: 'Blogs' },
        { id: 'watchlist', name: 'Watchlist' },
        { id: 'music', name: 'Music' },
        { id: 'wayfinder', name: 'WayFinder' },
        { id: 'holidays', name: 'Holidays' },
    ];

    useEffect(() => {
        fetchAllData();
    }, []);

    const fetchAllData = async () => {
        setLoading(true);
        await Promise.all([
            fetchServices(),
            fetchFullConfig()
        ]);
        setLoading(false);
    };

    const fetchFullConfig = async () => {
        try {
            // [FIX #14 | Issue #17 - Hardcoded URL]: Use environment variable for API URL
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/config`);
            const data = await response.json();
            if (data.success && data.config) {
                setFullConfig(data.config);
                setPrivacyInput(data.config.privacyConfig.nonNames.join(', '));
                setRoutingInput(data.config.routingConfig);
                // Populate keyword config state
                if (data.config.keywordConfig) {
                    const kc = data.config.keywordConfig;
                    if (kc.privacyDetection) {
                        setKwPrivacy({
                            personalDataKeywords: (kc.privacyDetection.personalDataKeywords || []).join(', '),
                            colleaguePatternWords: (kc.privacyDetection.colleaguePatternWords || []).join(', '),
                            bulkPatternPhrases: (kc.privacyDetection.bulkPatternPhrases || []).join(', '),
                            impersonationSkipWords: (kc.privacyDetection.impersonationSkipWords || []).join(', '),
                            aiRewriteVerbs: (kc.privacyDetection.aiRewriteVerbs || []).join(', '),
                        });
                    }
                    if (kc.travelService) {
                        setKwTravel({
                            travelDataKeywords: (kc.travelService.travelDataKeywords || []).join(', '),
                            travelEntities: (kc.travelService.travelEntities || []).join(', '),
                        });
                    }
                    if (kc.seatBookingService) {
                        setKwSeatBooking({
                            seatKeywords: (kc.seatBookingService.seatKeywords || []).join(', '),
                        });
                    }
                    if (kc.communityService) {
                        setKwCommunity({
                            communityDetectionKeywords: (kc.communityService.communityDetectionKeywords || []).join(', '),
                            communityNames: (kc.communityService.communityNames || []).join(', '),
                            joinIntentKeywords: (kc.communityService.joinIntentKeywords || []).join(', '),
                            listIntentPhrases: (kc.communityService.listIntentPhrases || []).join(', '),
                        });
                    }
                    if (kc.entryExitService) {
                        setKwEntryExit({
                            entryExitDataKeywords: (kc.entryExitService.entryExitDataKeywords || []).join(', '),
                        });
                    }
                }
            }
        } catch (error) {
            console.error('Failed to fetch full config:', error);
        }
    };

    const handleAutoDetect = async () => {
        if (!newService.baseUrl) {
            toast({
                title: "URL Required",
                description: "Please enter an MCP URL first.",
                variant: "destructive",
            });
            return;
        }

        setAnalyzing(true);
        try {
            // [FIX #14 | Issue #17 - Hardcoded URL]: Use environment variable for API URL
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services/discover`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: newService.baseUrl }),
            });

            const data = await response.json();

            if (data.success && data.analysis) {
                setNewService(prev => ({
                    ...prev,
                    name: data.analysis.name || prev.name,
                    description: data.analysis.description || prev.description,
                    id: data.analysis.recommendedPlanetId || prev.id,
                    baseUrl: data.analysis.derivedFromUrl || prev.baseUrl
                }));

                if (data.analysis.keywords && Array.isArray(data.analysis.keywords)) {
                    setKeywordsInput(data.analysis.keywords.join(', '));
                }

                toast({
                    title: "Discovery Successful",
                    description: "Smart analysis complete! Fields have been auto-filled.",
                });
            } else {
                throw new Error(data.error || 'Discovery failed');
            }
        } catch (error) {
            console.error(error);
            toast({
                title: "Discovery Failed",
                description: "Could not analyze the MCP. Please fill details manually.",
                variant: "destructive",
            });
        } finally {
            setAnalyzing(false);
        }
    };

    const fetchServices = async () => {
        try {
            // [FIX #14 | Issue #17 - Hardcoded URL]: Use environment variable for API URL
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services`);
            const data = await response.json();
            // [FIX #15 | Rule S3923 - Redundant Cond]: Removed redundant else-if condition
            if (data.services) {
                setServices(data.services);
            } else {
                console.error("Admin: Invalid data format", data);
                toast({
                    title: "Error fetching services",
                    description: data.error || "Unknown error",
                    variant: "destructive"
                });
            }
        } catch (error) {
            console.error('Admin: Failed to fetch services:', error);
            toast({
                title: "Connection Error",
                description: "Could not connect to backend",
                variant: "destructive"
            });
        }
    };

    const handleSaveService = async () => {
        try {
            if (!newService.id || !newService.name || !newService.baseUrl) {
                toast({
                    title: "Validation Error",
                    description: "Please fill in all required fields",
                    variant: "destructive"
                });
                return;
            }

            const keywords = keywordsInput.split(',').map(k => k.trim()).filter(k => k);
            const serviceToSave = { ...newService, keywords };

            // [FIX #14 | Issue #17 - Hardcoded URL]: Use environment variable for API URL
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(serviceToSave)
            });

            const data = await response.json();
            if (data.success) {
                toast({
                    title: "Success",
                    description: "Service saved successfully"
                });
                setIsAdding(false);
                setNewService({ id: '', name: '', baseUrl: '', description: '', keywords: [] });
                setKeywordsInput('');
                fetchServices();
            } else {
                toast({
                    title: "Error saving service",
                    description: data.error,
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to save service",
                variant: "destructive"
            });
        }
    };

    const handleDeleteService = (id: string) => {
        setServiceToDelete(id);
    };

    const confirmDeleteService = async () => {
        if (!serviceToDelete) return;

        try {
            // [FIX #14 | Issue #17 - Hardcoded URL]: Use environment variable for API URL
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services/${serviceToDelete}`, {
                method: 'DELETE'
            });
            const data = await response.json();

            if (data.success) {
                toast({ title: "Service deleted" });
                fetchServices();
            } else {
                toast({
                    title: "Error",
                    description: data.error,
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to delete service",
                variant: "destructive"
            });
        } finally {
            setServiceToDelete(null);
        }
    };

    const handleUpdateCoreService = async (serviceId: string, updatedService: CoreService) => {
        setSavingConfig(true);
        try {
            const response = await fetch(`http://localhost:3001/api/admin/config/core/${serviceId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedService)
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Core Service Updated", description: `${updatedService.name} keywords saved.` });
                fetchFullConfig();
            }
        } catch (error) {
            toast({ title: "Update Failed", variant: "destructive" });
        } finally {
            setSavingConfig(false);
        }
    };

    const handleSavePrivacy = async () => {
        setSavingConfig(true);
        try {
            const nonNames = privacyInput.split(',').map(k => k.trim()).filter(k => k);
            const response = await fetch('http://localhost:3001/api/admin/config/privacy', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nonNames })
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Whitelist Saved", description: "Privacy whitelists updated across all services." });
                fetchFullConfig();
            }
        } finally {
            setSavingConfig(false);
        }
    };

    const handleSaveRouting = async () => {
        if (!routingInput) return;
        setSavingConfig(true);
        try {
            const response = await fetch('http://localhost:3001/api/admin/config/routing', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(routingInput)
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Routing Updated", description: "Global routing heuristics and follow-up patterns saved." });
                fetchFullConfig();
            }
        } catch (error) {
            toast({ title: "Save Failed", variant: "destructive" });
        } finally {
            setSavingConfig(false);
        }
    };

    // ── Keyword config save helpers ──
    const toArr = (s: string) => s.split(',').map(k => k.trim()).filter(k => k);

    const handleSaveKeywordsPrivacy = async () => {
        setSavingKeywords('privacy');
        try {
            const body = {
                personalDataKeywords: toArr(kwPrivacy.personalDataKeywords),
                colleaguePatternWords: toArr(kwPrivacy.colleaguePatternWords),
                bulkPatternPhrases: toArr(kwPrivacy.bulkPatternPhrases),
                impersonationSkipWords: toArr(kwPrivacy.impersonationSkipWords),
                aiRewriteVerbs: toArr(kwPrivacy.aiRewriteVerbs),
            };
            const res = await fetch('http://localhost:3001/api/admin/config/keywords/privacy', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Privacy Detection Keywords Saved', description: 'All privacy detection keyword lists updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsTravel = async () => {
        setSavingKeywords('travel');
        try {
            const body = {
                travelDataKeywords: toArr(kwTravel.travelDataKeywords),
                travelEntities: toArr(kwTravel.travelEntities),
            };
            const res = await fetch('http://localhost:3001/api/admin/config/keywords/travel', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Travel Keywords Saved', description: 'Travel data keywords and entities updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsSeatBooking = async () => {
        setSavingKeywords('seatbooking');
        try {
            const body = { seatKeywords: toArr(kwSeatBooking.seatKeywords) };
            const res = await fetch('http://localhost:3001/api/admin/config/keywords/seatbooking', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Seat Booking Keywords Saved', description: 'Seat booking keyword list updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsCommunity = async () => {
        setSavingKeywords('community');
        try {
            const body = {
                communityDetectionKeywords: toArr(kwCommunity.communityDetectionKeywords),
                communityNames: toArr(kwCommunity.communityNames),
                joinIntentKeywords: toArr(kwCommunity.joinIntentKeywords),
                listIntentPhrases: toArr(kwCommunity.listIntentPhrases),
            };
            const res = await fetch('http://localhost:3001/api/admin/config/keywords/community', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Community Keywords Saved', description: 'Community keyword lists updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsEntryExit = async () => {
        setSavingKeywords('entryexit');
        try {
            const body = { entryExitDataKeywords: toArr(kwEntryExit.entryExitDataKeywords) };
            const res = await fetch('http://localhost:3001/api/admin/config/keywords/entryexit', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Entry/Exit Keywords Saved', description: 'Entry/Exit keyword list updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    return (
        <div className="min-h-screen bg-slate-50 p-8">
            <div className="max-w-5xl mx-auto space-y-8">
                
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" onClick={() => navigate('/')}>
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Bosch AI Admin</h1>
                            <p className="text-slate-500">Unified configuration for services, keywords, and privacy</p>
                        </div>
                    </div>
                </div>

                <Tabs defaultValue="dynamic" className="w-full">
                    <TabsList className="grid w-full grid-cols-5 mb-8 bg-white border shadow-sm">
                        <TabsTrigger value="dynamic" className="flex items-center gap-2">
                            <Globe className="h-4 w-4" /> Dynamic MCPs
                        </TabsTrigger>
                        <TabsTrigger value="core" className="flex items-center gap-2">
                            <Settings className="h-4 w-4" /> Core Services
                        </TabsTrigger>
                        <TabsTrigger value="privacy" className="flex items-center gap-2">
                            <ShieldCheck className="h-4 w-4" /> Privacy Settings
                        </TabsTrigger>
                        <TabsTrigger value="keywords" className="flex items-center gap-2">
                            <Tag className="h-4 w-4" /> Keywords
                        </TabsTrigger>
                        <TabsTrigger value="routing" className="flex items-center gap-2">
                            <Zap className="h-4 w-4" /> Advanced Routing
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="dynamic" className="space-y-6">
                        <div className="flex justify-between items-center decoration-slate-200">
                             <h2 className="text-xl font-semibold text-slate-800">External MCP Services</h2>
                             <Button onClick={() => setIsAdding(true)} variant="default" className="bg-blue-600 hover:bg-blue-700">
                                <Plus className="h-4 w-4 mr-2" /> Add Service
                            </Button>
                        </div>

                        {isAdding && (
                            <Card className="border-blue-200 bg-blue-50/30 shadow-md">
                                <CardHeader>
                                    <CardTitle>Add New MCP Service</CardTitle>
                                    <CardDescription>Configure a new dynamic service planet</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                     <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Planet Category</Label>
                                            <select 
                                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                                value={newService.id}
                                                onChange={(e) => {
                                                    const planet = availablePlanets.find(p => p.id === e.target.value);
                                                    setNewService({ ...newService, id: e.target.value, name: planet ? `${planet.name} Assistant` : '' })
                                                }}
                                            >
                                                <option value="">Select a Planet...</option>
                                                {availablePlanets.map(planet => (
                                                    <option key={planet.id} value={planet.id}>{planet.name}</option>
                                                ))}
                                                <option value="custom">Custom ID...</option>
                                            </select>
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Service Name</Label>
                                            <Input 
                                                value={newService.name}
                                                onChange={(e) => setNewService({...newService, name: e.target.value})}
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Server URL</Label>
                                        <div className="flex gap-2">
                                            <Input 
                                                className="font-mono text-xs"
                                                value={newService.baseUrl}
                                                onChange={(e) => setNewService({...newService, baseUrl: e.target.value})}
                                                placeholder="https://..."
                                            />
                                            <Button variant="secondary" onClick={handleAutoDetect} disabled={analyzing}>
                                                {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                                            </Button>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Keywords</Label>
                                        <Input 
                                            value={keywordsInput}
                                            onChange={(e) => setKeywordsInput(e.target.value)}
                                            placeholder="comma separated keywords"
                                        />
                                    </div>
                                </CardContent>
                                <CardFooter className="flex justify-end gap-2">
                                    <Button variant="ghost" onClick={() => setIsAdding(false)}>Cancel</Button>
                                    <Button onClick={handleSaveService}>Save Connection</Button>
                                </CardFooter>
                            </Card>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {services.map(service => (
                                <Card key={service.id} className="bg-white hover:shadow-md transition-shadow border-slate-200">
                                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                        <div>
                                            <CardTitle className="text-lg text-slate-800">{service.name}</CardTitle>
                                            <Badge variant="outline" className="mt-1 text-slate-500">{service.id}</Badge>
                                        </div>
                                        <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-500" onClick={() => handleDeleteService(service.id)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-sm text-slate-500 mb-3">{service.description}</p>
                                        <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 mb-4 bg-slate-50 p-2 rounded">
                                            <Server className="h-3 w-3" /> {service.baseUrl}
                                        </div>
                                        <div className="flex flex-wrap gap-1">
                                            {service.keywords && service.keywords.map(k => (
                                                <Badge key={k} variant="secondary" className="text-[10px] bg-slate-100 text-slate-600 border-none">{k}</Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="core" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Core Services Routing</h2>
                            <Badge variant="secondary" className="bg-blue-100 text-blue-700 border-none">System Built-in</Badge>
                        </div>
                        
                        {!fullConfig ? (
                            <div className="text-center py-10"><Loader2 className="animate-spin h-8 w-8 mx-auto text-slate-300" /></div>
                        ) : (
                            <div className="space-y-4">
                                {Object.entries(fullConfig.coreServices).map(([id, s]) => (
                                    <Card key={id} className="bg-white border-slate-200">
                                        <CardContent className="pt-6 space-y-4">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-xl">
                                                        {id === 'canteen' ? '🍴' : id === 'entryexit' ? '⏰' : id === 'travel' ? '✈️' : id === 'seatbooking' ? '💺' : id === 'community' ? '👥' : '📋'}
                                                    </div>
                                                    <div>
                                                        <h3 className="font-bold text-slate-800">{s.name}</h3>
                                                        <p className="text-xs text-slate-400 uppercase tracking-wider">{id}</p>
                                                    </div>
                                                </div>
                                                <Button 
                                                    size="sm" 
                                                    variant="outline" 
                                                    onClick={() => handleUpdateCoreService(id, fullConfig.coreServices[id])}
                                                    disabled={savingConfig}
                                                >
                                                    {savingConfig ? <Loader2 className="animate-spin h-4 w-4" /> : <Save className="h-4 w-4 mr-2" />} Save
                                                </Button>
                                            </div>
                                            
                                            <div className="grid grid-cols-1 gap-4">
                                                <div className="space-y-2">
                                                    <Label className="text-xs font-semibold text-slate-500 uppercase">Description (Impacts AI Routing)</Label>
                                                    <Input 
                                                        value={s.description} 
                                                        onChange={(e) => {
                                                            const newServices = { ...fullConfig.coreServices };
                                                            newServices[id] = { ...s, description: e.target.value };
                                                            setFullConfig({ ...fullConfig, coreServices: newServices });
                                                        }}
                                                    />
                                                </div>
                                                <div className="space-y-2">
                                                    <Label className="text-xs font-semibold text-slate-500 uppercase">Routing Keywords</Label>
                                                    <Textarea 
                                                        value={s.keywords.join(', ')} 
                                                        className="min-h-[60px] text-sm"
                                                        onChange={(e) => {
                                                            const newKeywords = e.target.value.split(',').map(k => k.trim());
                                                            const newServices = { ...fullConfig.coreServices };
                                                            newServices[id] = { ...s, keywords: newKeywords };
                                                            setFullConfig({ ...fullConfig, coreServices: newServices });
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="privacy" className="space-y-6">
                        <Card className="bg-white border-slate-200">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <ShieldCheck className="h-5 w-5 text-green-600" />
                                    Privacy Guard Whitelist
                                </CardTitle>
                                <CardDescription>
                                    Define keywords that should NOT be treated as colleague names. This prevents false positives in the privacy guard for words like "confirmed", "today", or "bangalore".
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="p-4 bg-orange-50 border border-orange-100 rounded-md">
                                    <p className="text-sm text-orange-800">
                                        <strong>How it works:</strong> If a user query contains a word in this list, the Bosch AI assistant will 
                                        <em> ignore</em> it when searching for potential colleague names.
                                    </p>
                                </div>
                                <div className="space-y-2">
                                    <Label>Global Whitelist (Comma-separated)</Label>
                                    <Textarea 
                                        className="min-h-[300px] font-mono text-sm leading-relaxed"
                                        value={privacyInput}
                                        onChange={(e) => setPrivacyInput(e.target.value)}
                                        placeholder="Enter keywords separated by commas..."
                                    />
                                </div>
                                <div className="flex items-center gap-2 text-xs text-slate-400">
                                    <Badge variant="secondary" className="bg-slate-100 text-slate-500 border-none font-normal">
                                        Total Keywords: {privacyInput.split(',').filter(k => k.trim()).length}
                                    </Badge>
                                    <span>Tip: Keep generic locations, common verbs, and confirmation words here.</span>
                                </div>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button 
                                    className="bg-green-600 hover:bg-green-700" 
                                    onClick={handleSavePrivacy}
                                    disabled={savingConfig}
                                >
                                    {savingConfig ? (
                                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                                    ) : (
                                        <><Save className="h-4 w-4 mr-2" /> Save Whitelist</>
                                    )}
                                </Button>
                            </CardFooter>
                        </Card>
                    </TabsContent>
                    {/* ════════════ KEYWORDS TAB ════════════ */}
                    <TabsContent value="keywords" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Keyword Management</h2>
                            <Badge variant="secondary" className="bg-indigo-100 text-indigo-700 border-none">Centralised Config</Badge>
                        </div>
                        <p className="text-sm text-slate-500 -mt-4">
                            These keyword lists power the privacy guard, service routing, and entity recognition across all services.
                            Changes take effect immediately after saving.
                        </p>

                        {/* ── Card 1: Privacy Detection ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <ShieldCheck className="h-5 w-5 text-orange-500" /> Privacy Detection Keywords
                                </CardTitle>
                                <CardDescription>Keywords used by the privacy guard to detect personal data queries, colleague references, and bulk data requests.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="p-3 bg-orange-50 border border-orange-100 rounded-md mb-4">
                                    <p className="text-xs text-orange-700">
                                        <strong>Note:</strong> Some entries support regex syntax (e.g. <code className="bg-orange-100 px-1 rounded">check.?in</code>).
                                        Phrases with spaces (e.g. <code className="bg-orange-100 px-1 rounded">team mate</code>) are auto-converted to flexible patterns.
                                    </p>
                                </div>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="personalDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Personal Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.personalDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that indicate a query is about personal/sensitive data (attendance, salary, etc.)</p>
                                            <Textarea className="min-h-[100px] font-mono text-xs" value={kwPrivacy.personalDataKeywords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, personalDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="colleaguePatternWords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Colleague Pattern Words
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.colleaguePatternWords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that indicate the query is about another person (friend, boss, colleague, etc.)</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwPrivacy.colleaguePatternWords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, colleaguePatternWords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="bulkPatternPhrases">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Bulk Request Patterns
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.bulkPatternPhrases).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Phrases that indicate a request for bulk/collective employee data (all employees, team attendance, etc.)</p>
                                            <Textarea className="min-h-[100px] font-mono text-xs" value={kwPrivacy.bulkPatternPhrases}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, bulkPatternPhrases: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="impersonationSkipWords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Impersonation Skip Words
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.impersonationSkipWords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words after "I am..." that are NOT person names (looking, checking, etc.) to avoid false impersonation flags.</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwPrivacy.impersonationSkipWords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, impersonationSkipWords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="aiRewriteVerbs">
                                        <AccordionTrigger className="text-sm font-medium">
                                            AI Rewrite Verbs
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.aiRewriteVerbs).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Verbs/descriptors the AI may introduce when rewriting queries (provide, retrieve, comprehensive, etc.). Prevents false-positive name detection on AI-generated words.</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwPrivacy.aiRewriteVerbs}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, aiRewriteVerbs: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-orange-600 hover:bg-orange-700" onClick={handleSaveKeywordsPrivacy} disabled={savingKeywords === 'privacy'}>
                                    {savingKeywords === 'privacy' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Privacy Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 2: Travel Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Plane className="h-5 w-5 text-blue-500" /> Travel Service Keywords
                                </CardTitle>
                                <CardDescription>Keywords and entity lists for the travel booking service privacy guard.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="p-3 bg-blue-50 border border-blue-100 rounded-md mb-4">
                                    <p className="text-xs text-blue-700">
                                        <strong>Travel Entities</strong> prevent false-positive name detection for airlines, hotels, cities, and transport terms.
                                        Add new cities or airlines here instead of editing source code.
                                    </p>
                                </div>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="travelDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Travel Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwTravel.travelDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate a travel-related query (travel, trip, flight, etc.)</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwTravel.travelDataKeywords}
                                                onChange={(e) => setKwTravel({ ...kwTravel, travelDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="travelEntities">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Travel Entities (Airlines, Hotels, Cities, etc.)
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwTravel.travelEntities).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Proper nouns that are NOT person names: airline names, hotel chains, city names, transport terms, booking platforms.</p>
                                            <Textarea className="min-h-[200px] font-mono text-xs" value={kwTravel.travelEntities}
                                                onChange={(e) => setKwTravel({ ...kwTravel, travelEntities: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleSaveKeywordsTravel} disabled={savingKeywords === 'travel'}>
                                    {savingKeywords === 'travel' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Travel Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 3: Seat Booking Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Armchair className="h-5 w-5 text-purple-500" /> Seat Booking Keywords
                                </CardTitle>
                                <CardDescription>Keywords for the seat/desk booking service privacy guard gate.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="seatKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Seat Booking Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwSeatBooking.seatKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate a seat/desk booking query (seat, desk, booking, etc.)</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwSeatBooking.seatKeywords}
                                                onChange={(e) => setKwSeatBooking({ seatKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-purple-600 hover:bg-purple-700" onClick={handleSaveKeywordsSeatBooking} disabled={savingKeywords === 'seatbooking'}>
                                    {savingKeywords === 'seatbooking' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Seat Booking Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 4: Community Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Users className="h-5 w-5 text-green-500" /> Community Keywords
                                </CardTitle>
                                <CardDescription>Detection keywords, community names, join & list intent phrases for the community service.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="communityDetection">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Detection Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.communityDetectionKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that identify a query as community-related (community, communities, associate arena).</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwCommunity.communityDetectionKeywords}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, communityDetectionKeywords: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="communityNames">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Community Names
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.communityNames).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Known community names (Mind Buddies, Art in Motion, Cyco, etc.). These bypass the privacy guard and trigger community routing.</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwCommunity.communityNames}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, communityNames: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="joinIntent">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Join Intent Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.joinIntentKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words indicating the user wants to join/register for a community.</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwCommunity.joinIntentKeywords}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, joinIntentKeywords: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="listIntent">
                                        <AccordionTrigger className="text-sm font-medium">
                                            List Intent Phrases
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.listIntentPhrases).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Phrases that trigger showing all communities (show all, list all, all communities, etc.).</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwCommunity.listIntentPhrases}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, listIntentPhrases: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-green-600 hover:bg-green-700" onClick={handleSaveKeywordsCommunity} disabled={savingKeywords === 'community'}>
                                    {savingKeywords === 'community' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Community Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 5: Entry/Exit Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Clock className="h-5 w-5 text-teal-500" /> Entry/Exit Keywords
                                </CardTitle>
                                <CardDescription>Data keywords for the entry/exit time tracking privacy guard gate.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="entryExitDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Entry/Exit Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwEntryExit.entryExitDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate entry/exit personal data (entry, exit, swipe, attendance, etc.).</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwEntryExit.entryExitDataKeywords}
                                                onChange={(e) => setKwEntryExit({ entryExitDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-teal-600 hover:bg-teal-700" onClick={handleSaveKeywordsEntryExit} disabled={savingKeywords === 'entryexit'}>
                                    {savingKeywords === 'entryexit' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Entry/Exit Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>
                    </TabsContent>

                    <TabsContent value="routing" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Advanced Routing & Context</h2>
                            <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 border-none">Expert Only</Badge>
                        </div>

                        {!routingInput ? (
                            <div className="text-center py-10"><Loader2 className="animate-spin h-8 w-8 mx-auto text-slate-300" /></div>
                        ) : (
                            <div className="space-y-6">
                                <Card className="bg-white border-slate-200 shadow-sm">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Globe className="h-4 w-4 text-blue-500" /> Greeting Keywords
                                        </CardTitle>
                                        <CardDescription>Keywords that trigger the "general" assistant response (concconcatenated by OR logic).</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Textarea 
                                            value={routingInput.greetingKeywords.join(', ')}
                                            className="min-h-[100px] font-mono text-sm"
                                            onChange={(e) => setRoutingInput({
                                                ...routingInput,
                                                greetingKeywords: e.target.value.split(',').map(k => k.trim()).filter(k => k)
                                            })}
                                        />
                                    </CardContent>
                                </Card>

                                <Card className="bg-white border-slate-200 shadow-sm">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Sparkles className="h-4 w-4 text-purple-500" /> Subject Recognition
                                        </CardTitle>
                                        <CardDescription>Advanced: Keywords used to detect if a short query has a specific subject. Impacts follow-up logic.</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Textarea 
                                            value={routingInput.subjectKeywords.join(', ')}
                                            className="min-h-[100px] font-mono text-sm"
                                            onChange={(e) => setRoutingInput({
                                                ...routingInput,
                                                subjectKeywords: e.target.value.split(',').map(k => k.trim()).filter(k => k)
                                            })}
                                        />
                                    </CardContent>
                                </Card>

                                <Card className="bg-slate-900 text-white border-none shadow-lg">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Save className="h-4 w-4" /> Persist Heuristics
                                        </CardTitle>
                                        <CardDescription className="text-slate-400">These changes affect global conversation context and routing accuracy.</CardDescription>
                                    </CardHeader>
                                    <CardFooter className="pt-0">
                                        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold" onClick={handleSaveRouting} disabled={savingConfig}>
                                            {savingConfig ? (
                                                <><Loader2 className="animate-spin mr-2 h-4 w-4" /> Updating System...</>
                                            ) : (
                                                <><Save className="mr-2 h-4 w-4" /> Update Routing Engine</>
                                            )}
                                        </Button>
                                    </CardFooter>
                                </Card>
                            </div>
                        )}
                    </TabsContent>
                </Tabs>

                <AlertDialog open={!!serviceToDelete} onOpenChange={(open) => !open && setServiceToDelete(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the MCP service configuration from the system.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setServiceToDelete(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDeleteService} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete Service</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </div>
        </div>
    );
};

export default Admin;
