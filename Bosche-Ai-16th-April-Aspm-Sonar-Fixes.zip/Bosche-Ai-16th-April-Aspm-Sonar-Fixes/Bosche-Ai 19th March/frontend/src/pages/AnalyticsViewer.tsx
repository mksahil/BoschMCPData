import { useState, useEffect } from "react";
import { BarChart2, Activity, TrendingUp, Users, Clock, MousePointer } from "lucide-react";
import analyticsDashboard from "@/lib/analytics-dashboard";
import { format } from "date-fns";
import { API_ENDPOINTS } from "@/config";

interface AnalyticsData {
  summary: any;
  sessions: any[];
  behavior: any;
}

export const AnalyticsViewer = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));

  const fetchLogsAndAnalyze = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_ENDPOINTS.logs}?date=${selectedDate}&limit=1000`);
      const data = await response.json();
      const logData = data.logs || [];
      setLogs(logData);
      
      // Generate analytics
      const report = analyticsDashboard.generateReport(logData);
      setAnalytics(report);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogsAndAnalyze();
    const interval = setInterval(fetchLogsAndAnalyze, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, [selectedDate]);

  const formatDuration = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  if (loading && !analytics) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-12 h-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Analyzing user behavior...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-card rounded-xl shadow-elevated p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <BarChart2 className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">Analytics Dashboard</h1>
            </div>
            <div className="flex items-center gap-4">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-3 py-2 bg-secondary rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        {analytics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-card rounded-xl p-6 shadow-card">
              <div className="flex items-center justify-between mb-4">
                <Users className="w-10 h-10 text-primary bg-primary/10 p-2 rounded-lg" />
                <span className="text-2xl font-bold text-foreground">{analytics.summary.totalSessions}</span>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground">Active Sessions</h3>
              <p className="text-xs text-muted-foreground mt-1">Unique user sessions today</p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-card">
              <div className="flex items-center justify-between mb-4">
                <Activity className="w-10 h-10 text-success bg-success/10 p-2 rounded-lg" />
                <span className="text-2xl font-bold text-foreground">{analytics.summary.totalActions}</span>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground">Total Actions</h3>
              <p className="text-xs text-muted-foreground mt-1">{analytics.summary.averageActionsPerSession.toFixed(1)} per session</p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-card">
              <div className="flex items-center justify-between mb-4">
                <Clock className="w-10 h-10 text-info bg-info/10 p-2 rounded-lg" />
                <span className="text-2xl font-bold text-foreground">
                  {formatDuration(analytics.summary.averageSessionDuration)}
                </span>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground">Avg Session Time</h3>
              <p className="text-xs text-muted-foreground mt-1">User engagement duration</p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-card">
              <div className="flex items-center justify-between mb-4">
                <MousePointer className="w-10 h-10 text-warning bg-warning/10 p-2 rounded-lg" />
                <span className="text-2xl font-bold text-foreground">{analytics.summary.totalButtonClicks}</span>
              </div>
              <h3 className="text-sm font-medium text-muted-foreground">Button Clicks</h3>
              <p className="text-xs text-muted-foreground mt-1">{analytics.summary.totalChatMessages} chat messages</p>
            </div>
          </div>
        )}

        {/* Activity Timeline */}
        {analytics && (
          <div className="bg-card rounded-xl p-6 shadow-card">
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Activity Timeline
            </h2>
            <div className="h-64 relative">
              <div className="absolute inset-0 flex items-end justify-between gap-1">
                {analytics.behavior.peakActivityTimes.map((time) => {
                  const maxCount = Math.max(...analytics.behavior.peakActivityTimes.map(t => t.count));
                  const height = (time.count / maxCount) * 100;
                  
                  return (
                    <div key={time.hour} className="flex-1 flex flex-col items-center">
                      <div className="relative w-full group">
                        <div
                          className="bg-primary hover:bg-primary/80 transition-all duration-300 rounded-t"
                          style={{ height: `${height}%` }}
                        />
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-popover text-popover-foreground px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                          {time.count} actions
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground mt-1">{time.hour}h</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Popular Features & Common Paths */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Popular Features */}
          {analytics && (
            <div className="bg-card rounded-xl p-6 shadow-card">
              <h2 className="text-lg font-semibold text-foreground mb-4">Popular Features</h2>
              <div className="space-y-3">
                {analytics.behavior.popularFeatures.slice(0, 10).map((feature, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="text-sm text-foreground">{feature.feature}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-secondary rounded-full h-2 overflow-hidden">
                        <div
                          className="h-full bg-primary"
                          style={{
                            width: `${(feature.count / analytics.behavior.popularFeatures[0].count) * 100}%`
                          }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-10 text-right">{feature.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Common Navigation Paths */}
          {analytics && (
            <div className="bg-card rounded-xl p-6 shadow-card">
              <h2 className="text-lg font-semibold text-foreground mb-4">Common Navigation Paths</h2>
              <div className="space-y-3">
                {analytics.behavior.commonPaths.slice(0, 10).map((path, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      {path.path.map((page, i) => (
                        <span key={i} className="flex items-center gap-1">
                          <span className="text-foreground">{page}</span>
                          {i < path.path.length - 1 && <span className="text-muted-foreground">→</span>}
                        </span>
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">{path.count} times</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Session Details */}
        {analytics && (
          <div className="bg-card rounded-xl p-6 shadow-card">
            <h2 className="text-lg font-semibold text-foreground mb-4">Recent Sessions</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {/* [FIX #16 | Rule S6816 - Table Headers]: Added scope="col" to table headers for accessibility */}
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Session ID</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Start Time</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Duration</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Actions</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Pages</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Chats</th>
                    <th scope="col" className="text-left py-3 px-2 font-medium text-foreground">Most Visited</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {analytics.sessions.slice(-10).reverse().map((session, idx) => (
                    <tr key={idx} className="hover:bg-secondary/50 transition-colors">
                      <td className="py-3 px-2 text-xs text-muted-foreground">
                        {session.sessionId.substring(0, 15)}...
                      </td>
                      <td className="py-3 px-2 text-xs text-foreground">
                        {format(new Date(session.startTime), 'HH:mm:ss')}
                      </td>
                      <td className="py-3 px-2 text-xs text-foreground">
                        {formatDuration(session.activeDuration)}
                      </td>
                      <td className="py-3 px-2 text-xs text-foreground">{session.totalActions}</td>
                      <td className="py-3 px-2 text-xs text-foreground">{session.pageViews}</td>
                      <td className="py-3 px-2 text-xs text-foreground">{session.chatMessages}</td>
                      <td className="py-3 px-2 text-xs text-muted-foreground">{session.mostVisitedPage}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
