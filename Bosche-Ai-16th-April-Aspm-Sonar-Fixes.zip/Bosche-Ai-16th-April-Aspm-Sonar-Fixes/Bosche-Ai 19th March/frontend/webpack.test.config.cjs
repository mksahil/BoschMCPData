const path = require('path');
const webpack = require('webpack');

module.exports = {
  mode: 'development',
  devtool: 'inline-source-map',
  resolve: {
    extensions: ['.ts', '.tsx', '.js', '.jsx'],
    alias: {
      // Resolve @ imports to src/
      '@': path.resolve(__dirname, 'src'),
      // Replace MSAL-dependent service with a no-op mock during tests
      '@/services/azureAuthService': path.resolve(
        __dirname,
        'tests/setup/mocks/azureAuthService.mock.ts'
      ),
    },
  },
  optimization: {
    splitChunks: false,
  },
  module: {
    rules: [
      {
        test: /\.(ts|tsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', { targets: { browsers: ['last 2 Chrome versions'] } }],
              ['@babel/preset-react', { runtime: 'automatic' }],
              '@babel/preset-typescript',
            ],
            plugins: [
              [
                'istanbul',
                {
                  // Only instrument source files, not specs or mocks
                  exclude: ['tests/**'],
                },
              ],
            ],
          },
        },
      },
      {
        // Ignore CSS — not needed for unit tests
        test: /\.css$/,
        use: 'null-loader',
      },
      {
        // Inline binary assets
        test: /\.(svg|png|jpg|gif|woff|woff2|eot|ttf)$/,
        type: 'asset/inline',
      },
    ],
  },
  plugins: [
    // Polyfill Vite's import.meta.env for webpack
    new webpack.DefinePlugin({
      'import.meta.env': JSON.stringify({
        PROD: false,
        DEV: true,
        BASE_URL: '/',
        MODE: 'development',
        VITE_AZURE_CLIENT_ID: 'test-client-id',
        VITE_AZURE_TENANT_ID: 'test-tenant-id',
        VITE_EXCHANGE_TOKEN_URL: 'https://test.example.com/exchange',
      }),
    }),
  ],
};
