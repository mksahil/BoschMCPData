import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const lcovPath = path.join(__dirname, 'coverage', 'lcov.info');

if (fs.existsSync(lcovPath)) {
  let content = fs.readFileSync(lcovPath, 'utf8');
  
  // Replace SF: (source file) paths with absolute paths so SonarQube can map them correctly
  content = content.replace(/^SF:(.*)$/gm, (match, relativePath) => {
    // Generate absolute path based on frontend directory
    const absolutePath = path.resolve(__dirname, relativePath).replace(/\\/g, '/');
    return `SF:${absolutePath}`;
  });
  
  fs.writeFileSync(lcovPath, content, 'utf8');
  console.log('✅ Successfully fixed coverage paths to absolute for SonarQube');
} else {
  console.log('⚠️ lcov.info not found, skipping path fix');
}
