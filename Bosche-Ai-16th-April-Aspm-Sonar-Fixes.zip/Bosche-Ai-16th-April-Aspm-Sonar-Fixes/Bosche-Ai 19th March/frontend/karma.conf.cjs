module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine'],
    files: [
      { pattern: 'tests/setup/spec-helper.ts', watched: false },
      { pattern: 'tests/**/*.spec.ts', watched: false },
      { pattern: 'tests/**/*.spec.tsx', watched: false },
    ],
    preprocessors: {
      'tests/setup/spec-helper.ts': ['webpack', 'sourcemap'],
      'tests/**/*.spec.ts': ['webpack', 'sourcemap'],
      'tests/**/*.spec.tsx': ['webpack', 'sourcemap'],
    },
    webpack: require('./webpack.test.config.cjs'),
    reporters: ['spec', 'coverage'],
    coverageReporter: {
      type: 'lcov',
      dir: 'coverage',
      subdir: '.',
      file: 'lcov.info',
    },
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: false,
    browsers: ['ChromeHeadless'],
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox', '--disable-gpu'],
      },
    },
    // Prevent disconnects on large bundles
    browserNoActivityTimeout: 120000,
    browserDisconnectTimeout: 20000,
    pingTimeout: 20000,
    browserDisconnectTolerance: 3,
    singleRun: true,
    concurrency: Infinity,
  });
};
