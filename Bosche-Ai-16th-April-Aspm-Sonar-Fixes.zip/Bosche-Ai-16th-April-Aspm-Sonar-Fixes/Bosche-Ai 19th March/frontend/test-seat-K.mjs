import https from 'https';
import fs from 'fs';

const employeeNumber = 34835634; // NUMERIC

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-K',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-K',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN', // In the real app, this will be the JWT
        session_id: 'test-session-K'
      },
      // Candidate K: user_data with NUMERIC employee_id and NO mode markers
      user_data: {
        employee_id: employeeNumber,
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      },
      employee_id: employeeNumber,
      user_id: String(employeeNumber)
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
};

console.log('Calling A2A Seat Booking Agent (Candidate K Numeric ID)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-K.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-K.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
