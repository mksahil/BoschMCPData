# MyBGSW.AI - Azure Deployment Guide v2.0

**Release Date:** December 7, 2025  
**Version:** 2.0.0

---

## 📋 Release Summary

This release includes:
- ✅ Unified AI Chat with smart routing to multiple MCP services
- ✅ Integration with 6 deployed MCP/A2A services
- ✅ Bosch Arena SSO Authentication
- ✅ Solar System UI with active/inactive planet states
- ✅ Banner image display in chat
- ✅ Entry/Exit time tracking
- ✅ Community explorer

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              AZURE CLOUD                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────┐         ┌────────────────────┐                      │
│  │  Azure Static      │  HTTPS  │  Azure App Service │                      │
│  │  Web Apps          │────────▶│  (Backend API)     │                      │
│  │                    │         │                    │                      │
│  │  React + Vite      │         │  Node.js/Express   │                      │
│  │  Port: 443         │         │  Port: 3001/8080   │                      │
│  └────────────────────┘         └─────────┬──────────┘                      │
│                                           │                                  │
│                    ┌──────────────────────┼──────────────────────┐          │
│                    │                      │                      │          │
│         ┌──────────▼──────────┐ ┌────────▼────────┐ ┌───────────▼────────┐ │
│         │ Canteen MCP         │ │ Entry/Exit MCP  │ │ Community MCP      │ │
│         │ Azure App Service   │ │ Azure App Svc   │ │ Azure App Service  │ │
│         │ mcp-canteen-dev     │ │ mcp-entry-exit  │ │ comunitymcpserver  │ │
│         └─────────────────────┘ └─────────────────┘ └────────────────────┘ │
│                                                                              │
│         ┌─────────────────────┐ ┌─────────────────────────────────────────┐ │
│         │ Banner MCP          │ │         A2A AGENTS (Container Apps)    │ │
│         │ Azure App Service   │ │  ┌─────────────┐  ┌─────────────────┐  │ │
│         │ banner-mcp-dev-001  │ │  │ Travel A2A  │  │ Seat Booking    │  │ │
│         └─────────────────────┘ │  │ Host Agent  │  │ A2A Host Agent  │  │ │
│                                 │  └─────────────┘  └─────────────────┘  │ │
│                                 └─────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔌 Service Endpoints (Current Deployments)

| Service | URL | Protocol | Status |
|---------|-----|----------|--------|
| **Canteen MCP** | `https://mcp-canteen-dev.azurewebsites.net` | HTTP/MCP | ✅ Working (no data) |
| **Entry/Exit MCP** | `https://mcp-entry-exit-dev.azurewebsites.net/mcp` | MCP | ✅ Working |
| **Community MCP** | `https://my-bgsw-ai-comunitymcpserver-dev-001.azurewebsites.net/mcp` | MCP | ✅ Working |
| **Banner MCP** | `https://my-bgsw-ai-banner-mcp-dev-001.azurewebsites.net/mcp` | MCP | ✅ Working |
| **Travel A2A** | `https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io` | A2A/JSON-RPC | ⚠️ Agent responds, no MCP tools |
| **Seat Booking A2A** | `https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io` | A2A/JSON-RPC | ⚠️ Agent responds, no MCP tools |

---

## 📦 What Gets Deployed

### 1. Frontend (Azure Static Web Apps)
- **Source:** `frontend/` directory
- **Build Output:** `frontend/dist/`
- **Framework:** React + Vite + TypeScript
- **Key Features:**
  - Solar System UI with planet navigation
  - Chat window with AI assistant
  - Bosch Arena SSO login
  - Banner image rendering
  - Active/inactive service indicators

### 2. Backend (Azure App Service)
- **Source:** `backend/` directory
- **Runtime:** Node.js 18 LTS
- **Framework:** Express.js
- **Key Features:**
  - Unified `/api/chat` endpoint with AI routing
  - MCP client connections to all services
  - A2A protocol support for Travel/Seat Booking
  - Session management
  - Activity logging

---

## 🚀 Deployment Steps

### Prerequisites
```bash
# Install Azure CLI
winget install Microsoft.AzureCLI

# Login to Azure
az login

# Set subscription
az account set --subscription "<SUBSCRIPTION_ID>"
```

### Step 1: Create Resource Group
```bash
az group create \
  --name myBGSW-AI-RG \
  --location southindia
```

### Step 2: Deploy Backend (Azure App Service)

```bash
# Create App Service Plan
az appservice plan create \
  --name myBGSW-AI-Plan \
  --resource-group myBGSW-AI-RG \
  --sku B1 \
  --is-linux

# Create Web App for Backend
az webapp create \
  --resource-group myBGSW-AI-RG \
  --plan myBGSW-AI-Plan \
  --name mybgsw-ai-backend \
  --runtime "NODE:18-lts"

# Configure environment variables
az webapp config appsettings set \
  --resource-group myBGSW-AI-RG \
  --name mybgsw-ai-backend \
  --settings \
    PORT="8080" \
    NODE_ENV="production" \
    OPENAI_API_KEY="<YOUR_OPENAI_KEY>" \
    CANTEEN_MCP_URL="https://mcp-canteen-dev.azurewebsites.net" \
    ENTRYEXIT_MCP_URL="https://mcp-entry-exit-dev.azurewebsites.net/mcp" \
    COMMUNITY_MCP_URL="https://my-bgsw-ai-comunitymcpserver-dev-001.azurewebsites.net/mcp" \
    BANNER_MCP_URL="https://my-bgsw-ai-banner-mcp-dev-001.azurewebsites.net/mcp" \
    TRAVEL_MCP_URL="https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io" \
    SEATBOOKING_MCP_URL="https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io" \
    BOSCH_CLIENT_ID="BE3B36B4-ED49-490E-94BB-7F34E86499BF" \
    BOSCH_SERVICE_USERNAME="<SERVICE_ACCOUNT>" \
    BOSCH_SERVICE_PASSWORD="<ENCRYPTED_PASSWORD>" \
    BOSCH_DEVICE_TOKEN="<DEVICE_TOKEN>"
```

#### Deploy Backend Code

**Option A: ZIP Deploy**
```bash
cd backend
npm install --production

# Create deployment package (PowerShell)
Compress-Archive -Path * -DestinationPath backend.zip -Force

# Deploy
az webapp deployment source config-zip \
  --resource-group myBGSW-AI-RG \
  --name mybgsw-ai-backend \
  --src backend.zip
```

**Option B: GitHub Actions (Recommended)**

The repository includes `.github/workflows/main_mybgswai.yml` for automated deployment.

### Step 3: Deploy Frontend (Azure Static Web Apps)

#### Update Frontend Config

Edit `frontend/src/config.ts`:
```typescript
const API_BASE_URL = import.meta.env.PROD 
  ? 'https://mybgsw-ai-backend.azurewebsites.net'
  : 'http://localhost:3001';

export const API_ENDPOINTS = {
  chat: `${API_BASE_URL}/api/chat`,
  canteenQuery: `${API_BASE_URL}/api/canteen/query`,
  health: `${API_BASE_URL}/api/health`,
  // ... other endpoints
};
```

#### Create Static Web App

```bash
# Create Static Web App
az staticwebapp create \
  --name mybgsw-ai-frontend \
  --resource-group myBGSW-AI-RG \
  --source https://github.com/<YOUR_ORG>/mybgs-companion \
  --branch main \
  --app-location "frontend" \
  --output-location "dist" \
  --login-with-github
```

#### Build and Deploy Manually

```bash
cd frontend
npm install
npm run build

# The dist/ folder contains the static files to deploy
```

---

## 🔧 Environment Variables

### Backend Required Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `PORT` | Server port (use 8080 for Azure) | ✅ |
| `OPENAI_API_KEY` | OpenAI API key for AI routing | ✅ |
| `CANTEEN_MCP_URL` | Canteen MCP server URL | ✅ |
| `ENTRYEXIT_MCP_URL` | Entry/Exit MCP server URL | ✅ |
| `COMMUNITY_MCP_URL` | Community MCP server URL | ✅ |
| `BANNER_MCP_URL` | Banner MCP server URL | ✅ |
| `TRAVEL_MCP_URL` | Travel A2A agent URL | ✅ |
| `SEATBOOKING_MCP_URL` | Seat Booking A2A agent URL | ✅ |
| `BOSCH_CLIENT_ID` | Bosch Arena client ID | ✅ |
| `BOSCH_SERVICE_USERNAME` | Service account number | ✅ |
| `BOSCH_SERVICE_PASSWORD` | Encrypted service password | ✅ |
| `BOSCH_DEVICE_TOKEN` | Device token for auth | ✅ |

### Frontend Environment Variables

Create `frontend/.env.production`:
```env
VITE_API_BASE_URL=https://mybgsw-ai-backend.azurewebsites.net
```

---

## 📡 API Endpoints

### Unified Chat Endpoint
```
POST /api/chat
Content-Type: application/json

{
  "query": "show me today's menu",
  "sessionId": "optional-session-id",
  "locationId": 1,
  "employeeNumber": "30608520"
}
```

**Response:**
```json
{
  "success": true,
  "response": "Today's menu...",
  "service": "canteen",
  "serviceName": "Canteen Menu"
}
```

### Health Check
```
GET /api/health
```

### Available Services
```
GET /api/services
```

---

## 🎯 Service Routing

The backend uses AI-powered routing to detect query intent:

| Query Pattern | Routes To |
|---------------|-----------|
| "menu", "food", "cafeteria", "lunch" | Canteen MCP |
| "entry", "exit", "attendance", "check in" | Entry/Exit MCP |
| "community", "groups", "clubs" | Community MCP |
| "banner", "announcement", "news" | Banner MCP |
| "travel", "trip", "flight", "hotel" | Travel A2A |
| "seat", "desk", "booking", "workspace" | Seat Booking A2A |

---

## 🔒 Security Configuration

### CORS Settings (Backend)
```javascript
app.use(cors({
  origin: [
    'https://mybgsw-ai-frontend.azurestaticapps.net',
    'https://*.azurestaticapps.net',
    'http://localhost:8080',
    'http://localhost:5173'
  ],
  credentials: true
}));
```

### HTTPS Only
```bash
az webapp update \
  --resource-group myBGSW-AI-RG \
  --name mybgsw-ai-backend \
  --https-only true
```

---

## 📊 Monitoring

### Enable Application Insights
```bash
az monitor app-insights component create \
  --app mybgsw-ai-insights \
  --location southindia \
  --resource-group myBGSW-AI-RG

# Get connection string
az monitor app-insights component show \
  --app mybgsw-ai-insights \
  --resource-group myBGSW-AI-RG \
  --query connectionString -o tsv
```

### View Logs
```bash
# Live logs
az webapp log tail \
  --resource-group myBGSW-AI-RG \
  --name mybgsw-ai-backend

# Download logs
az webapp log download \
  --resource-group myBGSW-AI-RG \
  --name mybgsw-ai-backend \
  --log-file logs.zip
```

---

## 🔄 GitHub Actions Workflow

The repository includes CI/CD workflows:

### Backend Deployment (`.github/workflows/main_mybgswai.yml`)
- Triggers on push to `main` branch
- Builds Node.js application
- Deploys to Azure App Service

### Frontend Deployment (`.github/workflows/main_hrmsservicehub.yml`)
- Triggers on push to `main` branch
- Builds Vite/React application
- Deploys to Azure Static Web Apps

---

## ✅ Post-Deployment Verification

### 1. Check Backend Health
```bash
curl https://mybgsw-ai-backend.azurewebsites.net/api/health
# Expected: {"status":"ok","timestamp":"..."}
```

### 2. Test Chat Endpoint
```bash
curl -X POST https://mybgsw-ai-backend.azurewebsites.net/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query":"hello"}'
```

### 3. Verify Frontend
- Navigate to `https://mybgsw-ai-frontend.azurestaticapps.net`
- Should see login page
- Login with Bosch credentials
- Solar System should load with active/inactive planets

---

## ⚠️ Known Issues & Limitations

| Issue | Status | Notes |
|-------|--------|-------|
| Canteen MCP returns no data | 🟡 | Database needs menu data import |
| Travel A2A "no capability" | 🟡 | A2A agent needs MCP tools connected |
| Seat Booking A2A "no capability" | 🟡 | A2A agent needs MCP tools connected |
| Entry/Exit no data for test employee | 🟢 | MCP working, just no test data |

---

## 📞 Support

For deployment issues:
1. Check Azure Portal logs
2. Verify environment variables
3. Test MCP endpoints directly
4. Review GitHub Actions workflow logs

---

## 📝 Changelog

### v2.0.0 (December 7, 2025)
- Added unified chat endpoint with AI routing
- Integrated 6 MCP/A2A services
- Added banner image display
- Added active/inactive planet states
- Fixed A2A response parsing
- Removed Lovable branding
- Updated environment configuration

### v1.0.0 (November 29, 2025)
- Initial release
- Basic canteen and entry/exit integration
