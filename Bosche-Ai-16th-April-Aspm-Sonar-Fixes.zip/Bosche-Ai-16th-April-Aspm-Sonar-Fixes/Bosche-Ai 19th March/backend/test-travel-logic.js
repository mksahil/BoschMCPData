/**
 * Test script for Travel Service slot-filling logic
 */
const travelService = require('./services/travel-service');
const conversationContextService = require('./services/conversation-context-service');

async function runTests() {
  const sessionId = 'test-session-' + Date.now();
  console.log('--- TEST 1: Partial Query (Destination only) ---');
  let result = await travelService.processQuery('I want to book a trip to Paris', { sessionId, employeeNumber: '123' });
  console.log('Response:', result.response);
  console.log('State:', JSON.stringify(result.travelState, null, 2));

  console.log('\n--- TEST 2: Partial Follow-up (Dates only) ---');
  result = await travelService.processQuery('Departing next Monday and returning Friday', { sessionId, employeeNumber: '123' });
  console.log('Response:', result.response);
  console.log('State:', JSON.stringify(result.travelState, null, 2));

  console.log('\n--- TEST 3: Origin ---');
  result = await travelService.processQuery('From Bangalore', { sessionId, employeeNumber: '123' });
  console.log('Response:', result.response);
  console.log('State:', JSON.stringify(result.travelState, null, 2));
  
  if (result.travelState.isComplete) {
    console.log('\n--- TEST 4: Full context should trigger API (Mocking call) ---');
    // Note: This will attempt to call the real API if credentials allow, 
    // but we can see the 'Context complete' log.
  }
}

runTests().catch(console.error);
