const bannerService = require('./services/banner-service');

async function testBannerService() {
    console.log('Testing Banner Service...');

    try {
        console.log('\n--- Test 1: getBannerDetails(5) ---');
        const result = await bannerService.getBannerDetails(5);
        console.log('Result:', JSON.stringify(result, null, 2));

        if (result.error) {
            console.error('❌ Test 1 Failed: Service returned error');
        } else if (result.banners && result.banners.length > 0) {
            console.log('✅ Test 1 Passed: Retrieved', result.banners.length, 'banners');
        } else {
            console.warn('⚠️ Test 1 Warning: Success but 0 banners found');
        }

    } catch (error) {
        console.error('❌ Test 1 Exception:', error);
    }
}

testBannerService();
