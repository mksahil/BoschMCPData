/**
 * HTTP-based MCP Client for deployed Canteen MCP Server
 * Connects to: https://mcp-canteen-dev.azurewebsites.net
 */

const axios = require('axios');
const https = require('https');
const { v4: uuidv4 } = require('uuid');

// Disable SSL verification for Azure APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

class MCPHttpClient {
  constructor() {
    this.baseUrl = process.env.CANTEEN_MCP_URL || 'https://mcp-canteen-dev.azurewebsites.net';
    // Remove trailing slash if present
    this.baseUrl = this.baseUrl.replace(/\/$/, '');
    this.mcpEndpoint = `${this.baseUrl}/mcp`;
    this.chatEndpoint = `${this.baseUrl}/chat`;
    this.sessionId = null;
    this.initialized = false;
    
    console.log('[Canteen MCP] Base URL:', this.baseUrl);
    console.log('[Canteen MCP] MCP Endpoint:', this.mcpEndpoint);
    console.log('[Canteen MCP] Chat Endpoint:', this.chatEndpoint);
  }

  /**
   * Parse SSE response data
   */
  parseSSEResponse(sseData) {
    if (typeof sseData !== 'string') return sseData;
    
    const lines = sseData.split('\n');
    let result = null;
    
    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          result = JSON.parse(line.substring(6));
        } catch (e) {
          result = { answer: line.substring(6) };
        }
      }
    }
    
    return result;
  }

  /**
   * Initialize connection to MCP server
   */
  async connect() {
    try {
      console.log('[Canteen MCP] Connecting to:', this.baseUrl);
      
      // First check if the server is healthy
      try {
        const healthCheck = await axios.get(this.baseUrl, {
          timeout: 5000,
          httpsAgent
        });
        console.log('[Canteen MCP] Server health:', healthCheck.data);
      } catch (healthError) {
        console.log('[Canteen MCP] Health check failed:', healthError.message);
      }
      
      // Try to initialize MCP session with SSE format
      const initPayload = {
        jsonrpc: "2.0",
        method: "initialize",
        params: {
          protocolVersion: "2024-11-05",
          capabilities: { tools: {} },
          clientInfo: { name: "mybgs-canteen-client", version: "1.0.0" }
        },
        id: 1
      };

      const response = await axios.post(this.mcpEndpoint, initPayload, {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream'
        },
        timeout: 45000, // 45s for Azure cold starts
        httpsAgent,
        transformResponse: [(data) => data]
      });

      // Parse SSE response
      const result = this.parseSSEResponse(response.data);
      
      // Extract session ID if available
      this.sessionId = response.headers['mcp-session-id'] || response.headers['x-mcp-session-id'] || uuidv4();
      this.initialized = true;
      
      console.log('[Canteen MCP] Connected successfully, session:', this.sessionId);
      return result || response.data;
    } catch (error) {
      console.log('[Canteen MCP] Init via MCP endpoint failed, will use chat endpoint:', error.message);
      // Still mark as initialized - we can use the chat endpoint
      this.initialized = true;
      return { status: 'fallback-mode' };
    }
  }

  /**
   * Call MCP tool using direct HTTP endpoints
   * The canteen MCP server exposes /tools/{toolName} endpoints
   */
  async callTool(name, args = {}) {
    if (!this.initialized) {
      await this.connect();
    }

    // SSRF and Path Traversal Protection
    if (!/^[a-zA-Z0-9_\-]+$/.test(name)) {
      throw new Error('Invalid tool name format');
    }

    try {
      // Use direct tool endpoint instead of JSON-RPC /mcp endpoint
      const toolEndpoint = `${this.baseUrl}/tools/${name}`;
      
      console.log(`[Canteen MCP] Calling tool: ${name}`, args);
      console.log(`[Canteen MCP] Tool endpoint: ${toolEndpoint}`);

      const response = await axios.post(toolEndpoint, args, {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        timeout: 30000,
        httpsAgent
      });

      console.log('[Canteen MCP] Tool response received:', JSON.stringify(response.data).substring(0, 200));
      return response.data;
    } catch (error) {
      console.error(`[Canteen MCP] Tool call failed: ${error.message}`);
      // Fallback to chat endpoint only for critical failures
      if (error.response?.status === 404) {
        console.log('[Canteen MCP] Tool endpoint not found, using chat fallback');
        return this.queryChatEndpoint(`${name}: ${JSON.stringify(args)}`);
      }
      throw error;
    }
  }

  /**
   * Query the chat endpoint (fallback)
   */
  async queryChatEndpoint(query) {
    try {
      console.log('[Canteen MCP] Using chat endpoint for query:', query.substring(0, 50));

      const response = await axios.post(this.chatEndpoint, {
        query: query,
        question: query
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        timeout: 30000,
        httpsAgent
      });

      return response.data;
    } catch (error) {
      console.error('[Canteen MCP] Chat endpoint failed:', error.message);
      throw error;
    }
  }

  /**
   * Process natural language canteen query
   */
  async processCanteenQuery(query) {
    const lowerQuery = query.toLowerCase();
    
    try {
      // First try the chat endpoint which has AI-powered intent detection
      try {
        const chatResult = await this.queryChatEndpoint(query);
        if (chatResult?.answer || chatResult?.response || chatResult?.result) {
          return {
            content: [{ 
              type: 'text', 
              text: chatResult.answer || chatResult.response || JSON.stringify(chatResult.result)
            }]
          };
        }
      } catch (chatError) {
        console.log('[Canteen MCP] Chat failed, trying direct tool calls');
      }

      // Fallback to direct tool calls based on query intent
      let result;
      
      if (lowerQuery.includes('today') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch') || lowerQuery.includes('breakfast'))) {
        result = await this.callTool('get_menu_by_date', { date: 'today' });
      }
      else if (lowerQuery.includes('tomorrow') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch'))) {
        result = await this.callTool('get_menu_by_date', { date: 'tomorrow' });
      }
      else if (lowerQuery.includes('yesterday') && lowerQuery.includes('menu')) {
        result = await this.callTool('get_menu_by_date', { date: 'yesterday' });
      }
      else if (lowerQuery.includes('week') && lowerQuery.includes('menu')) {
        result = await this.callTool('get_weekly_menu', {});
      }
      else {
        // Search for specific food items
        const foodItems = ['dosa', 'biryani', 'paneer', 'chicken', 'fish', 'egg', 'idli', 'vada', 'rice', 'chapati', 'roti', 'dal', 'sambar'];
        const foundItem = foodItems.find(item => lowerQuery.includes(item));
        
        if (foundItem) {
          if (lowerQuery.includes('when') || lowerQuery.includes('available') || lowerQuery.includes('next')) {
            result = await this.callTool('check_item_availability', { itemName: foundItem });
          } else {
            result = await this.callTool('search_menu_item', { searchTerm: foundItem });
          }
        }
        else if (lowerQuery.includes('special')) {
          result = await this.callTool('get_special_menu_days', {});
        }
        else {
          // Default to today's menu
          result = await this.callTool('get_menu_by_date', { date: 'today' });
        }
      }
      
      return result;
      
    } catch (error) {
      console.error('[Canteen MCP] Error processing query:', error);
      throw error;
    }
  }

  disconnect() {
    this.initialized = false;
    this.sessionId = null;
  }
}

// Singleton instance
let mcpHttpClient = null;

module.exports = {
  getClient: async () => {
    if (!mcpHttpClient) {
      mcpHttpClient = new MCPHttpClient();
      await mcpHttpClient.connect();
    }
    return mcpHttpClient;
  },
  MCPHttpClient
};
