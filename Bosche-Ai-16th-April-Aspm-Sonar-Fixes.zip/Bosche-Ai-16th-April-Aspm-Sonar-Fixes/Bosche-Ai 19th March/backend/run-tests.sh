#!/bin/bash
# BGSW AI Comprehensive Test Script
# Usage: TOKEN=<your_token> bash run-tests.sh

RESULTS_FILE="/tmp/bgsw_test_results.txt"
> "$RESULTS_FILE"

if [ -z "$TOKEN" ]; then
  echo "ERROR: TOKEN env var not set. Run: export TOKEN=<your_access_token>"
  exit 1
fi

run_test() {
  local category="$1"
  local label="$2"
  local query="$3"
  local sid="test-$(date +%s)-$RANDOM"
  
  echo -n "Testing: [$category] $label... "
  
  local start_time=$(date +%s)
  local raw
  raw=$(curl -s -X POST http://localhost:3001/api/chat \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -H "x-employee-number: 30246494" \
    -d "{\"query\":\"$query\",\"employeeNumber\":\"30246494\",\"sessionId\":\"$sid\",\"conversationHistory\":[]}" \
    --max-time 180 2>/dev/null)
  local end_time=$(date +%s)
  local elapsed=$((end_time - start_time))
  
  local service
  service=$(echo "$raw" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('service','N/A'))" 2>/dev/null || echo "ERROR")
  local success
  success=$(echo "$raw" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('success','N/A'))" 2>/dev/null || echo "ERROR")
  local response
  response=$(echo "$raw" | python3 -c "
import sys,json
d=json.load(sys.stdin)
r=d.get('response','N/A')
if r:
    print(r[:300])
else:
    print('EMPTY')
" 2>/dev/null || echo "PARSE_ERROR")
  
  local status="FAIL"
  if [[ "$success" == "True" ]] && [[ "$response" != "EMPTY" ]] && [[ "$response" != "PARSE_ERROR" ]] && [[ "$service" != "ERROR" ]]; then
    if echo "$response" | grep -qi "unable to\|trouble connecting\|error when trying\|couldn't get\|cannot process\|currently unavailable\|couldn't parse"; then
      status="PARTIAL"
    else
      status="PASS"
    fi
  fi
  
  echo "[$status] ${elapsed}s"
  
  echo "[$status] [$category] $label | Service: $service | Time: ${elapsed}s" >> "$RESULTS_FILE"
  echo "  Query: $query" >> "$RESULTS_FILE"
  echo "  Response: $response" >> "$RESULTS_FILE"
  echo "" >> "$RESULTS_FILE"
  
  sleep 2
}

echo "===== BGSW AI TESTING STARTED: $(date) =====" | tee -a "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

echo ""
echo "=== BANNERS ==="
echo "--- BANNERS ---" >> "$RESULTS_FILE"
run_test "Banner" "Upcoming events" "Which are the upcoming events in BGSW?"
run_test "Banner" "Event info" "What is the FitForFuture event about?"
run_test "Banner" "Event location" "Where is the FitForFuture event held?"

echo ""
echo "=== COMMUNITIES ==="
echo "--- COMMUNITIES ---" >> "$RESULTS_FILE"
run_test "Community" "Active communities" "Which all active communities can I join?"
run_test "Community" "Specific community" "Is there a photography community available?"
run_test "Community" "Community info" "Tell me about the active communities at BGSW"

echo ""
echo "=== TRAVEL ==="
echo "--- TRAVEL ---" >> "$RESULTS_FILE"
run_test "Travel" "TP details" "Display my TP details"
run_test "Travel" "Past travels" "Details of my past travels"
run_test "Travel" "Upcoming travel" "When is my upcoming travel starting?"
run_test "Travel" "Travel duration" "What is the duration of my next travel?"
run_test "Travel" "Raise TP" "Raise a travel plan from Bangalore to Mumbai from 20th May to 23rd May 2026"
run_test "Travel" "Book travel" "Book me a flight from Pune to Delhi on 15th April 2026"

echo ""
echo "=== SEAT BOOKING ==="
echo "--- SEATS ---" >> "$RESULTS_FILE"
run_test "Seat" "Available seats" "How many seats are available in 905 building 1st floor on Friday?"
run_test "Seat" "Specific seat" "Which seats are available in 905 building 1st floor?"
run_test "Seat" "Seat check" "Is seat L1-001 available for tomorrow?"
run_test "Seat" "Book seat tomorrow" "Book me a seat for tomorrow on 905 building 1st floor"
run_test "Seat" "Book seat today" "Book me a seat for today on 903 building 1st floor full day"

echo ""
echo "=== CANTEEN ==="
echo "--- CANTEEN ---" >> "$RESULTS_FILE"
run_test "Canteen" "Snacks today" "What is for snacks today?"
run_test "Canteen" "Breakfast today" "What is for breakfast today morning?"
run_test "Canteen" "Breakfast tomorrow" "What is for breakfast tomorrow?"
run_test "Canteen" "Lunch Friday" "What is lunch on Friday?"

echo ""
echo "=== ENTRY/EXIT ==="
echo "--- ENTRY/EXIT ---" >> "$RESULTS_FILE"
run_test "Entry/Exit" "Swipe in today" "What time did I swipe in today?"
run_test "Entry/Exit" "Swipe out yesterday" "What time did I swipe out yesterday?"
run_test "Entry/Exit" "Weekly swipes" "What are my swipe records for this week?"
run_test "Entry/Exit" "Monthly swipes" "What are my swipe details for this month?"
run_test "Entry/Exit" "January swipes" "What are my swipe details for January?"
run_test "Entry/Exit" "Avg swipe Feb" "What is my average swipe in time for February?"
run_test "Entry/Exit" "Leave yesterday" "When did I leave office yesterday?"
run_test "Entry/Exit" "Days in office" "How many days did I come to office last month?"

echo "" >> "$RESULTS_FILE"
echo "===== TESTING COMPLETED: $(date) =====" | tee -a "$RESULTS_FILE"

echo ""
echo "Results saved to: $RESULTS_FILE"
echo ""
echo "=== SUMMARY ==="
echo "PASS:    $(grep -c '^\[PASS\]' "$RESULTS_FILE")"
echo "PARTIAL: $(grep -c '^\[PARTIAL\]' "$RESULTS_FILE")"
echo "FAIL:    $(grep -c '^\[FAIL\]' "$RESULTS_FILE")"
