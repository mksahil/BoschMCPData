const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const travelService = require('./services/travel-service');
const conversationContextService = require('./services/conversation-context-service');

async function runTest() {
    console.log("=== TRAVEL RESET INTENT TEST ===");
    const sessionId = 'test-session-' + Date.now();
    const empNumber = '30945143';
    
    // Step 1: Start 1st booking
    console.log("\n1. Query: 'book a travel'");
    let res = await travelService.processQuery("book a travel", { sessionId, employeeNumber: empNumber });
    console.log("Response: " + res.response.substring(0, 100) + "...");
    console.log("State Complete: " + res.travelState.isComplete);

    // Step 2: Provide partial details
    console.log("\n2. Query: 'bangalore to pune'");
    res = await travelService.processQuery("bangalore to pune", { sessionId, employeeNumber: empNumber });
    console.log("Response: " + res.response.substring(0, 100) + "...");
    console.log("State Origin: " + res.travelState.from);
    console.log("State Destination: " + res.travelState.to);

    // Step 3: Start 2nd booking (Expected: RESET)
    console.log("\n3. Query: 'book a ticket'");
    res = await travelService.processQuery("book a ticket", { sessionId, employeeNumber: empNumber });
    console.log("Response: " + res.response.substring(0, 100) + "...");
    
    // VERIFICATION
    if (res.travelState.from === null && res.travelState.to === null) {
        console.log("\n✅ SUCCESS: State was correctly reset by 'book a ticket'!");
    } else {
        console.warn("\n❌ FAILURE: State was NOT reset. Still contains: " + res.travelState.from + " to " + res.travelState.to);
    }
}

// We need to initialize the context service first
async function main() {
    try {
        await runTest();
    } catch (err) {
        console.error("Test failed with error:", err.message);
    }
}

main();
