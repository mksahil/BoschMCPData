const fs = require('fs');

let serverCode = fs.readFileSync('./server.js', 'utf8');

// Replace Information Exposure instances (Issue #14)
serverCode = serverCode.replace(/res\.status\(500\)\.json\(\{(.*?)(error:\s*error\.message)(.*?)\}\);/g, (match, p1, p2, p3) => {
    return `// this fixed: Issue #14 - Information Exposure
    res.status(500).json({${p1}error: 'An internal server error occurred'${p3}});`;
});

// Write it back
fs.writeFileSync('./server.js', serverCode);

console.log('Fixed Information Exposure occurrences.');
