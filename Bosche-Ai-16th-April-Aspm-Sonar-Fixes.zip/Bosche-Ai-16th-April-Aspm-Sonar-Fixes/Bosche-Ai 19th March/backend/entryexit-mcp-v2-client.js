const axios = require('axios');
const { createOpenAIClient, getChatModelName } = require('./services/openai-client');
const configService = require('./services/config-service');

class EntryExitMCPV2Client {
  constructor() {
    // Use new deployed MCP server URLs
    this.mcpServerUrl = process.env.ENTRYEXIT_MCP_SERVER_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/mcp';
    this.chatEndpoint = process.env.ENTRYEXIT_CHAT_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/chat';
    this.defaultEmployeeNumber = process.env.DEFAULT_EMPLOYEE_NUMBER;
    this.sessionId = null;
    this.isInitialized = false;

    // Initialize OpenAI for local AI processing if chat endpoint fails
    this.openai = createOpenAIClient();

    // Available MCP tools as per the documentation
    this.availableTools = [
      'get_attendance_by_date',
      'get_attendance_range',
      'get_month_summary',
      'get_current_status',
      'get_raw_swipes',
      'get_employee_name'
    ];
  }

  /**
   * Parse SSE response from MCP server
   */
  parseSSEResponse(sseData) {
    const lines = sseData.split('\n');
    let result = null;

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          result = JSON.parse(line.substring(6));
        } catch (e) {
          console.log('Failed to parse SSE data line:', line);
        }
      }
    }

    return result;
  }

  /**
   * Initialize MCP session with the server
   */
  async initializeSession(employeeNumber) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    try {
      console.log('Initializing MCP session...');

      const initPayload = {
        jsonrpc: "2.0",
        method: "initialize",
        params: {
          protocolVersion: "2024-11-05",
          capabilities: { tools: {} },
          clientInfo: { name: "mybgs-client", version: "1.0.0" }
        },
        id: 1
      };

      const response = await axios.post(
        this.mcpServerUrl,
        initPayload,
        {
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/event-stream',
            'X-Employee-Number': empNumber
          },
          timeout: 45000, // 45s for Azure cold starts
          transformResponse: [(data) => data] // Keep as raw string to parse SSE
        }
      );

      const result = this.parseSSEResponse(response.data);

      if (result && result.result) {
        // Extract session ID from response headers
        this.sessionId = response.headers['mcp-session-id'] || response.headers['x-mcp-session-id'];
        console.log('MCP Session initialized:', result.result.serverInfo);
        console.log('Session ID:', this.sessionId);
        this.isInitialized = true;
        return result;
      } else {
        throw new Error('Invalid initialization response');
      }
    } catch (error) {
      console.error('Error initializing MCP session:', error.message);
      throw error;
    }
  }

  /**
   * Call MCP tool using proper JSON-RPC protocol
   */
  async callMCPToolWithProtocol(toolName, params, employeeNumber) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    // Initialize session if not done
    if (!this.isInitialized) {
      await this.initializeSession(empNumber);
    }

    const toolCallPayload = {
      jsonrpc: "2.0",
      method: "tools/call",
      params: {
        name: toolName,
        arguments: params || {}
      },
      id: Date.now()
    };

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream',
      'X-Employee-Number': empNumber
    };

    // Add session ID if available
    if (this.sessionId) {
      headers['Mcp-Session-Id'] = this.sessionId;
    }

    try {
      console.log(`Calling MCP tool: ${toolName} with params:`, params);

      const response = await axios.post(
        this.mcpServerUrl,
        toolCallPayload,
        {
          headers,
          timeout: 15000,
          transformResponse: [(data) => data]
        }
      );

      const result = this.parseSSEResponse(response.data);

      if (result && result.result) {
        console.log('MCP tool result:', result.result);
        return result.result;
      } else if (result && result.error) {
        throw new Error(result.error.message || 'MCP tool call failed');
      }

      return result;
    } catch (error) {
      console.error(`Error calling MCP tool ${toolName}:`, error.message);

      // Reset session on error
      this.isInitialized = false;
      this.sessionId = null;

      throw error;
    }
  }

  /**
   * Process query using the FastAPI chat endpoint (recommended approach)
   * This leverages the Azure OpenAI + LangGraph agent on the server
   */
  /**
   * Check if query is asking about another person's data.
   * Only block queries with EXPLICIT other-person references.
   * "give me entry exit times" = self → ALLOW
   * "Rahul's entry time" = colleague → BLOCK
   * "who all came today" = bulk → BLOCK
   */
  isQueryAboutOtherPerson(query, loggedInUserName) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // --- helpers ---
    const loggedInNames = [];
    if (loggedInUserName) {
      const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
      loggedInNames.push(...parts, loggedInUserName.toLowerCase());
    }
    const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

    // Global privacy whitelist from centralised config (cities, common words, etc.)
    const nonNames = new Set(
      (configService.getPrivacyWhitelistSync() || []).map(w => w.toLowerCase())
    );

    // Personal data keywords from centralised config (editable via Admin UI)
    const personalDataKeywords = configService.getKeywordConfigSync().entryExitService.entryExitDataKeywords;
    const hasPersonalData = personalDataKeywords.some(kw => q.includes(kw));
    if (!hasPersonalData) return false;

    // Self-reference
    const hasSelfRef = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i\sam)\b/i.test(q);
    // Colleague / relationship words
    const hasColleagueWord = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|subordinate|buddy|peer|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i.test(q);

    // FAST PATH: self-ref without colleague word AND no other-person name → ALLOW
    if (hasSelfRef && !hasColleagueWord) {
      let otherName = false;
      // Check "of/for <word(s)>" — split multi-word captures and check EACH word
      const ofFor = q.match(/\b(?:of|for)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\b/i);
      if (ofFor) {
        const words = ofFor[1].toLowerCase().split(/\s+/).filter(Boolean);
        if (words.some(w => !nonNames.has(w) && !isOwnName(w))) otherName = true;
      }
      const poss = q.match(/(\w{3,})(?:'s|s')\s+/i);
      if (poss) {
        const pName = poss[1].toLowerCase();
        const skip = new Set(['today', 'yesterday', 'tomorrow', 'it', 'that', 'this', 'there', 'here',
          'what', 'let', 'don', 'doesn', 'didn', 'won', 'week', 'month', 'year', 'last', 'next',
          'swipe', 'entry', 'exit', 'time', 'check', 'clock', 'shift', 'who', 'where', 'when', 'how']);
        if (!skip.has(pName) && !nonNames.has(pName) && !isOwnName(pName)) otherName = true;
      }
      if (!otherName) return false;
      // else fall through to full checks
    }

    // Bulk / collective requests
    if (/\b(all\s+employee|every\s*one|everybody|entire\s+team|whole\s+team|team\s+(?:attendance|entry|exit)|who\s+(?:all\s+)?(?:came|entered|left|exited|checked|swiped|is|are|was|were)|list\s+(?:all|every)|how\s+many\s+(?:people|employee|colleague)|show\s+(?:all|every|each)\s+(?:employee|people|person|staff|member))\b/i.test(q)) {
      console.log('[EntryExit] Privacy: blocked bulk/collective request');
      return true;
    }

    // Colleague word + personal data
    if (hasColleagueWord) {
      console.log('[EntryExit] Privacy: blocked colleague word + personal data');
      return true;
    }

    // Third-person pronouns
    if (/\b(his|her|their|them|him)\b/i.test(q)) {
      console.log('[EntryExit] Privacy: blocked third-person pronoun');
      return true;
    }

    // Possessive capitalized name: "Rahul's entry"
    const possessives = [...original.matchAll(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g)];
    for (const m of possessives) {
      const pName = m[1].toLowerCase();
      if (!nonNames.has(pName) && !isOwnName(pName)) {
        console.log(`[EntryExit] Privacy: blocked possessive name pattern: ${m[1]}`);
        return true;
      }
    }

    // "of/for <Name>" — split multi-word captures and check EACH word individually
    const ofForMatches = [...q.matchAll(/\b(?:of|for)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\b/gi)];
    for (const m of ofForMatches) {
      const phraseWords = m[1].toLowerCase().split(/\s+/).filter(Boolean);
      if (phraseWords.some(w => !nonNames.has(w) && !isOwnName(w))) {
        console.log(`[EntryExit] Privacy: blocked of/for name pattern: ${m[1]}`);
        return true;
      }
    }

    // Impersonation: "I am Rahul, show my entry time"
    const impersonation = q.match(/\b(?:i\s+am|i'm|this\s+is|my\s+name\s+is)\s+([a-z]{3,})/i);
    if (impersonation) {
      const claimed = impersonation[1].toLowerCase();
      if (!isOwnName(claimed) && !nonNames.has(claimed)) {
        console.log(`[EntryExit] Privacy: possible impersonation detected: ${impersonation[1]}`);
        return true;
      }
    }

    // Capitalized name near personal data (no self-ref)
    if (!hasSelfRef) {
      const allCapNames = [...original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)];
      for (const m of allCapNames) {
        const nameStr = m[1].toLowerCase();
        const words = nameStr.split(/\s+/);
        if (words.some(w => !nonNames.has(w) && !isOwnName(w)) && nameStr.length > 3) {
          console.log(`[EntryExit] Privacy: blocked capitalized name: ${m[1]}`);
          return true;
        }
      }
    }

    // DEFAULT: no explicit other-person reference → ALLOW
    console.log('[EntryExit] Privacy: allowing query - no colleague mention found');
    return false;
  }

  async processQueryWithAI(query, employeeNumber = null, userName = null) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;
    const lowerQuery = query.toLowerCase();
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/;

    // Privacy check: Block queries about other people's data
    if (this.isQueryAboutOtherPerson(query, userName)) {
      console.log('[EntryExit] Privacy check: Blocking query about colleague data');
      return {
        success: false,
        response: "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.",
        employeeNumber: empNumber,
        method: 'privacy-blocked'
      };
    }

    if (identityPattern.test(lowerQuery)) {
      console.log('Identity query detected, bypassing chat endpoint');
      return await this.processIdentityQuery(empNumber);
    }

    try {
      console.log(`Processing AI-powered entry/exit query for employee ${empNumber}: ${query}`);

      const response = await axios.post(
        this.chatEndpoint,
        {
          question: query
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-Employee-Number': empNumber
          },
          timeout: 30000
        }
      );

      if (response.data && response.data.answer) {
        return {
          success: true,
          response: response.data.answer,
          employeeNumber: empNumber,
          method: 'ai-chat'
        };
      } else {
        throw new Error('Invalid response from chat endpoint');
      }
    } catch (error) {
      console.error('Error calling chat endpoint:', error.message);

      // Fallback to direct tool calling
      console.log('Falling back to direct tool calling...');
      return await this.processQueryWithTools(query, empNumber);
    }
  }

  /**
   * Directly resolve identity queries to avoid chat endpoint refusals.
   */
  async processIdentityQuery(employeeNumber) {
    try {
      const toolResult = await this.callMCPTool('get_employee_name', {}, employeeNumber);
      const formattedResponse = this.basicFormatResponse(toolResult, 'get_employee_name');
      return {
        success: true,
        response: formattedResponse,
        employeeNumber,
        method: 'direct-tools',
        tool: 'get_employee_name'
      };
    } catch (error) {
      console.error('Error resolving employee name:', error);
      return {
        success: false,
        response: "I'm having trouble accessing your profile information. Please try again later.",
        error: error.message,
        method: 'error'
      };
    }
  }

  /**
   * Process query by analyzing intent and calling appropriate MCP tools directly
   * This is a fallback when the chat endpoint is unavailable
   */
  async processQueryWithTools(query, employeeNumber) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    try {
      // Use OpenAI to determine which tool to call
      const toolDecision = await this.determineToolToCall(query);

      if (!toolDecision.tool) {
        return {
          success: false,
          response: "I couldn't understand your attendance query. Please try asking about specific dates, ranges, or monthly summaries.",
          method: 'tool-selection-failed'
        };
      }

      // Normalize params to fix any freeform month/date strings from GPT
      const normalizedParams = this.normalizeParams(toolDecision.tool, toolDecision.params, query);

      // Call the appropriate MCP tool
      const toolResult = await this.callMCPTool(toolDecision.tool, normalizedParams, empNumber);

      // Format the response using AI
      const formattedResponse = await this.formatResponseWithAI(query, toolResult, toolDecision.tool);

      return {
        success: true,
        response: formattedResponse,
        employeeNumber: empNumber,
        method: 'direct-tools',
        tool: toolDecision.tool
      };

    } catch (error) {
      console.error('Error in tool-based processing:', error);
      return {
        success: false,
        response: "I'm having trouble accessing your attendance information. Please try again later.",
        error: error.message,
        method: 'error'
      };
    }
  }

  /**
   * Normalize tool params to ensure correct date/month formats before calling MCP.
   * Handles cases where GPT returns e.g. month: 'February 2026' instead of '2026-02'.
   */
  normalizeParams(toolName, params, originalQuery) {
    if (!params) return params;
    const normalized = { ...params };

    const monthMap = {
      january: '01', jan: '01', february: '02', feb: '02',
      march: '03', mar: '03', april: '04', apr: '04', may: '05',
      june: '06', jun: '06', july: '07', jul: '07', august: '08', aug: '08',
      september: '09', sep: '09', sept: '09', october: '10', oct: '10',
      november: '11', nov: '11', december: '12', dec: '12'
    };

    const toYYYYMM = (val) => {
      if (!val) return null;
      const s = String(val).trim();
      // Already correct: 2026-02
      if (/^\d{4}-\d{2}$/.test(s)) return s;
      // February 2026 or Feb 2026
      const m1 = s.match(/^([a-z]+)\s+(\d{4})$/i);
      if (m1 && monthMap[m1[1].toLowerCase()]) {
        return `${m1[2]}-${monthMap[m1[1].toLowerCase()]}`;
      }
      // 2026 February
      const m2 = s.match(/^(\d{4})\s+([a-z]+)$/i);
      if (m2 && monthMap[m2[2].toLowerCase()]) {
        return `${m2[1]}-${monthMap[m2[2].toLowerCase()]}`;
      }
      // Just month name: "February" → use current year
      if (monthMap[s.toLowerCase()]) {
        const yr = new Date().getFullYear();
        return `${yr}-${monthMap[s.toLowerCase()]}`;
      }
      // 02-2026 or 02/2026
      const m3 = s.match(/^(\d{2})[\-\/](\d{4})$/);
      if (m3) return `${m3[2]}-${m3[1]}`;
      return null;
    };

    const toYYYYMMDD = (val) => {
      if (!val) return null;
      const s = String(val).trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        // Validate: ensure components didn't overflow (e.g. Feb 29 in non-leap year)
        const [y, mo, d] = s.split('-').map(Number);
        const dateObj = new Date(y, mo - 1, d); // local constructor — no UTC overflow tricks
        if (dateObj.getFullYear() === y && dateObj.getMonth() === mo - 1 && dateObj.getDate() === d) {
          return s; // genuinely valid date
        }
        // Overflowed: clamp to real last day of that month
        const lastDay = new Date(y, mo, 0).getDate();
        const clamped = `${y}-${String(mo).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
        console.log(`[NormalizeParams] Clamped invalid date '${s}' → '${clamped}' (month only has ${lastDay} days)`);
        return clamped;
      }
      // Try JS Date parse for other formats
      const d = new Date(s);
      if (!isNaN(d.getTime())) {
        return d.toISOString().split('T')[0];
      }
      return null;
    };

    if (toolName === 'get_month_summary' && normalized.month) {
      const fixed = toYYYYMM(normalized.month);
      if (fixed) {
        console.log(`[NormalizeParams] month: '${normalized.month}' → '${fixed}'`);
        normalized.month = fixed;
      } else {
        // Fallback: extract from original query
        const fallback = this.extractMonth(originalQuery);
        if (fallback) normalized.month = fallback;
      }
    }

    if ((toolName === 'get_attendance_by_date' || toolName === 'get_raw_swipes') && normalized.date_str) {
      const fixed = toYYYYMMDD(normalized.date_str);
      if (fixed) {
        console.log(`[NormalizeParams] date_str: '${normalized.date_str}' → '${fixed}'`);
        normalized.date_str = fixed;
      }
    }

    if (toolName === 'get_attendance_range') {
      if (normalized.start_date) {
        const fixed = toYYYYMMDD(normalized.start_date);
        if (fixed) { console.log(`[NormalizeParams] start_date: '${normalized.start_date}' → '${fixed}'`); normalized.start_date = fixed; }
      }
      if (normalized.end_date) {
        const fixed = toYYYYMMDD(normalized.end_date);
        if (fixed) { console.log(`[NormalizeParams] end_date: '${normalized.end_date}' → '${fixed}'`); normalized.end_date = fixed; }
      }
    }

    return normalized;
  }

  /**
   * Use OpenAI to determine which MCP tool to call based on the query
   */
  async determineToolToCall(query) {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().toISOString().slice(0, 7);

    const systemPrompt = `You are an assistant that determines which attendance tool to call based on user queries.
Today's date is ${today}.

Available tools and their EXACT parameter schemas:
1. get_attendance_by_date - Get attendance for a specific date
   Parameters: { "date_str": "YYYY-MM-DD" } (required)
   
2. get_attendance_range - Get attendance for a date range
   Parameters: { "start_date": "YYYY-MM-DD", "end_date": "YYYY-MM-DD" } (both required)
   
3. get_month_summary - Get monthly attendance summary  
   Parameters: { "month": "YYYY-MM" } (required, e.g., "2025-01" for January 2025)
   
4. get_current_status - Get current check-in/out status
   Parameters: {} (no parameters needed)
   
5. get_raw_swipes - Get raw swipe events for a date
   Parameters: { "date_str": "YYYY-MM-DD" } (required)
   
6. get_employee_name - Get employee's name
   Parameters: {} (no parameters needed)

Routing Rules:
- For queries asking for a summary of a month (e.g., "my attendance for January", "monthly report"), use get_month_summary.
- For queries asking for detailed attendance over multiple days or a full month (e.g., "show me all my entries for last month", "my attendance from Jan 1 to Jan 31"), use get_attendance_range.
- get_raw_swipes should only be used when the user explicitly asks for "raw swipes", "all swipes", or "swipe data" for a *specific date*. It should not be used for general monthly or range queries.

IMPORTANT: Use the EXACT parameter names shown above (date_str, start_date, end_date, month).
For "today", use date: ${today}
For "this month", use month: ${currentMonth}

Respond with a JSON object containing:
- tool: the tool name to call
- params: the parameters object with correct keys and values
- explanation: brief explanation of why this tool was chosen`;

    try {
      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        // temperature: 0.1, // GPT-5 only supports default temperature of 1.0
        response_format: { type: "json_object" }
      });

      const decision = JSON.parse(response.choices[0].message.content);
      console.log('Tool decision:', decision);
      return decision;

    } catch (error) {
      console.error('Error determining tool:', error);

      // Fallback to basic keyword matching
      return this.fallbackToolSelection(query);
    }
  }

  /**
   * Fallback tool selection using keyword matching
   * Uses correct parameter names as per MCP tool definitions
   */
  fallbackToolSelection(query) {
    const lowerQuery = query.toLowerCase();
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format

    if (lowerQuery.includes('current') || lowerQuery.includes('now') || lowerQuery.includes('checked in') || lowerQuery.includes('status')) {
      return { tool: 'get_current_status', params: {} };
    } else if (lowerQuery.includes('today') && !lowerQuery.match(/\b(all|every|each)\b/)) {
      return { tool: 'get_attendance_by_date', params: { date_str: today } };
    } else if (lowerQuery.includes('yesterday')) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_by_date', params: { date_str: yesterday } };
    } else if (lowerQuery.includes('month') || lowerQuery.includes('january') || lowerQuery.includes('february') ||
      lowerQuery.includes('march') || lowerQuery.includes('april') || lowerQuery.includes('may') ||
      lowerQuery.includes('june') || lowerQuery.includes('july') || lowerQuery.includes('august') ||
      lowerQuery.includes('september') || lowerQuery.includes('october') || lowerQuery.includes('november') ||
      lowerQuery.includes('december') ||
      lowerQuery.includes('jan') || lowerQuery.includes('feb') || lowerQuery.includes('mar') ||
      lowerQuery.includes('apr') || lowerQuery.includes('jun') || lowerQuery.includes('jul') ||
      lowerQuery.includes('aug') || lowerQuery.includes('sep') || lowerQuery.includes('oct') ||
      lowerQuery.includes('nov') || lowerQuery.includes('dec')) {
      const monthMatch = this.extractMonth(query);
      const targetMonth = monthMatch || currentMonth;

      // If user wants detail per day (entry/exit/swipe details), use range; otherwise use summary
      const wantsDetail = /\b(all|every|each|exact|detail|entry|exit|swipe|swiped|days|times)\b/i.test(lowerQuery);
      if (wantsDetail) {
        // Build full-month date range
        const [yr, mo] = targetMonth.split('-');
        const lastDay = new Date(parseInt(yr), parseInt(mo), 0).getDate();
        const startDate = `${yr}-${mo}-01`;
        const endDate = `${yr}-${mo}-${String(lastDay).padStart(2, '0')}`;
        return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: endDate } };
      }
      return { tool: 'get_month_summary', params: { month: targetMonth } };
    } else if (lowerQuery.includes('week')) {
      // Last 7 days
      const startDate = new Date(Date.now() - 6 * 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: today } };
    } else if (lowerQuery.match(/last\s+(\d+)\s+days/)) {
      const daysMatch = lowerQuery.match(/last\s+(\d+)\s+days/);
      const days = parseInt(daysMatch[1]) - 1;
      const startDate = new Date(Date.now() - days * 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: today } };
    } else if (lowerQuery.includes('raw swipe') || (lowerQuery.includes('swipe') && !lowerQuery.match(/\b(all|every|each|month|days)\b/))) {
      // Only use raw_swipes for explicit single-day swipe requests
      return { tool: 'get_raw_swipes', params: { date_str: today } };
    } else if (lowerQuery.includes('name') || lowerQuery.includes('who am i')) {
      return { tool: 'get_employee_name', params: {} };
    }

    // Default: today's attendance
    return { tool: 'get_attendance_by_date', params: { date_str: today } };
  }

  /**
   * Extract month from query (e.g., "january 2025" -> "2025-01")
   */
  extractMonth(query) {
    const months = {
      'january': '01', 'jan': '01',
      'february': '02', 'feb': '02',
      'march': '03', 'mar': '03',
      'april': '04', 'apr': '04',
      'may': '05',
      'june': '06', 'jun': '06',
      'july': '07', 'jul': '07',
      'august': '08', 'aug': '08',
      'september': '09', 'sep': '09', 'sept': '09',
      'october': '10', 'oct': '10',
      'november': '11', 'nov': '11',
      'december': '12', 'dec': '12'
    };

    const lowerQuery = query.toLowerCase();
    for (const [name, num] of Object.entries(months)) {
      if (lowerQuery.includes(name)) {
        const yearMatch = lowerQuery.match(/\d{4}/);
        const year = yearMatch ? yearMatch[0] : new Date().getFullYear().toString();
        return `${year}-${num}`;
      }
    }

    return null;
  }

  /**
   * Format month string (e.g., "2025-11" -> "November 2025")
   */
  formatMonthName(monthStr) {
    if (!monthStr) return 'the month';

    const months = ['January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'];

    const [year, month] = monthStr.split('-');
    const monthIndex = parseInt(month) - 1;

    if (monthIndex >= 0 && monthIndex < 12) {
      return `${months[monthIndex]} ${year}`;
    }
    return monthStr;
  }

  /**
   * Call an MCP tool directly - delegates to protocol-based method
   */
  async callMCPTool(toolName, params, employeeNumber) {
    return await this.callMCPToolWithProtocol(toolName, params, employeeNumber);
  }

  /**
   * Format the tool response into natural language using AI
   */
  async formatResponseWithAI(originalQuery, toolResult, toolName) {
    try {
      const systemPrompt = `You are a helpful HR assistant formatting employee attendance data.
Convert the raw attendance data into a friendly, clear, conversational response.
Include relevant details like entry times, exit times, dates, and durations.
IMPORTANT:
- NEVER ask the user to rephrase their query or provide data in a specific format.
- NEVER mention internal tool names, API formats, or date formats (YYYY-MM-DD etc.) to the user.
- If the data is empty or missing, say the record was not found for that period — do not ask them to try a different format.
- Always respond as if you fully understood what the user asked.`;

      const userPrompt = `User asked: "${originalQuery}"
Tool called: ${toolName}
Raw data received: ${JSON.stringify(toolResult, null, 2)}

Please format this into a helpful response.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ]
      });

      const aiResponse = response.choices[0]?.message?.content;

      // If AI returned empty/null, use basic formatting
      if (!aiResponse || aiResponse.trim() === '') {
        console.log('AI returned empty response, using basic formatting');
        return this.basicFormatResponse(toolResult, toolName);
      }

      return aiResponse;

    } catch (error) {
      console.error('Error formatting response with AI:', error.message);

      // Fallback to basic formatting
      return this.basicFormatResponse(toolResult, toolName);
    }
  }

  /**
   * Basic response formatting without AI
   */
  basicFormatResponse(toolResult, toolName) {
    // Handle MCP response structure with content array
    let data = toolResult;
    if (toolResult && toolResult.structuredContent) {
      data = toolResult.structuredContent;
    } else if (toolResult && toolResult.content && toolResult.content[0]) {
      try {
        data = JSON.parse(toolResult.content[0].text);
      } catch (e) {
        data = toolResult.content[0].text;
      }
    }

    if (!data || typeof data === 'string') {
      return data || "No data available.";
    }

    switch (toolName) {
      case 'get_current_status':
        const status = data.status || (data.checked_in ? 'IN' : 'OUT');
        const lastSwipe = data.last_swipe || {};
        const swipeTime = lastSwipe.time || data.last_swipe_time || '';
        const location = lastSwipe.location || '';

        if (status === 'IN' || data.checked_in) {
          return `✅ You are currently **checked IN**${swipeTime ? `. Last swipe: ${swipeTime}` : ''}${location ? ` at ${location}` : ''}`;
        } else {
          return `⬜ You are currently **checked OUT**${swipeTime ? `. Last swipe: ${swipeTime}` : ''}${location ? ` at ${location}` : ''}`;
        }

      case 'get_attendance_by_date':
        const firstIn = data.first_in;
        const lastOut = data.last_out;
        const totalHours = data.total_hours || '00:00:00';
        const date = data.date;

        if (firstIn && lastOut) {
          return `📅 **${date}**\n• First entry: ${firstIn}\n• Last exit: ${lastOut}\n• Total hours: ${totalHours}`;
        } else if (firstIn) {
          return `📅 **${date}**\n• First entry: ${firstIn}\n• Last exit: Not recorded yet\n• Total hours: ${totalHours}`;
        } else {
          return `📅 **${date}**\nNo attendance record found for this date.`;
        }

      case 'get_month_summary':
        const monthData = data;
        const monthName = this.formatMonthName(monthData.month);
        const totalDays = monthData.total_days || 0;
        const sumHours = monthData.total_hours || 0;
        const avgIn = monthData.average_in || 'N/A';
        const avgOut = monthData.average_out || 'N/A';
        return `📊 **Monthly Summary for ${monthName}**\n• Days present: ${totalDays}\n• Total hours: ${sumHours}\n• Average entry: ${avgIn}\n• Average exit: ${avgOut}`;

      case 'get_attendance_range':
        const rangeSummary = data.summary || {};
        const days = data.days || data.records || [];

        if (Array.isArray(days) && days.length > 0) {
          let response = `📅 **Attendance Summary**\n`;
          response += `📈 Total: ${rangeSummary.total_days || days.length} days, ${rangeSummary.total_hours || 'N/A'} hours\n\n`;

          days.forEach(rec => {
            const dateStr = rec.date || 'N/A';
            const firstIn = rec.first_in ? rec.first_in.split('T')[1] : 'N/A';
            const lastOut = rec.last_out ? rec.last_out.split('T')[1] : 'N/A';
            response += `• **${dateStr}**: ${firstIn} - ${lastOut} (${rec.total_hours || 'N/A'})\n`;
          });
          return response;
        } else {
          return `📅 **Attendance Summary**\nNo attendance records found for this date range.`;
        }

      case 'get_raw_swipes':
        const swipes = data.result || data.swipes || data;
        if (Array.isArray(swipes) && swipes.length > 0) {
          let response = `🔄 **Raw Swipes:**\n`;
          swipes.forEach(s => {
            response += `• ${s.timestamp || s.time}: ${s.type || s.direction} at ${s.location || 'N/A'}\n`;
          });
          return response;
        }
        return `No swipe data found.`;

      case 'get_employee_name':
        return `You are ${data.name || data.employee_name || 'Unknown'}.`;

      default:
        return `Here's your attendance data:\n\`\`\`json\n${JSON.stringify(data, null, 2)}\n\`\`\``;
    }
  }
}

// Export singleton instance
let mcpV2Client = null;

module.exports = {
  getEntryExitV2Client: () => {
    if (!mcpV2Client) {
      mcpV2Client = new EntryExitMCPV2Client();
    }
    return mcpV2Client;
  }
};