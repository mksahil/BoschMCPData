#!/usr/bin/env python3
import requests
import json
import time
import os

TOKEN = os.environ.get("TOKEN", "")
if not TOKEN:
    print("ERROR: TOKEN env var not set")
    exit(1)

BASE_URL = "http://localhost:3001"

def run_test(category, label, query):
    sid = f"test-{int(time.time())}-{os.getpid()}"
    start = time.time()
    try:
        resp = requests.post(
            f"{BASE_URL}/api/chat",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {TOKEN}",
                "x-employee-number": "30246494"
            },
            json={
                "query": query,
                "employeeNumber": "30246494",
                "sessionId": sid,
                "conversationHistory": []
            },
            timeout=180
        )
        elapsed = time.time() - start
        data = resp.json()
        service = data.get("service", "N/A")
        success = data.get("success", False)
        response = data.get("response", "EMPTY") or "EMPTY"

        # Determine status
        status = "FAIL"
        if success and response not in ("EMPTY", "PARSE_ERROR") and service != "ERROR":
            if any(kw in response.lower() for kw in ["unable to", "trouble connecting", "error when trying", "couldn't get", "cannot process", "currently unavailable"]):
                status = "PARTIAL"
            else:
                status = "PASS"

        print(f"[{status}] [{category}] {label} | Service: {service} | Time: {elapsed:.0f}s")
        print(f"  Query: {query}")
        print(f"  Response: {response[:300]}")
        print()
        return {"status": status, "category": category, "label": label, "service": service, "time": f"{elapsed:.0f}s", "query": query, "response": response[:300]}
    except Exception as e:
        elapsed = time.time() - start
        print(f"[FAIL] [{category}] {label} | Error: {str(e)} | Time: {elapsed:.0f}s")
        print()
        return {"status": "FAIL", "category": category, "label": label, "service": "ERROR", "time": f"{elapsed:.0f}s", "query": query, "response": str(e)}

# Remaining Entry/Exit tests
tests = [
    ("Entry/Exit", "Weekly swipes", "What are my swipe records for this week?"),
    ("Entry/Exit", "Monthly swipes", "What are my swipe details for this month?"),
    ("Entry/Exit", "January swipes", "What are my swipe details for January?"),
    ("Entry/Exit", "Avg swipe Feb", "What is my average swipe in time for February?"),
    ("Entry/Exit", "Leave yesterday", "When did I leave office yesterday?"),
    ("Entry/Exit", "Days in office", "How many days did I come to office last month?"),
]

print("=== REMAINING ENTRY/EXIT TESTS ===")
print()
results = []
for cat, label, query in tests:
    result = run_test(cat, label, query)
    results.append(result)
    time.sleep(2)

# Save results as JSON
with open("/tmp/remaining_test_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("=== SUMMARY ===")
pass_count = sum(1 for r in results if r["status"] == "PASS")
fail_count = sum(1 for r in results if r["status"] == "FAIL")
partial_count = sum(1 for r in results if r["status"] == "PARTIAL")
print(f"PASS: {pass_count} | PARTIAL: {partial_count} | FAIL: {fail_count}")
