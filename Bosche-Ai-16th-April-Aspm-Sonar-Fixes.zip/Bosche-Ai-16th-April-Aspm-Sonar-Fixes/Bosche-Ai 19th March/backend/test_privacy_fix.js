const fs = require('fs');
const path = require('path');

// Mock the detectColleagueQuery function from server.js
// Since I can't easily import it without node_modules/express etc., 
// I'll copy the logic I just modified to verify it.

function detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName) {
  const q = query.toLowerCase().trim();
  const original = query.trim();

  // --- helpers ---
  const loggedInNames = [];
  if (loggedInUserName) {
    const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
    loggedInNames.push(...parts, loggedInUserName.toLowerCase());
  }
  const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

  // Personal data keywords
  const personalDataKeywords = [
    'entry', 'exit', 'attendance', 'check.?in', 'check.?out', 'swipe',
    'leave', 'payslip', 'salary', 'pay', 'compensation',
    'working hours', 'work hours', 'hours worked', 'time tracking',
    'late', 'absent', 'shift', 'overtime',
    'schedule', 'booking', 'seat', 'travel',
    'effort', 'performance', 'appraisal',
    'data', 'details', 'info', 'information', 'record', 'records'
  ];
  const personalDataPattern = new RegExp(`(${personalDataKeywords.join('|')})`, 'i');
  const hasPersonalData = personalDataPattern.test(q);

  // Self-reference tokens
  const selfPattern = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i am)\b/i;
  const hasSelfRef = selfPattern.test(q);

  // Colleague / relationship words
  const colleaguePattern = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|subordinate|buddy|peer|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i;
  const hasColleagueWord = colleaguePattern.test(q);

  const nonNames = new Set([
    'the', 'what', 'when', 'where', 'who', 'which', 'how', 'show', 'get', 'tell', 'give', 'find', 'fetch', 'list',
    'today', 'yesterday', 'tomorrow', 'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'thank',
    'hello', 'hi', 'hey', 'time', 'times', 'entry', 'exit', 'late', 'early', 'morning', 'evening', 'night',
    'afternoon', 'seat', 'travel', 'it', 'that', 'this', 'there', 'here', 'let', 'can', 'could', 'would', 'should',
    'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look', 'all', 'any', 'some', 'these', 'those', 'last',
    'next', 'first', 'second', 'working', 'hours', 'attendance', 'schedule', 'booking', 'details', 'information',
    'info', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
    'november', 'december', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
    'bangalore', 'coimbatore', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'india', 'bosch', 'one', 'day', 'days',
    'don', 'doesn', 'didn', 'won', 'wasn', 'aren', 'isn', 'haven', 'hasn', 'shouldn', 'wouldn', 'couldn', 'today',
    'office', 'home', 'shift', 'request', 'pending', 'approved', 'status', 'canteen', 'menu', 'food', 'lunch',
    'dinner', 'breakfast', 'snack', 'now', 'just', 'been', 'also', 'very', 'work', 'log', 'report', 'data',
    'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'overtime',
    'record', 'records', 'whole', 'entire', 'past', 'previous', 'each', 'every',
    'did', 'was', 'were', 'has', 'had', 'have',
    'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
    'provide', 'retrieve', 'display', 'generate', 'calculate', 'access', 'return', 'summarize', 'include',
    'share', 'pull', 'extract', 'compile', 'compute', 'present', 'load', 'read', 'query', 'search',
    'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
    'monthly', 'daily', 'weekly', 'annual', 'yearly', 'summary', 'period', 'range', 'between', 'during',
    'employee', 'user', 'member', 'staff', 'person', 'individual',
    'attendance', 'absences', 'presence', 'duration', 'login', 'logout', 'break',
    'second', 'third', 'fourth', 'fifth', 'quarter', 'half',
    'june', 'july', 'august', 'september', 'october', 'november', 'december',
    'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips', 'pune', 'delhi', 'bangalore',
    'start', 'end', 'date', 'dates', 'being', 'mode', 'with', 'from', 'to', 'into', 'for',
    'accommodation', 'user', 'employee', 'air', 'mode', 'required', 'needed', 'wants', 'needs', 
    'requires', 'regarding', 'about', 'taxi', 'car', 'rental', 'rooms', 
    'guest', 'guests', 'passenger', 'passengers', 'arrival', 'departure', 'arrive', 'depart',
    'and', 'but', 'nor', 'yet', 'yes', 'sure', 'confirm', 'confirmation', 'confirmed', 'proceed', 'proceeding', 'proceeded', 'approve', 'approved', 'approving', 'verify', 'verified', 'verification', 'cancel', 'canceled', 'cancelled', 'cancelling',
    'new', 'old', 'location', 'locations', 'city', 'cities', 'country', 'countries', 'information', 'info', 'details', 'data', 'record', 'records'
  ]);

  // Fast path for self-ref
  if (hasSelfRef && !hasColleagueWord) {
    // Check for "of/for <name>" pattern (case-insensitive)
    const hasOfForName = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
    let otherNameDetected = false;
    if (hasOfForName) {
      const candidate = hasOfForName[1].toLowerCase();
      if (!nonNames.has(candidate) && !isOwnName(candidate)) {
        otherNameDetected = true;
      }
    }
    if (!otherNameDetected) {
      return { isColleagueQuery: false, reason: '' };
    }
  }

  // Check 9: Capitalized name near personal data
  if (!hasSelfRef) {
    const capNameRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(capNameRe)) {
      const name = m[1].toLowerCase();
      if (!nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
        const idx = m.index;
        const window = original.substring(Math.max(0, idx - 40), idx + m[1].length + 40);
        if (personalDataPattern.test(window)) {
          return { isColleagueQuery: true, reason: `Capitalized name near personal data: ${m[1]}` };
        }
      }
    }
  }

  return { isColleagueQuery: false, reason: '' };
}

// Test cases
const tests = [
  "Confirm",
  "Confirmation",
  "Confirmed",
  "Proceed",
  "Confirm my travel booking",
  "Confirmation for travel",
  "Details of my trip",
  "Information on travel",
  "Cancel booking",
  "Approved request"
];

console.log("=== Privacy Guard Test ===");
tests.forEach(test => {
  const result = detectColleagueQuery(test, "35580530", "Prasad");
  console.log(`Query: "${test}" -> Blocked: ${result.isColleagueQuery}${result.reason ? ' ('+result.reason+')' : ''}`);
});
