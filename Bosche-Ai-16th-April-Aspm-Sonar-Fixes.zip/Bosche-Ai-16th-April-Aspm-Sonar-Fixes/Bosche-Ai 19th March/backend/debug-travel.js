require('dotenv').config();
const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

async function debugTravel() {
  const apiUrl = process.env.TRAVEL_API_URL || 'https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io/';
  const jwtToken = process.env.TEST_JWT_TOKEN || 'test-token';
  const sessionId = 'test-session-' + Date.now();
  const employeeNumber = '35580530';

  console.log(`[Debug] Calling Travel Agent at: ${apiUrl}`);

  const authMetadata = {
    auth: {
      session_id: sessionId,
      token: jwtToken
    },
    employee_id: employeeNumber,
    travel_mode: 'flight'
  };

  const a2aRequest = {
    jsonrpc: '2.0',
    id: 'debug-req-' + Date.now(),
    method: 'message/send',
    params: {
      message: {
        messageId: 'debug-msg-' + Date.now(),
        role: 'user',
        parts: [
          {
            type: 'text',
            text: 'I want to book a trip from Mumbai to Delhi on 5th May to 8th May'
          }
        ]
      },
      metadata: authMetadata
    }
  };

  try {
    const response = await axios.post(apiUrl.trim().replace(/\/+$/, '') + '/', a2aRequest, {
      headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
      httpsAgent,
      timeout: 30000
    });

    console.log('[Debug] Status:', response.status);
    console.log('[Debug] Data:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    if (error.response) {
      console.log('[Debug] Error Status:', error.response.status);
      console.log('[Debug] Error Data:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('[Debug] Error:', error.message);
    }
  }
}

debugTravel();
