const { spawn } = require('child_process');
const path = require('path');

class MCPClient {
  constructor() {
    this.mcpProcess = null;
    this.messageQueue = [];
    this.responseHandlers = new Map();
    this.messageId = 0;
  }

  async connect() {
    if (this.mcpProcess) {
      return;
    }

    // Path to your MCP server
    const mcpServerPath = path.join(__dirname, '..', 'mcp-canteen-server', 'dist', 'index.js');
    
    // Spawn the MCP server process
    this.mcpProcess = spawn('node', [mcpServerPath], {
      env: {
        ...process.env,
        DB_HOST: process.env.DB_HOST || 'localhost',
        DB_USER: process.env.DB_USER || 'root',
        DB_PASSWORD: process.env.DB_PASSWORD || 'rootpassword',
        DB_NAME: process.env.DB_NAME || 'canteen_db'
      }
    });

    // Handle stdout for responses
    this.mcpProcess.stdout.on('data', (data) => {
      const lines = data.toString().split('\n').filter(line => line.trim());
      lines.forEach(line => {
        try {
          if (line.includes('{') && line.includes('}')) {
            const jsonStr = line.substring(line.indexOf('{'));
            const response = JSON.parse(jsonStr);
            this.handleResponse(response);
          }
        } catch (err) {
          console.log('MCP output:', line);
        }
      });
    });

    // Handle stderr for debug logs
    this.mcpProcess.stderr.on('data', (data) => {
      console.log('MCP debug:', data.toString());
    });

    // Handle process errors
    this.mcpProcess.on('error', (err) => {
      console.error('MCP process error:', err);
    });

    // Initialize the connection
    await this.sendInitialize();
  }

  async sendInitialize() {
    const initMessage = {
      jsonrpc: "2.0",
      method: "initialize",
      params: {
        protocolVersion: "0.1.0",
        capabilities: {},
        clientInfo: {
          name: "mybgs-companion",
          version: "1.0.0"
        }
      },
      id: this.messageId++
    };

    return this.sendMessage(initMessage);
  }

  async callTool(toolName, args) {
    const toolMessage = {
      jsonrpc: "2.0",
      method: "tools/call",
      params: {
        name: toolName,
        arguments: args
      },
      id: this.messageId++
    };

    return this.sendMessage(toolMessage);
  }

  sendMessage(message) {
    return new Promise((resolve, reject) => {
      const messageId = message.id;
      
      // Store the resolver for this message ID
      this.responseHandlers.set(messageId, { resolve, reject });
      
      // Send the message
      this.mcpProcess.stdin.write(JSON.stringify(message) + '\n');
      
      // Timeout after 10 seconds
      setTimeout(() => {
        if (this.responseHandlers.has(messageId)) {
          this.responseHandlers.delete(messageId);
          reject(new Error('MCP request timeout'));
        }
      }, 10000);
    });
  }

  handleResponse(response) {
    if (response.id !== undefined && this.responseHandlers.has(response.id)) {
      const handler = this.responseHandlers.get(response.id);
      this.responseHandlers.delete(response.id);
      
      if (response.error) {
        handler.reject(new Error(response.error.message));
      } else {
        handler.resolve(response.result);
      }
    }
  }

  // Parse natural language query and call appropriate tool
  async processCanteenQuery(query) {
    const lowerQuery = query.toLowerCase();
    
    // Detect query intent and call appropriate tool
    if (lowerQuery.includes('today') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch') || lowerQuery.includes('breakfast'))) {
      return await this.callTool('get_menu_by_date', { date: 'today' });
    }
    
    if (lowerQuery.includes('tomorrow') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch'))) {
      return await this.callTool('get_menu_by_date', { date: 'tomorrow' });
    }
    
    if (lowerQuery.includes('yesterday') && lowerQuery.includes('menu')) {
      return await this.callTool('get_menu_by_date', { date: 'yesterday' });
    }
    
    if (lowerQuery.includes('week') && lowerQuery.includes('menu')) {
      return await this.callTool('get_weekly_menu', {});
    }
    
    // Search for specific food items
    const foodItems = ['dosa', 'biryani', 'paneer', 'chicken', 'fish', 'egg', 'idli', 'vada', 'rice', 'chapati'];
    const foundItem = foodItems.find(item => lowerQuery.includes(item));
    
    if (foundItem) {
      if (lowerQuery.includes('when') || lowerQuery.includes('available')) {
        return await this.callTool('check_item_availability', { itemName: foundItem });
      } else {
        return await this.callTool('search_menu_item', { searchTerm: foundItem });
      }
    }
    
    if (lowerQuery.includes('special')) {
      return await this.callTool('get_special_menu_days', {});
    }
    
    // Default to today's menu if can't determine intent
    return await this.callTool('get_menu_by_date', { date: 'today' });
  }

  disconnect() {
    if (this.mcpProcess) {
      this.mcpProcess.kill();
      this.mcpProcess = null;
    }
  }
}

// Singleton instance
const mcpClient = new MCPClient();

module.exports = mcpClient;
