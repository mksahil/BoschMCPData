/**
 * MCP Service Manager
 * Manages the configuration and persistence of dynamic MCP services
 */

const fs = require('fs-extra');
const path = require('path');

class McpServiceManager {
  constructor() {
    this.configPath = path.join(__dirname, '../data/mcp-config.json');
    this.services = [];
    this.initialized = false;
  }

  /**
   * Initialize and load services
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      // Ensure data directory exists
      await fs.ensureDir(path.dirname(this.configPath));
      
      // Load or create config file
      if (await fs.pathExists(this.configPath)) {
        const data = await fs.readJson(this.configPath);
        this.services = data.services || [];
      } else {
        // Initialize with empty list (core services are handled separately or can be added here as defaults)
        this.services = [];
        await this.saveConfig();
      }
      
      console.log(`[McpManager] Loaded ${this.services.length} dynamic services`);
      this.initialized = true;
    } catch (error) {
      console.error('[McpManager] Failed to initialize:', error);
      throw error;
    }
  }

  /**
   * Save current configuration to disk
   */
  async saveConfig() {
    try {
      await fs.writeJson(this.configPath, { services: this.services }, { spaces: 2 });
      console.log('[McpManager] Configuration saved');
    } catch (error) {
      console.error('[McpManager] Failed to save config:', error);
      throw error;
    }
  }

  /**
   * Get all services (dynamic + core if needed)
   */
  getAllServices() {
    return this.services;
  }

  /**
   * Get a specific service by ID
   */
  getService(id) {
    return this.services.find(s => s.id === id);
  }

  /**
   * Add or update a service
   */
  async addService(serviceConfig) {
    if (!this.initialized) await this.initialize();

    // Validate config
    if (!serviceConfig.id || !serviceConfig.name || !serviceConfig.baseUrl) {
      throw new Error('Invalid service configuration. Required: id, name, baseUrl');
    }

    const existingIndex = this.services.findIndex(s => s.id === serviceConfig.id);
    
    if (existingIndex >= 0) {
      // Update
      this.services[existingIndex] = { ...this.services[existingIndex], ...serviceConfig };
    } else {
      // Add new
      this.services.push(serviceConfig);
    }

    await this.saveConfig();
    return this.services.find(s => s.id === serviceConfig.id);
  }

  /**
   * Remove a service
   */
  async removeService(id) {
    if (!this.initialized) await this.initialize();

    const initialLength = this.services.length;
    this.services = this.services.filter(s => s.id !== id);
    
    if (this.services.length !== initialLength) {
      await this.saveConfig();
      return true;
    }
    return false;
  }
}

// Export singleton
module.exports = new McpServiceManager();
