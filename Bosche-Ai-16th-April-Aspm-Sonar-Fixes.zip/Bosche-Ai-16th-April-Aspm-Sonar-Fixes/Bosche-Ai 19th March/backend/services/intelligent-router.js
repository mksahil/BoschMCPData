/**
* Intelligent Router Service
* Uses OpenAI to classify user queries and route to the appropriate MCP service
*/

const { createOpenAIClient, getChatModelName } = require('./openai-client');
const mcpServiceManager = require('./mcp-service-manager');
const configService = require('./config-service');

class IntelligentRouter {
  constructor() {
    // Initialize OpenAI only when needed (lazy initialization)
    this._openai = null;

    // Core services are now loaded dynamically from configService
    this.coreServices = {};

    // Initialize dynamic services
    mcpServiceManager.initialize().catch(err => console.error('Failed to init MCP manager:', err));
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Get all available services (core + dynamic)
   */
  getAllServices() {
    const dynamicServices = mcpServiceManager.getAllServices();
    const coreServicesFromConfig = configService.getCoreServicesSync();
    const services = { ...coreServicesFromConfig };

    // Add manual "general" service if not in config
    if (!services.general) {
      services.general = {
        name: 'General Assistant',
        description: 'Handles general questions, greetings, help requests, and queries that don\'t fit other categories',
        keywords: ['hello', 'hi', 'help', 'what can you do', 'how are you']
      };
    }

    // Merge dynamic services
    dynamicServices.forEach(service => {
      services[service.id] = {
        name: service.name,
        description: service.description || `Handles queries related to ${service.name}`,
        keywords: service.keywords || [service.name.toLowerCase()],
        isDynamic: true,
        ...service // Include full config
      };
    });

    return services;
  }

  /**
   * Use OpenAI to intelligently classify the query
   * @param {string} query - The current user query
   * @param {Array} conversationHistory - Last N messages for context [{role, content}, ...]
   */
  async classifyQuery(query, conversationHistory = []) {
    try {
      // Quick check for simple greetings - these should always go to general
      const greetingKeywords = configService.getRoutingConfigSync().greetingKeywords;
      const lowerQuery = query.toLowerCase().trim();

      // If the entire query is just a greeting (very short and matches greeting keywords)
      if (lowerQuery.length < 15 && greetingKeywords.some(greeting => lowerQuery.includes(greeting))) {
        return 'general';
      }

      // Build conversation context string if history is provided
      // Focus on the LAST user message as the primary context for follow-ups
      let historyContext = '';
      if (conversationHistory && conversationHistory.length > 0) {
        // Find the last user message (most relevant for follow-up context)
        const lastUserMsg = [...conversationHistory].reverse().find(msg => msg.role === 'user');
        const lastUserContent = lastUserMsg?.content?.substring(0, 200) || '';

        historyContext = `\n\n=== CONVERSATION CONTEXT ===
LAST USER MESSAGE (MOST IMPORTANT FOR FOLLOW-UPS): "${lastUserContent}"

Full recent history:
${conversationHistory.slice(-4).map(msg => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content.substring(0, 100)}${msg.content.length > 100 ? '...' : ''}`).join('\n')}

CRITICAL: For follow-up queries like "what about yesterday?", "and tomorrow?", "last week?", etc:
- Look at the LAST USER MESSAGE to determine the topic
- If last user asked about "entry time/attendance", then "yesterday" = entryexit
- If last user asked about "food/menu", then "yesterday" = canteen  
- If last user asked about "travel", then "status?" = travel
`;
      }

      // 1. Build the list of services safely
      const services = this.getAllServices();
      let serviceListText = '';
      let serviceNames = [];
      let index = 1;

      for (const [id, service] of Object.entries(services)) {
        serviceListText += `${index}. ${id} - ${service.description}\n`;
        serviceNames.push(id);
        index++;
      }

      // 2. Construct the system prompt
      const systemPrompt = `You are a query classifier for a workplace assistant chatbot at Bosch.
Your job is to analyze user queries and determine which service should handle them.

Available services:
${serviceListText}
${historyContext}
Respond with ONLY the service name (one of: ${serviceNames.join(', ')}).
Do not include any explanation or additional text.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        max_tokens: 20,
        temperature: 0.1
      });

      const classification = response.choices[0].message.content.trim().toLowerCase();

      // Validate the classification
      if (services[classification]) {
        return classification;
      }

      // Fallback to keyword matching if OpenAI returns unexpected value
      return this.fallbackClassify(query);

    } catch (error) {
      console.error('OpenAI classification error:', error.message);
      // Fallback to keyword-based classification
      return this.fallbackClassify(query);
    }
  }

  /**
   * Fallback keyword-based classification
   */
  fallbackClassify(query) {
    const lowerQuery = query.toLowerCase().trim();
    const services = this.getAllServices();

    // Quick check for greetings - handle them first
    const greetingKeywords = configService.getRoutingConfigSync().greetingKeywords;
    if (lowerQuery.length < 20 && greetingKeywords.some(greeting => lowerQuery.includes(greeting))) {
      return 'general';
    }

    // Check each service's keywords
    for (const [serviceName, service] of Object.entries(services)) {
      if (serviceName === 'general') continue; // Check general last

      for (const keyword of service.keywords) {
        if (lowerQuery.includes(keyword.toLowerCase())) {
          return serviceName;
        }
      }
    }

    return 'general';
  }

  /**
   * Get service information
   */
  getServiceInfo(serviceName) {
    const services = this.getAllServices();
    return services[serviceName] || services.general;
  }

  /**
   * Route query and get response from appropriate service
   * @param {string} query - The current user query
   * @param {Array} conversationHistory - Last N messages for context [{role, content}, ...]
   */
  async routeQuery(query, conversationHistory = []) {
    const startTime = Date.now();

    // Classify the query with conversation history for better context understanding
    const classification = await this.classifyQuery(query, conversationHistory);
    const serviceInfo = this.getServiceInfo(classification);

    console.log(`Query classified as: ${classification} (${serviceInfo.name})`);
    console.log(`Classification took: ${Date.now() - startTime} ms`);
    if (conversationHistory?.length > 0) {
      console.log(`Used ${conversationHistory.length} messages of conversation history for context`);
    }

    return {
      service: classification,
      serviceName: serviceInfo.name,
      description: serviceInfo.description
    };
  }

  /**
   * Generate a general response for queries that don't fit any specific service
   * @param {string} query - The current user query
   * @param {Array} conversationHistory - Last N messages for context [{role, content}, ...]
   */
  async generateGeneralResponse(query, conversationHistory = []) {
    try {
      // Build context string from history
      let historyContext = '';
      if (conversationHistory && conversationHistory.length > 0) {
        historyContext = `\n\nCONVERSATION HISTORY: \n${conversationHistory.slice(-10).map(msg => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`).join('\n')} `;
      }

      const nowIST = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
      const today = nowIST.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

      // Calculate current week boundaries (Monday–Sunday) in IST
      const dayOfWeek = nowIST.getDay(); // 0=Sun, 1=Mon, ...
      const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
      const weekStart = new Date(nowIST);
      weekStart.setDate(nowIST.getDate() + mondayOffset);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      const fmtDate = (d) => d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const weekStartStr = fmtDate(weekStart);
      const weekEndStr = fmtDate(weekEnd);

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          {
            role: 'system',
            content: `You are MyBGSW AI, a helpful workplace assistant for Bosch employees.
Today is ${today}.
The current week is: ${weekStartStr} (Monday) to ${weekEndStr} (Sunday).
When users ask about "this week" or "the current week", always use the dates above.
You can help with:
${Object.values(configService.getCoreServicesSync()).map(s => `      - ${s.name}: ${s.description}`).join('\n')}

If the user asks something outside these areas, politely let them know what you can help with.

        IMPORTANT: You have access to the conversation history.
- If the user asks you to remember something(like a date, preference, or fact), say "Sure, I'll remember that" or similar.You DO remember it because it is saved in the chat history.
- If the user asks a question about previous messages(e.g., "what did I say my favorite place was?"), ANSWER IT based on the history.
- If the user asks about a preference you previously acknowledged, recall it.
- Do NOT say "I don't have access to personal information" or "I can't store reminders" if the information is right there in the chat history.Treat the chat history as your memory.

        ${historyContext}

Keep responses concise and helpful.`
          },
          { role: 'user', content: query }
        ],
        max_tokens: 1500,
        temperature: 0.7
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('General response error:', error.message);
      return "Hello! I'm MyBGSW AI, your workplace assistant. I can help you with:\n\n• 🍽️ Cafeteria menu and food\n• ⏰ Entry/exit time tracking\n• ✈️ Travel planning\n• 💺 Desk booking\n• 👥 Community information\n\nHow can I assist you today?";
    }
  }
}

module.exports = new IntelligentRouter();
 