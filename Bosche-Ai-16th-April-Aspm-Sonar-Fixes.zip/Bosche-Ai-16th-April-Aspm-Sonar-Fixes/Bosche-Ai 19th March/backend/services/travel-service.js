/**
 * Travel Service
 * Calls the Travel MCP Server (A2A Agent) for travel planning and settlements
 * Uses stable A2A Protocol (Mirroring SeatBooking implementation)
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');
const configService = require('./config-service');
const { createOpenAIClient, getChatModelName } = require('./openai-client');
const conversationContextService = require('./conversation-context-service');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

class TravelService {
  constructor() {
    // A2A Host Agent URL (Travel Agent) - Using TRAVEL_API_URL as primary (confirmed Hub endpoint)
    let rawUrl = process.env.TRAVEL_API_URL || 'https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    // Ensure URL is trimmed and ends with exactly one slash for consistency
    this.apiUrl = rawUrl.trim().replace(/\/+$/, '') + '/';
    this.agentCardPath = '/.well-known/agent.json';

    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000;
    this.agentCard = null;
    this._openai = null;
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Fetch the agent card from the Travel A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) return this.agentCard;
    try {
      console.log(`[Travel] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(`${this.apiUrl}${this.agentCardPath}`, { httpsAgent, timeout: 10000 });
      this.agentCard = response.data;
      return this.agentCard;
    } catch (error) {
      console.error('[Travel] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Call the Travel A2A Agent using proper A2A protocol
   * Mirroring the working SeatBooking implementation for maximum stability
   */
  async callTravelAPI(message, employeeNumber, userOAuthToken, files = [], explicitJwtToken = null, explicitSessionId = null, userName = null) {
    try {
      console.log(`[Travel] Calling A2A Travel Agent at: ${this.apiUrl}`);
      console.log('[Travel] Input context:', {
        employeeNumber,
        userName: userName || '(missing)',
        hasExplicitJwt: !!explicitJwtToken,
        explicitJwtPrefix: explicitJwtToken ? String(explicitJwtToken).substring(0, 30) + '...' : null,
        hasExplicitSession: !!explicitSessionId,
        hasOAuth: !!userOAuthToken
      });

      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;
      let authStrategy = null;

      // Strategy 1: Use explicit tokens if provided (passed from login context)
      if (jwtToken) {
        authStrategy = 'STRATEGY_1_EXPLICIT_USER_JWT';
        console.log('[Travel] ✅ Strategy 1: Using EXPLICIT user JWT token');
      }

      // Strategy 2: Try cached user tokens
      if (!jwtToken && userOAuthToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userOAuthToken);
        if (cachedTokens) {
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
          authStrategy = 'STRATEGY_2_CACHED_USER_TOKENS';
          console.log('[Travel] ✅ Strategy 2: Using CACHED user tokens');
        }
      }

      // Strategy 3: Convert OAuth to JWT if needed (standard login flow)
      if (!jwtToken && userOAuthToken) {
        try {
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userOAuthToken);
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
          authStrategy = 'STRATEGY_3_OAUTH_CONVERTED';
          console.log('[Travel] ✅ Strategy 3: User JWT generated from OAuth token');
        } catch (jwtError) {
          console.log('[Travel] ❌ Strategy 3 failed: could not convert OAuth->JWT:', jwtError.message);
        }
      }

      // Sanitize tokens (prevent literal "null" strings from browsers)
      const isNullStr = (val) => typeof val === 'string' && (val.toLowerCase() === 'null' || val.toLowerCase() === 'undefined' || val === '');
      if (isNullStr(jwtToken)) jwtToken = null;
      if (isNullStr(sessionId)) sessionId = null;

      // Strategy 4: Fallback to service account (if user data missing).
      // IMPORTANT: reaching this branch means the downstream A2A agent will
      // derive its user identity from the SERVICE ACCOUNT JWT, which on the
      // server side decrypts to the default test user "Votan". If you see
      // "Votan" in responses, it means this fallback fired — check why the
      // user JWT wasn't available upstream.
      if (!jwtToken) {
        try {
          jwtToken = await boschAuthService.getServiceToken();
          if (!sessionId) {
            sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);
          }
          authStrategy = 'STRATEGY_4_SERVICE_ACCOUNT_FALLBACK';
          console.log('[Travel] ⚠️ Strategy 4: Service account JWT token obtained as fallback — A2A agent will see "Votan" identity, NOT the logged-in user!');
        } catch (authError) {
          console.log('[Travel] Service token fallback failed:', authError.message);
        }
      }

      console.log(`[Travel] Final auth strategy used: ${authStrategy || 'NONE (will throw AUTH_REQUIRED)'}`);

      if (!jwtToken) throw new Error('AUTH_REQUIRED');
      if (!sessionId) sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // ISOLATION FIX: Suffix the sessionId with '_travel' so the A2A agent
      // doesn't inherit conversation history from seat booking / gym / other
      // services that share the base sessionId. Cross-service pollution on
      // the agent side was causing Python errors like
      //   "'str' object has no attribute 'get'"
      // because the agent tries to read stale metadata from the prior
      // service's conversation state. SeatBooking already does this with
      // a '_seat' suffix — Travel must mirror it with '_travel'.
      const isolatedSessionId = sessionId ? `${sessionId}_travel` : `travel_${Date.now()}`;

      console.log('[Travel] STABLE Session ID:', isolatedSessionId, '(base:', sessionId, ')');

      // Extract email/empNo from JWT claims (name is usually encrypted, so we
      // DO NOT pull it from there — see below).
      //
      // CRITICAL BUG HISTORY: Previously this block overwrote `userName` with
      // `claims.name` from the JWT. But the Bosch JWT stores `name` as an
      // encrypted AES blob (e.g. "mR1DfNIos4AKDqjZdIEl4AFu...=="), which the
      // downstream A2A agent can't parse. When that encrypted gibberish was
      // sent in `metadata.user_name`, the Travel agent fell back to its
      // hardcoded default test user "Votan" — causing retrieval responses to
      // start with "Votan, I checked your travel plans...". We now prefer the
      // explicit `userName` from the login context (which is the REAL plain
      // name) and only use a JWT claim if it clearly isn't an encrypted blob.
      let jwtName = null;
      let jwtEmail = null;
      let jwtEmpNo = null;

      const looksEncrypted = (val) => {
        if (typeof val !== 'string') return false;
        const v = val.trim();
        if (!v) return false;
        // Heuristic: encrypted blobs are base64-ish, no spaces, length > 24,
        // and usually end with "==" padding. Real names have spaces or short.
        if (v.includes(' ')) return false;
        if (v.length < 24) return false;
        if (/[^A-Za-z0-9+/=_-]/.test(v)) return false;
        return v.endsWith('==') || v.length > 40;
      };

      try {
        if (typeof jwtToken === 'string' && jwtToken.split('.').length === 3) {
          const payloadB64 = jwtToken.split('.')[1]
            .replace(/-/g, '+').replace(/_/g, '/');
          const padded = payloadB64 + '==='.slice((payloadB64.length + 3) % 4);
          const claims = JSON.parse(Buffer.from(padded, 'base64').toString('utf8'));

          // DIAGNOSTIC: dump the claim keys and the raw name claim so we can
          // tell from the logs whether the JWT is a service-account token
          // (whose name claim decrypts server-side to "Votan") or the real
          // user JWT.
          const claimKeys = Object.keys(claims).filter(k => !['exp', 'iat', 'nbf', 'iss', 'aud', 'jti'].includes(k));
          console.log('[Travel] 🔑 JWT claim keys:', claimKeys);
          console.log('[Travel] 🔑 JWT raw user claims:', {
            name: claims.name || claims.Name || null,
            username: claims.username || claims.userName || null,
            given_name: claims.given_name || null,
            email: claims.email || claims.Email || null,
            sub: claims.sub || null,
            employeeNumber: claims.employeeNumber || claims.emp_number || null,
            nameLooksEncrypted: looksEncrypted(claims.name || claims.Name || '')
          });
          if (claims.exp) {
            const expiresAt = new Date(claims.exp * 1000).toISOString();
            const isExpired = Date.now() > claims.exp * 1000;
            console.log(`[Travel] 🔑 JWT exp: ${expiresAt} (expired=${isExpired})`);
          }

          const rawName = claims.name || claims.Name || claims.username || claims.userName || claims.given_name || null;
          // Only trust the claim if it isn't an encrypted blob
          if (rawName && !looksEncrypted(rawName)) {
            jwtName = rawName;
          }
          jwtEmail = claims.email || claims.Email || claims.EmailId || null;
          if (looksEncrypted(jwtEmail)) jwtEmail = null;
          jwtEmpNo = claims.emp_number || claims.employeeNumber || claims.id || claims.sub || null;
        }
      } catch (e) {
        console.log('[Travel] Auth enrichment failed:', e.message);
      }

      // Final Sanitization: Ensure all identity fields are strings and non-empty.
      // Order of preference: explicit userName from login context > JWT plain claim > fallback.
      // This was previously inverted and caused the "Votan" default bug.
      const safeId = String(employeeNumber || jwtEmpNo || '34835634').replace(/[^0-9]/g, '') || String(employeeNumber || '34835634');
      const safeName = (userName && !looksEncrypted(userName)) ? userName : (jwtName || 'Bosch User');
      const safeEmail = jwtEmail || (safeId.includes('@') ? safeId : `${safeId}@bosch.com`);

      console.log(`[Travel] A2A Sync: Using Identity: Name="${safeName}", ID=${safeId}, Email=${safeEmail}`);

      // Build auth metadata as per standard A2A protocol (exactly matches SeatBooking)
      // Including mandatory employee identity and enriched profile info.
      const authMetadata = {
        auth: {
          session_id: isolatedSessionId,
          token: jwtToken
        },
        employee_id: safeId,
        user_id: safeId,             // Mirroring employee_id as string
        user_name: safeName,         // Non-null user name
        user_email: safeEmail,       // Non-null user email
        travel_mode: (message.toLowerCase().includes('train') ? 'train' : 
                     message.toLowerCase().includes('bus') ? 'bus' : 
                     message.toLowerCase().includes('taxi') ? 'taxi' : 'flight'),
        // Also provide a nested user_data object as some agents look for it
        user_data: {
          employee_id: safeId,       // Synchronized with SeatBooking/Candidate G
          name: safeName,
          email: safeEmail
        }
      };

      console.log(`[Travel] A2A Sync: Mode=${authMetadata.travel_mode}, Identity="${safeName}" (ID=${safeId})`);

      // Standard A2A Protocol: SendMessageRequest format
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          message: {
            messageId: messageId,
            role: 'user',
            parts: [
              {
                type: 'text',
                text: message
              }
            ]
          },
          metadata: authMetadata
        }
      };

      const response = await axios.post(this.apiUrl, a2aRequest, {
        headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
        httpsAgent,
        timeout: 300000 // 5 minutes
      });

      const a2aResult = response.data;
      if (a2aResult.error) throw new Error(a2aResult.error.message || 'A2A request failed');

      return a2aResult.result;
    } catch (error) {
      console.error('[Travel] API error:', error.message);
      throw error;
    }
  }

  /**
   * Check if query is asking about another person's travel data.
   *
   * Strategy: Instead of flagging every unknown capitalised word as a person
   * name (which false-positives on cities, airlines, hotels, etc.), we detect
   * **syntactic patterns** that strongly indicate a person reference:
   *   A) Possessive:  "Rajesh's travel expenses"
   *   B) Genitive:    "travel details of Kumar"
   *   C) Action-for:  "book a flight for Priya"
   *   D) Name-before-travel-noun: "Check Ramesh travel booking"
   *
   * Capitalised words appearing after travel prepositions (to/from/in/at/via …)
   * are treated as locations and excluded from name checks.
   */
  isQueryAboutOtherPerson(query, loggedInUserName) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // ── Helper: does `name` match the logged-in user? ──
    const isOwnName = (name) => {
      if (!loggedInUserName) return false;
      const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
      const n = name.toLowerCase();
      return parts.some(p => p === n || n.includes(p) || p.includes(n));
    };

    // ── Step 1 – Gate: must contain a travel-data keyword (from config) ──
    const travelKwConfig = configService.getKeywordConfigSync().travelService;
    const travelDataKeywords = travelKwConfig.travelDataKeywords;
    if (!travelDataKeywords.some(kw => q.includes(kw))) return false;

    // ── Step 2 – Self-reference → safe (unless colleague word) ──
    const hasSelfRef  = /\b(my|mine|me|myself|i)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|team\s?mate|boss|manager|reportee|someone\s+else)\b/i.test(q);
    if (hasSelfRef && !hasColleagueWord) return false;

    // ── Step 3 – Colleague / role word → blocked ──
    if (hasColleagueWord) return true;

    // ── Step 4 – Third-person possessive pronoun + travel noun → blocked ──
    //   Matching "his trip", "her booking", "their expenses" etc.
    //   Avoids false-positives from standalone "he/she/they" (e.g. "they cancelled the flight").
    const travelNounRe = '(?:travel|trip|flight|booking|expense|settlement|reimbursement|itinerary|ticket|details?|data|records?|history|status|info|information)';
    if (new RegExp(`\\b(his|her|their)\\s+${travelNounRe}`, 'i').test(q)) return true;
    if (/\bfor\s+(him|her|them)\b/i.test(q)) return true;

    // ── Step 5 – Pattern-based person-name detection ──

    // 5.0  Build a set of words that appear after travel prepositions → these are locations
    const locationPositions = new Set();
    const prepRe = /\b(?:to|from|in|at|via|through|near|around|between|towards?|into)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)/g;
    for (const m of original.matchAll(prepRe)) {
      m[1].toLowerCase().split(/\s+/).forEach(w => locationPositions.add(w));
    }

    // 5.1  Combined safe-word check: global whitelist + travel entities + preposition locations
    const whitelist = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));

    //      Travel-specific proper nouns from config (airlines, hotels, cities, etc.)
    const TRAVEL_ENTITIES = new Set(travelKwConfig.travelEntities.map(e => e.toLowerCase()));

    const isKnownSafe = (name) => {
      const n = name.toLowerCase();
      if (whitelist.has(n) || TRAVEL_ENTITIES.has(n) || locationPositions.has(n)) return true;
      // Multi-word: safe if any constituent word is recognised
      return n.split(/\s+/).some(w => whitelist.has(w) || TRAVEL_ENTITIES.has(w) || locationPositions.has(w));
    };

    // ── Pattern A: Possessive — "<Name>'s …" (strongest person signal) ──
    for (const m of original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)'s\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: possessive "${m[1]}'s"`);
        return true;
      }
    }

    // ── Pattern B: "<travel noun> of/for <Name>" ──
    const genitiveRe = new RegExp(
      `\\b${travelNounRe}\\s+(?:of|for)\\s+([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\b`, 'g'
    );
    for (const m of original.matchAll(genitiveRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: "of/for ${m[1]}" after travel noun`);
        return true;
      }
    }

    // ── Pattern C: "book/show/get … for <Name>" (not a known location) ──
    for (const m of original.matchAll(/\b(?:book|show|get|find|fetch|check|retrieve|pull|display)\b[^.]*?\bfor\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: action "for ${m[1]}"`);
        return true;
      }
    }

    // ── Pattern D: "<Name> <travel-data-noun>" where Name is NOT after a preposition ──
    const nameBeforeNounRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${travelNounRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeNounRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        // Make sure it's not immediately preceded by a travel preposition
        const before = original.substring(Math.max(0, m.index - 15), m.index).trim().toLowerCase();
        if (!/\b(?:to|from|in|at|via|through|near|around|between)\s*$/.test(before)) {
          console.log(`[Travel Privacy] Blocked: "${m[1]}" before travel noun`);
          return true;
        }
      }
    }

    // No person-name pattern detected → safe
    return false;
  }

  /**
   * Extract travel slots using LLM
   */
  async extractTravelSlots(query, history = [], currentState = {}) {
    try {
      const today = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: 'full' });
      const systemPrompt = `You are a travel parameter extractor. Extract travel details from the user's latest query into JSON.
Current Date (IST): ${today}
Current State: ${JSON.stringify(currentState)}

FIELDS TO EXTRACT:
- from: Origin city (CRITICAL: Do not swap with destination)
- to: Destination city (CRITICAL: Do not swap with origin)
- startDate: Departure date (YYYY-MM-DD. If relative like 'next Friday', calculate from ${today})
- endDate: Return date (YYYY-MM-DD. Must be after startDate)
- passengers: Number of people (integer, default 1)
- travelClass: Preferred class (Economy, Business, First)
- preferences: Any other notes (specific airlines, hotels, activities, etc.)
- approved: Boolean (Set true if user says: yes, yep, sure, go ahead, confirm, book it, let's do it, or anything affirmative.)
- isNewBooking: Boolean (Set true if the user wants to start a FRESH travel request. This should be true if: (A) They use keywords like 'new', 'another', 'start over', 'start fresh'; (B) They use generic initiation phrases like 'book a ticket', 'I want to travel', 'plan a trip' without providing more specific details yet; OR (C) The user provides a NEW origin (from) or destination (to) that clearly contradicts the current incomplete state.)

CONSTRAINTS:
- If the user says "Mysore to Bangalore", from="Mysore" and to="Bangalore". DO NOT SWAP THEM.
- Ensure dates strictly follow the user's request. If the user mentions specific dates in May 2026, use those exact dates.
- Return a JSON object with all fields above. Identify if any mandatory fields are missing based on the aggregated context (current state + new query) and list them in "missingFields" (array).
- Set "isComplete": true if and only if all 4 mandatory fields (from, to, startDate, endDate) are present in the final aggregate state.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (e) {
      console.error('[Travel] Extraction error:', e.message);
      return { isComplete: false };
    }
  }

  /**
   * Main query entry point
   */
  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId, userName } = context;

      // DIAGNOSTIC: confirm identity fields actually arrived from server.js.
      // If userName here is '(missing)' or 'Bosch User', then the A2A agent
      // will fall back to its default test user "Votan" regardless of what
      // we try to pass in metadata.
      console.log('[Travel] processQuery context received:', {
        employeeNumber: employeeNumber || '(missing)',
        userName: userName || '(missing)',
        hasAuthToken: !!authToken,
        hasJwtToken: !!jwtToken,
        jwtPrefix: jwtToken ? String(jwtToken).substring(0, 30) + '...' : null,
        hasSessionId: !!sessionId
      });

      if (this.isQueryAboutOtherPerson(query, userName)) {
        return { success: false, response: "I'm sorry, but I can only provide your own personal information for privacy reasons." };
      }

      const sessionContext = conversationContextService.getContext(sessionId);

      // 1. Check for EXPLICIT "Retrieval" intent phrases
      // Phrases like "show my travel plans" or "list my bookings" should skip
      // slot-extraction and go straight to the A2A agent, which manages
      // retrieval naturally.
      const retrievalPhrases = [
        /\b(?:show|list|view|display|get|retrieve|see)\b.*\b(?:my|mine)\b.*\b(?:plan|plans|trip|trips|booking|bookings|itinerary|itineraries)\b/i,
        /\b(?:my|mine)\b.*\b(?:plan|plans|trip|trips|booking|bookings|itinerary|itineraries)\b.*\b(?:details|info|information|status)\b/i,
        /^\s*(?:my\s+)?(?:plans|bookings|trips)\s*$/i
      ];
      const isRetrievalQuery = retrievalPhrases.some(re => re.test(query));

      if (isRetrievalQuery) {
        console.log(`[Travel] Retrieval intent detected: "${query}". Delegating directly to A2A Agent.`);
        let result = await this.callTravelAPI(query, employeeNumber, authToken, [], jwtToken, sessionId, userName);
        let response = this.formatTravelResponse(result, userName);

        // Same Python-error detection as the booking path: if the agent
        // returned an internal error, retry once with a fresh session id
        // before giving up.
        const looksLikeAgentInternalError = (text) => {
          if (!text || typeof text !== 'string') return false;
          return /'str'\s+object\s+has\s+no\s+attribute\s+'get'/i.test(text)
            || /traceback\s*\(most recent call last\)/i.test(text)
            || /AttributeError|TypeError|KeyError/.test(text)
            || /travel agent tool.*error/i.test(text)
            || /unable to process travel booking requests due to an issue with the travel agent/i.test(text);
        };

        if (looksLikeAgentInternalError(response)) {
          console.warn('[Travel] ⚠️ Retrieval path: agent internal error detected. Retrying with fresh session id.');
          const retrySessionId = `travel_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          try {
            result = await this.callTravelAPI(query, employeeNumber, authToken, [], jwtToken, retrySessionId, userName);
            response = this.formatTravelResponse(result, userName);
          } catch (retryErr) {
            console.error('[Travel] Retrieval retry failed:', retryErr.message);
          }

          if (looksLikeAgentInternalError(response)) {
            return {
              success: false,
              response: "✈️ **Travel Assistant**\n\nI'm temporarily unable to retrieve travel plans — the travel agent service is returning an internal error. This is usually transient. Please try again in a minute.",
              travelState: sessionContext.travelState
            };
          }
        }

        return {
          success: true,
          response,
          data: result,
          travelState: sessionContext.travelState
        };
      }

      // 2. Check for EXPLICIT "Force Reset" trigger phrases before calling LLM
      const forceResetPhrases = [/^\s*book a travel\s*$/i, /^\s*book a ticket\s*$/i, /^\s*plan a trip\s*$/i, /^\s*start a new booking\s*$/i, /^\s*book another ticket\s*$/i, /^\s*start over\s*$/i, /^\s*new booking\s*$/i];
      const isForceReset = forceResetPhrases.some(re => re.test(query));
      
      // 3. Extract slots and intent from current query
      const extraction = await this.extractTravelSlots(query, [], sessionContext.travelState);

      // 3. Handle New Booking Intent: Reset state if user clearly wants a fresh start
      if (extraction.isNewBooking || isForceReset) {
        console.log(`[Travel] New booking intent detected (ForceReset: ${isForceReset}), resetting travelState.`);
        sessionContext.travelState = {
          from: null, to: null, startDate: null, endDate: null,
          passengers: 1, travelClass: null, preferences: null,
          isComplete: false, approved: false, missingFields: []
        };
      }

      // Smart Merge: Preserve previous non-null values and truthy flags
      const newState = { ...sessionContext.travelState };

      // Update fields if new extraction has value
      ['from', 'to', 'startDate', 'endDate', 'passengers', 'travelClass', 'preferences'].forEach(field => {
        if (extraction[field]) newState[field] = extraction[field];
      });

      // Update flags (once true, they stay true unless user specifically cancels which isn't handled here)
      newState.isComplete = sessionContext.travelState.isComplete || extraction.isComplete || false;
      newState.approved = sessionContext.travelState.approved || extraction.approved || false;
      newState.missingFields = extraction.missingFields || [];

      // Programmatic Sanity Check for completion
      if (!newState.isComplete && newState.from && newState.to && newState.startDate && newState.endDate) {
        console.log('[Travel] Programmatic check: context IS complete.');
        newState.isComplete = true;
        newState.missingFields = [];
      }

      sessionContext.travelState = newState;

      // Phase 1: Check for mandatory completion
      if (!sessionContext.travelState.isComplete) {
        console.log(`[Travel] Context incomplete. Missing: ${sessionContext.travelState.missingFields?.join(', ')}`);

        // Generate a friendly local response asking for missing fields
        const missingResponse = await this.generateLocalGatheringResponse(
          query,
          sessionContext.travelState,
          sessionContext.travelState.missingFields
        );

        return {
          success: true,
          response: missingResponse,
          travelState: sessionContext.travelState
        };
      }

      // Phase 2: Context is complete, hand off to A2A Agent
      console.log('[Travel] Context complete, delegating to A2A Agent.');

      // Sanitize travelState fields into plain primitives/strings. The LLM
      // extractor can occasionally return `preferences` as an object or array,
      // which would get stringified as "[object Object]" and confuse the
      // downstream agent. Forcing everything to a plain string here keeps the
      // consolidated prompt clean.
      const toPlainString = (val) => {
        if (val === null || val === undefined) return '';
        if (typeof val === 'string') return val;
        if (typeof val === 'number' || typeof val === 'boolean') return String(val);
        try { return JSON.stringify(val); } catch { return String(val); }
      };

      const safeState = {
        from: toPlainString(sessionContext.travelState.from),
        to: toPlainString(sessionContext.travelState.to),
        startDate: toPlainString(sessionContext.travelState.startDate),
        endDate: toPlainString(sessionContext.travelState.endDate),
        passengers: toPlainString(sessionContext.travelState.passengers) || '1',
        travelClass: toPlainString(sessionContext.travelState.travelClass) || 'Not specified',
        preferences: toPlainString(sessionContext.travelState.preferences) || 'None',
        approved: !!sessionContext.travelState.approved
      };

      // Build consolidated prompt for the agent
      const consolidatedPrompt = `Travel Booking Request:
- From: ${safeState.from}
- To: ${safeState.to}
- Departure: ${safeState.startDate}
- Return: ${safeState.endDate}
- Passengers: ${safeState.passengers}
- Class: ${safeState.travelClass}
- Preferences: ${safeState.preferences}
- Confirmed/Approved: ${safeState.approved ? 'Yes' : 'User is reviewing details'}

Full User Request: ${toPlainString(query)}`;

      // Helper: detect the Python-style internal errors the A2A agent
      // sometimes returns as plain text (e.g. "'str' object has no attribute
      // 'get'"). When we see one, we retry once with a fresh isolated
      // session id to blow away any poisoned agent-side state.
      const looksLikeAgentInternalError = (text) => {
        if (!text || typeof text !== 'string') return false;
        return /'str'\s+object\s+has\s+no\s+attribute\s+'get'/i.test(text)
          || /traceback\s*\(most recent call last\)/i.test(text)
          || /AttributeError|TypeError|KeyError/.test(text)
          || /travel agent tool.*error/i.test(text)
          || /unable to book your travel/i.test(text)
          || /unable to process travel booking requests due to an issue with the travel agent/i.test(text);
      };

      let result = await this.callTravelAPI(consolidatedPrompt, employeeNumber, authToken, [], jwtToken, sessionId, userName);
      let response = this.formatTravelResponse(result, userName);

      if (looksLikeAgentInternalError(response)) {
        console.warn('[Travel] ⚠️ Detected internal A2A agent error in response. Retrying once with a fresh isolated session id.');
        // Rotate the session id so the agent drops any poisoned state
        // associated with the current session on its side.
        const retrySessionId = `travel_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        try {
          result = await this.callTravelAPI(consolidatedPrompt, employeeNumber, authToken, [], jwtToken, retrySessionId, userName);
          response = this.formatTravelResponse(result, userName);
        } catch (retryErr) {
          console.error('[Travel] Retry with fresh session failed:', retryErr.message);
        }

        if (looksLikeAgentInternalError(response)) {
          console.error('[Travel] Retry still returned an internal agent error. Surfacing friendly message.');
          return {
            success: false,
            response: "✈️ **Travel Assistant**\n\nI'm temporarily unable to process travel bookings — the travel agent service is returning an internal error. This is usually transient. Please try again in a minute, or visit the Bosch travel portal directly if the issue persists.",
            travelState: sessionContext.travelState
          };
        }
      }

      // Check if booking was successful/recorded (clear state for next time)
      const lowerResponse = response.toLowerCase();
      if (lowerResponse.includes('creation id') || lowerResponse.includes('recorded') || lowerResponse.includes('finalized') || lowerResponse.includes('confirmed')) {
        console.log('[Travel] Success response detected, clearing travelState.');
        sessionContext.travelState = {
          from: null, to: null, startDate: null, endDate: null,
          passengers: 1, travelClass: null, preferences: null,
          isComplete: false, approved: false, missingFields: []
        };
      }

      return {
        success: true,
        response,
        data: result,
        travelState: sessionContext.travelState
      };
    } catch (error) {
      console.error('[Travel] Process error:', error.message);
      return { success: false, response: "✈️ **Travel Assistant**\n\nI'm having trouble connecting to the travel system. Please try again or visit the portal directly." };
    }
  }

  /**
   * Generate a friendly local response when fields are missing
   */
  async generateLocalGatheringResponse(query, state, missingFields = []) {
    try {
      const systemPrompt = `You are a helpful travel assistant. The user wants to book travel.
Current State: ${JSON.stringify(state)}
Missing Mandatory Fields: ${missingFields.join(', ')}

Your goal:
1. Acknowledge what the user just provided.
2. Politely ask for the missing information (Origin, Destination, Start Date, or End Date).
3. Be concise and friendly.
4. If they just said "book travel" without details, provide the list of things needed (similar to: Where, When, Who, Class, Preferences).

Respond in Markdown.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        temperature: 0.7
      });

      const text = response.choices[0].message.content;
      return `✈️ **Travel Assistant**\n\n${text}`;
    } catch (e) {
      return "✈️ **Travel Assistant**\n\nI've noted those details. Could you please provide your departure and return dates so I can help you with the booking?";
    }
  }

  /**
   * Format the final display text — aggregates text/data from ALL parts,
   * artifacts, history entries, and top-level data payloads returned by the
   * A2A Travel Agent.
   *
   * The old implementation picked only the FIRST text part from
   * result.status.message.parts, which meant that when the agent returned
   * a short acknowledgement text first and then pushed flight options / fare
   * / fund details into an artifact (or a later `data` part, or
   * `result.artifacts[].parts[]`), none of those details ever reached the
   * user. This is why "fund details" were missing after the booking was
   * delegated to the agent.
   *
   * This version mirrors `formatSeatBookingResponse`: it collects every
   * text and data chunk it can find, de-duplicates them, and joins them
   * into a single response. It also safely handles the "Processing..."
   * placeholder so it can be skipped without discarding other real content.
   */
  formatTravelResponse(result, userName) {
    if (!result) return "✈️ **Travel Assistant**\n\nNo response from travel system.";

    console.log('[Travel] Raw A2A Result keys:', Object.keys(result));
    if (result.status) console.log('[Travel] Result status keys:', Object.keys(result.status));
    if (result.artifacts) console.log('[Travel] Result artifacts count:', result.artifacts.length);
    
    // DEBUG: Look for "fund" or "cost" in the stringified result
    const rawString = JSON.stringify(result);
    if (rawString.toLowerCase().includes('fund') || rawString.toLowerCase().includes('detail')) {
      console.log('[Travel] 🔍 FOUND mentions of "fund" or "detail" in raw response!');
      // Log the full result for deep inspection
      console.log('[Travel] FULL RESULT:', JSON.stringify(result, null, 2));
    }

    const textChunks = [];

    const pushChunk = (val) => {
      if (val === undefined || val === null) return;
      let s;
      if (typeof val === 'string') s = val;
      else {
        try { s = JSON.stringify(val, null, 2); } catch { s = String(val); }
      }
      s = s.trim();
      if (!s) return;
      // Skip the noisy "Processing..." placeholder — the agent often sends
      // it as a first text frame before the real answer, and surfacing it
      // would hide the actual content that comes after.
      if (s === 'Processing...') return;
      textChunks.push(s);
    };

    const collectFromParts = (parts) => {
      if (!Array.isArray(parts)) return;
      for (const p of parts) {
        if (!p) continue;
        
        // Capture text from any field name the agent might use
        if (typeof p.text === 'string') pushChunk(p.text);
        if (typeof p.content === 'string') pushChunk(p.content);
        
        // Capture data objects from any field name
        if (p.data !== undefined) pushChunk(p.data);
        if (p.content !== undefined && typeof p.content === 'object') pushChunk(p.content);
        
        // Fallback: if the part has none of the above but has a 'result' or 'payload'
        if (p.result !== undefined) pushChunk(p.result);
        if (p.payload !== undefined) pushChunk(p.payload);
      }
    };

    // 1) Primary message parts
    if (result.status?.message?.parts) collectFromParts(result.status.message.parts);
    if (result.message?.parts) collectFromParts(result.message.parts);

    // 2) Artifacts — the A2A Travel Agent places flight options, fare /
    //    fund breakdowns and structured booking data here.
    if (Array.isArray(result.artifacts)) {
      for (const art of result.artifacts) {
        if (!art) continue;
        if (art.parts) collectFromParts(art.parts);
        if (art.content !== undefined) pushChunk(art.content);
        if (art.data !== undefined) pushChunk(art.data);
      }
    }

    // 3) Top-level data fields
    if (result.status?.data !== undefined) pushChunk(result.status.data);
    if (result.data !== undefined) pushChunk(result.data);

    // 4) History: Always check the latest agent turn for details that might 
    //    not be in the primary message (like fund breakdowns). We collect 
    //    everything and de-duplicate at the end to be safe.
    if (Array.isArray(result.history)) {
      const agentMsgs = result.history.filter(h => h?.role === 'agent');
      if (agentMsgs.length > 0) {
        // Collect from the last 2 agent messages just in case details 
        // were split across turns or echoed.
        const startIdx = Math.max(0, agentMsgs.length - 2);
        for (let i = agentMsgs.length - 1; i >= startIdx; i--) {
          collectFromParts(agentMsgs[i]?.parts);
        }
      }
    }

    // De-duplicate identical chunks (agents sometimes echo the same text
    // in both `status.message.parts` and `history`)
    const seen = new Set();
    const unique = textChunks.filter(t => { if (seen.has(t)) return false; seen.add(t); return true; });

    if (unique.length === 0) {
      return "✈️ **Travel Assistant**\n\nReceived a response from the travel agent but couldn't extract any readable content. Please try again or check the server logs.";
    }

    let joined = unique.join('\n\n');

    // Replace the fallback dev test identity ("Votan") with the real user's
    // first name so the response doesn't confuse the user when the service
    // account JWT is in use.
    if (userName) {
      const firstName = String(userName).split(' ')[0];
      if (firstName) {
        joined = joined.replace(/Votan/gi, firstName);
      }
    }

    return `✈️ **Travel Assistant**\n\n${joined}`;
  }
}

module.exports = new TravelService();
