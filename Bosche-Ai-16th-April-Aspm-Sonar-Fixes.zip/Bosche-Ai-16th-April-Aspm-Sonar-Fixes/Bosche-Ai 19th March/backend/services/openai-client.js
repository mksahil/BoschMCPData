const OpenAI = require('openai');

const AZURE_API_VERSION_DEFAULT = '2024-12-01-preview';

function getAzureConfig() {
  return {
    apiKey: process.env.AZURE_OPENAI_API_KEY,
    endpoint: process.env.AZURE_OPENAI_ENDPOINT,
    deployment: process.env.AZURE_OPENAI_DEPLOYMENT,
    apiVersion: process.env.AZURE_OPENAI_API_VERSION || AZURE_API_VERSION_DEFAULT
  };
}

function isAzureOpenAI() {
  const { apiKey, endpoint, deployment } = getAzureConfig();
  return !!(apiKey && endpoint && deployment);
}

function createOpenAIClient() {
  if (isAzureOpenAI()) {
    const { apiKey, endpoint, deployment, apiVersion } = getAzureConfig();
    const baseUrl = `${endpoint.replace(/\/+$/, '')}/openai/deployments/${deployment}`;

    return new OpenAI({
      apiKey,
      baseURL: baseUrl,
      defaultQuery: { 'api-version': apiVersion },
      defaultHeaders: { 'api-key': apiKey }
    });
  }

  return new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });
}

function getChatModelName(defaultModel = 'gpt-4o') {
  if (isAzureOpenAI()) {
    return getAzureConfig().deployment;
  }

  return process.env.OPENAI_MODEL || defaultModel;
}

module.exports = {
  createOpenAIClient,
  getChatModelName,
  isAzureOpenAI
};
