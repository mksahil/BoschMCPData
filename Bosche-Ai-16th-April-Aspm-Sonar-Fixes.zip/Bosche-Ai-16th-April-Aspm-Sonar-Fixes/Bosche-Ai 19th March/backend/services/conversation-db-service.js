/**
 * Conversation Database Service
 * Persists chat conversations to MS SQL Azure DB
 * Table: dbo.Conversation (Id, SessionId, Source, Time, Question, Answer, Feedback)
 * Feedback values: 0 = no feedback, -1 = thumbs down, +1 = thumbs up
 * 
 * NOTE: The original schema uses BIT for Feedback (only 0/1). 
 * If your table uses BIT, -1 will be stored as 0. For full -1/0/+1 support,
 * ALTER the column to SMALLINT: ALTER TABLE dbo.Conversation ALTER COLUMN Feedback SMALLINT NOT NULL;
 */

const sql = require('mssql');

class ConversationDbService {
    constructor() {
        this.pool = null;
        this.connectionString = process.env.MSSQL_CONNECTION_STRING || '';
        this.isConnected = false;
    }

    /**
     * Parse the ADO.NET-style connection string into mssql config
     */
    _parseConnectionString(connStr) {
        const parts = {};
        connStr.split(';').forEach(part => {
            const [key, ...valueParts] = part.split('=');
            if (key && valueParts.length > 0) {
                parts[key.trim().toLowerCase()] = valueParts.join('=').trim();
            }
        });

        // Parse server (format: tcp:hostname,port)
        let server = parts['server'] || parts['data source'] || '';
        let port = 1433;

        // Remove tcp: prefix
        server = server.replace(/^tcp:/i, '');

        // Extract port if present (comma-separated)
        if (server.includes(',')) {
            const [host, p] = server.split(',');
            server = host;
            port = parseInt(p, 10);
        }

        return {
            server,
            port,
            database: parts['initial catalog'] || parts['database'] || '',
            user: parts['user id'] || parts['uid'] || '',
            password: parts['password'] || parts['pwd'] || '',
            options: {
                encrypt: (parts['encrypt'] || 'true').toLowerCase() === 'true',
                trustServerCertificate: (parts['trustservercertificate'] || 'false').toLowerCase() === 'true',
                connectTimeout: parseInt(parts['connection timeout'] || '30', 10) * 1000,
                requestTimeout: 30000,
            },
            pool: {
                max: 10,
                min: 0,
                idleTimeoutMillis: 30000
            }
        };
    }

    /**
     * Connect to the database
     */
    async connect() {
        if (this.isConnected && this.pool) {
            return this.pool;
        }

        if (!this.connectionString) {
            console.warn('[ConversationDB] No MSSQL_CONNECTION_STRING configured. DB persistence disabled.');
            return null;
        }

        try {
            const config = this._parseConnectionString(this.connectionString);
            console.log(`[ConversationDB] Connecting to ${config.server}:${config.port}/${config.database}...`);

            this.pool = await sql.connect(config);
            this.isConnected = true;
            console.log('[ConversationDB] Connected successfully to MS SQL Azure DB');

            // Handle pool errors
            this.pool.on('error', (err) => {
                console.error('[ConversationDB] Pool error:', err.message);
                this.isConnected = false;
                this.pool = null;
            });

            return this.pool;
        } catch (error) {
            console.error('[ConversationDB] Connection failed:', error.message);
            this.isConnected = false;
            this.pool = null;
            return null;
        }
    }

    /**
     * Save a conversation (question + answer) to the database
     * Returns the inserted row Id for feedback reference
     */
    async saveConversation(sessionId, source, question, answer) {
        try {
            const pool = await this.connect();
            if (!pool) {
                console.warn('[ConversationDB] Skipping save — no DB connection');
                return null;
            }

            const result = await pool.request()
                .input('SessionId', sql.UniqueIdentifier, sessionId)
                .input('Source', sql.NVarChar(50), source || 'web')
                .input('Time', sql.DateTimeOffset, new Date())
                .input('Question', sql.NVarChar(sql.MAX), question)
                .input('Answer', sql.NVarChar(sql.MAX), answer || '')
                .input('Feedback', sql.SmallInt, 0) // Default: no feedback
                .query(`
          INSERT INTO [dbo].[Conversation] 
            ([SessionId], [Source], [Time], [Question], [Answer], [Feedback])
          OUTPUT INSERTED.Id
          VALUES 
            (@SessionId, @Source, @Time, @Question, @Answer, @Feedback)
        `);

            const insertedId = result.recordset[0]?.Id;
            console.log(`[ConversationDB] Saved conversation ID: ${insertedId}`);
            return insertedId;

        } catch (error) {
            console.error('[ConversationDB] Error saving conversation:', error.message);
            return null;
        }
    }

    /**
     * Update feedback for a conversation
     * @param {number} conversationId - The row Id
     * @param {number} feedback - -1 (thumbs down), 0 (no feedback), 1 (thumbs up)
     */
    async updateFeedback(conversationId, feedback) {
        try {
            const pool = await this.connect();
            if (!pool) {
                console.warn('[ConversationDB] Skipping feedback update — no DB connection');
                return false;
            }

            // Validate feedback value
            if (![-1, 0, 1].includes(feedback)) {
                console.warn(`[ConversationDB] Invalid feedback value: ${feedback}`);
                return false;
            }

            const result = await pool.request()
                .input('Id', sql.BigInt, conversationId)
                .input('Feedback', sql.SmallInt, feedback)
                .query(`
          UPDATE [dbo].[Conversation] 
          SET [Feedback] = @Feedback 
          WHERE [Id] = @Id
        `);

            const success = result.rowsAffected[0] > 0;
            console.log(`[ConversationDB] Feedback updated for ID ${conversationId}: ${feedback} (${success ? 'success' : 'not found'})`);
            return success;

        } catch (error) {
            console.error('[ConversationDB] Error updating feedback:', error.message);
            return false;
        }
    }

    /**
     * Get conversation history from DB for the last N days
     */
    async getHistory(sessionId, days = 7) {
        try {
            const pool = await this.connect();
            if (!pool) return [];

            const result = await pool.request()
                .input('SessionId', sql.UniqueIdentifier, sessionId)
                .input('Days', sql.Int, days)
                .query(`
          SELECT [Id], [SessionId], [Source], [Time], [Question], [Answer], [Feedback]
          FROM [dbo].[Conversation]
          WHERE [SessionId] = @SessionId
            AND [Time] >= DATEADD(DAY, -@Days, GETUTCDATE())
          ORDER BY [Time] ASC
        `);

            return result.recordset;

        } catch (error) {
            console.error('[ConversationDB] Error fetching history:', error.message);
            return [];
        }
    }

    /**
     * Test the connection
     */
    async testConnection() {
        try {
            const pool = await this.connect();
            if (!pool) return { success: false, error: 'No connection string configured' };

            await pool.request().query('SELECT 1 AS test');
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

module.exports = new ConversationDbService();
