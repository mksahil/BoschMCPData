/**
 * MCP Discovery Service
 * Probes a target MCP URL and uses AI to determine its purpose and metadata.
 */

const { createOpenAIClient, getChatModelName } = require('./openai-client');
const GenericMCPClient = require('./generic-mcp-client');

class McpDiscoveryService {
    constructor() {
        this._openai = null;

        // Available planets for recommendation
        this.planets = [
            { id: 'gym', keywords: ['gym', 'fitness', 'workout', 'exercise', 'health', 'wellness'] },
            { id: 'cafeteria', keywords: ['food', 'menu', 'canteen', 'lunch', 'dinner', 'snack'] },
            { id: 'parking', keywords: ['parking', 'car', 'vehicle', 'slot'] },
            { id: 'travel', keywords: ['travel', 'flight', 'ticket', 'booking', 'trip'] },
            { id: 'courses', keywords: ['learn', 'course', 'study', 'training', 'education'] },
            { id: 'music', keywords: ['music', 'song', 'playlist', 'audio'] },
            { id: 'holidays', keywords: ['holiday', 'leave', 'vacation', 'off'] },
            { id: 'seatbooking', keywords: ['seat', 'desk', 'booking', 'office'] },
            { id: 'entryexit', keywords: ['entry', 'exit', 'attendance', 'time', 'clock'] }
        ];
    }

    get openai() {
        if (!this._openai) {
            this._openai = createOpenAIClient();
        }
        return this._openai;
    }

    /**
     * Discover metadata for a given MCP URL
     */
    async discover(url) {
        console.log(`[McpDiscovery] Probing URL: ${url}`);

        try {
            // 1. Create a temporary client to probe the service
            // Use a dummy ID/Name since we don't know it yet
            const tempConfig = {
                id: 'discovery_probe',
                name: 'Probe',
                baseUrl: url
            };

            const client = new GenericMCPClient(tempConfig);

            // 2. Probe the service
            // We ask a specific question to get a summary of capabilities
            const probeQuery = "System Probe: Briefly list your capabilities and what specific topics you can help with.";
            const probeResult = await client.processQuery(probeQuery);

            if (!probeResult.success) {
                throw new Error(`Failed to probe service: ${probeResult.error}`);
            }

            const mcpResponse = probeResult.response;
            console.log(`[McpDiscovery] Probe response: ${mcpResponse.substring(0, 100)}...`);

            // 3. Use LLM to analyze the response
            const analysis = await this.analyzeResponse(mcpResponse);

            // 4. Recommend a planet
            const planetId = this.recommendPlanet(analysis.keywords);

            return {
                ...analysis,
                recommendedPlanetId: planetId,
                derivedFromUrl: client.baseUrl // Return the clean base URL
            };

        } catch (error) {
            console.error('[McpDiscovery] Discovery failed:', error);
            throw error;
        }
    }

    /**
     * Use OpenAI to extract structured metadata from the MCP's description
     */
    async analyzeResponse(mcpText) {
        try {
            const response = await this.openai.chat.completions.create({
                model: getChatModelName('gpt-4o-mini'),
                messages: [
                    {
                        role: 'system',
                        content: `You are a metadata extractor for specific microservices. 
Analyze the provided text (which is a self-description from a chatbot service).
Extract the following JSON structure:
{
  "name": "A short, professional service name (e.g. Gym Assistant)",
  "description": "A 1-sentence description of what it does",
  "keywords": ["array", "of", "5", "relevant", "keywords", "lowercase"]
}
Return ONLY valid JSON.`
                    },
                    { role: 'user', content: mcpText }
                ],
                temperature: 0.1,
                response_format: { type: "json_object" }
            });

            const content = response.choices[0].message.content;
            return JSON.parse(content);
        } catch (e) {
            console.error('[McpDiscovery] AI analysis failed:', e);
            // Fallback
            return {
                name: 'Unknown Service',
                description: 'Could not analyze service capabilities.',
                keywords: []
            };
        }
    }

    /**
     * Simple heuristic to recommend a planet based on keywords
     */
    recommendPlanet(keywords) {
        let bestMatch = null;
        let maxOverlap = 0;

        for (const planet of this.planets) {
            const overlap = planet.keywords.filter(pk => keywords.includes(pk)).length;
            if (overlap > maxOverlap) {
                maxOverlap = overlap;
                bestMatch = planet.id;
            }
        }

        return bestMatch; // Can be null if no connection found
    }
}

module.exports = new McpDiscoveryService();
