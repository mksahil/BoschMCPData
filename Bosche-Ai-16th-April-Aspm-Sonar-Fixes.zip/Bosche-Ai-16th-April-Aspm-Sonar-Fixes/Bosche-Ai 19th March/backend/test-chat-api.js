const axios = require('axios');

async function testChatApi() {
    console.log('Testing Chat API for Banners...');

    try {
        const response = await axios.post('http://localhost:3001/api/chat', {
            query: "get all banners",
            employeeNumber: "30945143"
        });

        console.log('Status:', response.status);
        console.log('Service Classified:', response.data.service);
        console.log('Has Banners Array:', !!response.data.banners);
        if (response.data.banners) {
            console.log('Banners Count:', response.data.banners.length);
        }
        console.log('Response Keys:', Object.keys(response.data));

    } catch (error) {
        console.error('API Call Failed:', error.message);
        if (error.response) {
            console.error('Response Data:', error.response.data);
        }
    }
}

testChatApi();
