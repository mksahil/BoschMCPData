function detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName) {
  const q = query.toLowerCase().trim();
  const original = query.trim();

  // --- helpers ---
  const loggedInNames = [];
  if (loggedInUserName) {
    const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
    loggedInNames.push(...parts, loggedInUserName.toLowerCase());
  }
  const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

  // Personal data keywords
  const personalDataKeywords = [
    'entry', 'exit', 'attendance', 'check.?in', 'check.?out', 'swipe',
    'leave', 'payslip', 'salary', 'pay', 'compensation',
    'working hours', 'work hours', 'hours worked', 'time tracking',
    'late', 'absent', 'shift', 'overtime',
    'schedule', 'booking', 'seat', 'travel',
    'effort', 'performance', 'appraisal',
    'data', 'details', 'info', 'information', 'record', 'records'
  ];
  const personalDataPattern = new RegExp(`(${personalDataKeywords.join('|')})`, 'i');
  const hasPersonalData = personalDataPattern.test(q);

  // Self-reference tokens
  const selfPattern = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i am)\b/i;
  const hasSelfRef = selfPattern.test(q);

  // Colleague / relationship words
  const colleaguePattern = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|subordinate|buddy|peer|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i;
  const hasColleagueWord = colleaguePattern.test(q);

  if (hasSelfRef && !hasColleagueWord) {
    return { isColleagueQuery: false, reason: '' };
  }

  // --- CHECK 9: Capitalized name near personal data (no self-ref) -> BLOCK ---
  const nonNames = new Set([
    'the', 'what', 'when', 'where', 'who', 'which', 'how', 'show', 'get', 'tell', 'give', 'find', 'fetch', 'list',
    'today', 'yesterday', 'tomorrow', 'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'thank',
    'hello', 'hi', 'hey', 'time', 'times', 'entry', 'exit', 'late', 'early', 'morning', 'evening', 'night',
    'afternoon', 'seat', 'travel', 'it', 'that', 'this', 'there', 'here', 'let', 'can', 'could', 'would', 'should',
    'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look', 'all', 'any', 'some', 'these', 'those', 'last',
    'next', 'first', 'second', 'working', 'hours', 'attendance', 'schedule', 'booking', 'details', 'information',
    'info', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
    'november', 'december', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
    'bangalore', 'coimbatore', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'india', 'bosch', 'one', 'day', 'days',
    'don', 'doesn', 'didn', 'won', 'wasn', 'aren', 'isn', 'haven', 'hasn', 'shouldn', 'wouldn', 'couldn', 'today',
    'office', 'home', 'shift', 'request', 'pending', 'approved', 'status', 'canteen', 'menu', 'food', 'lunch',
    'dinner', 'breakfast', 'snack', 'now', 'just', 'been', 'also', 'very', 'work', 'log', 'report', 'data',
    'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'overtime',
    'record', 'records', 'whole', 'entire', 'past', 'previous', 'each', 'every',
    'did', 'was', 'were', 'has', 'had', 'have',
    'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
    'provide', 'retrieve', 'display', 'generate', 'calculate', 'access', 'return', 'summarize', 'include',
    'share', 'pull', 'extract', 'compile', 'compute', 'present', 'load', 'read', 'query', 'search',
    'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
    'monthly', 'daily', 'weekly', 'annual', 'yearly', 'summary', 'period', 'range', 'between', 'during',
    'employee', 'user', 'member', 'staff', 'person', 'individual',
    'attendance', 'absences', 'presence', 'duration', 'login', 'logout', 'break',
    'second', 'third', 'fourth', 'fifth', 'quarter', 'half',
    'june', 'july', 'august', 'september', 'october', 'november', 'december',
    'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips', 'pune', 'delhi', 'bangalore',
    'start', 'end', 'date', 'dates', 'being', 'mode', 'with', 'from', 'to', 'into', 'for', 'air'
  ]);

  if (!hasSelfRef) {
    const capNameRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(capNameRe)) {
      const name = m[1].toLowerCase();
      if (!nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
        const idx = m.index;
        const window = original.substring(Math.max(0, idx - 40), idx + m[1].length + 40);
        if (personalDataPattern.test(window)) {
          return { isColleagueQuery: true, reason: `Capitalized name near personal data: ${m[1]}` };
        }
      }
    }
  }

  const thirdPerson = /\b(his|her|their|he|she|they)\b/i;
  if (thirdPerson.test(q) && hasPersonalData) {
    return { isColleagueQuery: true, reason: 'Third-person pronoun with personal data' };
  }

  return { isColleagueQuery: false, reason: '' };
}

console.log(detectColleagueQuery("23rd april to 25th april from pune to Hyderabad travel mode is air and no accommodation required", "123", "Prasad"));
