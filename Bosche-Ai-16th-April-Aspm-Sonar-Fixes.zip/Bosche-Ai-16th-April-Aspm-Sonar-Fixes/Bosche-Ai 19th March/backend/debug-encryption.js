const axios = require('axios');
const https = require('https');

// Disable SSL verification
const httpsAgent = new https.Agent({ rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk });

async function debugEncryption() {
    console.log('🔍 Debugging Encryption Output...\n');

    const USERNAME = '34852320';
    const PLAIN_PASSWORD = 'Test';

    // This is the hash the user successfully used in Step 189/220
    // WAIT - in Step 189/220 the username was 34835634, but here it is 34852320.
    // The user changed usernames between requests.
    // Step 198 (successful): username=34835634, password=E6brx...
    // Step 244 (curl example): username=34852320, password=Test
    // Step 291 (user edit): username=34852320, password=Test

    console.log(`Checking encyption for User: ${USERNAME}, Password: ${PLAIN_PASSWORD}`);

    try {
        const response = await axios.post(
            'https://dev.boschassociatearena.com/api/ManageUser/GetEncryptedPassword',
            { "EmailId": USERNAME, "Password": PLAIN_PASSWORD },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer '
                },
                httpsAgent
            }
        );

        if (response.data?.ResponseData?.[0]?.Password) {
            const encrypted = response.data.ResponseData[0].Password;
            console.log(`\n🔑 Encrypted Result: ${encrypted}`);
        } else {
            console.log('❌ Failed to get encrypted password');
            console.log(JSON.stringify(response.data, null, 2));
        }

    } catch (error) {
        console.error('❌ Error:', error.message);
    }
}

debugEncryption();
