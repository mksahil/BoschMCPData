const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

async function testApi() {
  const url = 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io/';
  const data = {
    jsonrpc: '2.0',
    id: 'test-123',
    method: 'message/send',
    params: {
      message: {
        messageId: 'msg-123',
        role: 'user',
        parts: [{ type: 'text', text: 'book a seat' }]
      },
      metadata: {
        employee_id: '34835634',
        user_id: '34835634',
        user_name: 'Manjunath',
        user_email: 'manjunath@bosch.com',
        user_data: {
          id: '34835634',
          name: 'Manjunath',
          email: 'manjunath@bosch.com'
        }
      }
    }
  };

  try {
    console.log('Calling A2A Seat Booking Agent...');
    const response = await axios.post(url, data, {
      headers: { 'Content-Type': 'application/json' },
      httpsAgent
    });
    console.log('Response Status:', response.status);
    console.log('Response Data:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.message);
    if (error.response) {
      console.error('Error Data:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testApi();
