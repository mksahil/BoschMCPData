# MyBGS Companion Logging Backend

## Overview
This backend server captures and stores all user activities in real-time from the MyBGS Companion frontend.

## Features
- Real-time activity logging
- Session-based tracking
- Daily log files
- CSV export capability
- Log viewer API

## Log Structure
Logs are stored in:
- `logs/` - Daily activity logs (YYYY-MM-DD_activity.json)
- `logs/sessions/` - Individual session logs

## API Endpoints

### POST /api/logs
Log a user activity
```json
{
  "sessionId": "emp_1234567_abc123",
  "timestamp": "2024-11-13T12:00:00Z",
  "action": "button_click",
  "page": "/dashboard",
  "details": {
    "buttonId": "leave-apply",
    "buttonText": "Apply Leave"
  }
}
```

### GET /api/logs
Retrieve logs
- Query params: `date`, `sessionId`, `limit`

### GET /api/sessions
Get all session IDs

### GET /api/logs/download
Download logs as JSON or CSV
- Query params: `date`, `format`

## Installation
```bash
cd backend
npm install
npm run dev
```

## Usage
The server runs on port 3001 by default.
