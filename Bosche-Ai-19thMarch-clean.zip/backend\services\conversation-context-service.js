/**
 * Conversation Context Service
 * Maintains conversation context for AI orchestration
 * Enables follow-up queries like "what about yesterday?" to work correctly
 */

const { createOpenAIClient, getChatModelName } = require('./openai-client');
const fs = require('fs-extra');
const path = require('path');
const configService = require('./config-service');

class ConversationContextService {
  constructor() {
    // Store conversation contexts by sessionId
    // In production, use Redis or similar for persistence
    this.contexts = new Map();

    // Maximum number of messages to keep per session
    this.maxHistoryLength = 10;

    // Context expiry time (30 minutes)
    this.contextExpiryMs = 30 * 60 * 1000;

    // Initialize OpenAI for context analysis
    this._openai = null;

    // Directory for storing conversation history
    // In Azure/Cloud, use an absolute path to a mounted persistent volume via env var
    this.dataDir = process.env.CHAT_HISTORY_DIR || path.join(__dirname, '../data/conversations');
    fs.ensureDirSync(this.dataDir);
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Get or create a conversation context for a session
   */
  getContext(sessionId) {
    if (!this.contexts.has(sessionId)) {
      this.contexts.set(sessionId, {
        sessionId,
        messages: [],
        lastService: null,
        lastTopic: null,
        lastDate: null,
        lastMonth: null,
        locationId: null,
        employeeNumber: null,
        travelState: {
          from: null,
          to: null,
          startDate: null,
          endDate: null,
          passengers: 1,
          travelClass: null,
          preferences: null,
          isComplete: false,
          approved: false
        },
        // Stable A2A contextId for seat booking (Stage-2 pre-auth fallback).
        // Persisted across turns so the A2A agent retains slot-fill state
        // within a single browser/chat session.  Reset when the session expires
        // or the user starts a new conversation (new sessionId from the frontend).
        seatbookingContextId: null,
        // Stable A2A contextId for travel (Stage-2 pre-auth fallback).
        // Same rationale as seatbookingContextId above.
        travelContextId: null,
        // The contextId returned by the travel A2A agent after it presents a
        // booking summary and asks "Do you approve?".  Stored so the next "yes"
        // from the user is sent to the SAME A2A session rather than starting a
        // fresh request that causes the agent to ask for approval again.
        travelAgentContextId: null,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    return this.contexts.get(sessionId);
  }

  /**
   * Initialize context for a user (load history)
   */
  async initializeContext(sessionId, employeeNumber) {
    if (!employeeNumber) return this.getContext(sessionId);

    // If context doesn't exist or is empty, try to load from disk
    let context = this.getContext(sessionId);

    if (context.messages.length === 0) {
      const history = await this.loadContext(employeeNumber, sessionId);
      if (history && history.length > 0) {
        console.log(`[ConversationContext] Loaded ${history.length} messages for session ${sessionId}`);
        // Add loaded messages to current session context
        context.messages = history;
        context.employeeNumber = employeeNumber;

        // Restore context state (last service, topic, etc.) from the most recent relevant message
        for (let i = history.length - 1; i >= 0; i--) {
          const msg = history[i];
          if (msg.service || msg.topic || msg.locationId) {
            context.lastService = msg.service || context.lastService;
            context.lastTopic = msg.topic || context.lastTopic;
            context.lastDate = msg.date || context.lastDate;
            context.locationId = msg.locationId || context.locationId;
            
            // Restore travel state if present in metadata
            if (msg.travelState) {
              context.travelState = { ...context.travelState, ...msg.travelState };
            }
            
            if (msg.role === 'assistant' && msg.service) break;
          }
        }

        this.contexts.set(sessionId, context);
      }
    }

    return context;
  }

  /**
   * Save context to disk
   */
  async saveContext(employeeNumber, sessionId, messages) {
    if (!employeeNumber || !sessionId) return;

    try {
      const filePath = path.join(this.dataDir, `${employeeNumber}_${sessionId}.json`);
      await fs.writeJson(filePath, messages, { spaces: 2 });
    } catch (error) {
      console.error(`[ConversationContext] Failed to save context for session ${sessionId}:`, error.message);
    }
  }

  /**
   * Load context from disk
   */
  async loadContext(employeeNumber, sessionId) {
    if (!employeeNumber || !sessionId) return [];
    try {
      const filePath = path.join(this.dataDir, `${employeeNumber}_${sessionId}.json`);
      if (await fs.pathExists(filePath)) {
        const messages = await fs.readJson(filePath);

        // Filter out messages older than 7 days
        const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
        let activeMessages = messages.filter(msg => {
          const timestamp = new Date(msg.timestamp).getTime();
          return timestamp > sevenDaysAgo;
        });

        // Optimization: Keep only the last 100 messages
        if (activeMessages.length > 100) {
          activeMessages = activeMessages.slice(-100);
        }

        // If we filtered out messages, save the cleaned up version
        if (activeMessages.length !== messages.length) {
          await this.saveContext(employeeNumber, sessionId, activeMessages);
        }

        return activeMessages;
      }
    } catch (error) {
      console.error(`[ConversationContext] Failed to load context for session ${sessionId}:`, error.message);
    }
    return [];
  }

  /**
   * Add a message to the conversation context
   */
  addMessage(sessionId, role, content, metadata = {}) {
    const context = this.getContext(sessionId);

    context.messages.push({
      role,
      content,
      timestamp: Date.now(),
      ...metadata
    });

    // Keep only the last N messages in memory for immediate context
    // But we'll persist more to disk

    context.updatedAt = Date.now();

    // Update context metadata if provided
    if (metadata.service) {
      context.lastService = metadata.service;
    }
    if (metadata.topic) {
      context.lastTopic = metadata.topic;
    }
    if (metadata.date) {
      context.lastDate = metadata.date;
    }
    if (metadata.month) {
      context.lastMonth = metadata.month;
    }
    if (metadata.locationId) {
      context.locationId = metadata.locationId;
    }
    if (metadata.employeeNumber) {
      context.employeeNumber = metadata.employeeNumber;
    }

    // Persist to disk if we have an employee number and session ID
    if (context.employeeNumber && context.sessionId) {
      // We want to save all messages (not just the limited in-memory window)
      // So we'll reload, append, and save, or just append to what we have if we know it's complete
      // For simplicity and correctness with the 7-day window, let's load-merge-save async
      this.saveContextWithHistory(context.employeeNumber, context.sessionId, {
        role,
        content,
        timestamp: Date.now(),
        ...metadata
      });
    }

    return context;
  }

  /**
   * Helper to append message to persistent storage
   */
  async saveContextWithHistory(employeeNumber, sessionId, newMessage) {
    try {
      // Load existing full history
      let history = await this.loadContext(employeeNumber, sessionId);

      // Add new message
      history.push(newMessage);

      // Save back (filter for 7 days happens in loadContext, but we can also enforce here)
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      history = history.filter(msg => new Date(msg.timestamp).getTime() > sevenDaysAgo);

      // Optimization: Enforce 100 message limit
      if (history.length > 100) {
        history = history.slice(-100);
      }

      await this.saveContext(employeeNumber, sessionId, history);
    } catch (error) {
      console.error('[ConversationContext] Error in saveContextWithHistory:', error);
    }
  }

  /**
   * Tag the most recent user message with the resolved service after routing completes.
   * This builds a labelled history so follow-up detection can filter by service.
   */
  tagLastUserMessage(sessionId, metadata = {}) {
    const context = this.getContext(sessionId);
    for (let i = context.messages.length - 1; i >= 0; i--) {
      if (context.messages[i].role === 'user') {
        Object.assign(context.messages[i], metadata);
        if (context.employeeNumber && context.sessionId) {
          this._updateLastUserMessageOnDisk(context.employeeNumber, context.sessionId, metadata)
            .catch(e => console.warn('[ConversationContext] tagLastUserMessage disk update failed:', e.message));
        }
        break;
      }
    }
  }

  async _updateLastUserMessageOnDisk(employeeNumber, sessionId, metadata) {
    const history = await this.loadContext(employeeNumber, sessionId);
    for (let i = history.length - 1; i >= 0; i--) {
      if (history[i].role === 'user') {
        Object.assign(history[i], metadata);
        break;
      }
    }
    await this.saveContext(employeeNumber, sessionId, history);
  }

  /**
   * Return the last `limit` messages that belong to a specific service,
   * preserving user+assistant pairs. Used to build focused context for LLM follow-up checks.
   */
  getServiceHistory(sessionId, service, limit = 6) {
    const context = this.getContext(sessionId);
    if (!context.messages.length || !service) return [];

    const filtered = [];
    for (let i = 0; i < context.messages.length; i++) {
      const msg = context.messages[i];
      const belongsToService = msg.service === service;
      // Include user messages tagged with this service, or untagged user messages
      // that immediately precede a service-tagged assistant response.
      if (msg.role === 'assistant' && belongsToService) {
        const prev = context.messages[i - 1];
        if (prev && prev.role === 'user' && (!filtered.length || filtered[filtered.length - 1] !== prev)) {
          filtered.push(prev);
        }
        filtered.push(msg);
      } else if (msg.role === 'user' && belongsToService) {
        filtered.push(msg);
      }
    }

    return filtered.slice(-limit);
  }

  /**
   * Update context with service-specific metadata after processing
   */
  updateServiceContext(sessionId, serviceData) {
    const context = this.getContext(sessionId);

    if (serviceData.service) {
      context.lastService = serviceData.service;
    }
    if (serviceData.topic) {
      context.lastTopic = serviceData.topic;
    }
    if (serviceData.date) {
      context.lastDate = serviceData.date;
    }
    if (serviceData.month) {
      context.lastMonth = serviceData.month;
    }
    if (serviceData.locationId) {
      context.locationId = serviceData.locationId;
    }

    context.updatedAt = Date.now();
    return context;
  }

  /**
   * Check if a query is a genuine follow-up that needs context-based rewriting.
   *
   * OLD approach (removed): word-count ≤ 4 AND no subject keyword.
   *   Problem: any short query ("list of events", "show banners", "any news?") was
   *   treated as a follow-up and rewritten using mixed-service conversation history,
   *   causing cross-service contamination (e.g. banner query getting "Bangalore canteen"
   *   injected from a prior canteen conversation).
   *   Additionally the subject-keyword blocklist required constant maintenance as new
   *   query patterns were discovered.
   *
   * NEW approach: only treat a query as a follow-up when it contains a REFERENCE
   * EXPRESSION that makes it incomplete without prior context — relative time words,
   * deictic pronouns, or explicit continuation phrases.  These are the only cases
   * where rewriting genuinely adds value.
   *
   * Note: high-confidence classifier results are gated out in server.js BEFORE this
   * method is ever called, so this only runs for genuinely ambiguous queries.
   */
  isFollowUpQuery(query) {
    const lowerQuery = query.toLowerCase().trim();

    // 1. Check admin-configured follow-up patterns (e.g. "what about", bare date patterns)
    const routingConfig = configService.getRoutingConfigSync();
    const patterns = routingConfig.followUpPatterns || {};
    const followUpPatterns = Object.values(patterns).map(p => new RegExp(p, 'i'));
    for (const pattern of followUpPatterns) {
      if (pattern.test(lowerQuery)) {
        console.log('[ConversationContext] Matched follow-up pattern:', pattern);
        return true;
      }
    }

    // 2. Reference expression detection — the query must REFERENCE something from
    //    prior context to genuinely need rewriting.
    const referenceExpressions = [
      // Relative / deictic time references
      /\b(yesterday|tomorrow|last\s+week|next\s+week|last\s+month|next\s+month|that\s+month|that\s+day|that\s+date|that\s+week|this\s+week|this\s+month|the\s+same\s+day|the\s+previous|the\s+next)\b/i,
      // Continuation / comparison phrases
      /\b(what\s+about|how\s+about|what\s+else|show\s+more|and\s+also|same\s+for|same\s+in|same\s+as|instead|rather|as\s+well)\b/i,
      // Bare pronouns / deictic references at the start of the query
      /^(it|that|this|those|these|same|there|then)\b/i,
      // Affirmation / negation as a standalone response (conversational turn)
      /^(ok|yes|no|confirm|go\s+ahead|cancel|sure|yeah|nope|correct|approved?|reject)\b$/i,
      // "the same / another / the next / more of"
      /\b(the\s+same|another\s+one|the\s+next|the\s+previous|more\s+of|rest\s+of)\b/i,
    ];

    for (const re of referenceExpressions) {
      if (re.test(lowerQuery)) {
        console.log('[ConversationContext] Reference expression detected, treating as follow-up:', re.source);
        return true;
      }
    }

    // 3. Ultra-short query (≤ 2 words) with an active service context — these are
    //    almost always location / date clarifications (e.g. "Bangalore", "tomorrow")
    //    that are only meaningful in the context of the prior turn.
    const wordCount = query.split(/\s+/).filter(Boolean).length;
    if (wordCount <= 2) {
      console.log('[ConversationContext] Ultra-short query (≤2 words), treating as follow-up');
      return true;
    }

    console.log('[ConversationContext] No follow-up signal detected, treating as new query');
    return false;
  }

  /**
   * Rewrite a follow-up query to include context from previous conversation
   * This is the key method for context-aware responses
   */
  async rewriteQueryWithContext(sessionId, query, conversationHistory = []) {
    const context = this.getContext(sessionId);
    const lowerQuery = query.toLowerCase();
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/;

    console.log('[ConversationContext] Processing query:', query);
    console.log('[ConversationContext] Session:', sessionId);
    console.log('[ConversationContext] Stored context:', {
      lastService: context.lastService,
      lastTopic: context.lastTopic,
      lastDate: context.lastDate,
      messageCount: context.messages?.length || 0
    });
    console.log('[ConversationContext] Conversation history length:', conversationHistory?.length || 0);

    // If no previous context AND no conversation history, return query as-is
    if (!context.lastService && (!conversationHistory || conversationHistory.length === 0)) {
      console.log('[ConversationContext] No context available, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    // Identity queries should not be rewritten as follow-ups
    if (identityPattern.test(lowerQuery)) {
      console.log('[ConversationContext] Identity query detected, skipping rewrite');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: 'entryexit'
      };
    }

    // Check if this might be a follow-up
    const isFollowUp = this.isFollowUpQuery(query);
    console.log('[ConversationContext] Is follow-up query:', isFollowUp);

    if (!isFollowUp) {
      console.log('[ConversationContext] Not a follow-up, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    console.log('[ConversationContext] === FOLLOW-UP DETECTED ===');
    console.log('[ConversationContext] Original query:', query);
    console.log('[ConversationContext] Last service:', context.lastService);
    console.log('[ConversationContext] Last topic:', context.lastTopic);

    // Use AI to rewrite the query with context
    try {
      // Only use messages from the SAME service as the current context.
      // Using the full unfiltered history causes cross-service contamination:
      // e.g. a banner follow-up getting "Bangalore canteen" injected from a prior
      // canteen conversation that happened to appear in the last-10 window.
      // getServiceHistory() already filters to paired user+assistant turns for the
      // active service, giving the LLM a clean single-topic thread to reason about.
      const serviceMessages = context.lastService
        ? this.getServiceHistory(sessionId, context.lastService, 10)
        : [];
      const recentMessages = serviceMessages.length > 0
        ? serviceMessages
        : (context.messages.length > 0 ? context.messages.slice(-6) : conversationHistory);
      const historyToUse = recentMessages.slice(-10);

      const recentHistory = historyToUse.map(msg =>
        `${msg.role === 'user' ? 'User' : 'Assistant'}: ${(msg.content || '').substring(0, 2000)}`
      ).join('\n');

      const systemPrompt = `You are a context-aware query rewriter. Given a follow-up question and conversation history, rewrite the query to be self-contained and explicit.

CONVERSATION HISTORY:
${recentHistory}

CONTEXT:
- Last service used: ${context.lastService || 'unknown'}
- Last topic discussed: ${context.lastTopic || 'unknown'}
- Last date mentioned: ${context.lastDate || 'not specified'}
- Last month referenced: ${context.lastMonth || 'not specified'}

RULES:
1. If the user asks "what about yesterday?" after asking about today's menu, rewrite to "What is the canteen menu for yesterday?"
2. If the user asks "and tomorrow?" after asking about entry time, rewrite to "What was my entry time tomorrow?" (or correct grammar)
3. If the user asks "same for last week?", understand the previous query topic and rewrite accordingly
4. If the user says "that month", "that month's details", "in that month", or "for that month", replace it with the actual month name from context (e.g., "February 2026")
5. Preserve any specific details the user mentions in the follow-up
6. Make the rewritten query complete and understandable without context
7. Also identify which service should handle this query

Respond in JSON format:
{
  "rewrittenQuery": "the complete, self-contained query",
  "inferredService": "canteen|entryexit|travel|seatbooking|community|banner|general",
  "explanation": "brief explanation of what context was used"
}`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Follow-up question: "${query}"` }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content);

      console.log('[ConversationContext] Rewritten query:', result.rewrittenQuery);
      console.log('[ConversationContext] Inferred service:', result.inferredService);

      // Safety guard: if the rewriter inferred a DIFFERENT service than the last
      // service used (e.g. user switched from banner → community), do NOT apply
      // the rewrite. Rewrites using another service's conversation history create
      // confusing cross-service contamination (e.g. "my community" getting rewritten
      // to "show my community memberships" using banner context).
      // Only accept the rewrite when the services match OR the inferred service is
      // the same as a clear keyword in the original query.
      if (result.inferredService && context.lastService && result.inferredService !== context.lastService) {
        console.log(`[ConversationContext] Discarding rewrite — inferred service "${result.inferredService}" differs from last service "${context.lastService}". Returning original query.`);
        return {
          rewrittenQuery: query,
          originalQuery: query,
          wasRewritten: false,
          inferredService: result.inferredService
        };
      }

      return {
        rewrittenQuery: result.rewrittenQuery,
        originalQuery: query,
        wasRewritten: true,
        inferredService: result.inferredService,
        explanation: result.explanation
      };

    } catch (error) {
      console.error('[ConversationContext] Error rewriting query:', error.message);

      // Fallback: simple context injection
      return this.fallbackRewrite(query, context);
    }
  }

  /**
   * Unified context resolver.
   *
   * Single LLM call that replaces both rewriteQueryWithContext (Step 2b) and the
   * standalone resolveQueryContext function (Step 3) in server.js.  Handles all
   * three cases in one round-trip:
   *
   *   Case 1 — Follow-up to the SAME service:
   *     The query references prior conversation (pronouns, relative time, corrections).
   *     Returns a fully rewritten, self-contained query.
   *     { isFollowUp: true,  targetService: lastService, rewrittenQuery: "<rewritten>", wasRewritten: true }
   *
   *   Case 2 — New request for a DIFFERENT service:
   *     The query clearly belongs to a different service.
   *     { isFollowUp: false, targetService: "<other-service>", rewrittenQuery: <original>, wasRewritten: false }
   *
   *   Case 3 — New self-contained query (same service or ambiguous):
   *     { isFollowUp: false, targetService: null, rewrittenQuery: <original>, wasRewritten: false }
   *
   * No word-count heuristics, no keyword blocklists.
   */
  async resolveAndRewriteQuery(sessionId, query) {
    const context = this.getContext(sessionId);

    // No prior service context — nothing to resolve
    if (!context.lastService) {
      console.log('[UnifiedContext] No lastService, returning original query as-is');
      return { isFollowUp: false, rewrittenQuery: query, targetService: null, wasRewritten: false };
    }

    // Build service-filtered history — clean single-service thread
    const serviceHistory = this.getServiceHistory(sessionId, context.lastService, 10);

    if (!serviceHistory.length) {
      console.log('[UnifiedContext] No service history, returning original query as-is');
      return { isFollowUp: false, rewrittenQuery: query, targetService: null, wasRewritten: false };
    }

    try {
      const serviceLabels = {
        seatbooking: 'Seat / Desk Booking',
        travel: 'Travel Booking',
        entryexit: 'Entry & Exit Attendance',
        community: 'Community',
        canteen: 'Cafeteria / Canteen',
        banner: 'Banners & Announcements'
      };

      const serviceDescriptions = `Available services:
- banner: company events, announcements, banners, promotions, highlights, what's new
- travel: book/raise/arrange travel, trips, flights, tickets
- seatbooking: book/reserve/cancel a seat, desk, or workspace
- entryexit: attendance, swipe details/records, punch in/out, check-in/out, working hours, entry/exit/in/out time
- community: join communities or clubs, show/list communities, community membership
- canteen: cafeteria menu, food menu, today's lunch/dinner/breakfast`;

      const historyText = serviceHistory
        .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${(m.content || '').substring(0, 400)}`)
        .join('\n');

      const lastServiceLabel = serviceLabels[context.lastService] || context.lastService;
      const contextLines = [
        context.lastTopic  ? `Last topic: ${context.lastTopic}`   : null,
        context.lastDate   ? `Last date: ${context.lastDate}`     : null,
        context.lastMonth  ? `Last month: ${context.lastMonth}`   : null
      ].filter(Boolean).join('\n');

      const systemPrompt = `You are a context resolver for a workplace chatbot at Bosch.

${serviceDescriptions}

The user's last active service: ${lastServiceLabel} (key: "${context.lastService}")
${contextLines ? `Additional context:\n${contextLines}` : ''}

Recent ${lastServiceLabel} conversation:
${historyText}

New user message: "${query}"

Decide ONE of the three cases below and respond with ONLY valid JSON:

CASE 1 — Follow-up to the SAME service (the message continues, corrects, or refers back to the conversation above):
Signs: pronouns (it/that/this/those/same/there/then), relative time words (yesterday/tomorrow/last week/next month/that month/that day), continuation phrases (what about/show more/and also/same for/instead/rather), short clarifications that are only meaningful given the prior exchange, or affirmations/denials (yes/no/go ahead/cancel/sure/correct).
Action: rewrite the query into a fully self-contained sentence by replacing all references with explicit values from the conversation history. Do NOT leave any pronoun or relative reference in the rewritten query.
Return: {"isFollowUp": true, "targetService": "${context.lastService}", "rewrittenQuery": "<complete standalone question>"}

CASE 2 — New request for a DIFFERENT service (the message clearly belongs to a different service from the list):
Return: {"isFollowUp": false, "targetService": "<service-key>", "rewrittenQuery": null}

CASE 3 — New self-contained request for the same service OR ambiguous:
The message stands on its own — it does not reference the prior conversation.
Return: {"isFollowUp": false, "targetService": null, "rewrittenQuery": null}

Additional rules:
- If "that month", "in that month", or "for that month" appears, replace with the actual month name from context.
- Never add information not present in the conversation history.
- targetService must be exactly one of: banner, travel, seatbooking, entryexit, community, canteen, or null.
- Always respond with valid JSON only — no extra text or markdown.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [{ role: 'user', content: systemPrompt }],
        response_format: { type: 'json_object' },
        max_tokens: 200,
        temperature: 0
      });

      const raw = response.choices[0].message.content.trim();
      const parsed = JSON.parse(raw);

      const isFollowUp    = parsed.isFollowUp === true;
      const targetService = parsed.targetService || null;
      const rewrittenQuery = (isFollowUp && parsed.rewrittenQuery) ? parsed.rewrittenQuery : query;
      const wasRewritten   = isFollowUp && !!parsed.rewrittenQuery && parsed.rewrittenQuery !== query;

      console.log(`[UnifiedContext] "${query}" → isFollowUp=${isFollowUp}, targetService=${targetService}, wasRewritten=${wasRewritten}`);
      if (wasRewritten) {
        console.log(`[UnifiedContext] Rewritten to: "${rewrittenQuery}"`);
      }

      return { isFollowUp, rewrittenQuery, targetService, wasRewritten };

    } catch (error) {
      console.error('[UnifiedContext] LLM call failed, returning original query:', error.message);
      return { isFollowUp: false, rewrittenQuery: query, targetService: null, wasRewritten: false };
    }
  }

  /**
   * Fallback query rewriting when AI is unavailable
   */
  fallbackRewrite(query, context) {
    const lowerQuery = query.toLowerCase().trim();
    let rewrittenQuery = query;
    let inferredService = context.lastService;

    // Handle date-based follow-ups
    const datePatterns = {
      'yesterday': 'yesterday',
      'tomorrow': 'tomorrow',
      'today': 'today',
      'last week': 'last week',
      'this week': 'this week',
      'last month': 'last month',
      'this month': 'this month'
    };

    for (const [pattern, dateStr] of Object.entries(datePatterns)) {
      if (lowerQuery.includes(pattern) || lowerQuery === pattern || lowerQuery === `what about ${pattern}?`) {
        // Add topic context
        if (context.lastService === 'canteen') {
          rewrittenQuery = `What is the canteen menu for ${dateStr}?`;
        } else if (context.lastService === 'entryexit') {
          rewrittenQuery = `What was my entry/exit time ${dateStr}?`;
        } else if (context.lastTopic) {
          rewrittenQuery = `${context.lastTopic} for ${dateStr}`;
        }
        break;
      }
    }

    // Handle "what about X" patterns
    if (lowerQuery.startsWith('what about') || lowerQuery.startsWith('and what about')) {
      const subject = query.replace(/^(and\s+)?what about\s*/i, '').replace(/\?$/, '').trim();
      if (context.lastService === 'canteen') {
        rewrittenQuery = `What is the canteen menu for ${subject}?`;
      } else if (context.lastService === 'entryexit') {
        rewrittenQuery = `What was my entry/exit time for ${subject}?`;
      }
    }

    return {
      rewrittenQuery,
      originalQuery: query,
      wasRewritten: rewrittenQuery !== query,
      inferredService
    };
  }

  /**
   * Extract topic from an AI response for context tracking
   */
  extractTopicFromResponse(response, service) {
    const routingConfig = configService.getRoutingConfigSync();
    const topics = routingConfig.topicKeywords || {};

    const serviceTopics = topics[service] || [];
    const lowerResponse = response.toLowerCase();

    for (const topic of serviceTopics) {
      if (lowerResponse.includes(topic)) {
        return topic;
      }
    }

    return service; // Default to service name as topic
  }

  /**
   * Extract date from query or response
   */
  extractDate(text) {
    const lowerText = text.toLowerCase();

    if (lowerText.includes('today')) return 'today';
    if (lowerText.includes('yesterday')) return 'yesterday';
    if (lowerText.includes('tomorrow')) return 'tomorrow';

    // Try to find date patterns
    const dateMatch = text.match(/(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})|(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*\d{0,4})/i);
    if (dateMatch) {
      return dateMatch[0];
    }

    return null;
  }

  /**
   * Get conversation history for API responses
   */
  getMessageHistory(sessionId) {
    const context = this.getContext(sessionId);
    return context.messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }

  /**
   * Clean up expired contexts
   */
  cleanupExpiredContexts() {
    const now = Date.now();
    for (const [sessionId, context] of this.contexts.entries()) {
      if (now - context.updatedAt > this.contextExpiryMs) {
        this.contexts.delete(sessionId);
        console.log('[ConversationContext] Cleaned up expired context:', sessionId);
      }
    }
  }

  /**
   * Clear context for a session
   */
  clearContext(sessionId) {
    this.contexts.delete(sessionId);
  }
}

module.exports = new ConversationContextService();
