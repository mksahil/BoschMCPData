const path = require('path');
// Load .env from the backend directory
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const fs = require('fs-extra');
const https = require('https');
const axios = require('axios');
const { format } = require('date-fns');
const boschAuthService = require('./services/bosch-auth-service');
const communityService = require('./services/community-service');
const conversationContextService = require('./services/conversation-context-service');
const conversationDbService = require('./services/conversation-db-service');
const mcpServiceManager = require('./services/mcp-service-manager');
const mcpDiscoveryService = require('./services/mcp-discovery-service');
const configService = require('./services/config-service');
const GenericMCPClient = require('./services/generic-mcp-client');

// Disable SSL certificate verification for dev environments (Bosch Arena API has self-signed cert)
const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

// [FIX #1 | Rule S5144 - SSRF]: Extract Bearer token at the source using strict regex.
// Only a correctly-formed Bearer token (RFC 6750 chars) is forwarded.
// Malformed / injected values return null, breaking the taint chain before it can propagate.
function extractBearerToken(authHeader) {
  if (typeof authHeader !== 'string') return null;
  const match = authHeader.match(/^Bearer\s+([A-Za-z0-9\-_.~+/=]+)$/);
  if (!match) return null;
  return match[1]; // Only the clean token — no 'Bearer ' prefix, no special chars
}

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
const defaultCorsOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:8080',
  'https://my-bgsw-ai-dev.azurewebsites.net'
];
const configuredCorsOrigins = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(origin => origin.trim()).filter(Boolean)
  : defaultCorsOrigins;

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) {
      return callback(null, true);
    }

    if (configuredCorsOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error(`CORS not allowed for origin: ${origin}`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Employee-Number']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Ensure logs directory exists
const logsDir = path.join(__dirname, 'logs');
const sessionsDir = path.join(logsDir, 'sessions');
fs.ensureDirSync(logsDir);
fs.ensureDirSync(sessionsDir);

// Root endpoint for health checks
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    service: 'MyBGSW Backend API',
    timestamp: new Date().toISOString(),
    endpoints: ['/api/health', '/api/canteen/query', '/api/entryexit/query', '/api/logs']
  });
});

// Helper function to get log file path for today
const getDailyLogFile = () => {
  const today = format(new Date(), 'yyyy-MM-dd');
  return path.join(logsDir, `${today}_activity.json`);
};

// Helper function to get session log file
const getSessionLogFile = (sessionId) => {
  return path.join(sessionsDir, `${sessionId}.json`);
};

// API endpoint to log user activities
app.post('/api/logs', async (req, res) => {
  try {
    const logEntry = {
      ...req.body,
      serverTimestamp: new Date().toISOString(),
      ip: req.ip || req.connection.remoteAddress
    };

    // Filter out unwanted events at the server level too
    const blockedActions = ['mouse_activity', 'scroll_behavior', 'hover_event', 'scroll_depth', 'idle_detection'];
    if (blockedActions.includes(logEntry.action)) {
      console.log(`Blocked unwanted log: ${logEntry.action}`);
      return res.json({ success: true, blocked: true }); // Return success but don't save
    }

    // Write to daily log file
    const dailyLogFile = getDailyLogFile();
    await fs.appendFile(dailyLogFile, JSON.stringify(logEntry) + '\n');

    // Also write to session-specific log
    if (logEntry.sessionId) {
      if (!/^[a-zA-Z0-9_-]+$/.test(logEntry.sessionId)) {
        return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
      }
      // [FIX #2 | Rule S2083 - Path Traversal]: Path containment check for session log file
      const sessionLogFile = path.resolve(getSessionLogFile(logEntry.sessionId));
      if (!sessionLogFile.startsWith(path.resolve(sessionsDir))) {
        return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
      }
      await fs.appendFile(sessionLogFile, JSON.stringify(logEntry) + '\n');
    }

    console.log(`Logged: ${logEntry.action}`);
    res.json({ success: true });
  } catch (error) {
    console.error('Error logging activity:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get logs (for viewer)
app.get('/api/logs', async (req, res) => {
  try {
    const { date, sessionId, limit = 100 } = req.query;

    // Strict validation to prevent Path Traversal
    if (sessionId && !/^[a-zA-Z0-9_-]+$/.test(sessionId)) {
      return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
    }
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    let logFile;
    if (sessionId) {
      logFile = getSessionLogFile(sessionId);
    } else if (date) {
      logFile = path.join(logsDir, `${date}_activity.json`);
    } else {
      logFile = getDailyLogFile();
    }

    // [FIX #2 | Rule S2083 - Path Traversal]: Path injection containment check — resolvedLogFile must stay within logsDir
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.json({ logs: [] });
    }

    // Read file and parse logs
    const content = await fs.readFile(resolvedLogFile, 'utf-8');
    const logs = content
      .trim()
      .split('\n')
      .filter(line => line)
      .map(line => {
        try {
          return JSON.parse(line);
        } catch (e) {
          return null;
        }
      })
      .filter(log => log !== null);

    // Return last 'limit' logs
    const limitedLogs = logs.slice(-limit);
    res.json({ logs: limitedLogs, total: logs.length });
  } catch (error) {
    console.error('Error retrieving logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get all sessions
app.get('/api/sessions', async (req, res) => {
  try {
    const sessionFiles = await fs.readdir(sessionsDir);
    const sessions = sessionFiles
      .filter(file => file.endsWith('.json'))
      .map(file => file.replace('.json', ''));

    res.json({ sessions });
  } catch (error) {
    console.error('Error retrieving sessions:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to download logs
app.get('/api/logs/download', async (req, res) => {
  try {
    const { date, format: exportFormat = 'json' } = req.query;

    // Strict validation to prevent Path Traversal and HTTP Header CRLF Injection
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    const logFile = date
      ? path.join(logsDir, `${date}_activity.json`)
      : getDailyLogFile();

    // [FIX #2 | Rule S2083 - Path Traversal]: Path injection containment check for download endpoint
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.status(404).json({ error: 'Log file not found' });
    }

    if (exportFormat === 'json') {
      res.download(resolvedLogFile);
    } else if (exportFormat === 'csv') {
      // Convert to CSV format
      const content = await fs.readFile(resolvedLogFile, 'utf-8');
      const logs = content
        .trim()
        .split('\n')
        .filter(line => line)
        .map(line => JSON.parse(line));

      // Create CSV
      const csv = [
        'Timestamp,SessionID,Action,Page,Details',
        ...logs.map(log =>
          `"${log.timestamp}","${log.sessionId}","${log.action}","${log.page}","${JSON.stringify(log.details || {}).replace(/"/g, '""')}"`
        )
      ].join('\n');

      // [FIX #2 | CWE-113 - HTTP Header Injection]: Strip CR/LF characters from the filename
      // as defense-in-depth, even though date is already validated by the regex above.
      const safeFilename = (date || 'today').replace(/[\r\n]/g, '');
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}_logs.csv"`);
      res.send(csv);
    }
  } catch (error) {
    console.error('Error downloading logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Import MCP client - use HTTP client for deployed Canteen MCP, stdio for local
const { getClient: getHttpClient } = require('./mcp-client-http');
const { getClient: getStdioClient } = require('./mcp-client-stdio');

// Determine which canteen client to use based on environment
const isDeployedCanteen = process.env.CANTEEN_MCP_URL &&
  !process.env.CANTEEN_MCP_URL.includes('localhost');

const getClient = isDeployedCanteen ? getHttpClient : getStdioClient;
console.log(`Using ${isDeployedCanteen ? 'HTTP' : 'stdio'} client for Canteen MCP`);

// Import intelligent canteen handler
const { processIntelligentQuery } = require('./intelligent-canteen');

// Import Entry/Exit MCP client
const { getEntryExitV2Client } = require('./entryexit-mcp-v2-client');

// Store conversation contexts (in production, use Redis or similar)
const conversationContexts = new Map();

// Canteen query endpoint
app.post('/api/canteen/query', async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('Processing canteen query:', query);
    console.log('Auth token present:', !!authToken);
    console.log('Employee number:', empNumber);

    // Get or create conversation context
    let context = conversationContexts.get(sessionId) || {};

    // If locationId is provided (user selected location), update context
    if (locationId) {
      context.location_id = locationId;
      context.location = locationId === 1 ? 'bangalore' : 'coimbatore';
      conversationContexts.set(sessionId, context);
    }

    // Get MCP client instance
    const mcpClient = await getClient();

    // Process query with intelligence
    const result = await processIntelligentQuery(query, mcpClient, context);

    // Update context if location was determined
    if (result.location_id) {
      context.location_id = result.location_id;
      context.location = result.location;
      conversationContexts.set(sessionId, context);
    }

    res.json({
      response: result.response,
      needs_location: result.needs_location,
      location_id: result.location_id,
      menuData: result.menuData, // Include structured menu data for CafeteriaCard
      success: true
    });

  } catch (error) {
    console.error('Canteen query error:', error);
    res.status(500).json({
      error: 'Failed to process canteen query',
      details: error.message
    });
  }
});

// Import Entry/Exit services
const entryExitService = require('./services/entry-exit-service-v2');

// ============= ENTRY/EXIT TIME TRACKING ENDPOINTS =============

// Main endpoint for time tracking queries
app.post('/api/time-tracking/query', async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Query is required'
      });
    }

    // Use default employee number if not provided
    const empNum = employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const userName = req.body.userName || null;

    console.log(`Time tracking query for employee ${empNum}: ${query}`);

    const result = await entryExitService.getEmployeeTimeData(empNum, query, userName);

    // If it's a privacy block, handle it gracefully
    if (result && result.success === false && result.answer) {
      return res.json({
        success: false,
        employeeNumber: empNum,
        response: result.answer,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      response: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Time tracking query error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process time tracking query',
      details: error.message
    });
  }
});

// Quick endpoint for today's entry time
app.get('/api/time-tracking/today-entry/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayEntry(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today entry:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Quick endpoint for today's exit time
app.get('/api/time-tracking/today-exit/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayExit(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today exit:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get today's working hours
app.get('/api/time-tracking/today-hours/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today hours:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get weekly attendance summary
app.get('/api/time-tracking/weekly-summary/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getWeeklyHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get weekly summary:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get monthly report
app.get('/api/time-tracking/monthly-report/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const currentDate = new Date();
    const month = req.query.month || (currentDate.getMonth() + 1);
    const year = req.query.year || currentDate.getFullYear();

    const result = await entryExitService.getMonthlyReport(empNum, month, year);
    res.json({
      success: true,
      employeeNumber: empNum,
      month,
      year,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get monthly report:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Check if late today
app.get('/api/time-tracking/late-check/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.checkLateToday(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to check late status:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get attendance statistics
app.get('/api/time-tracking/stats/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const period = req.query.period || 'this month';

    const result = await entryExitService.getAttendanceStats(empNum, period);
    res.json({
      success: true,
      employeeNumber: empNum,
      period,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get attendance stats:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Admin endpoint to clear cache
app.post('/api/time-tracking/cache/clear', (req, res) => {
  const { employeeNumber } = req.body;
  entryExitService.clearCache(employeeNumber);
  res.json({
    success: true,
    message: employeeNumber ?
      `Cache cleared for employee ${employeeNumber}` :
      'All cache cleared'
  });
});

// Admin endpoint to get cache stats
app.get('/api/time-tracking/cache/stats', (req, res) => {
  const stats = entryExitService.getCacheStats();
  res.json({ success: true, stats });
});

// ============= ADMIN API ENDPOINTS =============

// Smart Discovery Endpoint
app.post('/api/admin/services/discover', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    console.log(`[AdminAPI] Discovering service at: ${url}`);
    const analysis = await mcpDiscoveryService.discover(url);
    res.json({ success: true, analysis });
  } catch (error) {
    console.error('Discovery error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get all configured services

// Get all configured services
app.get('/api/admin/services', (req, res) => {
  try {
    const services = mcpServiceManager.getAllServices();
    res.json({ success: true, services });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Add or update a service
app.post('/api/admin/services', async (req, res) => {
  try {
    const serviceConfig = req.body;
    // Basic validation
    if (!serviceConfig.id || !serviceConfig.name || !serviceConfig.baseUrl) {
      return res.status(400).json({ error: 'Missing required fields: id, name, baseUrl' });
    }

    const savedService = await mcpServiceManager.addService(serviceConfig);
    res.json({ success: true, service: savedService });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete a service
app.delete('/api/admin/services/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const removed = await mcpServiceManager.removeService(id);
    if (removed) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, error: 'Service not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- Unified App Config Endpoints ---

// Get full application configuration
app.get('/api/admin/config', async (req, res) => {
  try {
    const config = await configService.getFullConfig();
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update a core service config
app.post('/api/admin/config/core/:serviceId', async (req, res) => {
  try {
    const { serviceId } = req.params;
    const serviceConfig = req.body;
    const updated = await configService.updateCoreService(serviceId, serviceConfig);
    res.json({ success: true, service: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update privacy whitelist
app.post('/api/admin/config/privacy', async (req, res) => {
  try {
    const { nonNames } = req.body;
    if (!nonNames || !Array.isArray(nonNames)) {
      return res.status(400).json({ success: false, error: 'nonNames array is required' });
    }
    const updated = await configService.updatePrivacyWhitelist(nonNames);
    res.json({ success: true, nonNames: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update routing configuration
app.post('/api/admin/config/routing', async (req, res) => {
  try {
    const routingConfig = req.body;
    const updated = await configService.updateRoutingConfig(routingConfig);
    res.json({ success: true, routingConfig: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ── Keyword Config endpoints (centralised keyword management) ──

app.post('/api/admin/config/keywords/privacy', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Privacy detection config object is required' });
    }
    const updated = await configService.updateKeywordConfig('privacyDetection', data);
    res.json({ success: true, privacyDetection: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/travel', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Travel service config object is required' });
    }
    const updated = await configService.updateKeywordConfig('travelService', data);
    res.json({ success: true, travelService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/seatbooking', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Seat booking config object is required' });
    }
    const updated = await configService.updateKeywordConfig('seatBookingService', data);
    res.json({ success: true, seatBookingService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/community', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Community config object is required' });
    }
    const updated = await configService.updateKeywordConfig('communityService', data);
    res.json({ success: true, communityService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/entryexit', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Entry/Exit config object is required' });
    }
    const updated = await configService.updateKeywordConfig('entryExitService', data);
    res.json({ success: true, entryExitService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get employee name from Entry/Exit MCP
app.get('/api/time-tracking/employee-name', async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting employee name for:', empNum);

    const entryExitV2Client = getEntryExitV2Client();
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_employee_name', {}, empNum);

    // Parse the result - MCP returns content array
    let name = 'Unknown';
    if (result && result.content) {
      const content = result.content[0];
      if (content && content.text) {
        try {
          const parsed = JSON.parse(content.text);
          name = parsed.name || parsed.employee_name || 'Unknown';
        } catch (e) {
          name = content.text;
        }
      }
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      name: name,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get employee name:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get current check-in/out status from Entry/Exit MCP
app.get('/api/time-tracking/current-status', async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting current status for:', empNum);

    const entryExitV2Client = getEntryExitV2Client();
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_current_status', {}, empNum);

    // Parse the result - MCP returns content array or structuredContent
    let status = 'unknown';
    let lastSwipe = null;
    let location = null;

    // Try structuredContent first (more reliable)
    if (result && result.structuredContent) {
      const data = result.structuredContent;
      status = data.status || 'unknown';
      // last_swipe is an object with time, status, location
      if (data.last_swipe) {
        lastSwipe = data.last_swipe.time || null;
        location = data.last_swipe.location || null;
      }
    } else if (result && result.content) {
      const content = result.content[0];
      if (content && content.text) {
        try {
          const parsed = JSON.parse(content.text);
          status = parsed.status || parsed.current_status || 'unknown';
          // last_swipe is an object with time, status, location
          if (parsed.last_swipe) {
            lastSwipe = parsed.last_swipe.time || null;
            location = parsed.last_swipe.location || null;
          }
        } catch (e) {
          // Try to parse simple text response
          const text = content.text.toLowerCase();
          if (text.includes('in') || text.includes('checked in')) {
            status = 'IN';
          } else if (text.includes('out') || text.includes('checked out')) {
            status = 'OUT';
          }
        }
      }
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      status: status,
      lastSwipe: lastSwipe,
      location: location,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get current status:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// ============= COMMUNITY API ENDPOINTS =============

/**
 * GET /api/community/list - Get list of communities from MCP
 */
app.get('/api/community/list', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;

    console.log(`[Community API] Fetching communities: page=${page}, pageSize=${pageSize}`);

    const data = await communityService.getCommunityList(page, pageSize);

    // Use flattenCommunities for consistent parsing across MCP/legacy responses
    const flat = communityService.flattenCommunities(data);
    const communities = flat.map(c => ({
      id: c.communityId,
      name: c.name,
      description: c.description || '',
      members: c.members || 0,
      color: c.color || '#007bc0',
      icon: c.imageUrl || null,
      category: 'General',
      locations: (c.locations || []).map(l => ({
        id: l.id,
        name: l.name,
        code: l.code
      }))
    }));

    res.json({
      success: true,
      communities: communities,
      totalCount: communities.length,
      page: page,
      pageSize: pageSize
    });
  } catch (error) {
    console.error('[Community API] Error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      communities: []
    });
  }
});

/**
 * POST /api/community/register - Register user to a community
 */
app.post('/api/community/register', async (req, res) => {
  try {
    const { communityId, locationId } = req.body;
    const authToken = req.headers['authorization'];

    if (!communityId || !locationId) {
      return res.status(400).json({ success: false, error: 'communityId and locationId are required' });
    }
    if (!authToken) {
      return res.status(401).json({ success: false, error: 'Authorization header is required' });
    }

    console.log(`[Community API] Registering: communityId=${communityId}, locationId=${locationId}`);

    const result = await communityService.registerUserToCommunity(
      Number(communityId),
      Number(locationId),
      { authToken }
    );

    const parsed = typeof result === 'string' ? JSON.parse(result) : result;
    
    if (parsed && parsed.IsSuccess) {
      // Apply optimistic update to cache so the UI sees the member count increase immediately
      await communityService.applyOptimisticUpdate(Number(communityId));
    }
    
    res.json({
      success: parsed?.IsSuccess || false,
      message: parsed?.Message || '',
      data: parsed
    });
  } catch (error) {
    console.error('[Community API] Register error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Entry/Exit query endpoint for AI Chat
app.post('/api/entryexit/query', async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    // Use employee number from header if available, else from body, else default
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Processing entry/exit query:', query);
    console.log('Employee number:', empNumber);
    console.log('Auth token present:', !!authToken);

    // Use the new V2 AI-powered client that properly uses MCP tools
    const entryExitV2Client = getEntryExitV2Client();

    // Process the query using AI (chat endpoint) or intelligent tool selection
    // Pass the employee number from headers/body
    const result = await entryExitV2Client.processQueryWithAI(query, empNumber, req.body.userName);

    res.json({
      response: result.response,
      employeeNumber: result.employeeNumber,
      method: result.method,
      tool_used: result.tool,
      success: result.success
    });

  } catch (error) {
    console.error('Entry/Exit query error:', error);
    res.status(500).json({
      error: 'Failed to process entry/exit query',
      details: error.message,
      response: "I'm having trouble accessing the attendance system. Please try again later or check the HR portal directly."
    });
  }
});

// Health check - Enhanced to check Entry/Exit MCP
app.get('/api/health', async (req, res) => {
  const health = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    services: {
      server: true,
      entryExit: false
    }
  };

  // Test Entry/Exit MCP connection
  try {
    await entryExitService.getEmployeeTimeData(routingContext.employeeNumber || 'test', 'test');
    health.services.entryExit = true;
  } catch (error) {
    health.services.entryExit = false;
    health.status = 'DEGRADED';
  }

  res.json(health);
});

// Authentication endpoint - Proxy to Bosch Arena API
// Authentication endpoint - Proxy to Bosch Arena API
app.post('/api/auth/login', async (req, res) => {
  let username = '';
  try {
    const { username: reqUsername, password, isPreEncrypted } = req.body;
    username = reqUsername; // Store for error handling scope

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    console.log('Login attempt for user:', username);
    console.log('Using boschAuthService for secure login...');
    console.log('Password is pre-encrypted:', isPreEncrypted ? 'Yes' : 'No (will encrypt)');

    // Use the service - pass isPreEncrypted flag to skip double-encryption
    const loginResponse = await boschAuthService.login(username, password, null, isPreEncrypted === true);

    console.log('Login successful for user:', username);

    // Store user tokens in cache for A2A agent calls
    try {
      console.log('--- STARTING JWT GENERATION AND CACHE DURING LOGIN ---');
      const oauthToken = loginResponse.access_token;
      console.log('OAuth Token to cache:', oauthToken?.substring(0, 50) + '...');
      const expiresIn = loginResponse.expires_in;
      const tokenResult = await boschAuthService.storeUserTokens(username, oauthToken, expiresIn);

      // Add session ID to response so frontend can use it
      loginResponse.sessionId = tokenResult.sessionId;
      console.log(`User ${username} tokens SUCCESSFULLY generated and cached with session ID: ${tokenResult.sessionId}`);
    } catch (tokenError) {
      console.error('--- FAILED to cache user tokens during login! ---');
      console.error('Error:', tokenError.message);
      // Continue anyway - login was successful
    }

    res.json(loginResponse);

  } catch (error) {
    console.error('Login proxy error:', error.message);

    // Handle axios error responses
    if (error.response) {
      const errorData = error.response.data;
      console.log('Login failed for user:', username, 'Status:', error.response.status);
      return res.status(error.response.status).json({
        error: errorData.error_description || errorData.error || 'Login failed'
      });
    }

    res.status(500).json({
      error: 'Authentication service unavailable. Please try again later.'
    });
  }
});

// ============= UNIFIED SMART CHAT ENDPOINT =============
// Import all services for smart routing
const intelligentRouter = require('./services/intelligent-router');
// communityService already imported at top of file
const travelService = require('./services/travel-service');
const seatbookingService = require('./services/seatbooking-service');
const bannerService = require('./services/banner-service');

/**
 * GET /api/chat/history - Get chat history for a user (7 days context)
 */
app.get('/api/chat/history', async (req, res) => {
  try {
    const { employeeNumber } = req.query;
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber) {
      return res.status(400).json({ error: 'Employee number is required' });
    }

    console.log(`[Chat History] Fetching history for ${empNumber}`);
    const history = await conversationContextService.loadContext(empNumber);

    res.json({
      success: true,
      history: history || []
    });
  } catch (error) {
    console.error('Error fetching chat history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch chat history'
    });
  }
});

/**
 * Privacy guard: Detect if a query is asking about another colleague's personal data
 * Returns { isColleagueQuery: boolean, reason: string }
 *
 * DESIGN PRINCIPLES:
 * 1. Queries about the LOGGED-IN USER's own data -> ALLOW
 * 2. Queries that EXPLICITLY reference another person (name, pronoun, relationship) -> BLOCK
 * 3. Queries that try to access BULK / ALL employee data -> BLOCK
 * 4. Ambiguous queries with NO explicit other-person reference -> ALLOW (assume self)
 *
 * ALLOW: "give me entry exit times", "my attendance", "show me today's hours", "when did I come"
 * BLOCK: "Rahul's attendance", "my friend's entry time", "his hours", "show all employee attendance",
 *        "who came late today", "list everyone's attendance", "team attendance"
 */
function detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName) {
  const q = query.toLowerCase().trim();
  const original = query.trim();

  // --- helpers ---
  const loggedInNames = [];
  if (loggedInUserName) {
    const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
    loggedInNames.push(...parts, loggedInUserName.toLowerCase());
  }
  const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

  // ── Load keyword config from centralised config (editable via Admin UI) ──
  const kwConfig = configService.getKeywordConfigSync().privacyDetection;

  // Personal data keywords (from config)
  const personalDataKeywords = kwConfig.personalDataKeywords;
  const personalDataPattern = new RegExp(`(${personalDataKeywords.join('|')})`, 'i');
  const hasPersonalData = personalDataPattern.test(q);

  // Self-reference tokens
  const selfPattern = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i am)\b/i;
  const hasSelfRef = selfPattern.test(q);

  // Colleague / relationship words (from config — build regex dynamically)
  const colleagueWords = kwConfig.colleaguePatternWords.map(w => w.replace(/\s+/g, '\\s+'));
  const colleaguePattern = new RegExp(`\\b(${colleagueWords.join('|')})\\b`, 'i');
  const hasColleagueWord = colleaguePattern.test(q);

  // Global privacy whitelist (cities, common words, service keywords, etc.)
  // Declared early so it can be reused by ALL checks below, avoiding stale hardcoded subsets.
  const nonNames = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));

  // --- FAST PATH: self-reference with NO colleague word AND no other-person name -> ALLOW ---
  // We must NOT fast-path if the query also contains another person's name.
  // e.g. "show me entry exit of vaishnav" has 'me' but also 'vaishnav'
  if (hasSelfRef && !hasColleagueWord) {
    // Check for "of/for <name>" pattern (case-insensitive)
    const hasOfForName = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
    let otherNameDetected = false;
    if (hasOfForName) {
      const candidate = hasOfForName[1].toLowerCase();
      const safeWords = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
        'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
        'week', 'month', 'year', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
        'bangalore', 'coimbatore', 'bosch', 'india',
        'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'noida',
        'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
        'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
        'yes', 'no', 'ok', 'confirm', 'confirmation', 'approve', 'approved', 'proceed', 'proceeding',
        'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat',
        'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
        'data', 'record', 'records', 'report', 'log', 'hours', 'working',
        'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
        'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
        'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
        'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
        'book', 'booked', 'booking', 'planning', 'planned', 'location', 'locations', 'building', 'floor',
        'desk', 'station', 'meeting', 'room', 'office', 'details', 'information', 'info',
        'accommodation', 'air', 'required', 'needed']);
      if (!safeWords.has(candidate) && !nonNames.has(candidate) && !isOwnName(candidate)) {
        otherNameDetected = true;
      }
    }
    // Check for possessive name: "vaishnav's entry"
    const hasPossessiveName = q.match(/(\w{3,})(?:'s|s')\s+/i);
    if (hasPossessiveName && !isOwnName(hasPossessiveName[1])) {
      const pName = hasPossessiveName[1].toLowerCase();
      const skipPossessive = new Set(['today', 'yesterday', 'tomorrow', 'it', 'that', 'this', 'there', 'here',
        'what', 'let', 'don', 'doesn', 'didn', 'won', 'today', 'week', 'month', 'year', 'last', 'next',
        'swipe', 'entry', 'exit', 'time', 'check', 'clock', 'shift', 'who', 'where', 'when', 'how']);
      if (!skipPossessive.has(pName) && !nonNames.has(pName)) otherNameDetected = true;
    }
    if (!otherNameDetected) {
      return { isColleagueQuery: false, reason: '' };
    }
    // Otherwise fall through to full checks
  }

  // --- CHECK 1: Bulk / collective data requests -> BLOCK ---
  // (phrases from config — build regex dynamically)
  const bulkPhrases = kwConfig.bulkPatternPhrases.map(p => p.replace(/\s+/g, '\\s+'));
  const bulkPatterns = new RegExp(`\\b(${bulkPhrases.join('|')})\\b`, 'i');
  if (bulkPatterns.test(q)) {
    return { isColleagueQuery: true, reason: 'Bulk / collective data request' };
  }

  // --- CHECK 2: Impersonation detection -> BLOCK ---
  // "I am Rahul, show entry time", "my name is Priya, give attendance"
  const impersonation = q.match(/\b(?:i\s+am|i'm|my\s+name\s+is|this\s+is)\s+([a-z]+)/i);
  if (impersonation) {
    const claimedName = impersonation[1].toLowerCase();
    const skipWords = new Set(kwConfig.impersonationSkipWords);
    if (!isOwnName(claimedName) && !skipWords.has(claimedName)) {
      return { isColleagueQuery: true, reason: `Possible impersonation: ${impersonation[1]}` };
    }
  }

  // --- CHECK 3: Employee number for someone else -> BLOCK ---
  const empNumMatches = q.match(/\b(\d{7,8})\b/g);
  if (empNumMatches) {
    for (const num of empNumMatches) {
      if (num !== loggedInEmployeeNumber) {
        return { isColleagueQuery: true, reason: `Contains different employee number: ${num}` };
      }
    }
  }

  // --- CHECK 4: Explicit colleague / relationship words -> BLOCK ---
  if (hasColleagueWord) {
    return { isColleagueQuery: true, reason: 'Explicit colleague / relationship reference' };
  }

  // --- CHECK 5: Third-person pronouns with personal data -> BLOCK ---
  const thirdPerson = /\b(his|her|their|he|she|they)\b/i;
  if (thirdPerson.test(q) && hasPersonalData) {
    return { isColleagueQuery: true, reason: 'Third-person pronoun with personal data' };
  }

  // --- CHECK 6: "details/information about <someone>" -> BLOCK ---
  // Split multi-word captures and check EACH word against nonNames / safeSelf.
  // e.g. "info about Mind Buddies" → both "mind" and "buddies" should be safe.
  const aboutMatch = q.match(/\b(?:details?|information|info)\s+(?:about|on|of)\s+([a-z'']+(?:\s+[a-z'']+)?)/i);
  if (aboutMatch) {
    const safeSelf = new Set(['me', 'myself', 'my', 'mine']);
    const targetWords = aboutMatch[1].toLowerCase().split(/\s+/).filter(Boolean);
    const anyUnsafe = targetWords.some(w => !safeSelf.has(w) && !nonNames.has(w) && !isOwnName(w));
    if (anyUnsafe) {
      return { isColleagueQuery: true, reason: `Asking about someone: ${aboutMatch[1]}` };
    }
  }

  // --- CHECK 7: Possessive name pattern: "Rahul's attendance" -> BLOCK ---
  // (nonNames already declared above, before the fast path)

  const possessiveRe = /(\w+)(?:'s|s')\s+/gi;
  for (const m of q.matchAll(possessiveRe)) {
    const name = m[1].toLowerCase();
    if (name.length > 2 && !nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
      return { isColleagueQuery: true, reason: `Possessive name: ${m[1]}` };
    }
  }

  // --- CHECK 8: "of/for <Name>" pattern -> BLOCK ---
  const ofForRe = /\b(?:of|for)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b/g;
  for (const m of original.matchAll(ofForRe)) {
    const nameStr = m[1].toLowerCase();
    const words = nameStr.split(/\s+/);
    const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));
    if (anyOtherPerson && hasPersonalData) {
      return { isColleagueQuery: true, reason: `of/for <Name>: ${m[1]}` };
    }
  }

  // --- CHECK 9: Capitalized name near personal data (no self-ref) -> BLOCK ---
  if (!hasSelfRef) {
    const capNameRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(capNameRe)) {
      const nameStr = m[1].toLowerCase();
      const words = nameStr.split(/\s+/);
      const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));

      if (anyOtherPerson && hasPersonalData) {
        // proximity check: name within 40 chars of a personal data keyword
        const idx = m.index;
        const window = original.substring(Math.max(0, idx - 40), idx + m[1].length + 40);
        if (personalDataPattern.test(window)) {
          return { isColleagueQuery: true, reason: `Capitalized name near personal data: ${m[1]}` };
        }
      }
    }
  }

  // --- CHECK 10: "for <Name>" without personal data keywords (follow-up evasion) -> BLOCK ---
  // Catches: "can you do it for vaishnavi", "do it for Rahul", "same for Priya"
  //
  // IMPORTANT: when the captured phrase is multi-word (e.g. "full day",
  // "the whole day") we must check EACH WORD individually against the
  // safe-list, not the joined phrase. Otherwise a legitimate query like
  // "need the booking for 9th of April and for full day" was being
  // blocked because the single-string key "full day" isn't in the set,
  // even though both "full" and "day" are.
  const forNameEvasion = q.match(/\bfor\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\s*\??$/i);
  if (forNameEvasion) {
    const phrase = forNameEvasion[1].toLowerCase();
    const safeForTargets = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
      'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
      'week', 'weeks', 'month', 'months', 'year', 'years', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
      'bangalore', 'bengaluru', 'coimbatore', 'bosch', 'india',
      'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'gurugram', 'noida',
      'mysore', 'mysuru',
      'lunch', 'dinner', 'breakfast',
      'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
      'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
      'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat', 'seats', 'desk', 'desks',
      'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
      'data', 'record', 'records', 'report', 'log', 'hours', 'working',
      'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
      'morning', 'afternoon', 'evening', 'night', 'noon', 'midnight', 'midday',
      'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec',
      'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
      'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
      'book', 'booked', 'booking', 'planning', 'planned', 'location', 'locations', 'building', 'floor',
      'desk', 'station', 'meeting', 'room', 'office', 'details', 'information', 'info',
      'yes', 'no', 'ok', 'confirm', 'confirmation', 'approve', 'approved', 'proceed', 'proceeding',
      'accommodation', 'air', 'required', 'needed',
      'first', 'second', 'third', 'fourth', 'fifth', 'half', 'quarter']);

    const phraseWords = phrase.split(/\s+/).filter(Boolean);
    // Allow the phrase if EVERY word is either safe, in the global privacy
    // whitelist (nonNames), the logged-in user's name, or a pure number/ordinal.
    const allSafe = phraseWords.every(w =>
      safeForTargets.has(w) ||
      nonNames.has(w) ||
      isOwnName(w) ||
      /^\d+(?:st|nd|rd|th)?$/i.test(w)
    );
    if (!allSafe) {
      return { isColleagueQuery: true, reason: `"for <Name>" evasion: ${forNameEvasion[1]}` };
    }
  }

  // --- CHECK 11: Indirect phrasing ("tell about", "show details of") with a name -> BLOCK ---
  const indirectMatch = original.match(/\b(?:tell|show|give|get|fetch|find|display|check)\s+(?:me\s+)?(?:about|details?\s+(?:of|about|for))\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/);
  if (indirectMatch) {
    const nameStr = indirectMatch[1].toLowerCase();
    const words = nameStr.split(/\s+/);
    const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));
    if (anyOtherPerson) {
      return { isColleagueQuery: true, reason: `Indirect phrasing about: ${indirectMatch[1]}` };
    }
  }

  // DEFAULT: No explicit other-person reference -> treat as self-query -> ALLOW
  return { isColleagueQuery: false, reason: '' };
}

function isExplicitBannerQuery(queryText) {
  return /\b(?:what'?s\s+new|company\s+news|(?:latest|newest|recent|new|upcoming|current|present|ongoing)\s+(?:banners?|announcements?|news|promotions?)|(?:bosch|bgsw|company)\s+(?:banners?|announcements?|news|promotions?)|(?:banner|announcement|news|promotion)(?:s)?(?:\s+(?:image|images|detail|details|info))?|(?:upcoming|current|present|company|bosch|bgsw)\s+events?|events?\s+(?:in|on|of)\s+(?:bosch|bgsw|company))\b/i.test(String(queryText || ''));
}

function isExplicitCommunityQuery(queryText) {
  const q = String(queryText || '').toLowerCase();
  // Load detection keywords + community names from centralised config
  const communityKw = configService.getKeywordConfigSync().communityService;
  const detectionKeywords = communityKw.communityDetectionKeywords || ['community', 'communities', 'associate arena'];
  const communityNames = communityKw.communityNames || [];
  // Build a combined regex from both lists
  const allPatterns = [...detectionKeywords, ...communityNames].map(k => k.replace(/\s+/g, '\\s+'));
  const regex = new RegExp(`\\b(${allPatterns.join('|')})\\b`, 'i');
  return regex.test(q);
}


/**
 * Unified chat endpoint with intelligent routing
 * Routes queries to appropriate MCP service using OpenAI classification
 */
app.post('/api/chat', async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber, conversationHistory } = req.body;

    // Extract auth headers (check both header and body) and strictly sanitize
    let authToken = req.headers['authorization'] || req.body.authToken || req.body.authorization;
    if (authToken && typeof authToken === 'string') {
      authToken = authToken.trim().replace(/[\r\n]/g, '');
    }
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber || empNumber.trim() === '') {
      console.log('[UnifiedChat] REJECTED: No user identity (employeeNumber) provided');
      return res.status(401).json({
        error: 'Authentication required',
        response: "Please log in to your Bosch account to access the AI Travel Assistant and other personal services."
      });
    }

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('\n========== UNIFIED CHAT REQUEST ==========');
    console.log('Query:', query);
    console.log('Session:', sessionId);
    console.log('Employee:', empNumber);
    console.log('Auth present:', !!authToken);
    console.log('Auth token (first 60 chars):', authToken ? authToken.substring(0, 60) + '...' : 'NONE');
    console.log('Conversation history:', conversationHistory?.length || 0, 'messages');

    // ===== CONVERSATION CONTEXT ORCHESTRATION =====

    // Step 0: Initialize context (load history if needed)
    await conversationContextService.initializeContext(sessionId, empNumber);

    // Step 0.5: Add user message to conversation context
    conversationContextService.addMessage(sessionId, 'user', query, {
      employeeNumber: empNumber,
      locationId
    });

    // Step 1: PRIVACY CHECK FIRST (on original query before rewriting)
    // This catches explicit friend/colleague requests before they get rewritten with names
    const explicitBannerQuery = isExplicitBannerQuery(query);
    const explicitCommunityQuery = isExplicitCommunityQuery(query);
    console.log(`[UnifiedChat] Processing query for Employee: ${empNumber}, User: ${req.body.userName || 'Unknown'}`);
    const colleagueQueryCheck = (explicitBannerQuery || explicitCommunityQuery)
      ? { isColleagueQuery: false, reason: '' }
      : detectColleagueQuery(query, empNumber, req.body.userName);
    if (colleagueQueryCheck.isColleagueQuery) {
      console.log('[Privacy] Blocked colleague data query:', colleagueQueryCheck.reason);

      // Save the privacy response to conversation context
      const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

      conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
        blocked: true,
        reason: 'colleague_privacy'
      });

      // Save to DB
      let conversationId = null;
      try {
        conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
      } catch (dbErr) {
        console.error('[Privacy] DB save error:', dbErr.message);
      }

      return res.json({
        response: privacyResponse,
        service: 'privacy_guard',
        serviceName: 'Privacy Protection',
        success: true,
        conversationId
      });
    }

    // Step 2a: Quick check for simple greetings - route them directly to general
    const greetingKeywords = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings'];
    const lowerQuery = query.toLowerCase().trim();
    const isSimpleGreeting = lowerQuery.length < 20 && greetingKeywords.some(greeting => lowerQuery.includes(greeting));

    if (isSimpleGreeting) {
      console.log('[Routing] Simple greeting detected, routing to general: "' + query + '"');
      const generalResponse = await intelligentRouter.generateGeneralResponse(query, conversationHistory);
      return res.json({
        success: true,
        response: generalResponse,
        service: 'general',
        serviceName: 'General Assistant'
      });
    }

    // Step 2b: Check if this is a follow-up query and rewrite it with context
    console.log('[Context] Checking for follow-up with sessionId:', sessionId);
    const contextResult = await conversationContextService.rewriteQueryWithContext(
      sessionId,
      query,
      conversationHistory
    );

    const effectiveQuery = contextResult.rewrittenQuery;
    const wasRewritten = contextResult.wasRewritten;

    console.log('[Context] Was rewritten:', wasRewritten);
    console.log('[Context] Effective query:', effectiveQuery);

    if (wasRewritten) {
      console.log('[Context] Original query:', query);
      console.log('[Context] Rewritten query:', effectiveQuery);
      console.log('[Context] Inferred service:', contextResult.inferredService);
    }

    // Step 2c: NARROW PRIVACY CHECK on the rewritten query
    // ONLY check for explicit name injection (possessive "Rahul's" or
    // We do NOT run the full detectColleagueQuery here because AI-rewritten queries
    // might introduce words like "Provide" (capitalized) which trip the privacy guard falsely.
    // We only check for explicit name injection patterns.
    const strictEvasionRe = /\b([A-Z][a-z]{2,})(?:'s|s')\s+(?:entry|exit|attendance|time|swipe|leave|record|data|details|info|information)/g;
    const strictForEvasionRe = /\b(?:of|for)\s+([A-Z][a-z]{2,})\b/g;

    if (wasRewritten && effectiveQuery !== query && !isExplicitBannerQuery(effectiveQuery) && !isExplicitCommunityQuery(effectiveQuery)) {
      const loggedInNames = [];
      if (req.body.userName) {
        req.body.userName.toLowerCase().split(/\s+/).filter(Boolean).forEach(p => loggedInNames.push(p));
        loggedInNames.push(req.body.userName.toLowerCase());
      }
      const isOwnNameRewrite = (n) => loggedInNames.includes(n.toLowerCase());

      // Known safe words: derive from global nonNames whitelist + AI rewrite verbs from config
      // This eliminates the stale duplicate "rewriteSafe" list — single source of truth.
      const _nonNamesArr = configService.getPrivacyWhitelistSync().map(w => w.toLowerCase());
      const _aiVerbs = configService.getKeywordConfigSync().privacyDetection.aiRewriteVerbs;
      const rewriteSafe = new Set([..._nonNamesArr, ..._aiVerbs, 'me', 'myself']);

      let nameInjected = false;
      let nameInjectedReason = '';

      // Only block: possessive "Name's data" injected into rewrite
      const possMatch = effectiveQuery.match(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g);
      if (possMatch) {
        for (const m of possMatch) {
          const name = m.replace(/('s|s')\s*$/i, '').trim().toLowerCase();
          if (!rewriteSafe.has(name) && !isOwnNameRewrite(name)) {
            nameInjected = true;
            nameInjectedReason = `Possessive name injected in rewrite: ${m.trim()}`;
            break;
          }
        }
      }

      // Only block: explicit "for <ProperName>" at end of sentence (evasion pattern)
      if (!nameInjected) {
        const forNameMatch = effectiveQuery.match(/\bfor\s+([A-Z][a-z]{3,}(?:\s+[A-Z][a-z]{3,})?)\s*[?.!]?$/);
        if (forNameMatch) {
          const matchedPhrase = forNameMatch[1];
          const words = matchedPhrase.toLowerCase().split(/\s+/).filter(Boolean);

          // It's a violation if ANY word in the phrase is NOT safe AND NOT the user's name
          const hasInsecureWord = words.some(word => !rewriteSafe.has(word) && !isOwnNameRewrite(word));

          if (hasInsecureWord) {
            nameInjected = true;
            nameInjectedReason = `Name injected via "for <Name>" evasion: ${matchedPhrase}`;
          }
        }
      }

      if (nameInjected) {
        console.log('[Privacy] Blocked REWRITTEN query (name injection):', nameInjectedReason);
        console.log('[Privacy] Original was:', query);
        console.log('[Privacy] Rewritten was:', effectiveQuery);

        const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

        conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
          blocked: true,
          reason: 'colleague_privacy_rewritten'
        });

        let conversationId = null;
        try {
          conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
        } catch (dbErr) {
          console.error('[Privacy] DB save error:', dbErr.message);
        }

        return res.json({
          response: privacyResponse,
          service: 'privacy_guard',
          serviceName: 'Privacy Protection',
          success: true,
          conversationId
        });
      }
    }

    // Step 3: Classify the query using AI (use rewritten query for better classification)
    // If context already inferred a service, use that as a hint
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/i;
    const isIdentityQuery = identityPattern.test(effectiveQuery);

    let classification = { service: 'general', serviceName: 'General Assistant' };
    if (!isIdentityQuery) {
      classification = await intelligentRouter.routeQuery(
        effectiveQuery,
        conversationHistory
      );
    } else {
      console.log('[Routing] Identity query detected, forcing entryexit service');
      classification = { service: 'entryexit', serviceName: 'Entry/Exit Time Tracking' };
    }

    // Override classification if context inference is strong
    let finalService = classification.service;
    const explicitBannerQueryFromEffectiveQuery = isExplicitBannerQuery(effectiveQuery);
    if (!isIdentityQuery && explicitBannerQueryFromEffectiveQuery) {
      finalService = 'banner';
    }

    if (!isIdentityQuery && wasRewritten && contextResult.inferredService && contextResult.inferredService !== 'general') {
      console.log('[Context] Using inferred service:', contextResult.inferredService);
      finalService = explicitBannerQueryFromEffectiveQuery ? 'banner' : contextResult.inferredService;
    }

    console.log('Classification:', finalService, '-', classification.serviceName);

    /**
     * Helper to sanitize browser-sent parameters that might be literal strings "null" or "undefined"
     * @param {any} val - Value to sanitize
     * @returns {any} - Sanitized value
     */
    const sanitizeParam = (val) => {
      if (typeof val === 'string') {
        const trimmed = val.trim();
        const lowerVal = trimmed.toLowerCase();
        if (lowerVal === 'null' || lowerVal === 'undefined' || lowerVal === 'nan' || lowerVal === '') {
          return null;
        }
        return trimmed; // Return the trimmed version
      }
      return val;
    };

    // Step 3: Route to appropriate service
    let result;
    const routingContext = {
      sessionId: sanitizeParam(sessionId),
      authToken: sanitizeParam(authToken) ? sanitizeParam(authToken).replace(/^Bearer\s+/i, '') : null,
      employeeNumber: sanitizeParam(empNumber),
      locationId: sanitizeParam(locationId)
    };

    // Global Diagnostic Logging
    console.log(`[UnifiedChat] Processing ${finalService} for ${empNumber}.`);
    console.log(`[UnifiedChat] AuthToken Source: ${req.headers['authorization'] ? 'Header' : (req.body.authToken || req.body.authorization ? 'Body' : 'None')}`);
    if (routingContext.authToken) {
       console.log(`[UnifiedChat] AuthToken Length: ${routingContext.authToken.length}`);
       console.log(`[UnifiedChat] AuthToken Sample: ${routingContext.authToken.substring(0, 5)}...${routingContext.authToken.substring(routingContext.authToken.length - 5)}`);
    } else {
       console.warn('[UnifiedChat] WARNING: No authToken found for routingContext');
    }

    // Use finalService for routing (accounts for context-inferred service)
    switch (finalService) {
      case 'canteen':
        // Use existing canteen logic with context-aware query
        const mcpClient = await getClient();
        let canteenContext = conversationContexts.get(sessionId) || {};
        if (locationId) {
          canteenContext.location_id = locationId;
          canteenContext.location = locationId === 1 ? 'bangalore' : 'coimbatore';
          conversationContexts.set(sessionId, canteenContext);
        }
        // Use effectiveQuery (rewritten with context) instead of original query
        const canteenResult = await processIntelligentQuery(effectiveQuery, mcpClient, canteenContext);
        if (canteenResult.location_id) {
          canteenContext.location_id = canteenResult.location_id;
          canteenContext.location = canteenResult.location;
          conversationContexts.set(sessionId, canteenContext);
        }
        result = {
          success: true,
          response: canteenResult.response,
          service: 'canteen',
          serviceName: 'Canteen Menu',
          needs_location: canteenResult.needs_location,
          location_id: canteenResult.location_id,
          menuData: canteenResult.menuData
        };
        break;

      case 'entryexit':
        // Use existing entry/exit logic with context-aware query
        const entryExitV2Client = getEntryExitV2Client();
        // Use effectiveQuery (rewritten with context) instead of original query
        const entryExitResult = await entryExitV2Client.processQueryWithAI(effectiveQuery, empNumber, req.body.userName);
        result = {
          success: entryExitResult.success,
          response: entryExitResult.response,
          service: 'entryexit',
          serviceName: 'Entry/Exit Time Tracking',
          employeeNumber: entryExitResult.employeeNumber,
          tool_used: entryExitResult.tool
        };
        break;

      case 'travel':
        // Ensure userName and identity metadata are correctly propagated
        if (req.body.userName) {
          routingContext.userName = req.body.userName;
        }

        // Resolve tokens for the user
        try {
          if (routingContext.authToken) {
            console.log(`[UnifiedChat] Resolving tokens for Travel Service (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken);
            if (userTokens) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.sessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token and Session ID successfully attached to routingContext (Travel)');
            }
          } else {
            console.log('[UnifiedChat] No authToken provided, travel-service will fallback to Service Account (Votan)');
          }
        } catch (tokenError) {
          console.log('[UnifiedChat] Token resolution warning:', tokenError.message);
        }

        // Use effectiveQuery for context-aware processing
        const travelResult = await travelService.processQuery(effectiveQuery, {
          authToken: routingContext.authToken,
          employeeNumber: empNumber,
          jwtToken: routingContext.jwtToken, // Restore user token for A2A capabilities
          sessionId: routingContext.sessionId,
          userName: req.body.userName || routingContext.user?.name || 'Bosch User'
        });
        result = {
          success: travelResult.success,
          response: travelResult.response,
          service: 'travel',
          serviceName: 'Travel Assistant',
          data: travelResult.data,
          travelState: travelResult.travelState // Include structured state for frontend
        };
        break;

      case 'seatbooking':
        // Ensure userName and identity metadata are correctly propagated
        // (mirror the travel case — the A2A seat-booking agent may use this
        // to identify the requester in the booking record and the privacy
        // check uses it to whitelist the user's own name).
        if (req.body.userName) {
          routingContext.userName = req.body.userName;
        }

        // 2. Resolve tokens for the user (checks header OR cache).
        //    Only attempt resolution if we actually have an OAuth token,
        //    otherwise let the service fall back to its own strategies and
        //    log clearly so we can tell from the server logs whether the
        //    issue is token resolution or something further downstream.
        try {
          if (routingContext.authToken) {
            console.log(`[UnifiedChat] Resolving tokens for Seat Booking (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken);
            if (userTokens && userTokens.jwtToken) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.sessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token and Session ID successfully attached to routingContext (SeatBooking)');
              console.log('[UnifiedChat] SeatBooking jwtToken (first 40):', (userTokens.jwtToken || '').substring(0, 40) + '...');
              console.log('[UnifiedChat] SeatBooking sessionId:', userTokens.sessionId);
            } else {
              console.warn('[UnifiedChat] getTokenForUser returned no jwtToken for SeatBooking — service will fallback.');
            }
          } else {
            console.log('[UnifiedChat] No authToken provided, seat-booking service will fallback to Service Account');
          }
        } catch (tokenError) {
          console.error('[UnifiedChat] ERROR resolving tokens for seat booking:', tokenError.message);
          console.log('[UnifiedChat] Proceeding without user tokens - Seat Booking service will handle fallback.');
        }

        // Use effectiveQuery for context-aware processing
        // Pass an EXPLICIT context object so userName (and every other
        // identity field) is guaranteed to reach the service.
        const seatResult = await seatbookingService.processQuery(effectiveQuery, {
          authToken: routingContext.authToken,
          employeeNumber: routingContext.employeeNumber,
          jwtToken: routingContext.jwtToken,
          sessionId: routingContext.sessionId,
          //locationId: routingContext.locationId,
          userName: req.body.userName || routingContext.user?.name || 'Bosch User'
        });

        // Seat Booking: No longer force a location selection popup.
        // Let the A2A agent's natural response handle the conversation.
        result = {
          success: seatResult.success,
          response: seatResult.response,
          service: 'seatbooking',
          serviceName: 'Seat Booking',
          data: seatResult.data,
          needs_location: false
        };
        break;

      case 'community':
        // 1. Resolve tokens for the user
        try {
          if (routingContext.authToken) {
            console.log(`[UnifiedChat] Community: Raw authToken length: ${routingContext.authToken.length}`);
            console.log(`[UnifiedChat] Community: Raw authToken sample: ${routingContext.authToken.substring(0, 5)}...${routingContext.authToken.substring(routingContext.authToken.length - 5)}`);
            
            console.log(`[UnifiedChat] Resolving tokens for Community Service (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken);
            if (userTokens && userTokens.jwtToken) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.sessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token successfully attached to routingContext (Community)');
            } else {
              console.warn('[UnifiedChat] Token resolution returned no JWT for Community');
            }
          } else {
            console.warn('[UnifiedChat] No authToken found for Community resolution');
          }
        } catch (tokenError) {
          console.warn('[UnifiedChat] Token resolution warning for Community:', tokenError.message);
        }

        // Use effectiveQuery for context-aware processing
        const communityResult = await communityService.processQuery(effectiveQuery, {
          ...routingContext,
          jwtToken: routingContext.jwtToken,
          sessionId: routingContext.sessionId,
          userName: req.body.userName || routingContext.user?.name || 'Bosch User'
        });
        result = {
          success: communityResult.success,
          response: communityResult.response,
          service: 'community',
          serviceName: 'Bosch Community',
          data: communityResult.data
        };
        break;

      case 'banner':
        // Use effectiveQuery for context-aware processing
        const bannerResult = await bannerService.processBannerQuery(effectiveQuery);
        result = {
          success: !bannerResult.error,
          response: bannerResult.response,
          service: 'banner',
          serviceName: 'Company News/Snippets',
          banners: bannerResult.banners,
          hasBannerImages: bannerResult.hasBannerImages
        };
        break;

      case 'general':
        // Use effectiveQuery for context-aware processing
        // Get full context including persisted history
        const generalContext = conversationContextService.getContext(sessionId);
        const fullHistory = generalContext && generalContext.messages.length > 0 ? generalContext.messages : conversationHistory;

        const generalResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fullHistory);
        result = {
          success: true,
          response: generalResponse,
          service: 'general',
          serviceName: 'General Assistant'
        };
        break;

      default:
        // Check if it's a dynamic service
        const serviceConfig = mcpServiceManager.getService(finalService);
        if (serviceConfig) {
          try {
            const genericClient = new GenericMCPClient(serviceConfig);
            // Pass context
            const dynamicContext = {
              sessionId,
              employeeNumber: empNumber,
              locationId,
              history: conversationHistory
            };

            const dynamicResult = await genericClient.processQuery(effectiveQuery, dynamicContext);

            result = {
              success: dynamicResult.success,
              response: dynamicResult.response,
              service: finalService,
              serviceName: serviceConfig.name,
              data: dynamicResult.originalData
            };
          } catch (err) {
            console.error(`Error invoking dynamic service ${finalService}:`, err);
            // Fallback to general if dynamic service fails
            const fallbackContext = conversationContextService.getContext(sessionId);
            const fallbackHistory = fallbackContext && fallbackContext.messages.length > 0 ? fallbackContext.messages : conversationHistory;
            const fallbackResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fallbackHistory);
            result = {
              success: true,
              response: fallbackResponse,
              service: 'general',
              serviceName: 'General Assistant (Fallback)'
            };
          }
        } else {
          // Unknown service, default to general
          const unknownContext = conversationContextService.getContext(sessionId);
          const unknownHistory = unknownContext && unknownContext.messages.length > 0 ? unknownContext.messages : conversationHistory;
          const unknownResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, unknownHistory);
          result = {
            success: true,
            response: unknownResponse,
            service: 'general',
            serviceName: 'General Assistant'
          };
        }
        break;
    }

    // ===== UPDATE CONVERSATION CONTEXT =====
    // Step 4: Store the AI response and update context metadata
    const topic = conversationContextService.extractTopicFromResponse(result.response, result.service);
    const dateInQuery = conversationContextService.extractDate(effectiveQuery);

    // Extract month reference from the query (e.g. "February 2026" → "2026-02")
    const monthNames = {
      january: '01', jan: '01', february: '02', feb: '02', march: '03', mar: '03',
      april: '04', apr: '04', may: '05', june: '06', jun: '06', july: '07', jul: '07',
      august: '08', aug: '08', september: '09', sep: '09', october: '10', oct: '10',
      november: '11', nov: '11', december: '12', dec: '12'
    };
    let monthInQuery = null;
    const monthRegex = /\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\b(?:\s+(\d{4}))?/i;
    const monthMatch = effectiveQuery.match(monthRegex);
    if (monthMatch) {
      const mNum = monthNames[monthMatch[1].toLowerCase()];
      const mYear = monthMatch[2] || new Date().getFullYear().toString();
      monthInQuery = `${mYear}-${mNum}`;
    }

    conversationContextService.addMessage(sessionId, 'assistant', result.response, {
      service: result.service,
      topic: topic,
      date: dateInQuery,
      month: monthInQuery,
      locationId: result.location_id || locationId
    });

    // Update service context for future follow-ups
    conversationContextService.updateServiceContext(sessionId, {
      service: result.service,
      topic: topic,
      date: dateInQuery,
      month: monthInQuery,
      locationId: result.location_id || locationId
    });

    console.log('[Context] Updated context - Service:', result.service, 'Topic:', topic, 'Date:', dateInQuery);
    console.log('Response service:', result.service);
    console.log('==========================================\n');

    // Include context info in response for debugging (optional)
    result.contextInfo = {
      wasRewritten: wasRewritten,
      originalQuery: wasRewritten ? query : undefined,
      effectiveQuery: wasRewritten ? effectiveQuery : undefined
    };

    // ===== PERSIST TO MS SQL AZURE DB =====
    // Save conversation to database (non-blocking, don't fail the response)
    let conversationId = null;
    try {
      // Generate a proper UUID for the session if the frontend sessionId isn't UUID format
      const { v4: uuidv4, validate: uuidValidate } = require('uuid');
      const dbSessionId = uuidValidate(sessionId) ? sessionId : uuidv4();

      conversationId = await conversationDbService.saveConversation(
        dbSessionId,
        result.service || 'web',
        query,
        result.response || ''
      );
    } catch (dbError) {
      console.error('[ConversationDB] Failed to persist (non-fatal):', dbError.message);
    }

    // Include conversationId in response for feedback reference
    result.conversationId = conversationId;

    res.json(result);

  } catch (error) {
    console.error('Unified chat error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process query',
      details: error.message,
      response: "I'm having trouble processing your request right now. Please try again."
    });
  }
});

/**
 * POST /api/chat/feedback - Submit feedback for a conversation
 * Body: { conversationId: number, feedback: number }
 * feedback: -1 = thumbs down, 0 = no feedback, 1 = thumbs up
 */
app.post('/api/chat/feedback', async (req, res) => {
  try {
    const { conversationId, feedback } = req.body;

    if (!conversationId) {
      return res.status(400).json({ error: 'conversationId is required' });
    }

    if (![-1, 0, 1].includes(feedback)) {
      return res.status(400).json({ error: 'feedback must be -1, 0, or 1' });
    }

    console.log(`[Feedback] Updating conversation ${conversationId} with feedback: ${feedback}`);
    const success = await conversationDbService.updateFeedback(conversationId, feedback);

    if (success) {
      res.json({ success: true, message: 'Feedback saved' });
    } else {
      res.status(404).json({ success: false, error: 'Conversation not found or DB unavailable' });
    }
  } catch (error) {
    console.error('Feedback error:', error);
    res.status(500).json({ success: false, error: 'Failed to save feedback' });
  }
});

// Get available services
app.get('/api/services', (req, res) => {
  const servicesMap = intelligentRouter.getAllServices();
  const servicesList = Object.entries(servicesMap).map(([id, s]) => ({
    id: id,
    name: s.name,
    icon: s.icon || 'ðŸ¤–', // Default icon if none provided
    description: s.description,
    isDynamic: !!s.isDynamic
  }));

  res.json({
    services: servicesList
  });
});

// Start server
app.listen(PORT, '0.0.0.0', async () => {
  // Initialize configuration
  try {
    const configService = require('./services/config-service');
    await configService.initialize();
  } catch (err) {
    console.error('Failed to initialize ConfigService:', err);
  }
  console.log(`Server running on port ${PORT}`);
  console.log(`Logs will be stored in: ${logsDir}`);
  console.log(`Entry/Exit MCP URL: ${process.env.ENTRYEXIT_MCP_URL || 'Using default URL'}`);
  console.log(`Smart routing enabled with services: canteen, entryexit, travel, seatbooking, community, banner`);
});