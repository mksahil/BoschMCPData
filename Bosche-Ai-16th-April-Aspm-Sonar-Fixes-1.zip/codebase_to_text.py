"""
codebase_to_zip.py
====================
Zips an entire codebase (excluding node_modules, .git, build artefacts, etc.)
into a single .zip file, preserving the original folder structure.

Usage:
    python codebase_to_text.py
    python codebase_to_text.py --root "C:/path/to/project" --out my_project.zip
"""

import os
import zipfile
import argparse
import datetime
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────────────────────────────────────

DEFAULT_ROOT   = "."
DEFAULT_OUTPUT = "codebase.zip"

# Directories to completely skip
SKIP_DIRS = {
    "node_modules",
    ".git",
    ".svn",
    ".hg",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".tox",
    "venv",
    ".venv",
    "env",
    "dist",
    "build",
    ".next",
    "out",
    ".nuxt",
    ".output",
    "coverage",
    ".nyc_output",
    "vendor",
    "storage",
    ".idea",
    ".vscode",
}

# Exact filenames to always skip
SKIP_FILES = {
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "composer.lock",
    "Pipfile.lock",
    "poetry.lock",
    ".DS_Store",
    "Thumbs.db",
}

# ──────────────────────────────────────────────────────────────────────────────

def is_skipped_dir(name: str) -> bool:
    return name in SKIP_DIRS


def is_skipped_file(name: str) -> bool:
    return name in SKIP_FILES


def generate_zip(root: str, output: str):
    root_path   = Path(root).resolve()
    output_path = Path(output).resolve()

    # Make sure we don't zip the output file itself
    timestamp   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    if not output_path.suffix:
        output_path = output_path.with_suffix(".zip")

    total_files    = 0
    skipped_files  = 0
    total_bytes    = 0

    print(f"📦  Zipping: {root_path}")
    print(f"📄  Output : {output_path}\n")

    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for dirpath, dirnames, filenames in os.walk(root_path):
            # Prune skipped dirs in-place (os.walk respects this)
            dirnames[:] = sorted(
                d for d in dirnames if not is_skipped_dir(d)
            )

            for fname in sorted(filenames):
                fpath = Path(dirpath) / fname

                # Skip the output zip itself
                if fpath.resolve() == output_path:
                    continue

                if is_skipped_file(fname):
                    skipped_files += 1
                    continue

                rel_path   = fpath.relative_to(root_path)
                file_size  = fpath.stat().st_size

                try:
                    zf.write(fpath, arcname=rel_path)
                    total_files  += 1
                    total_bytes  += file_size
                    print(f"  ✓  {rel_path}")
                except Exception as e:
                    print(f"  ✗  {rel_path}  ({e})")
                    skipped_files += 1

    zip_size = output_path.stat().st_size / 1024

    print(f"\n{'='*60}")
    print(f"✅  Done!")
    print(f"   Files zipped  : {total_files}")
    print(f"   Files skipped : {skipped_files}")
    print(f"   Source size   : {total_bytes / 1024:.1f} KB")
    print(f"   ZIP size      : {zip_size:.1f} KB")
    print(f"   Output        : {output_path}")
    print(f"{'='*60}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Zip a codebase without node_modules and build noise.")
    parser.add_argument("--root", default=DEFAULT_ROOT,   help="Root directory to zip (default: current dir)")
    parser.add_argument("--out",  default=DEFAULT_OUTPUT, help="Output zip file name (default: codebase.zip)")
    args = parser.parse_args()

    generate_zip(args.root, args.out)

