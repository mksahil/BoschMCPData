const axios = require('axios');
const https = require('https');

// Disable SSL verification for verification
const httpsAgent = new https.Agent({
    rejectUnauthorized: false
});

async function testEncryption() {
    console.log('Testing GetEncryptedPassword API...');

    const url = 'https://dev.boschassociatearena.com/api/ManageUser/GetEncryptedPassword';

    const payload = {
        "EmailId": "34835634", // Using the working user ID
        "Password": "TestPassword"
    };

    try {
        const response = await axios.post(
            url,
            payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' // Explicitly sending empty bearer as per user example
                },
                httpsAgent
            }
        );

        console.log('Status:', response.status);
        console.log('Response Data:', response.data);

        // Check if we got something looking like an encrypted string
        if (typeof response.data === 'string' || response.data?.EncryptedPassword) {
            console.log('✅ Success: Received response (likely encrypted password)');
        } else {
            console.log('⚠️ Warning: Response format unexpected');
        }

    } catch (error) {
        console.error('❌ API Error:', error.message);
        if (error.response) {
            console.error('Response status:', error.response.status);
            console.error('Response data:', error.response.data);
        }
    }
}

testEncryption();
