const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
    rejectUnauthorized: false
});

async function runTest() {
    const token = '1SjXS9CgTCUU-2cTredsXFNG0u6SrtyjZsgp9JIHNiZSkiVk-cosPSr-3jSkbI-dD1L428oovs_bYf-aTnt7k1jD9rB9aB8N5cO1cM1xG1vM6Qv_0G4_9XFkTjXqYwB0R6Z0UaUfV5nO3X0cVwF1iW_V9L7rJ8Q2hT2cZ9uN7P2H3K2nN0X4Y0qE7lS5T0xQ5hE4aU7uY0L9Q9yI5P2nZ2sA5jI0M5lO_2aB2fO0O1kG9rN5Y4kL2cZ0sT8sK_9uF0aA6hH9uX5cM1aR0O0L9uH6hQ2_2H'; // A sample from the logs
    const clientId = 'BE3B36B4-ED49-490E-94BB-7F34E86499BF';
    const baseUrl = 'https://dev.boschassociatearena.com/api';

    try {
        console.log('Testing JWT generation with frontend token...');
        const response = await axios.get(`${baseUrl}/Token/GenrateTokenDetails`, {
            params: { clientID: clientId },
            headers: { 'Authorization': `Bearer ${token}` },
            httpsAgent
        });
        console.log('SUCCESS:', response.data);
    } catch (error) {
        if (error.response) {
            console.error('FAILED (401 expected):', error.response.status);
            console.error('Data:', error.response.data);
        } else {
            console.error('FAILED (other):', error.message);
        }
    }
}

runTest();
