/**
 * Bosch Arena Authentication Service
 * Handles OAuth login, JWT token generation, and token validation
 */

const axios = require('axios');
const https = require('https');
// [FIX #5 | Issue #23 - Module Loading]: Crypto module moved to top-level import
const crypto = require('crypto');

// [FIX #6 | Rule S5144 - SSRF]: Strict whitelist of allowed outbound hostnames
// No user-controlled input can expand this list, which breaks the taint chain from req.body.
const ALLOWED_API_HOSTS = [
  'dev.boschassociatearena.com',
  'bgsw-bmam-dev-001.azurewebsites.net',
];

/**
 * Validates that the target URL belongs to an approved Bosch host.
 * Throws if the URL is not on the allowlist — prevents SSRF.
 */
function validateTargetUrl(rawUrl) {
  // [FIX #6 | Rule S5144 - SSRF]: Validate URL against allowlist before use
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error(`[BoschAuth] SSRF guard: invalid target URL: ${rawUrl}`);
  }
  if (!ALLOWED_API_HOSTS.includes(parsed.hostname)) {
    throw new Error(`[BoschAuth] SSRF guard: disallowed host '${parsed.hostname}'`);
  }
  return rawUrl;
}

/**
 * Sanitizes OAuth/Bearer tokens before they are placed in HTTP headers.
 * Strips any character that is not a valid JWT or opaque-token character.
 * Prevents header injection through user-controlled token values.
 */
function sanitizeOAuthToken(token) {
  // [FIX #6 | Rule S5144 - SSRF]: Strip non-token chars to prevent header injection
  if (typeof token !== 'string') return '';
  // Allow only alphanumeric, dash, underscore, dot, tilde (RFC 6750 token chars)
  return token.replace(/[^A-Za-z0-9\-_\.~+\/=]/g, '');
}

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

class BoschAuthService {
  constructor() {
    this.baseUrl = 'https://dev.boschassociatearena.com/api';
    this.clientId = process.env.BOSCH_CLIENT_ID || 'BE3B36B4-ED49-490E-94BB-7F34E86499BF';

    // Cache for SERVICE ACCOUNT tokens (fallback)
    this.tokenCache = {
      oauthToken: null,
      jwtToken: null,
      expiresAt: null
    };

    // Cache for USER tokens (keyed by employee number)
    // Format: { employeeNumber: { oauthToken, jwtToken, sessionId, expiresAt } }
    this.userTokenCache = new Map();

    // Token refresh buffer (refresh 5 minutes before expiry)
    this.refreshBuffer = 5 * 60 * 1000;

    // Session ID cache (keyed by employee number) - persists across requests
    this.userSessionCache = new Map();
  }

  /**
   * Helper: Get encrypted password before login
   */
  async getEncryptedPassword(username, plainPassword) {
    try {
      console.log(`[BoschAuth] Encrypting password for user: ${username}`);

      // [FIX #7 | Rule S2083 - Path Injection]: Prevent path injection by using URL parser
      const endpoint = new URL('ManageUser/GetEncryptedPassword', this.baseUrl + '/').href;

      const response = await axios.post(
        endpoint,
        {
          "EmailId": username,
          "Password": plainPassword
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' // Required header even if empty
          },
          httpsAgent,
          timeout: 10000
        }
      );

      if (response.data && response.data.IsSuccess && response.data.ResponseData && response.data.ResponseData.length > 0) {
        return response.data.ResponseData[0].Password;
      }

      throw new Error('Failed to get encrypted password from response');
    } catch (error) {
      console.error('[BoschAuth] Password encryption error:', error.message);
      throw error;
    }
  }

  /**
   * Step 1: Login to get OAuth Bearer token
   * @param {string} username - User ID
   * @param {string} password - Plain text or pre-encrypted password
   * @param {string} deviceToken - Device token
   * @param {boolean} isPreEncrypted - If true, skip encryption (password is already encrypted)
   */
  async login(username, password, deviceToken, isPreEncrypted = false) {
    try {
      console.log(`[BoschAuth] Logging in user: ${username}`);

      let encryptedPassword;
      if (isPreEncrypted) {
        console.log('[BoschAuth] Using pre-encrypted password');
        encryptedPassword = password;
      } else {
        // Encrypt the password first
        encryptedPassword = await this.getEncryptedPassword(username, password);
        console.log('[BoschAuth] Password encrypted successfully');
      }

      const loginData = [
        'grant_type=password',
        `username=${username}`,
        `password=${encodeURIComponent(encryptedPassword)}`,
        // [FIX #8 | Issue #9 - Hardcoded Secret]: Device token loaded from environment
        `DeviceToken=${deviceToken || process.env.BOSCH_DEVICE_TOKEN}`,
        'IsIOS=true',
        'IsAndroid=false',
        'RequestSource=App'
      ].join('&');

      // [FIX #7 | Rule S2083 - Path Injection]: Prevent path injection by using URL parser
      const endpoint = new URL('ManageUser/Login', this.baseUrl + '/').href;

      const response = await axios.post(
        endpoint,
        loginData,
        {
          headers: {
            'Content-Type': 'text/plain'
          },
          httpsAgent,
          timeout: 30000
        }
      );

      console.log('[BoschAuth] Login successful');
      console.log('[BoschAuth] OAuth Token (first 50 chars):', response.data?.access_token?.substring(0, 50) + '...');
      console.log('[BoschAuth] Token Type:', response.data?.token_type);
      console.log('[BoschAuth] Expires In:', response.data?.expires_in, 'seconds');
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] Login error:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  /**
   * Step 2: Generate JWT token using OAuth token
   */
  async generateJWTToken(oauthToken) {
    try {
      console.log('[BoschAuth] Generating JWT token...');

      // [FIX #7 | Rule S2083 - Path Injection]: Prevent path injection by using URL parser
      const endpoint = new URL('Token/GenrateTokenDetails', this.baseUrl + '/').href;

      // [FIX #6 | Rule S5144 - SSRF]: Sanitize token and validate target URL
      const safeToken = sanitizeOAuthToken(oauthToken);
      validateTargetUrl(endpoint);

      const response = await axios.get(
        endpoint,
        {
          params,
          headers,
          httpsAgent,
          timeout: 30000
        }
      );

      console.log('[BoschAuth] JWT token generated successfully');
      const token = response.data?.ResponseData?.Token || response.data?.token || response.data;
      console.log('[BoschAuth] JWT Token Structure:', Object.keys(response.data || {}));
      console.log('[BoschAuth] JWT Token (first 50 chars):', typeof token === 'string' ? token.substring(0, 50) + '...' : 'Not a string');
      console.log('[BoschAuth] Full JWT Response:', JSON.stringify(response.data).substring(0, 200));
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] JWT generation error:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  /**
   * Step 3: Validate JWT token
   */
  async validateToken(jwtToken) {
    try {
      console.log('[BoschAuth] Validating JWT token...');

      // [FIX #7 | Rule S2083 - Path Injection]: Prevent path injection by using URL parser
      const endpoint = new URL('Token/ValidateToken', this.baseUrl + '/').href;

      const response = await axios.get(
        endpoint,
        {
          headers: {
            'Authorization': `Bearer ${jwtToken}`,
            'clientid': this.clientId
          },
          httpsAgent,
          timeout: 30000
        }
      );

      console.log('[BoschAuth] Token validated successfully');
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] Token validation error:', error.message);
      return { valid: false, error: error.message };
    }
  }

  /**
   * Get a valid JWT token (with caching and auto-refresh)
   * Uses service account credentials from environment
   */
  async getServiceToken() {
    try {
      // Check if cached token is still valid
      if (this.tokenCache.jwtToken && this.tokenCache.expiresAt) {
        const now = Date.now();
        if (now < this.tokenCache.expiresAt - this.refreshBuffer) {
          console.log('[BoschAuth] Using cached JWT token');
          console.log('[BoschAuth] Cached Token (first 50 chars):', this.tokenCache.jwtToken?.substring(0, 50) + '...');
          console.log('[BoschAuth] Cache Expires At:', new Date(this.tokenCache.expiresAt).toISOString());
          return this.tokenCache.jwtToken;
        }
      }

      // Get service account credentials from env
      const username = process.env.BOSCH_SERVICE_USERNAME;
      const password = process.env.BOSCH_SERVICE_PASSWORD;
      // Check if password is pre-encrypted (set in .env)
      const isPreEncrypted = process.env.BOSCH_SERVICE_PASSWORD_ENCRYPTED === 'true';

      if (!username || !password) {
        throw new Error('Service account credentials not configured');
      }

      // Step 1: Login to get OAuth token (pass isPreEncrypted flag)
      const loginResponse = await this.login(username, password, null, isPreEncrypted);
      const oauthToken = loginResponse.access_token || loginResponse;

      // Step 2: Generate JWT token
      const jwtResponse = await this.generateJWTToken(oauthToken);
      // Extract token from ResponseData.Token structure
      const jwtToken = jwtResponse?.ResponseData?.Token || jwtResponse?.token || jwtResponse;

      // Cache the token (expires in ~30 days based on the example, but we'll refresh daily)
      this.tokenCache.jwtToken = jwtToken;
      this.tokenCache.oauthToken = oauthToken;
      this.tokenCache.expiresAt = Date.now() + (24 * 60 * 60 * 1000); // 24 hours

      console.log('[BoschAuth] New JWT token obtained and cached');
      console.log('[BoschAuth] Final JWT Token (first 80 chars):', typeof jwtToken === 'string' ? jwtToken.substring(0, 80) + '...' : 'Token is not a string: ' + typeof jwtToken);
      console.log('[BoschAuth] Token Cache Expires At:', new Date(this.tokenCache.expiresAt).toISOString());
      return jwtToken;
    } catch (error) {
      console.error('[BoschAuth] Failed to get service token:', error.message);
      throw error;
    }
  }

  /**
   * Store user tokens after successful login
   * Called from login endpoint to cache OAuth token and generate JWT
   */
  async storeUserTokens(employeeNumber, oauthToken, expiresIn) {
    try {
      console.log(`[BoschAuth] Storing tokens for user: ${employeeNumber}`);

      // [FIX #6 | Rule S5144 - SSRF]: Sanitize incoming oauthToken before passing to generateJWTToken
      // This prevents header injection and breaks the taint chain from req.body → axios header
      const safeOAuthToken = sanitizeOAuthToken(oauthToken);

      // Generate JWT token from OAuth token
      const jwtResponse = await this.generateJWTToken(safeOAuthToken);
      const jwtToken = jwtResponse?.ResponseData?.Token || jwtResponse?.token || jwtResponse;

      // Generate or retrieve persistent session ID for this user
      let sessionId = this.userSessionCache.get(employeeNumber);
      if (!sessionId) {
        sessionId = crypto.randomUUID();
        this.userSessionCache.set(employeeNumber, sessionId);
        // console.log(`[BoschAuth] Created new session ID for ${employeeNumber}: ${sessionId}`);
      } else {
        // console.log(`[BoschAuth] Using existing session ID for ${employeeNumber}: ${sessionId}`);
      }

      // Calculate expiration (default to 24 hours if not provided)
      const expiresAt = Date.now() + ((expiresIn || 86400) * 1000);

      // Store in user cache
      this.userTokenCache.set(employeeNumber, {
        oauthToken,
        jwtToken,
        sessionId,
        expiresAt
      });

      console.log(`[BoschAuth] Tokens stored for user ${employeeNumber}`);
      console.log(`[BoschAuth] JWT Token (first 50 chars): ${jwtToken?.substring(0, 50)}...`);
      // console.log(`[BoschAuth] Session ID: ${sessionId}`);
      console.log(`[BoschAuth] Expires at: ${new Date(expiresAt).toISOString()}`);

      return { jwtToken, sessionId, expiresAt };
    } catch (error) {
      console.error(`[BoschAuth] Failed to store tokens for ${employeeNumber}:`, error.message);
      throw error;
    }
  }

  /**
   * Get cached tokens for a specific user
   * Returns null if not found or expired
   */
  /**
   * Get cached tokens for a specific user
   * Returns null if not found, expired, or if an OAuth token is provided that
   * does not match the one stored in cache.  This guards against an attacker
   * supplying only an employee number and relying on stale cached credentials.
   *
   * @param {string} employeeNumber
   * @param {string?} userOAuthToken - optional bearer token from the client
   */
  getUserTokens(employeeNumber, userOAuthToken = null) {
    const cached = this.userTokenCache.get(employeeNumber);
    if (!cached) {
      console.log(`[BoschAuth] No cached tokens for user: ${employeeNumber} (Cache missing)`);
      return null;
    }

    // If an OAuth token is provided ensure it matches the one in cache
    if (userOAuthToken && cached.oauthToken && userOAuthToken !== cached.oauthToken) {
      console.log(`[BoschAuth] Cached OAuth token mismatch for user: ${employeeNumber}`);
      console.log(`[BoschAuth] Provided: ${userOAuthToken.substring(0, 20)}...`);
      console.log(`[BoschAuth] Cached:   ${cached.oauthToken.substring(0, 20)}...`);
      return null;
    }

    // Check if expired
    if (Date.now() > cached.expiresAt - this.refreshBuffer) {
      console.log(`[BoschAuth] Cached tokens expired for user: ${employeeNumber}`);
      this.userTokenCache.delete(employeeNumber);
      return null;
    }

    console.log(`[BoschAuth] Using cached tokens for user: ${employeeNumber}`);
    // console.log(`[BoschAuth] Cached Session ID: ${cached.sessionId}`);
    return cached;
  }

  /**
   * Get or create session ID for a user (persists across requests)
   */
  getOrCreateSessionId(employeeNumber) {
    let sessionId = this.userSessionCache.get(employeeNumber);
    if (!sessionId) {
      sessionId = crypto.randomUUID();
      this.userSessionCache.set(employeeNumber, sessionId);
      // console.log(`[BoschAuth] Created new session ID for ${ employeeNumber }: ${ sessionId } `);
    } else {
      // console.log(`[BoschAuth] Using existing session ID for ${ employeeNumber }: ${ sessionId } `);
    }
    return sessionId;
  }

  /**
   * Get token for a specific user (after they log in)
   * First checks cache, then tries to generate from OAuth token
   */
  async getTokenForUser(employeeNumber, userOAuthToken) {
    try {
      // First check cache, but only if the caller has provided a matching OAuth token
      const cached = this.getUserTokens(employeeNumber, userOAuthToken);
      if (cached) {
        return {
          jwtToken: cached.jwtToken,
          sessionId: cached.sessionId
        };
      }

      // If we fall through and an OAuth token was supplied, we can generate
      // fresh tokens and cache them.  Without an OAuth token we must refuse.
      if (userOAuthToken) {
        const result = await this.storeUserTokens(employeeNumber, userOAuthToken);
        return {
          jwtToken: result.jwtToken,
          sessionId: result.sessionId
        };
      }

      throw new Error('No cached tokens and no OAuth token provided');
    } catch (error) {
      console.error('[BoschAuth] Failed to get user token:', error.message);
      throw error;
    }
  }

  /**
   * Generate session ID for API calls (DEPRECATED - use getOrCreateSessionId instead)
   * Format: UUID (required by Travel API)
   */
  generateSessionId(employeeNumber) {
    // Use persistent session ID instead of generating new ones
    return this.getOrCreateSessionId(employeeNumber);
  }

  /**
   * Generate session ID in legacy format (for services that need it)
   * Format: user_<employeeNumber>_<timestamp>
   */
  generateLegacySessionId(employeeNumber) {
    const timestamp = Date.now();
    return `user_${employeeNumber}_${timestamp} `;
  }

  /**
   * Clear user tokens (on logout)
   */
  clearUserTokens(employeeNumber) {
    this.userTokenCache.delete(employeeNumber);
    // Keep session ID for continuity if they log back in
    console.log(`[BoschAuth] Cleared tokens for user: ${employeeNumber} `);
  }
}

// Export singleton instance
module.exports = new BoschAuthService();
