/**
 * Debug Seat Booking A2A Agent
 *
 * Tries several `metadata` shapes against the seat-booking host agent to
 * isolate which field the agent actually needs in order to stop replying
 * with "Failed to parse user data: Invalid user data format".
 *
 * Usage:
 *   1. Log in to the frontend once so boschAuthService has a valid user
 *      JWT cached (or set TEST_JWT_TOKEN in .env to a valid user JWT).
 *   2. From backend/: node debug-seatbooking.js
 *   3. Compare the responses across candidates A–H and report back the
 *      candidate(s) that did NOT fail with the user-data parse error.
 */

require('dotenv').config();
const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

const apiUrl = (process.env.SEATBOOKING_API_URL || 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io')
  .trim()
  .replace(/\/+$/, '');

const jwtToken = process.env.TEST_JWT_TOKEN;
const employeeNumber = process.env.TEST_EMPLOYEE_NUMBER || '35580530';
const userName = process.env.TEST_USER_NAME || 'Manjunatha Kirugaval Vijaya Narayan';
const userEmail = process.env.TEST_USER_EMAIL || 'test.user@in.bosch.com';

if (!jwtToken) {
  console.error('[Debug] TEST_JWT_TOKEN env var is required.');
  console.error('        Set it to a valid user JWT (not a service-account token).');
  process.exit(1);
}

const baseSessionId = 'debug-seat-' + Date.now();

// Candidate metadata shapes to test. Each one is a full `metadata` object
// that will be attached to the A2A params.
const candidates = [
  {
    label: 'A: baseline (current code) — auth + employee_id',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-A' },
      employee_id: employeeNumber
    }
  },
  {
    label: 'B: travel-shape clone — auth + employee_id + travel_mode:flight',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-B' },
      employee_id: employeeNumber,
      travel_mode: 'flight'
    }
  },
  {
    label: 'C: booking_mode:seat (seat analogue of travel_mode)',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-C' },
      employee_id: employeeNumber,
      booking_mode: 'seat'
    }
  },
  {
    label: 'D: enriched user fields — user_name + user_email + user_id',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-D' },
      employee_id: employeeNumber,
      user_name: userName,
      user_email: userEmail,
      user_id: employeeNumber
    }
  },
  {
    label: 'E: literal user_data JSON string (matches parse-error wording)',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-E' },
      employee_id: employeeNumber,
      user_data: JSON.stringify({
        employee_id: employeeNumber,
        name: userName,
        email: userEmail
      })
    }
  },
  {
    label: 'F: literal user_data OBJECT (not string)',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-F' },
      employee_id: employeeNumber,
      user_data: {
        employee_id: employeeNumber,
        name: userName,
        email: userEmail
      }
    }
  },
  {
    label: 'G: everything kitchen sink',
    metadata: {
      auth: { token: jwtToken, session_id: baseSessionId + '-G' },
      employee_id: employeeNumber,
      user_id: employeeNumber,
      user_name: userName,
      user_email: userEmail,
      booking_mode: 'seat',
      travel_mode: 'seat',
      user_data: {
        employee_id: employeeNumber,
        name: userName,
        email: userEmail
      }
    }
  },
  {
    label: 'H: user_data inside auth block',
    metadata: {
      auth: {
        token: jwtToken,
        session_id: baseSessionId + '-H',
        user_data: {
          employee_id: employeeNumber,
          name: userName,
          email: userEmail
        }
      },
      employee_id: employeeNumber
    }
  }
];

async function callAgent(candidate) {
  const reqId = 'debug-req-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  const msgId = 'debug-msg-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  const body = {
    jsonrpc: '2.0',
    id: reqId,
    method: 'message/send',
    params: {
      message: {
        messageId: msgId,
        role: 'user',
        parts: [
          { type: 'text', text: 'book a seat' }
        ]
      },
      metadata: candidate.metadata
    }
  };

  console.log('\n=============================================================');
  console.log(`[Debug] CANDIDATE ${candidate.label}`);
  console.log('[Debug] metadata keys:', Object.keys(candidate.metadata));
  console.log('[Debug] metadata.auth keys:', Object.keys(candidate.metadata.auth || {}));
  try {
    const res = await axios.post(apiUrl + '/', body, {
      headers: { accept: 'application/json', 'Content-Type': 'application/json' },
      httpsAgent,
      timeout: 120000
    });

    const result = res.data && res.data.result;
    const texts = [];
    const pushText = (label, parts) => {
      if (!Array.isArray(parts)) return;
      for (const p of parts) {
        const t = p?.text || p?.content || (typeof p === 'string' ? p : null);
        if (t) texts.push(`[${label}] ${String(t).substring(0, 400)}`);
      }
    };
    pushText('status.message', result?.status?.message?.parts);
    pushText('message', result?.message?.parts);
    if (Array.isArray(result?.artifacts)) {
      result.artifacts.forEach((a, i) => pushText(`artifacts[${i}]`, a?.parts));
    }
    if (Array.isArray(result?.history)) {
      result.history.forEach((h, i) => pushText(`history[${i}]`, h?.parts));
    }

    console.log('[Debug] HTTP status:', res.status);
    console.log('[Debug] Task state :', result?.status?.state);
    if (texts.length === 0) {
      console.log('[Debug] (no text parts found)');
      console.log('[Debug] Top-level keys:', result ? Object.keys(result) : '(null)');
    } else {
      for (const t of texts) console.log('[Debug]', t);
    }

    const combined = texts.join(' ').toLowerCase();
    const failedParse = combined.includes('failed to parse user data') ||
                        combined.includes('invalid user data') ||
                        combined.includes('error with the user data');
    console.log(failedParse
      ? '[Debug] ❌ STILL FAILS with user-data parse error'
      : '[Debug] ✅ NO user-data parse error — this shape may work!');
  } catch (err) {
    if (err.response) {
      console.log('[Debug] HTTP error status:', err.response.status);
      console.log('[Debug] HTTP error body  :', JSON.stringify(err.response.data).substring(0, 400));
    } else {
      console.log('[Debug] Network error:', err.message);
    }
  }
}

(async () => {
  console.log(`[Debug] Seat Booking A2A agent: ${apiUrl}`);
  console.log(`[Debug] Employee: ${employeeNumber}`);
  console.log(`[Debug] JWT prefix: ${jwtToken.substring(0, 40)}...`);
  for (const c of candidates) {
    await callAgent(c);
  }
})();
