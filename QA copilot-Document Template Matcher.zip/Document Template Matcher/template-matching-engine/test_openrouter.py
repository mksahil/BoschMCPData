#!/usr/bin/env python3
"""
Test script for OpenRouter LLM integration.
Tests the connection, API key, and LLM re-ranking flow.

Usage:
    # Set your API key
    export OPENROUTER_API_KEY="sk-or-v1-..."
    
    # Test basic connectivity
    python test_openrouter.py
    
    # Test with a specific model
    export LLM_MODEL="openai/gpt-4o"
    python test_openrouter.py
    
    # Test full pipeline with sample documents
    python test_openrouter.py --full-test
"""

import os
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))


def test_api_connection():
    """Test 1: Basic API connectivity."""
    print("\n" + "=" * 60)
    print("TEST 1: API Connection")
    print("=" * 60)
    
    api_key = "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"
    if not api_key:
        print("ERROR: OPENROUTER_API_KEY environment variable not set!")
        print("\nSet it with:")
        print('  export OPENROUTER_API_KEY="sk-or-v1-..."')
        print("\nGet your key at: https://openrouter.ai/keys")
        return False
    
    print(f"API Key found: {api_key[:15]}...")
    
    try:
        import openai
        
        client = openai.OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
        )
        
        print("\nSending test request to OpenRouter...")
        response = client.chat.completions.create(
            model="openai/gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": "Say 'OpenRouter connection successful!' and nothing else."}
            ],
            max_tokens=20,
        )
        
        reply = response.choices[0].message.content
        print(f"Response: {reply}")
        print("\nConnection test: PASSED")
        return True
        
    except Exception as e:
        print(f"\nConnection test: FAILED")
        print(f"Error: {e}")
        return False


def test_available_models():
    """Test 2: List available models."""
    print("\n" + "=" * 60)
    print("TEST 2: Available Models")
    print("=" * 60)
    
    api_key = "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"
    if not api_key:
        print("SKIP: No API key set")
        return
    
    try:
        import openai
        
        client = openai.OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
        )
        
        # Try to get available models
        print("\nFetching available models from OpenRouter...")
        models = client.models.list()
        
        # Filter for common models
        popular_models = [
            "openai/gpt-3.5-turbo",
            "openai/gpt-4o",
            "openai/gpt-4o-mini",
            "anthropic/claude-3.5-sonnet",
            "anthropic/claude-3-haiku",
            "google/gemini-flash-1.5",
            "meta-llama/llama-3.1-70b-instruct",
        ]
        
        print("\nPopular models available:")
        available_ids = [m.id for m in models.data]
        
        for model_id in popular_models:
            status = "Available" if model_id in available_ids else "Not found"
            print(f"  {'[x]' if model_id in available_ids else '[ ]'} {model_id} - {status}")
        
        print(f"\nTotal models available: {len(models.data)}")
        
    except Exception as e:
        print(f"Could not fetch model list: {e}")
        print("\nYou can check available models at: https://openrouter.ai/models")


def test_llm_config():
    """Test 3: LLM configuration loading."""
    print("\n" + "=" * 60)
    print("TEST 3: Configuration Loading")
    print("=" * 60)
    
    from template_matcher.config import get_config
    
    config = get_config()
    llm_config = config.llm
    
    print(f"Provider:        {llm_config.provider}")
    print(f"Model:           {llm_config.model}")
    print(f"API Key:         {'Set' if llm_config.api_key else 'Not set'}")
    print(f"API Base:        {llm_config.get_api_base()}")
    print(f"Re-ranking:      {'Enabled' if llm_config.enable_reranking else 'Disabled'}")
    print(f"Explanation:     {'Enabled' if llm_config.enable_explanation else 'Disabled'}")
    print(f"Temperature:     {llm_config.temperature}")
    print(f"Max Tokens:      {llm_config.max_tokens}")
    
    if llm_config.provider == "openrouter":
        print(f"Site URL:        {llm_config.openrouter_site_url or '(not set)'}")
        print(f"Site Name:       {llm_config.openrouter_site_name}")


def test_llm_reranker():
    """Test 4: LLM Re-ranker initialization."""
    print("\n" + "=" * 60)
    print("TEST 4: LLM Re-ranker")
    print("=" * 60)
    
    from template_matcher.llm_reranker import LLMReranker
    
    try:
        reranker = LLMReranker()
        
        if reranker.config.enable_reranking:
            print("Re-ranker initialized successfully!")
            print(f"  Client ready:  Yes")
            print(f"  Provider:      {reranker.config.provider}")
            print(f"  Model:         {reranker.config.model}")
        else:
            print("Re-ranking is disabled (API key may be missing)")
            
    except Exception as e:
        print(f"Failed to initialize re-ranker: {e}")


def test_full_pipeline():
    """Test 5: Full pipeline with a single document match."""
    print("\n" + "=" * 60)
    print("TEST 5: Full Pipeline Test")
    print("=" * 60)
    
    from template_matcher.matcher_pipeline import TemplateMatchingPipeline, PipelineConfig
    
    base_dir = Path(__file__).parent / "sample_data"
    templates_dir = base_dir / "Templates"
    test_doc = base_dir / "Folder_A" / "Weekly_Report_May.docx"
    
    if not templates_dir.exists():
        print(f"ERROR: Templates directory not found: {templates_dir}")
        return False
    
    if not test_doc.exists():
        print(f"ERROR: Test document not found: {test_doc}")
        return False
    
    print(f"Templates dir: {templates_dir}")
    print(f"Test document: {test_doc}")
    
    # Initialize pipeline
    pipeline_config = PipelineConfig(
        use_llm_reranking=True,
        output_dir="./output",
    )
    
    print("\nInitializing pipeline...")
    pipeline = TemplateMatchingPipeline(pipeline_config=pipeline_config)
    
    # Index templates
    print("Indexing templates...")
    stats = pipeline.index_templates(str(templates_dir), progress=False)
    print(f"Indexed {stats['templates_indexed']} templates")
    
    # Match document
    print(f"\nMatching: {test_doc.name}")
    print("This may take 10-30 seconds for the first run (model downloading)...")
    print("-" * 40)
    
    try:
        result = pipeline.match_document(str(test_doc))
        
        print(f"\nResult:")
        print(f"  Input File:      {result.input_file}")
        print(f"  Matched Template: {result.matched_template}")
        print(f"  Similarity Score: {result.similarity_score:.2%}")
        print(f"  Confidence:       {result.confidence}")
        print(f"  Reason:           {result.reason}")
        
        if result.llm_explanation:
            print(f"\n  LLM Explanation:  Available")
        else:
            print(f"\n  LLM Explanation:  Not generated (LLM may be disabled)")
        
        if result.alternatives:
            print(f"\n  Alternatives:")
            for alt in result.alternatives:
                print(f"    - {alt['template']}: {alt['score']:.2%}")
        
        return True
        
    except Exception as e:
        print(f"\nPipeline test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    parser = argparse.ArgumentParser(description="Test OpenRouter LLM Integration")
    parser.add_argument(
        "--full-test",
        action="store_true",
        help="Run full pipeline test with sample documents (requires embeddings download)",
    )
    parser.add_argument(
        "--skip-connection",
        action="store_true",
        help="Skip API connection test",
    )
    args = parser.parse_args()
    
    print("=" * 60)
    print("OpenRouter LLM Integration Test Suite")
    print("=" * 60)
    
    # Test 1: API Connection
    if not args.skip_connection:
        if not test_api_connection():
            print("\nAPI connection failed. Please check your API key.")
            print("\nTo set your OpenRouter API key:")
            print('  export OPENROUTER_API_KEY="sk-or-v1-xxxxxxxx"')
            return
    else:
        print("\n[Skipping connection test]")
    
    # Test 2: Available Models
    test_available_models()
    
    # Test 3: Configuration
    test_llm_config()
    
    # Test 4: LLM Re-ranker
    test_llm_reranker()
    
    # Test 5: Full Pipeline
    if args.full_test:
        test_full_pipeline()
    else:
        print("\n[Skipping full pipeline test. Use --full-test to run it.]")
    
    print("\n" + "=" * 60)
    print("Test suite completed!")
    print("=" * 60)
    
    print("\nNext steps:")
    print("  1. Run the full matching: python run_matching.py -t ./sample_data/Templates -d ./sample_data/Folder_A")
    print("  2. Browse models: https://openrouter.ai/models")
    print("  3. Change model: export LLM_MODEL='openai/gpt-4o'")


if __name__ == "__main__":
    main()