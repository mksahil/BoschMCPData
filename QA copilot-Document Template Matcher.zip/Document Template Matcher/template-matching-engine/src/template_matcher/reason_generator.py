"""
Evidence-Based Match Reason Generator
=====================================
Produces human-readable match explanations grounded in actual document content.

Key improvements:
* Every reason is backed by specific extracted headings, sections, or snippets.
* Highlights matching sections with confidence scores per reason.
* No hallucinated or generic explanations.
* Falls back to structured evidence summaries when LLM is unavailable.
"""

import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field

from template_matcher.config import get_config
from template_matcher.similarity_scorer import SimilarityScore, ScoreEvidence


logger = logging.getLogger(__name__)


@dataclass
class ReasonFragment:
    """A single evidence-backed statement about the match."""
    statement: str
    evidence_type: str               # "heading" | "section" | "table" | "content" | "layout" | "score"
    evidence: Optional[Dict[str, Any]] = None
    confidence: float = 0.0          # 0.0 – 1.0


@dataclass
class MatchExplanation:
    """Complete structured explanation of a template match."""
    summary: str                     # 1-2 sentence human-readable summary
    fragments: List[ReasonFragment] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "summary": self.summary,
            "fragments": [
                {
                    "statement": f.statement,
                    "evidence_type": f.evidence_type,
                    "evidence": f.evidence,
                    "confidence": round(f.confidence, 4),
                }
                for f in self.fragments
            ],
            "warnings": self.warnings,
        }


class ReasonGenerator:
    """
    Generates evidence-based match reasons from similarity scores and
    extracted document evidence.  No LLM required — all reasons are
    derived from concrete extracted features.
    """

    def __init__(self):
        self.config = get_config().scoring

    # ── public API ──────────────────────────────────────────────────────────

    def generate_reason(
        self,
        query_doc: Any,
        matched_template: Any,
        score: SimilarityScore,
    ) -> MatchExplanation:
        """
        Build a grounded explanation from evidence attached to the score.

        Parameters
        ----------
        query_doc : DocumentFeatures
        matched_template : DocumentFeatures
        score : SimilarityScore (must contain .evidence)

        Returns
        -------
        MatchExplanation with summary + evidence-backed fragments.
        """
        fragments: List[ReasonFragment] = []
        warnings: List[str] = []

        ev = score.evidence or ScoreEvidence()

        # ── Heading evidence ────────────────────────────────────────────────
        heading_frags = self._reason_from_headings(
            ev.matched_headings, score.heading_score
        )
        fragments.extend(heading_frags)

        # ── Content / section evidence ──────────────────────────────────────
        content_frags = self._reason_from_content(
            ev.content_snippets, score.content_score
        )
        fragments.extend(content_frags)

        # ── Table evidence ──────────────────────────────────────────────────
        table_frags = self._reason_from_tables(
            ev.matched_tables, score.table_score
        )
        fragments.extend(table_frags)

        # ── Score-level meta-reasons ────────────────────────────────────────
        meta_frags = self._reason_from_scores(score)
        fragments.extend(meta_frags)

        # ── Warnings for suspicious matches ─────────────────────────────────
        if score.is_low_content:
            warnings.append(
                "The input document contains very little content; "
                "similarity scores may not be reliable."
            )
        if score.is_template_only:
            warnings.append(
                "The input document appears to be a blank template "
                "(contains mostly placeholders)."
            )
        if score.confidence in ("Low", "Very Low") and score.total_score > 0.5:
            warnings.append(
                "Score is moderate but confidence is low — internal metrics "
                "disagree; manual review recommended."
            )

        # ── Compose summary sentence ────────────────────────────────────────
        summary = self._compose_summary(
            query_name=getattr(query_doc, "file_name", "Query"),
            template_name=getattr(matched_template, "file_name", "Template"),
            score=score,
            top_fragments=fragments,
        )

        explanation = MatchExplanation(
            summary=summary,
            fragments=fragments,
            warnings=warnings,
        )

        logger.debug(
            "ReasonGenerator produced %d fragments, %d warnings",
            len(fragments), len(warnings),
        )
        return explanation

    # ── fragment builders ───────────────────────────────────────────────────

    def _reason_from_headings(
        self, evidence_list: List[Dict[str, Any]], heading_score: float
    ) -> List[ReasonFragment]:
        """Build reason fragments from heading match evidence."""
        frags = []
        if not evidence_list:
            if heading_score > 0.3:
                frags.append(ReasonFragment(
                    statement="Documents share a similar heading hierarchy structure.",
                    evidence_type="heading",
                    confidence=heading_score,
                ))
            return frags

        exact = [e for e in evidence_list if e.get("match_type") == "exact"]
        fuzzy = [e for e in evidence_list if e.get("match_type") == "fuzzy"]

        if len(exact) >= 2:
            names = [f"'{e['query_heading']}'" for e in exact[:5]]
            frags.append(ReasonFragment(
                statement=(
                    f"Both documents contain identical sections for "
                    f"{', '.join(names)}."
                ),
                evidence_type="heading",
                evidence={"exact_matches": exact[:5]},
                confidence=0.9,
            ))
        elif len(exact) == 1:
            frags.append(ReasonFragment(
                statement=(
                    f"Both documents share the section "
                    f"'{exact[0]['query_heading']}'."
                ),
                evidence_type="heading",
                evidence=exact[0],
                confidence=0.85,
            ))

        if fuzzy:
            names = [f"' {e['query_heading']}'" for e in fuzzy[:3]]
            frags.append(ReasonFragment(
                statement=(
                    f"Similar section names found: "
                    f"{', '.join(names)}."
                ),
                evidence_type="heading",
                evidence={"fuzzy_matches": fuzzy[:3]},
                confidence=0.6,
            ))

        return frags

    def _reason_from_content(
        self, snippets: List[Dict[str, Any]], content_score: float
    ) -> List[ReasonFragment]:
        """Build reason fragments from content match evidence."""
        frags = []
        if not snippets:
            if content_score > 0.5:
                frags.append(ReasonFragment(
                    statement="Semantic content overlap detected between documents.",
                    evidence_type="content",
                    confidence=content_score,
                ))
            return frags

        for snip in snippets:
            snip_type = snip.get("type", "")
            if snip_type == "identical_heading":
                frags.append(ReasonFragment(
                    statement=(
                        f"Identical heading found: '{snip.get('query')}'."
                    ),
                    evidence_type="content",
                    evidence=snip,
                    confidence=snip.get("confidence", 1.0),
                ))
            elif snip_type == "similar_heading":
                frags.append(ReasonFragment(
                    statement=(
                        f"Similar heading: '{snip.get('query')}' ≈ "
                        f"'{snip.get('template')}'."
                    ),
                    evidence_type="content",
                    evidence=snip,
                    confidence=snip.get("confidence", 0.7),
                ))
            elif snip_type == "chunk_coverage":
                frags.append(ReasonFragment(
                    statement=snip.get("description", ""),
                    evidence_type="content",
                    evidence=snip,
                    confidence=snip.get("confidence", 0.5),
                ))

        return frags

    def _reason_from_tables(
        self, evidence_list: List[Dict[str, Any]], table_score: float
    ) -> List[ReasonFragment]:
        """Build reason fragments from table match evidence."""
        frags = []
        if not evidence_list:
            if table_score > 0.3:
                frags.append(ReasonFragment(
                    statement="Documents contain similar table structures.",
                    evidence_type="table",
                    confidence=table_score,
                ))
            return frags

        for ev in evidence_list:
            match_type = ev.get("match_type", "")
            if match_type == "identical_dimensions":
                frags.append(ReasonFragment(
                    statement=(
                        f"Matching table with identical dimensions "
                        f"{ev.get('query_shape', '')}."
                    ),
                    evidence_type="table",
                    evidence=ev,
                    confidence=0.85,
                ))
            elif match_type == "similar_dimensions":
                frags.append(ReasonFragment(
                    statement=(
                        f"Similar table structure "
                        f"({ev.get('query_shape', '')} vs "
                        f"{ev.get('template_shape', '')})."
                    ),
                    evidence_type="table",
                    evidence=ev,
                    confidence=0.6,
                ))

        return frags

    def _reason_from_scores(self, score: SimilarityScore) -> List[ReasonFragment]:
        """Build fragments directly from score components."""
        frags = []

        if score.structure_score > 0.7:
            frags.append(ReasonFragment(
                statement="Document organization patterns are strongly aligned.",
                evidence_type="score",
                confidence=score.structure_score,
            ))
        elif score.structure_score > 0.4:
            frags.append(ReasonFragment(
                statement="Similar document organization patterns detected.",
                evidence_type="score",
                confidence=score.structure_score,
            ))

        if score.layout_score > 0.7:
            frags.append(ReasonFragment(
                statement="Formatting and visual presentation are closely matched.",
                evidence_type="score",
                confidence=score.layout_score,
            ))
        elif score.layout_score > 0.4:
            frags.append(ReasonFragment(
                statement="Similar formatting and layout characteristics.",
                evidence_type="score",
                confidence=score.layout_score,
            ))

        return frags

    # ── summary composer ────────────────────────────────────────────────────

    def _compose_summary(
        self,
        query_name: str,
        template_name: str,
        score: SimilarityScore,
        top_fragments: List[ReasonFragment],
    ) -> str:
        """Compose a concise 1-3 sentence summary."""
        parts = []
        score_pct = score.total_score * 100

        # Build from strongest evidence
        if top_fragments:
            # Pick the 2-3 highest-confidence fragments
            sorted_frags = sorted(top_fragments, key=lambda f: f.confidence, reverse=True)
            selected = sorted_frags[:3]

            statements = [f.statement for f in selected if f.confidence > 0.3]
            if statements:
                reason_text = " ".join(statements)
                parts.append(
                    f"'{query_name}' matches '{template_name}' "
                    f"({score_pct:.0f}% similarity). {reason_text}"
                )
            else:
                parts.append(
                    f"'{query_name}' shows {score_pct:.0f}% similarity to "
                    f"'{template_name}' based on overall document analysis."
                )
        else:
            parts.append(
                f"'{query_name}' shows {score_pct:.0f}% similarity to "
                f"'{template_name}'."
            )

        # Add confidence qualifier
        if score.confidence == "Low":
            parts.append("Confidence is low — review recommended.")
        elif score.confidence == "Very Low":
            parts.append("Match is uncertain — manual verification strongly recommended.")

        return " ".join(parts)

    # ── convenience: flat string ────────────────────────────────────────────

    def generate_reason_string(
        self,
        query_doc: Any,
        matched_template: Any,
        score: SimilarityScore,
    ) -> str:
        """Return a single human-readable string (legacy API compatibility)."""
        explanation = self.generate_reason(query_doc, matched_template, score)
        return explanation.summary