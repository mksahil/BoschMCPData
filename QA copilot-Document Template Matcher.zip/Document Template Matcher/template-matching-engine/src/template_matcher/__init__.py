"""
Template Matching Engine
A production-ready GenAI document template matching system.
"""

__version__ = "1.0.0"

from template_matcher.config import AppConfig, get_config
from template_matcher.document_parser import DocumentParser, DocumentFeatures
from template_matcher.feature_extractor import FeatureExtractor, ExtractedFeatures
from template_matcher.embeddings import EmbeddingGenerator, EmbeddingAggregator
from template_matcher.vector_store import VectorStore, MultiIndexVectorStore
from template_matcher.similarity_scorer import SimilarityScorer, SimilarityScore
from template_matcher.llm_reranker import LLMReranker, MatchResult
from template_matcher.matcher_pipeline import TemplateMatchingPipeline, PipelineConfig

__all__ = [
    "AppConfig",
    "get_config",
    "DocumentParser",
    "DocumentFeatures",
    "FeatureExtractor",
    "ExtractedFeatures",
    "EmbeddingGenerator",
    "EmbeddingAggregator",
    "VectorStore",
    "MultiIndexVectorStore",
    "SimilarityScorer",
    "SimilarityScore",
    "LLMReranker",
    "MatchResult",
    "TemplateMatchingPipeline",
    "PipelineConfig",
]
