"""
Template Matching Pipeline v2
=============================
Orchestrates the end-to-end document template matching process with:
* SimilarityScorerV2 (accuracy-improved, calibrated)
* Evidence-based ReasonGenerator (no hallucinated reasons)
* Excel / CSV file support
* Structured pipeline logging with correlation IDs and timing
* Content-quality validation at every stage
"""

import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field

import numpy as np
from tqdm import tqdm

# Config (v2)
from template_matcher.config import get_config, AppConfig

# Components
from template_matcher.document_parser import DocumentParser, DocumentFeatures
from template_matcher.excel_parser import ExcelParser
from template_matcher.feature_extractor import FeatureExtractor, ExtractedFeatures
from template_matcher.embeddings import EmbeddingGenerator, EmbeddingAggregator
from template_matcher.vector_store import VectorStore, MultiIndexVectorStore

# v2 improvements
from template_matcher.similarity_scorer import SimilarityScorer, SimilarityScore
from template_matcher.reason_generator import ReasonGenerator, MatchExplanation
from template_matcher.pipeline_logger import (
    setup_logging, set_correlation_id,
    get_parser_logger, get_feature_logger, get_embedding_logger,
    get_vector_logger, get_scorer_logger, get_reranker_logger,
    get_pipeline_logger, get_pipeline_trace,
)
from template_matcher.llm_reranker import LLMReranker, MatchResult


logger = get_pipeline_logger()


@dataclass
class PipelineConfig:
    """Pipeline execution configuration."""
    use_vector_search: bool = True
    use_llm_reranking: bool = True
    use_evidence_reasons: bool = True
    top_k_vector: int = 10
    top_k_candidates: int = 5
    save_results: bool = True
    output_dir: str = "./output"


@dataclass
class PipelineResult:
    """Extended match result with evidence and trace."""
    input_file: str
    matched_template: str
    similarity_score: float
    confidence: str
    reason: str
    explanation: Optional[MatchExplanation] = None
    content_score: float = 0.0
    structure_score: float = 0.0
    heading_score: float = 0.0
    layout_score: float = 0.0
    table_score: float = 0.0
    llm_explanation: Optional[str] = None
    alternatives: List[Dict[str, Any]] = field(default_factory=list)
    is_low_content: bool = False
    is_template_only: bool = False
    content_quality_penalty: float = 0.0
    pipeline_trace: List[Dict[str, Any]] = field(default_factory=list)
    scoring_time_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "input_file": self.input_file,
            "matched_template": self.matched_template,
            "similarity_score": round(self.similarity_score, 4),
            "confidence": self.confidence,
            "reason": self.reason,
            "explanation": self.explanation.to_dict() if self.explanation else None,
            "detailed_scores": {
                "content": round(self.content_score, 4),
                "structure": round(self.structure_score, 4),
                "heading": round(self.heading_score, 4),
                "layout": round(self.layout_score, 4),
                "table": round(self.table_score, 4),
            },
            "content_quality": {
                "is_low_content": self.is_low_content,
                "is_template_only": self.is_template_only,
                "penalty_applied": round(self.content_quality_penalty, 4),
            },
            "llm_explanation": self.llm_explanation,
            "alternatives": self.alternatives,
            "pipeline_trace": self.pipeline_trace,
            "scoring_time_ms": round(self.scoring_time_ms, 2),
        }


class TemplateMatchingPipeline:
    """
    End-to-end template matching pipeline with v2 improvements.

    Usage
    -----
        pipeline = TemplateMatchingPipelineV2()
        pipeline.index_templates("./Templates")
        results = pipeline.match_documents("./Folder_A")
        pipeline.save_results(results, "./output")
    """

    def __init__(
        self,
        config: Optional[AppConfig] = None,
        pipeline_config: Optional[PipelineConfig] = None,
    ):
        self.config = config or get_config()
        self.pipeline_config = pipeline_config or PipelineConfig()

        # Initialize structured logging
        setup_logging(
            level=self.config.logging.log_level,
            json_mode=self.config.logging.json_mode,
            log_file=self.config.logging.log_file,
        )

        # Initialize components
        self.document_parser = DocumentParser()
        self.excel_parser = ExcelParser()
        self.feature_extractor = FeatureExtractor()
        self.embedding_generator = EmbeddingGenerator()
        self.embedding_aggregator = EmbeddingAggregator()
        self.vector_store = MultiIndexVectorStore()
        self.similarity_scorer = SimilarityScorer()
        self.reason_generator = ReasonGenerator()
        self.llm_reranker = LLMReranker()

        # Storage
        self.templates: Dict[str, DocumentFeatures] = {}
        self.template_features: Dict[str, ExtractedFeatures] = {}
        self.template_embeddings: Dict[str, Dict[str, np.ndarray]] = {}
        self.template_aggregated: Dict[str, np.ndarray] = {}

        logger.info("TemplateMatchingPipeline initialized")

    # ── Template indexing ───────────────────────────────────────────────────

    def index_templates(self, templates_dir: str, progress: bool = True) -> Dict[str, Any]:
        """Index all template documents from a directory (DOCX, PDF, Excel, CSV)."""
        templates_path = Path(templates_dir)
        if not templates_path.exists():
            raise FileNotFoundError(f"Templates directory not found: {templates_dir}")

        set_correlation_id()
        with logger.timed_step("index_templates"):
            logger.info(f"Indexing templates from {templates_dir}")

            # Find all supported files
            template_files = []
            for ext in self.config.document.supported_extensions:
                template_files.extend(templates_path.glob(f"*{ext}"))

            if not template_files:
                raise ValueError(f"No template documents found in {templates_dir}")

            logger.info(f"Found {len(template_files)} template files")

            # Parse → Extract → Embed → Index
            self._parse_and_index_files(template_files, is_template=True, progress=progress)

            stats = {
                "templates_indexed": len(self.templates),
                "templates": list(self.templates.keys()),
            }
            logger.info(f"Indexed {stats['templates_indexed']} templates")
            return stats

    # ── Document matching ───────────────────────────────────────────────────

    def match_document(self, document_path: str, top_k: Optional[int] = None) -> PipelineResult:
        """Match a single document against indexed templates."""
        top_k = top_k or self.pipeline_config.top_k_candidates
        set_correlation_id()
        t_start = time.perf_counter()

        with logger.timed_step("match_document"):
            # 1. Parse
            with get_parser_logger().timed_step("parse"):
                query_features = self._parse_file(document_path)
                logger.info(
                    "Parsed  %s  →  type=%s  chars=%d  headings=%d  tables=%d",
                    query_features.file_name,
                    query_features.file_type,
                    len(query_features.full_text),
                    len(query_features.headings),
                    query_features.table_count,
                )

            # 2. Feature extraction
            with get_feature_logger().timed_step("extract"):
                query_extracted = self.feature_extractor.extract(query_features)
                logger.info(
                    "Extracted features  →  content_chunks=%d  headings=%d  tables=%d",
                    len(query_extracted.content_features),
                    len(query_extracted.heading_features),
                    len(query_extracted.table_features),
                )

            # 3. Embedding generation
            with get_embedding_logger().timed_step("embed"):
                query_embeddings = self.embedding_generator.generate_for_document(query_extracted)
                query_aggregated = self.embedding_aggregator.aggregate(query_embeddings)
                emb_dims = {k: v.shape for k, v in query_embeddings.items()}
                logger.info(f"Generated embeddings  →  {emb_dims}")

            # 4. Candidate retrieval
            if self.pipeline_config.use_vector_search:
                with get_vector_logger().timed_step("vector_search"):
                    candidates = self._vector_search_candidates(query_embeddings, top_k * 2)
                    logger.info(f"Vector search returned {len(candidates)} candidates")
            else:
                candidates = list(self.template_embeddings.keys())

            # 5. Similarity scoring (v2)
            with get_scorer_logger().timed_step("score"):
                scored = self._score_candidates_v2(
                    query_embeddings, query_features, candidates, top_k
                )
                logger.info(f"Scored {len(scored)} candidates")

            # 6. Build result
            top_name, top_features, top_score = scored[0] if scored else (
                "No match", None, SimilarityScore(total_score=0.0)
            )

            # 7. Evidence-based reason generation
            if self.pipeline_config.use_evidence_reasons and top_features is not None:
                explanation = self.reason_generator.generate_reason(
                    query_features, top_features, top_score
                )
                reason_text = explanation.summary
            else:
                explanation = None
                reason_text = self._fallback_reason(top_score)

            # 8. LLM re-ranking (optional)
            if (self.pipeline_config.use_llm_reranking
                    and self.config.llm.enable_reranking):
                with get_reranker_logger().timed_step("llm_rerank"):
                    llm_result = self.llm_reranker.rerank(query_features, scored)
                    # Override with LLM result if it changed the match
                    if llm_result.matched_template != top_name:
                        top_name = llm_result.matched_template
                        reason_text = llm_result.reason
                    llm_explanation = llm_result.llm_explanation
            else:
                llm_explanation = None

            elapsed_ms = (time.perf_counter() - t_start) * 1000

            # Build alternatives
            alternatives = []
            for name, features, score in scored[1:3]:
                alternatives.append({
                    "template": name,
                    "score": round(score.total_score, 4),
                    "confidence": score.confidence,
                })

            result = PipelineResult(
                input_file=query_features.file_name,
                matched_template=top_name,
                similarity_score=top_score.total_score,
                confidence=top_score.confidence,
                reason=reason_text,
                explanation=explanation,
                content_score=top_score.content_score,
                structure_score=top_score.structure_score,
                heading_score=top_score.heading_score,
                layout_score=top_score.layout_score,
                table_score=top_score.table_score,
                llm_explanation=llm_explanation,
                alternatives=alternatives,
                is_low_content=top_score.is_low_content,
                is_template_only=top_score.is_template_only,
                content_quality_penalty=top_score.content_quality_penalty,
                pipeline_trace=get_pipeline_trace(),
                scoring_time_ms=elapsed_ms,
            )

            logger.info(
                "MATCH  %s  →  %s  (score=%.2f%%, confidence=%s, time=%.1fms)",
                result.input_file, result.matched_template,
                result.similarity_score * 100, result.confidence,
                elapsed_ms,
            )
            return result

    def match_documents(
        self, documents_dir: str, recursive: bool = True, progress: bool = True
    ) -> List[PipelineResult]:
        """Match all documents in a directory against indexed templates."""
        docs_path = Path(documents_dir)
        if not docs_path.exists():
            raise FileNotFoundError(f"Documents directory not found: {documents_dir}")

        with logger.timed_step("match_documents"):
            # Find all documents
            document_files = []
            pattern = "**/*" if recursive else "*"
            for ext in self.config.document.supported_extensions:
                document_files.extend(docs_path.glob(f"{pattern}{ext}"))

            # Filter out templates
            template_names = set(self.templates.keys())
            document_files = [f for f in document_files if f.name not in template_names]

            if not document_files:
                logger.warning(f"No documents found in {documents_dir}")
                return []

            logger.info(f"Found {len(document_files)} documents to match")

            results = []
            iterator = tqdm(document_files, desc="Matching documents") if progress else document_files

            for file_path in iterator:
                try:
                    result = self.match_document(str(file_path))
                    results.append(result)
                except Exception as e:
                    logger.error(f"Failed to match {file_path}: {e}")
                    results.append(PipelineResult(
                        input_file=file_path.name,
                        matched_template="ERROR",
                        similarity_score=0.0,
                        confidence="Error",
                        reason=f"Processing error: {type(e).__name__}: {e}",
                    ))

            logger.info(f"Matched {len(results)} documents")
            return results

    # ── internal helpers ────────────────────────────────────────────────────

    def _parse_file(self, file_path: str) -> DocumentFeatures:
        """Dispatch to the correct parser based on file extension."""
        path = Path(file_path)
        if self.excel_parser.supports(path):
            return self.excel_parser.parse(path)
        return self.document_parser.parse(path)

    def _parse_and_index_files(
        self,
        file_paths: List[Path],
        is_template: bool = True,
        progress: bool = True,
    ):
        """Parse, extract features, generate embeddings, and add to vector store."""
        iterator = tqdm(file_paths, desc="Processing files") if progress else file_paths

        for file_path in iterator:
            try:
                # Parse
                features = self._parse_file(str(file_path))
                doc_name = features.file_name
                self.templates[doc_name] = features

                # Extract features
                extracted = self.feature_extractor.extract(features)
                self.template_features[doc_name] = extracted

                # Generate embeddings
                embeddings = self.embedding_generator.generate_for_document(extracted)
                self.template_embeddings[doc_name] = embeddings

                # Aggregate
                aggregated = self.embedding_aggregator.aggregate(embeddings)
                self.template_aggregated[doc_name] = aggregated

                # Add to vector store
                self.vector_store.add_document(
                    doc_id=doc_name,
                    embeddings=embeddings,
                    metadata={
                        "file_name": doc_name,
                        "file_type": features.file_type,
                    },
                )

            except Exception as e:
                logger.error(f"Failed to process {file_path}: {e}")

    def _vector_search_candidates(
        self, query_embeddings: Dict[str, np.ndarray], top_k: int
    ) -> List[str]:
        """Find candidate templates using vector search."""
        results = self.vector_store.search(query_embeddings, k=top_k)
        candidates = []
        seen = set()
        for result in results:
            name = result["doc_id"]
            if name not in seen:
                candidates.append(name)
                seen.add(name)
        if len(candidates) < 3:
            candidates.extend([n for n in self.templates.keys() if n not in seen])
        return candidates

    def _score_candidates_v2(
        self,
        query_embeddings: Dict[str, np.ndarray],
        query_features: DocumentFeatures,
        candidate_names: List[str],
        top_k: int,
    ) -> List[Tuple[str, DocumentFeatures, SimilarityScore]]:
        """Score candidates using SimilarityScorerV2 with evidence collection."""
        scored = []
        for name in candidate_names:
            if name not in self.template_embeddings:
                continue
            template_emb = self.template_embeddings[name]
            template_features = self.templates[name]

            score = self.similarity_scorer.compute_similarity(
                query_embeddings, template_emb,
                query_features=query_features,
                template_features=template_features,
            )
            scored.append((name, template_features, score))

        scored.sort(key=lambda x: x[2].total_score, reverse=True)
        return scored[:top_k]

    @staticmethod
    def _fallback_reason(score: SimilarityScore) -> str:
        """Generate a basic reason string when evidence generation is disabled."""
        reasons = []
        if score.content_score > 0.6:
            reasons.append("content similarity")
        if score.structure_score > 0.6:
            reasons.append("structural alignment")
        if score.heading_score > 0.6:
            reasons.append("heading hierarchy match")
        if score.layout_score > 0.6:
            reasons.append("layout similarity")
        if reasons:
            return f"Match based on {' and '.join(reasons)}."
        return f"Best match based on overall score of {score.total_score:.2%}."

    # ── Persistence ─────────────────────────────────────────────────────────

    def save_index(self, path: str):
        self.vector_store.save(path)
        logger.info(f"Index saved to {path}")

    def load_index(self, path: str):
        self.vector_store.load(path)
        logger.info(f"Index loaded from {path}")

    # ── Results output ──────────────────────────────────────────────────────

    def save_results(
        self,
        results: List[PipelineResult],
        output_dir: Optional[str] = None,
    ) -> Dict[str, str]:
        """Save matching results to JSON, CSV, and Markdown report."""
        output_dir = output_dir or self.pipeline_config.output_dir
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        output_files = {}

        # JSON
        json_path = output_path / "matching_results.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump([r.to_dict() for r in results], f, indent=2, ensure_ascii=False)
        output_files["json"] = str(json_path)

        # CSV
        csv_path = output_path / "matching_results.csv"
        import csv
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "Input File", "Matched Template", "Similarity Score",
                "Confidence", "Reason", "Content Quality",
                "Low Content", "Template Only", "Scoring Time (ms)",
            ])
            for r in results:
                writer.writerow([
                    r.input_file, r.matched_template, f"{r.similarity_score:.2%}",
                    r.confidence, r.reason,
                    "OK" if not (r.is_low_content or r.is_template_only) else "ISSUE",
                    r.is_low_content, r.is_template_only, round(r.scoring_time_ms, 1),
                ])
        output_files["csv"] = str(csv_path)

        # Markdown report
        report_path = output_path / "detailed_report.md"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Template Matching Results\n\n")
            f.write(f"Total documents processed: {len(results)}\n\n")

            for i, result in enumerate(results, 1):
                f.write(f"## {i}. {result.input_file}\n\n")
                f.write(f"**Matched Template:** {result.matched_template}\n\n")
                f.write(f"**Similarity Score:** {result.similarity_score:.2%}\n\n")
                f.write(f"**Confidence:** {result.confidence}\n\n")
                f.write(f"**Reason:** {result.reason}\n\n")

                if result.is_low_content or result.is_template_only:
                    f.write(
                        "> ⚠️ **Content Quality Warning:** "
                        f"{'Low content detected. ' if result.is_low_content else ''}"
                        f"{'Template-only document. ' if result.is_template_only else ''}"
                        f"Scores may not be reliable.\n\n"
                    )

                f.write("**Detailed Scores:**\n\n")
                f.write(f"- Content: {result.content_score:.4f}\n")
                f.write(f"- Structure: {result.structure_score:.4f}\n")
                f.write(f"- Heading: {result.heading_score:.4f}\n")
                f.write(f"- Layout: {result.layout_score:.4f}\n")
                f.write(f"- Table: {result.table_score:.4f}\n\n")

                if result.explanation and result.explanation.fragments:
                    f.write("**Evidence:**\n\n")
                    for frag in result.explanation.fragments:
                        conf = "✓" if frag.confidence > 0.7 else "~"
                        f.write(f"- {conf} {frag.statement}\n")
                    f.write("\n")

                if result.explanation and result.explanation.warnings:
                    f.write("**Warnings:**\n\n")
                    for w in result.explanation.warnings:
                        f.write(f"- ⚠️ {w}\n")
                    f.write("\n")

                if result.alternatives:
                    f.write("**Alternative Matches:**\n\n")
                    for alt in result.alternatives:
                        f.write(f"- {alt['template']}: {alt['score']:.4f} ({alt['confidence']})\n")
                    f.write("\n")

                f.write(f"**Pipeline Time:** {result.scoring_time_ms:.1f}ms\n\n")
                f.write("---\n\n")

        output_files["report"] = str(report_path)
        logger.info(f"Results saved to {output_dir}")
        return output_files

    def get_stats(self) -> Dict[str, Any]:
        return {
            "templates_indexed": len(self.templates),
            "template_names": list(self.templates.keys()),
            "vector_store_stats": self.vector_store.get_stats(),
        }