"""
Structured Pipeline Logger
==========================
Provides detailed, request-correlated, level-aware logging for every
stage of the document-matching pipeline.

Features:
* Correlation / request IDs for end-to-end tracking
* Structured JSON logs with consistent schema
* Per-stage execution timing
* Automatic log-level filtering (no noisy debug in production)
* Context managers for timing code blocks
* Execution trace collection for pipeline visibility
"""

import time
import uuid
import logging
import functools
from typing import Dict, List, Optional, Any, Callable
from contextvars import ContextVar
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict


# ── Context variable for correlation tracking ────────────────────────────────
_correlation_id: ContextVar[str] = ContextVar("correlation_id", default="")
_pipeline_trace: ContextVar[List[Dict[str, Any]]] = ContextVar("pipeline_trace")


# ─── Log level colour helpers (for console) ─────────────────────────────────
_LEVEL_STYLES = {
    "DEBUG": "\033[36m",      # cyan
    "INFO": "\033[32m",       # green
    "WARNING": "\033[33m",    # yellow
    "ERROR": "\033[31m",      # red
    "CRITICAL": "\033[35m",   # magenta
    "RESET": "\033[0m",
}


class StructuredFormatter(logging.Formatter):
    """
    Formatter that outputs either:
    * structured JSON (when json_mode=True)
    * colourised console lines (default)
    """

    def __init__(
        self,
        json_mode: bool = False,
        include_correlation: bool = True,
    ):
        super().__init__()
        self.json_mode = json_mode
        self.include_correlation = include_correlation

    def format(self, record: logging.LogRecord) -> str:
        corr = _correlation_id.get() if self.include_correlation else ""

        if self.json_mode:
            import json
            log_entry = {
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "correlation_id": corr,
            }
            if hasattr(record, "stage"):
                log_entry["stage"] = record.stage
            if hasattr(record, "timing_ms"):
                log_entry["timing_ms"] = record.timing_ms
            if hasattr(record, "extra"):
                log_entry.update(record.extra)
            return json.dumps(log_entry, default=str)

        # Console format
        colour = _LEVEL_STYLES.get(record.levelname, "")
        reset = _LEVEL_STYLES["RESET"]
        corr_str = f" [{corr[:8]}]" if corr else ""
        msg = record.getMessage()

        # Timing info
        timing = ""
        if hasattr(record, "timing_ms"):
            timing = f"  ({record.timing_ms:.1f}ms)"

        # Stage tag
        stage = ""
        if hasattr(record, "stage"):
            stage = f" [{record.stage}]"

        return (
            f"{colour}{record.levelname:>8}{reset}"
            f"{corr_str}{stage}  {msg}{timing}"
        )


def setup_logging(
    level: str = "INFO",
    json_mode: bool = False,
    log_file: Optional[str] = None,
) -> logging.Logger:
    """
    Configure root logging for the pipeline.

    Parameters
    ----------
    level : str
        One of DEBUG, INFO, WARNING, ERROR.
    json_mode : bool
        Output structured JSON instead of colourised text.
    log_file : str | None
        If given, also write logs to this file.

    Returns
    -------
    Logger
    """
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Clear existing handlers (idempotent re-configuration)
    root.handlers.clear()

    formatter = StructuredFormatter(json_mode=json_mode)

    # Console handler
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    # File handler
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(StructuredFormatter(json_mode=True))
        root.addHandler(file_handler)

    return root


# ── correlation ID helpers ──────────────────────────────────────────────────

def get_correlation_id() -> str:
    return _correlation_id.get() or "no-corr"


def set_correlation_id(cid: Optional[str] = None) -> str:
    cid = cid or str(uuid.uuid4())[:12]
    _correlation_id.set(cid)
    _pipeline_trace.set([])
    return cid


# ── execution trace ─────────────────────────────────────────────────────────

def get_pipeline_trace() -> List[Dict[str, Any]]:
    return list(_pipeline_trace.get())


def _append_trace(entry: Dict[str, Any]):
    trace = _pipeline_trace.get()
    trace.append(entry)
    _pipeline_trace.set(trace)


# ── stage logger class ──────────────────────────────────────────────────────

class StageLogger:
    """
    Per-stage logger that automatically injects:
    * correlation ID
    * stage name
    * timing information
    * structured extra fields
    """

    def __init__(self, stage_name: str, parent_logger_name: str = "template_matcher"):
        self.stage = stage_name
        self.logger = logging.getLogger(f"{parent_logger_name}.{stage_name}")

    # ── helpers ───────────────────────────────────────────────────────────

    def _log(
        self,
        level_fn: Callable,
        msg: str,
        timing_ms: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ):
        extra_attrs = {"stage": self.stage}
        if timing_ms is not None:
            extra_attrs["timing_ms"] = timing_ms
        if extra:
            extra_attrs["extra"] = extra
        level_fn(msg, extra=extra_attrs)

    # ── level-specific methods ────────────────────────────────────────────

    def debug(self, msg: str, *args, **kwargs):
        if args:
            msg = msg % args
        self._log(self.logger.debug, msg, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        if args:
           msg = msg % args
        self._log(self.logger.info, msg, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        if args:
            msg = msg % args
        self._log(self.logger.warning, msg, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        if args:
            msg = msg % args
        self._log(self.logger.error, msg, **kwargs)

    # ── timed context manager ─────────────────────────────────────────────

    @contextmanager
    def timed_step(self, step_name: str):
        """Context manager that logs timing for a pipeline step."""
        t0 = time.perf_counter()
        cid = get_correlation_id()
        self.info(f"▶ START  {step_name}")
        try:
            yield self
        except Exception as exc:
            elapsed = (time.perf_counter() - t0) * 1000
            self.error(
                f"✗ FAILED {step_name}: {type(exc).__name__}: {exc}",
                timing_ms=elapsed,
            )
            _append_trace({
                "stage": self.stage,
                "step": step_name,
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
                "timing_ms": round(elapsed, 2),
                "correlation_id": cid,
            })
            raise
        else:
            elapsed = (time.perf_counter() - t0) * 1000
            self.info(f"✓ DONE   {step_name}", timing_ms=elapsed)
            _append_trace({
                "stage": self.stage,
                "step": step_name,
                "status": "success",
                "timing_ms": round(elapsed, 2),
                "correlation_id": cid,
            })


# ── decorator for automatic timing ──────────────────────────────────────────

def timed(stage_name: str):
    """Decorator that times a function and logs via StageLogger."""
    def decorator(fn: Callable):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            logger = StageLogger(stage_name)
            with logger.timed_step(fn.__name__):
                return fn(*args, **kwargs)
        return wrapper
    return decorator


# ── convenience: per-stage logger factories ─────────────────────────────────

def get_parser_logger() -> StageLogger:
    return StageLogger("DOCUMENT_PARSER")


def get_feature_logger() -> StageLogger:
    return StageLogger("FEATURE_EXTRACTOR")


def get_embedding_logger() -> StageLogger:
    return StageLogger("EMBEDDING")


def get_vector_logger() -> StageLogger:
    return StageLogger("VECTOR_STORE")


def get_scorer_logger() -> StageLogger:
    return StageLogger("SIMILARITY_SCORER")


def get_reranker_logger() -> StageLogger:
    return StageLogger("LLM_RERANKER")


def get_pipeline_logger() -> StageLogger:
    return StageLogger("MATCHER_PIPELINE")