"""
LLM Re-ranking and Explainability Module
Uses LLM to re-rank candidates and generate human-readable explanations.
Provides final matching decision with reasoning.
"""

import json
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field

import openai
from tenacity import retry, stop_after_attempt, wait_exponential

from template_matcher.config import get_config, LLMConfig
from template_matcher.document_parser import DocumentFeatures
from template_matcher.similarity_scorer import SimilarityScore


logger = logging.getLogger(__name__)


@dataclass
class MatchResult:
    """Final match result with explanation."""
    
    input_file: str
    matched_template: str
    similarity_score: float
    confidence: str
    reason: str
    
    # Detailed scores
    content_score: float = 0.0
    structure_score: float = 0.0
    heading_score: float = 0.0
    layout_score: float = 0.0
    table_score: float = 0.0
    
    # LLM explanation
    llm_explanation: Optional[str] = None
    
    # Alternative matches
    alternatives: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "input_file": self.input_file,
            "matched_template": self.matched_template,
            "similarity_score": round(self.similarity_score, 4),
            "confidence": self.confidence,
            "reason": self.reason,
            "detailed_scores": {
                "content": round(self.content_score, 4),
                "structure": round(self.structure_score, 4),
                "heading": round(self.heading_score, 4),
                "layout": round(self.layout_score, 4),
                "table": round(self.table_score, 4),
            },
            "llm_explanation": self.llm_explanation,
            "alternatives": self.alternatives,
        }
    
    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)


class LLMReranker:
    """
    LLM-based re-ranking and explanation generation.
    Supports OpenAI, OpenRouter, and other OpenAI-compatible APIs.
    """
    
    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or get_config().llm
        self._client: Optional[openai.OpenAI] = None
        
        if self.config.enable_reranking:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize OpenAI-compatible client with provider-specific settings."""
        api_key = "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"
        api_base = "https://openrouter.ai/api/v1"
        
        if not api_key:
            provider_name = self.config.provider
            logger.warning(
                f"{provider_name.upper()} API key not configured. "
                f"Set {self.config.get_api_key_env()} environment variable. "
                f"LLM re-ranking disabled."
            )
            self.config.enable_reranking = False
            self.config.enable_explanation = False
            return
        
        client_kwargs = {"api_key": api_key}
        if api_base:
            client_kwargs["base_url"] = api_base
        
        # Add OpenRouter-specific default headers for rankings
        if self.config.provider == "openrouter":
            default_headers = {}
            if self.config.openrouter_site_url:
                default_headers["HTTP-Referer"] = self.config.openrouter_site_url
            if self.config.openrouter_site_name:
                default_headers["X-Title"] = self.config.openrouter_site_name
            if default_headers:
                client_kwargs["default_headers"] = default_headers
        
        try:
            self._client = openai.OpenAI(**client_kwargs)
            logger.info(
                f"LLM client initialized: provider={self.config.provider}, "
                f"model={self.config.model}, base_url={api_base}"
            )
        except Exception as e:
            logger.error(f"Failed to initialize LLM client: {e}")
            self.config.enable_reranking = False
            self.config.enable_explanation = False
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True,
    )
    def _call_llm(self, messages: List[Dict[str, str]]) -> str:
        """Call LLM with retry logic."""
        if not self._client:
            raise RuntimeError("LLM client not initialized")
        
        # Build request kwargs
        request_kwargs = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        
        response = self._client.chat.completions.create(**request_kwargs)
        
        return response.choices[0].message.content
    
    def rerank(
        self,
        query_doc: DocumentFeatures,
        candidates: List[Tuple[str, DocumentFeatures, SimilarityScore]],
    ) -> MatchResult:
        """
        Re-rank candidates using LLM and generate explanation.
        
        Args:
            query_doc: Query document features
            candidates: List of (template_name, template_features, score) tuples
            
        Returns:
            MatchResult with final decision and explanation
        """
        if not candidates:
            return MatchResult(
                input_file=query_doc.file_name,
                matched_template="No match found",
                similarity_score=0.0,
                confidence="None",
                reason="No template candidates available.",
            )
        
        # If LLM re-ranking is disabled, return top candidate
        if not self.config.enable_reranking or not self._client:
            top_name, top_features, top_score = candidates[0]
            return self._create_result_without_llm(query_doc, top_name, top_score, candidates)
        
        try:
            # Prepare context for LLM
            context = self._build_reranking_context(query_doc, candidates)
            
            # Call LLM for re-ranking
            messages = [
                {
                    "role": "system",
                    "content": (
                        "You are an expert document analysis system. Your task is to determine "
                        "which template document best matches a given input document. "
                        "Analyze the structural, content, and semantic similarities carefully. "
                        "Return your answer as a JSON object with the following fields:\n"
                        "- matched_template: name of the best matching template\n"
                        "- confidence: High, Medium, or Low\n"
                        "- reason: detailed explanation of why this template matches (2-3 sentences)\n"
                        "- score_adjustment: float between -0.1 and 0.1 to adjust the similarity score\n"
                        "- key_matching_features: list of key features that matched\n"
                        "- key_differences: list of notable differences from the template"
                    ),
                },
                {
                    "role": "user",
                    "content": context,
                },
            ]
            
            response = self._call_llm(messages)
            
            # Parse JSON response
            try:
                result_data = json.loads(response)
            except json.JSONDecodeError:
                # Try to extract JSON from markdown code block
                import re
                json_match = re.search(r'```json\n(.*?)\n```', response, re.DOTALL)
                if json_match:
                    result_data = json.loads(json_match.group(1))
                else:
                    raise ValueError("Could not parse LLM response as JSON")
            
            # Find the matched template
            matched_name = result_data.get("matched_template", candidates[0][0])
            
            # Find the candidate
            matched_candidate = None
            for name, features, score in candidates:
                if name == matched_name:
                    matched_candidate = (name, features, score)
                    break
            
            if matched_candidate is None:
                matched_candidate = candidates[0]
            
            matched_name, matched_features, matched_score = matched_candidate
            
            # Adjust score
            adjustment = result_data.get("score_adjustment", 0.0)
            adjusted_score = min(1.0, max(0.0, matched_score.total_score + adjustment))
            
            # Build alternatives
            alternatives = []
            for name, features, score in candidates[1:3]:  # Top 2 alternatives
                alternatives.append({
                    "template": name,
                    "score": round(score.total_score, 4),
                    "confidence": score.confidence,
                })
            
            return MatchResult(
                input_file=query_doc.file_name,
                matched_template=matched_name,
                similarity_score=adjusted_score,
                confidence=result_data.get("confidence", matched_score.confidence),
                reason=result_data.get("reason", "No explanation provided."),
                content_score=matched_score.content_score,
                structure_score=matched_score.structure_score,
                heading_score=matched_score.heading_score,
                layout_score=matched_score.layout_score,
                table_score=matched_score.table_score,
                llm_explanation=response,
                alternatives=alternatives,
            )
        
        except Exception as e:
            logger.error(f"LLM re-ranking failed: {e}. Falling back to score-based ranking.")
            top_name, top_features, top_score = candidates[0]
            return self._create_result_without_llm(query_doc, top_name, top_score, candidates)
    
    def _create_result_without_llm(
        self,
        query_doc: DocumentFeatures,
        matched_name: str,
        matched_score: SimilarityScore,
        candidates: List[Tuple[str, DocumentFeatures, SimilarityScore]],
    ) -> MatchResult:
        """Create result without LLM re-ranking."""
        # Generate automated reason
        reasons = []
        
        if matched_score.content_score > 0.7:
            reasons.append("strong content similarity")
        elif matched_score.content_score > 0.5:
            reasons.append("moderate content overlap")
        
        if matched_score.structure_score > 0.7:
            reasons.append("matching document structure")
        elif matched_score.structure_score > 0.5:
            reasons.append("similar structural organization")
        
        if matched_score.heading_score > 0.7:
            reasons.append("aligned heading hierarchy")
        
        if matched_score.layout_score > 0.7:
            reasons.append("similar layout and formatting")
        
        if reasons:
            reason = f"The document shows {' and '.join(reasons)} with the template."
        else:
            reason = f"Best match based on overall similarity score of {matched_score.total_score:.2%}."
        
        alternatives = []
        for name, features, score in candidates[1:3]:
            alternatives.append({
                "template": name,
                "score": round(score.total_score, 4),
                "confidence": score.confidence,
            })
        
        return MatchResult(
            input_file=query_doc.file_name,
            matched_template=matched_name,
            similarity_score=matched_score.total_score,
            confidence=matched_score.confidence,
            reason=reason,
            content_score=matched_score.content_score,
            structure_score=matched_score.structure_score,
            heading_score=matched_score.heading_score,
            layout_score=matched_score.layout_score,
            table_score=matched_score.table_score,
            alternatives=alternatives,
        )
    
    def _build_reranking_context(
        self,
        query_doc: DocumentFeatures,
        candidates: List[Tuple[str, DocumentFeatures, SimilarityScore]],
    ) -> str:
        """Build context string for LLM re-ranking."""
        lines = []
        
        # Query document info
        lines.append("=== INPUT DOCUMENT ===")
        lines.append(f"File: {query_doc.file_name}")
        lines.append(f"Type: {query_doc.file_type}")
        lines.append(f"Pages: {query_doc.page_count}")
        lines.append(f"Paragraphs: {query_doc.paragraph_count}")
        lines.append(f"Headings: {len(query_doc.headings)}")
        lines.append(f"Tables: {query_doc.table_count}")
        
        # Headings
        if query_doc.headings:
            lines.append("\nHeadings:")
            for h in query_doc.headings[:10]:
                lines.append(f"  - H{h.level}: {h.text[:50]}")
        
        # Content preview
        preview = query_doc.clean_text[:500] if query_doc.clean_text else ""
        lines.append(f"\nContent Preview:\n{preview}\n")
        
        # Candidate templates
        lines.append("\n=== TEMPLATE CANDIDATES ===")
        
        for rank, (name, features, score) in enumerate(candidates[:5], 1):
            lines.append(f"\n--- Candidate {rank}: {name} ---")
            lines.append(f"Overall Score: {score.total_score:.4f}")
            lines.append(f"Confidence: {score.confidence}")
            lines.append(f"Content Score: {score.content_score:.4f}")
            lines.append(f"Structure Score: {score.structure_score:.4f}")
            lines.append(f"Heading Score: {score.heading_score:.4f}")
            lines.append(f"Layout Score: {score.layout_score:.4f}")
            lines.append(f"Table Score: {score.table_score:.4f}")
            
            lines.append(f"Pages: {features.page_count}")
            lines.append(f"Paragraphs: {features.paragraph_count}")
            lines.append(f"Headings: {len(features.headings)}")
            lines.append(f"Tables: {features.table_count}")
            
            if features.headings:
                lines.append("Headings:")
                for h in features.headings[:8]:
                    lines.append(f"  - H{h.level}: {h.text[:50]}")
            
            preview = features.clean_text[:300] if features.clean_text else ""
            lines.append(f"Content Preview:\n{preview}\n")
        
        lines.append("\n=== INSTRUCTIONS ===")
        lines.append("Based on the above information, determine which template best matches the input document.")
        lines.append("Consider document structure, heading hierarchy, content semantics, and layout patterns.")
        lines.append("Return your answer as a JSON object.")
        
        return "\n".join(lines)
    
    def generate_explanation(
        self,
        query_doc: DocumentFeatures,
        matched_template: DocumentFeatures,
        score: SimilarityScore,
    ) -> str:
        """
        Generate a human-readable explanation of the match.
        
        Args:
            query_doc: Query document
            matched_template: Matched template document
            score: Similarity score breakdown
            
        Returns:
            Human-readable explanation string
        """
        if not self.config.enable_explanation or not self._client:
            return score.reason if hasattr(score, 'reason') else "No explanation available."
        
        try:
            context = (
                f"Explain why the document '{query_doc.file_name}' matches template "
                f"'{matched_template.file_name}' with the following scores:\n"
                f"- Overall: {score.total_score:.2%}\n"
                f"- Content: {score.content_score:.2%}\n"
                f"- Structure: {score.structure_score:.2%}\n"
                f"- Headings: {score.heading_score:.2%}\n"
                f"- Layout: {score.layout_score:.2%}\n"
                f"- Tables: {score.table_score:.2%}\n\n"
                f"Input headings: {[h.text for h in query_doc.headings[:5]]}\n"
                f"Template headings: {[h.text for h in matched_template.headings[:5]]}\n\n"
                "Provide a concise 2-3 sentence explanation."
            )
            
            messages = [
                {
                    "role": "system",
                    "content": (
                        "You are a document analysis expert. Explain template matches "
                        "in clear, professional language. Be specific about what features matched."
                    ),
                },
                {
                    "role": "user",
                    "content": context,
                },
            ]
            
            explanation = self._call_llm(messages)
            return explanation.strip()
        
        except Exception as e:
            logger.error(f"Explanation generation failed: {e}")
            return "Unable to generate detailed explanation."