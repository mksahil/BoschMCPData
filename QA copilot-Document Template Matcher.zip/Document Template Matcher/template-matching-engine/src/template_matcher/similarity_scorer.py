"""
Hierarchical Similarity Scoring Engine v2 — Accuracy-Improved
===============================================================
Computes multi-dimensional similarity scores between documents and templates.

Improvements over v1:
1. Content-grounded score breakdown with evidence snippets
2. Empty / low-content document penalization
3. Minimum content threshold validation with noise filtering
4. Improved normalization with sigmoid calibration
5. False-positive reduction via score consistency checks
6. Better weighting strategy for semantic vs structural similarity
7. Template-only / blank document detection
"""

import math
import time
import logging
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field

from template_matcher.config import get_config, ScoringConfig
from template_matcher.embeddings import EmbeddingGenerator, EmbeddingAggregator


logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────
_MIN_CONTENT_LENGTH = 80              # characters below → penalize heavily
_LOW_CONTENT_LENGTH = 200             # characters below → moderate penalty
_EMPTY_DOC_PENALTY_THRESHOLD = 0.25   # drop score to this max if essentially empty
_TEMPLATE_MARKER_PATTERNS = [         # common template placeholders
    "[insert", "[your name]", "[date]", "[company]", "[placeholder]",
    "{{", "}}", "_______", "<placeholder>", "[name]", "[title]",
    "lorem ipsum", "sample text", "[description]",
]
_MAX_RAW_SCORE = 10.0                 # clip raw dot-product similarities


@dataclass
class ScoreEvidence:
    """Evidence for why a particular score component was assigned."""
    matched_headings: List[Dict[str, Any]] = field(default_factory=list)
    matched_sections: List[Dict[str, Any]] = field(default_factory=list)
    matched_tables: List[Dict[str, Any]] = field(default_factory=list)
    content_snippets: List[Dict[str, Any]] = field(default_factory=list)
    layout_matches: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "matched_headings": self.matched_headings,
            "matched_sections": self.matched_sections,
            "matched_tables": self.matched_tables,
            "content_snippets": self.content_snippets,
            "layout_matches": self.layout_matches,
        }


@dataclass
class SimilarityScore:
    """Detailed similarity score breakdown with evidence and confidence calibration."""

    total_score: float
    content_score: float = 0.0
    structure_score: float = 0.0
    heading_score: float = 0.0
    layout_score: float = 0.0
    table_score: float = 0.0

    # Details per component
    content_details: Optional[Dict[str, Any]] = None
    structure_details: Optional[Dict[str, Any]] = None
    heading_details: Optional[Dict[str, Any]] = None
    layout_details: Optional[Dict[str, Any]] = None
    table_details: Optional[Dict[str, Any]] = None

    # Confidence calibration
    confidence: str = "Unknown"
    confidence_score: float = 0.0

    # Evidence snippets for explainability
    evidence: Optional[ScoreEvidence] = None

    # Content-quality flags
    is_low_content: bool = False
    is_template_only: bool = False
    content_quality_penalty: float = 0.0

    # Score normalization info
    normalization_applied: bool = False
    raw_unweighted_score: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_score": round(self.total_score, 4),
            "content_score": round(self.content_score, 4),
            "structure_score": round(self.structure_score, 4),
            "heading_score": round(self.heading_score, 4),
            "layout_score": round(self.layout_score, 4),
            "table_score": round(self.table_score, 4),
            "confidence": self.confidence,
            "confidence_score": round(self.confidence_score, 4),
            "details": {
                "content": self.content_details,
                "structure": self.structure_details,
                "heading": self.heading_details,
                "layout": self.layout_details,
                "table": self.table_details,
            },
            "evidence": self.evidence.to_dict() if self.evidence else None,
            "content_quality": {
                "is_low_content": self.is_low_content,
                "is_template_only": self.is_template_only,
                "penalty_applied": round(self.content_quality_penalty, 4),
            },
            "normalization_applied": self.normalization_applied,
            "raw_unweighted_score": round(self.raw_unweighted_score, 4),
        }


class SimilarityScorer:
    """
    Computes comprehensive similarity scores between documents.
    v2 improvements:
        – penalises empty / near-empty documents aggressively
        – uses sigmoid calibration to squeeze scores into a meaningful 0–1 range
        – detects template-only (placeholder-heavy) documents
        – collects evidence snippets for every component
        – applies false-positive reduction heuristics
    """

    def __init__(
        self,
        config: Optional[ScoringConfig] = None,
        embedding_generator: Optional[EmbeddingGenerator] = None,
    ):
        self.config = config or get_config().scoring
        self.embedding_generator = embedding_generator or EmbeddingGenerator()
        self.aggregator = EmbeddingAggregator()

    # ── public API ──────────────────────────────────────────────────────────

    def compute_similarity(
        self,
        query_embeddings: Dict[str, np.ndarray],
        template_embeddings: Dict[str, np.ndarray],
        query_features: Optional[Any] = None,
        template_features: Optional[Any] = None,
    ) -> SimilarityScore:
        """
        Compute similarity score between query and template documents.

        Parameters
        ----------
        query_embeddings, template_embeddings:
            Dicts mapping feature type -> np.ndarray of embeddings.
        query_features, template_features:
            Optional DocumentFeatures / ExtractedFeatures used to collect
            textual evidence (headings, snippets …).

        Returns
        -------
        SimilarityScore with calibrated total score, per-component breakdown,
        and evidence-backed explanations.
        """
        t0 = time.perf_counter()
        scores: Dict[str, float] = {}
        details: Dict[str, Dict[str, Any]] = {}
        evidence = ScoreEvidence()

        # ── 1.  Content similarity ───────────────────────────────────────────
        if "content" in query_embeddings and "content" in template_embeddings:
            q_emb = query_embeddings["content"]
            t_emb = template_embeddings["content"]
            content_score, content_detail = self._compute_content_similarity_v2(
                q_emb, t_emb
            )
            scores["content"] = content_score
            details["content"] = content_detail
            # Gather evidence snippets
            if query_features and template_features:
                evidence.content_snippets = self._extract_content_evidence(
                    query_features, template_features, content_detail
                )

        # ── 2.  Structure similarity ─────────────────────────────────────────
        if "structure" in query_embeddings and "structure" in template_embeddings:
            struct_score, struct_detail = self._compute_structure_similarity_v2(
                query_embeddings["structure"],
                template_embeddings["structure"],
            )
            scores["structure"] = struct_score
            details["structure"] = struct_detail

        # ── 3.  Heading similarity ───────────────────────────────────────────
        if "heading" in query_embeddings and "heading" in template_embeddings:
            h_score, h_detail = self._compute_heading_similarity_v2(
                query_embeddings["heading"],
                template_embeddings["heading"],
            )
            scores["heading"] = h_score
            details["heading"] = h_detail
            if query_features and template_features:
                evidence.matched_headings = self._extract_heading_evidence(
                    query_features, template_features, h_detail
                )

        # ── 4.  Layout similarity ────────────────────────────────────────────
        if "layout" in query_embeddings and "layout" in template_embeddings:
            l_score, l_detail = self._compute_layout_similarity_v2(
                query_embeddings["layout"],
                template_embeddings["layout"],
            )
            scores["layout"] = l_score
            details["layout"] = l_detail

        # ── 5.  Table similarity ─────────────────────────────────────────────
        if "table" in query_embeddings and "table" in template_embeddings:
            tbl_score, tbl_detail = self._compute_table_similarity_v2(
                query_embeddings["table"],
                template_embeddings["table"],
            )
            scores["table"] = tbl_score
            details["table"] = tbl_detail
            if query_features and template_features:
                evidence.matched_tables = self._extract_table_evidence(
                    query_features, template_features, tbl_detail
                )

        # ── 6.  Aggregate ────────────────────────────────────────────────────
        raw_total = self._aggregate_scores(scores)

        # ── 7.  Content-quality & calibration ────────────────────────────────
        is_low, is_template, penalty = self._assess_content_quality(query_features)
        calibrated_total = self._calibrate_score(raw_total, is_low, is_template, penalty)

        # ── 8.  Confidence calculation ───────────────────────────────────────
        confidence, confidence_score = self._calculate_confidence_v2(
            scores, calibrated_total, is_low, is_template
        )

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.debug(
            "SimilarityScorerV2.compute_similarity  q→t  "
            "raw=%.4f  calibrated=%.4f  confidence=%s  time=%.1fms",
            raw_total, calibrated_total, confidence, elapsed_ms,
        )

        return SimilarityScore(
            total_score=calibrated_total,
            content_score=scores.get("content", 0.0),
            structure_score=scores.get("structure", 0.0),
            heading_score=scores.get("heading", 0.0),
            layout_score=scores.get("layout", 0.0),
            table_score=scores.get("table", 0.0),
            content_details=details.get("content"),
            structure_details=details.get("structure"),
            heading_details=details.get("heading"),
            layout_details=details.get("layout"),
            table_details=details.get("table"),
            confidence=confidence,
            confidence_score=confidence_score,
            evidence=evidence,
            is_low_content=is_low,
            is_template_only=is_template,
            content_quality_penalty=penalty,
            normalization_applied=True,
            raw_unweighted_score=raw_total,
        )

    # ── similarity component computations (v2) ──────────────────────────────

    def _compute_content_similarity_v2(
        self,
        query_emb: np.ndarray,
        template_emb: np.ndarray,
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Content similarity using calibrated pairwise comparison.

        * Clips raw similarities to avoid outliers from near-zero vectors.
        * Uses sigmoid calibration so scores map to a meaningful range.
        * Adds coverage bonus so documents sharing many chunks score higher.
        """
        q = self._as_2d(query_emb)
        t = self._as_2d(template_emb)

        # Normalise rows so dot-product ≈ cosine similarity
        q = self._l2_normalize_rows(q)
        t = self._l2_normalize_rows(t)

        sim_matrix = np.matmul(q, t.T)          # shape [q_chunks, t_chunks]
        sim_matrix = np.clip(sim_matrix, -1.0, 1.0)

        max_sim = float(np.max(sim_matrix))

        # Mean of top-k (robust against a single spurious high match)
        top_k = min(5, sim_matrix.size)
        flat = sim_matrix.flatten()
        top_sims = np.partition(flat, -top_k)[-top_k:]
        mean_top_k = float(np.mean(top_sims))

        # Coverage – fraction of template chunks that have a decent match
        per_template_max = np.max(sim_matrix, axis=0)
        coverage = float(np.mean(per_template_max > 0.3))

        # Combined raw score
        raw = 0.4 * max_sim + 0.35 * mean_top_k + 0.25 * coverage

        # Sigmoid calibration: pushes mid-range scores apart
        calibrated = self._sigmoid_calibrate(raw, steepness=8.0, midpoint=0.45)

        detail = {
            "max_similarity": round(max_sim, 4),
            "mean_top5_similarity": round(mean_top_k, 4),
            "chunk_coverage": round(coverage, 4),
            "query_chunks": q.shape[0],
            "template_chunks": t.shape[0],
            "raw_score": round(raw, 4),
            "calibrated_score": round(calibrated, 4),
        }
        return calibrated, detail

    def _compute_structure_similarity_v2(
        self,
        query_emb: np.ndarray,
        template_emb: np.ndarray,
    ) -> Tuple[float, Dict[str, Any]]:
        """Structure similarity with cosine on L2-normalised vectors."""
        q = self._l2_normalize_rows(self._as_2d(query_emb))
        t = self._l2_normalize_rows(self._as_2d(template_emb))

        # Cosine similarity of mean-pooled vectors
        q_mean = np.mean(q, axis=0)
        t_mean = np.mean(t, axis=0)

        dot = float(np.dot(q_mean, t_mean))
        dot = max(-1.0, min(1.0, dot))

        calibrated = self._sigmoid_calibrate(dot, steepness=6.0, midpoint=0.35)

        detail = {
            "cosine_similarity": round(dot, 4),
            "calibrated_score": round(calibrated, 4),
        }
        return calibrated, detail

    def _compute_heading_similarity_v2(
        self,
        query_emb: np.ndarray,
        template_emb: np.ndarray,
    ) -> Tuple[float, Dict[str, Any]]:
        """Heading similarity with order-preservation bonus."""
        q = self._l2_normalize_rows(self._as_2d(query_emb))
        t = self._l2_normalize_rows(self._as_2d(template_emb))

        if q.shape[0] == 0 or t.shape[0] == 0:
            return 0.0, {"error": "No headings to compare"}

        sim_matrix = np.clip(np.matmul(q, t.T), -1.0, 1.0)

        max_sim = float(np.max(sim_matrix))
        avg_best = float(np.mean(np.max(sim_matrix, axis=1)))

        # Order preservation (monotonicity of best matches)
        query_best = np.argmax(sim_matrix, axis=1)
        if len(query_best) > 1:
            monotonicity = float(np.mean(np.diff(query_best) >= 0))
        else:
            monotonicity = 1.0

        raw = 0.35 * max_sim + 0.35 * avg_best + 0.30 * monotonicity
        calibrated = self._sigmoid_calibrate(raw, steepness=7.0, midpoint=0.40)

        detail = {
            "max_heading_similarity": round(max_sim, 4),
            "avg_best_match": round(avg_best, 4),
            "order_preservation": round(monotonicity, 4),
            "query_headings": q.shape[0],
            "template_headings": t.shape[0],
            "raw_score": round(raw, 4),
            "calibrated_score": round(calibrated, 4),
        }
        return calibrated, detail

    def _compute_layout_similarity_v2(
        self,
        query_emb: np.ndarray,
        template_emb: np.ndarray,
    ) -> Tuple[float, Dict[str, Any]]:
        """Layout similarity with proper normalisation."""
        q = self._l2_normalize_rows(self._as_2d(query_emb))
        t = self._l2_normalize_rows(self._as_2d(template_emb))

        q_mean = np.mean(q, axis=0)
        t_mean = np.mean(t, axis=0)

        dot = float(np.dot(q_mean, t_mean))
        dot = max(-1.0, min(1.0, dot))
        calibrated = self._sigmoid_calibrate(dot, steepness=6.0, midpoint=0.30)

        detail = {
            "layout_similarity": round(dot, 4),
            "calibrated_score": round(calibrated, 4),
        }
        return calibrated, detail

    def _compute_table_similarity_v2(
        self,
        query_emb: np.ndarray,
        template_emb: np.ndarray,
    ) -> Tuple[float, Dict[str, Any]]:
        """Table similarity with structural matching."""
        q = self._as_2d(query_emb)
        t = self._as_2d(template_emb)

        if q.shape[0] == 0 or t.shape[0] == 0:
            return 0.0, {"error": "No tables to compare"}

        q = self._l2_normalize_rows(q)
        t = self._l2_normalize_rows(t)

        sim_matrix = np.clip(np.matmul(q, t.T), -1.0, 1.0)
        max_sim = float(np.max(sim_matrix))
        avg_sim = float(np.mean(sim_matrix))

        raw = 0.6 * max_sim + 0.4 * avg_sim
        calibrated = self._sigmoid_calibrate(raw, steepness=6.0, midpoint=0.35)

        detail = {
            "max_table_similarity": round(max_sim, 4),
            "avg_table_similarity": round(avg_sim, 4),
            "query_tables": q.shape[0],
            "template_tables": t.shape[0],
            "raw_score": round(raw, 4),
            "calibrated_score": round(calibrated, 4),
        }
        return calibrated, detail

    # ── aggregation ─────────────────────────────────────────────────────────

    def _aggregate_scores(self, scores: Dict[str, float]) -> float:
        """
        Weighted aggregation with available-score weight re-normalisation.
        """
        weights = {
            "content": self.config.content_weight,
            "structure": self.config.structure_weight,
            "heading": self.config.heading_weight,
            "layout": self.config.layout_weight,
            "table": self.config.table_weight,
        }
        available_scores = {k: v for k, v in scores.items() if k in weights}
        if not available_scores:
            return 0.0

        available_weights = {k: weights[k] for k in available_scores}
        total_weight = sum(available_weights.values())
        if total_weight == 0:
            return sum(available_scores.values()) / len(available_scores)

        normalised = {k: v / total_weight for k, v in available_weights.items()}
        total = sum(scores[k] * normalised[k] for k in available_scores)
        return round(total, 4)

    # ── content-quality & calibration ───────────────────────────────────────

    def _assess_content_quality(
        self, query_features: Optional[Any]
    ) -> Tuple[bool, bool, float]:
        """
        Detect low-content and template-only documents.

        Returns
        -------
        (is_low_content, is_template_only, penalty_factor)
        """
        if query_features is None:
            return False, False, 0.0

        text = ""
        if hasattr(query_features, "clean_text"):
            text = query_features.clean_text or ""
        elif hasattr(query_features, "full_text"):
            text = query_features.full_text or ""

        text_lower = text.lower().strip()
        text_len = len(text_lower)

        # 1. Low-content detection
        is_low = text_len < _LOW_CONTENT_LENGTH

        # 2. Template-only detection (mostly placeholders)
        placeholder_count = sum(1 for p in _TEMPLATE_MARKER_PATTERNS if p in text_lower)
        is_template = placeholder_count >= 2 or (text_len > 0 and placeholder_count / max(text_len / 100, 1) > 0.5)

        # 3. Penalty factor
        penalty = 0.0
        if text_len < _MIN_CONTENT_LENGTH:
            penalty = 0.70          # 70% score reduction
        elif text_len < _LOW_CONTENT_LENGTH:
            penalty = 0.40          # 40% score reduction
        if is_template:
            penalty = max(penalty, 0.50)

        if is_low or is_template:
            logger.info(
                "Content-quality check: low=%s template=%s penalty=%.2f  (len=%d)",
                is_low, is_template, penalty, text_len,
            )

        return is_low, is_template, penalty

    def _calibrate_score(
        self,
        raw_total: float,
        is_low_content: bool,
        is_template_only: bool,
        penalty: float,
    ) -> float:
        """
        Apply sigmoid calibration + content-quality penalty + floor/ceiling rules.
        """
        score = raw_total

        # Hard floor for effectively-empty documents
        if is_low_content or is_template_only:
            score = min(score, _EMPTY_DOC_PENALTY_THRESHOLD)
            score = score * (1.0 - penalty)
            logger.debug(
                "Penalty applied: raw=%.4f  after_penalty=%.4f  (low=%s template=%s)",
                raw_total, score, is_low_content, is_template_only,
            )

        # Smooth sigmoid re-calibration of the final score
        score = self._sigmoid_calibrate(score, steepness=5.0, midpoint=0.50)

        # Clamp
        return float(np.clip(score, 0.0, 1.0))

    # ── confidence calculation ──────────────────────────────────────────────

    def _calculate_confidence_v2(
        self,
        scores: Dict[str, float],
        total_score: float,
        is_low_content: bool,
        is_template_only: bool,
    ) -> Tuple[str, float]:
        """
        Confidence incorporates score magnitude, consistency, and content quality.
        """
        if not scores:
            return "Unknown", 0.0

        values = list(scores.values())
        mean_val = np.mean(values)
        std_val = np.std(values)
        consistency = 1.0 - min(std_val / max(mean_val, 0.01), 1.0)

        # Score magnitude contribution
        magnitude = total_score

        # Feature ratio (how many components are above noise floor)
        feature_ratio = len([s for s in values if s > 0.25]) / max(len(values), 1)

        # Combine
        confidence_score = 0.35 * magnitude + 0.30 * consistency + 0.20 * feature_ratio

        # Penalise confidence for low-content / template-only docs
        if is_low_content or is_template_only:
            confidence_score *= 0.5

        # Threshold mapping
        cfg = self.config
        if confidence_score >= cfg.high_confidence_threshold:
            level = "High"
        elif confidence_score >= cfg.medium_confidence_threshold:
            level = "Medium"
        elif confidence_score >= cfg.low_confidence_threshold:
            level = "Low"
        else:
            level = "Very Low"

        # Override: even with decent numbers, low-content docs get Low at best
        if (is_low_content or is_template_only) and level in ("High", "Medium"):
            level = "Low"

        return level, round(confidence_score, 4)

    # ── evidence extraction ─────────────────────────────────────────────────

    def _extract_content_evidence(
        self,
        query_features: Any,
        template_features: Any,
        content_detail: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Extract specific matching content snippets as evidence."""
        snippets = []
        q_headings = getattr(query_features, "headings", []) or []
        t_headings = getattr(template_features, "headings", []) or []

        for qh in q_headings[:15]:
            for th in t_headings[:15]:
                if qh.text.strip().lower() == th.text.strip().lower():
                    snippets.append({
                        "type": "identical_heading",
                        "query": qh.text,
                        "template": th.text,
                        "confidence": 1.0,
                    })
                elif self._fuzzy_match(qh.text, th.text, threshold=0.7):
                    snippets.append({
                        "type": "similar_heading",
                        "query": qh.text,
                        "template": th.text,
                        "confidence": 0.7,
                    })

        # Add top chunk-match evidence if available
        coverage = content_detail.get("chunk_coverage", 0)
        if coverage > 0:
            snippets.append({
                "type": "chunk_coverage",
                "description": f"{coverage:.0%} of template chunks have a matching query chunk",
                "confidence": coverage,
            })

        return snippets

    def _extract_heading_evidence(
        self,
        query_features: Any,
        template_features: Any,
        heading_detail: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Extract heading-level match evidence."""
        evidence = []
        q_headings = getattr(query_features, "headings", []) or []
        t_headings = getattr(template_features, "headings", []) or []

        for qh in q_headings:
            for th in t_headings:
                if qh.text.strip().lower() == th.text.strip().lower():
                    evidence.append({
                        "query_heading": qh.text,
                        "template_heading": th.text,
                        "match_type": "exact",
                        "level_q": qh.level,
                        "level_t": th.level,
                    })
                elif self._fuzzy_match(qh.text, th.text, 0.75):
                    evidence.append({
                        "query_heading": qh.text,
                        "template_heading": th.text,
                        "match_type": "fuzzy",
                        "level_q": qh.level,
                        "level_t": th.level,
                    })
        return evidence

    def _extract_table_evidence(
        self,
        query_features: Any,
        template_features: Any,
        table_detail: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Extract table-structure match evidence."""
        evidence = []
        q_tables = getattr(query_features, "tables", []) or []
        t_tables = getattr(template_features, "tables", []) or []

        for qt in q_tables:
            for tt in t_tables:
                if qt.row_count == tt.row_count and qt.col_count == tt.col_count:
                    evidence.append({
                        "match_type": "identical_dimensions",
                        "query_shape": f"{qt.row_count}x{qt.col_count}",
                        "template_shape": f"{tt.row_count}x{tt.col_count}",
                    })
                elif abs(qt.row_count - tt.row_count) <= 2 and qt.col_count == tt.col_count:
                    evidence.append({
                        "match_type": "similar_dimensions",
                        "query_shape": f"{qt.row_count}x{qt.col_count}",
                        "template_shape": f"{tt.row_count}x{tt.col_count}",
                    })
        return evidence

    # ── helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _as_2d(arr: np.ndarray) -> np.ndarray:
        """Ensure array is 2-D."""
        if arr.ndim == 1:
            return arr.reshape(1, -1)
        return arr

    @staticmethod
    def _l2_normalize_rows(arr: np.ndarray) -> np.ndarray:
        """L2-normalise each row; zero-rows stay zero."""
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        return arr / norms

    @staticmethod
    def _sigmoid_calibrate(x: float, steepness: float = 6.0, midpoint: float = 0.5) -> float:
        """
        Sigmoid calibration that:
        * compresses extreme values,
        * spreads the region around *midpoint*.
        """
        try:
            return 1.0 / (1.0 + math.exp(-steepness * (x - midpoint)))
        except OverflowError:
            return 0.0 if x < midpoint else 1.0

    @staticmethod
    def _fuzzy_match(a: str, b: str, threshold: float = 0.7) -> bool:
        """Quick fuzzy match using normalised Levenshtein distance."""
        a, b = a.strip().lower(), b.strip().lower()
        if a == b:
            return True
        # Simple ratio
        max_len = max(len(a), len(b))
        if max_len == 0:
            return True
        import difflib
        ratio = difflib.SequenceMatcher(None, a, b).ratio()
        return ratio >= threshold

    # ── batch ranking (unchanged API) ───────────────────────────────────────

    def rank_templates(
        self,
        query_embeddings: Dict[str, np.ndarray],
        template_embeddings_list: List[Tuple[str, Dict[str, np.ndarray]]],
        query_features: Optional[Any] = None,
        template_features_map: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[str, SimilarityScore]]:
        """Rank templates by similarity to query document."""
        results = []
        for template_name, template_emb in template_embeddings_list:
            t_features = template_features_map.get(template_name) if template_features_map else None
            score = self.compute_similarity(
                query_embeddings, template_emb,
                query_features=query_features,
                template_features=t_features,
            )
            results.append((template_name, score))
        results.sort(key=lambda x: x[1].total_score, reverse=True)
        return results