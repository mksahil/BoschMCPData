"""
Multi-Modal Feature Extractor
Extracts and combines features from document content, structure, headings, layout, and tables.
Produces unified feature vectors for embedding generation.
"""

import re
import hashlib
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from collections import Counter

from template_matcher.config import get_config, DocumentConfig
from template_matcher.document_parser import DocumentFeatures, HeadingInfo, TableData

@dataclass
class ExtractedFeatures:
    """Unified feature representation for embedding."""
    
    # Fields without defaults (must come first)
    content_features: List[str]
    structure_features: str
    heading_features: List[str]
    layout_features: str
    table_features: List[str]
    metadata: Dict[str, Any]
    
    # Fields with defaults (must come after)
    structure_vector: Optional[List[float]] = None
    heading_vector: Optional[List[float]] = None
    layout_vector: Optional[List[float]] = None
    table_vector: Optional[List[float]] = None
    
    def get_all_texts(self) -> Dict[str, List[str]]:
        """Get all feature texts organized by type."""
        return {
            "content": self.content_features,
            "heading": self.heading_features,
            "table": self.table_features,
            "structure": [self.structure_features] if self.structure_features else [],
            "layout": [self.layout_features] if self.layout_features else [],
        }


class FeatureExtractor:
    """Extracts multi-modal features from parsed documents."""
    
    def __init__(self, config: Optional[DocumentConfig] = None):
        self.config = config or get_config().document
    
    def extract(self, features: DocumentFeatures) -> ExtractedFeatures:
        """
        Extract all features from a parsed document.
        
        Args:
            features: Parsed DocumentFeatures
            
        Returns:
            ExtractedFeatures with unified representations
        """
        # Extract content features
        content_features = self._extract_content_features(features)
        
        # Extract structure features
        structure_features = self._extract_structure_features(features)
        
        # Extract heading features
        heading_features = self._extract_heading_features(features)
        
        # Extract layout features
        layout_features = self._extract_layout_features(features)
        
        # Extract table features
        table_features = self._extract_table_features(features)
        
        # Compile metadata
        metadata = {
            "file_name": features.file_name,
            "file_type": features.file_type,
            "page_count": features.page_count,
            "paragraph_count": features.paragraph_count,
            "heading_count": len(features.headings),
            "table_count": features.table_count,
            "structure_hash": hashlib.md5(structure_features.encode()).hexdigest()[:16],
            "avg_paragraph_length": features.average_paragraph_length,
        }
        
        return ExtractedFeatures(
            content_features=content_features,
            structure_features=structure_features,
            heading_features=heading_features,
            layout_features=layout_features,
            table_features=table_features,
            metadata=metadata,
        )
    
    def _extract_content_features(self, features: DocumentFeatures) -> List[str]:
        """Extract content features - rich text chunks with context."""
        chunks = []
        
        # Use pre-generated chunks if available
        if features.content_chunks:
            chunks.extend(features.content_chunks)
        else:
            # Fallback: create chunks from full text
            text = features.clean_text or features.full_text
            chunks.extend(self._chunk_text(text))
        
        # Add section-based features with context
        for section in features.sections:
            section_text = section.get_full_text()
            if section.heading:
                # Prepend heading context to content
                contextualized = f"Section: {section.heading.text}\n{section_text}"
                chunks.append(contextualized)
        
        return chunks
    
    def _extract_structure_features(self, features: DocumentFeatures) -> str:
        """
        Extract structural features as a descriptive signature.
        This captures the document's organizational pattern.
        """
        parts = []
        
        # Document-level structure
        parts.append(f"Document Type: {features.file_type.upper()}")
        parts.append(f"Pages: {features.page_count}")
        parts.append(f"Paragraphs: {features.paragraph_count}")
        parts.append(f"Headings: {len(features.headings)}")
        parts.append(f"Tables: {features.table_count}")
        
        # Heading hierarchy pattern
        if features.headings:
            hierarchy = " -> ".join(
                f"H{h.level}({h.text[:25]})" 
                for h in features.headings[:20]  # Limit to first 20
            )
            parts.append(f"Hierarchy: {hierarchy}")
        
        # Section structure
        section_desc = self._describe_section_structure(features.sections)
        parts.append(f"Sections: {section_desc}")
        
        # Table patterns
        for i, table in enumerate(features.tables[:5]):  # Limit to first 5
            header = " | ".join(table.content[0]) if table.content else ""
            parts.append(f"Table {i+1}: [{table.row_count}x{table.col_count}] {header[:40]}")
        
        return "\n".join(parts)
    
    def _extract_heading_features(self, features: DocumentFeatures) -> List[str]:
        """Extract heading features with hierarchy context."""
        heading_texts = []
        
        for i, heading in enumerate(features.headings):
            # Create contextual heading representation
            context = f"Level {heading.level}: {heading.text}"
            
            # Add surrounding context (previous and next headings)
            if i > 0:
                context = f"After '{features.headings[i-1].text[:30]}' -> {context}"
            if i < len(features.headings) - 1:
                context = f"{context} -> Before '{features.headings[i+1].text[:30]}'"
            
            heading_texts.append(context)
        
        # Add heading sequence as a single feature
        if features.headings:
            sequence = " | ".join(f"H{h.level}:{h.text[:20]}" for h in features.headings)
            heading_texts.append(f"Heading Sequence: {sequence}")
        
        return heading_texts
    
    def _extract_layout_features(self, features: DocumentFeatures) -> str:
        """
        Extract layout features describing document formatting.
        """
        parts = []
        
        # Font information
        font_info = features.font_info
        if font_info:
            parts.append(f"Fonts: {', '.join(font_info.get('used_fonts', {}).keys())}")
            if font_info.get('dominant_font'):
                parts.append(f"Primary Font: {font_info['dominant_font']}")
            if font_info.get('average_font_size'):
                parts.append(f"Avg Font Size: {font_info['average_font_size']:.1f}pt")
        
        # Document dimensions
        parts.append(f"Document Size: {features.file_size} bytes")
        parts.append(f"Page Count: {features.page_count}")
        
        # Content density
        if features.page_count > 0:
            density = features.paragraph_count / features.page_count
            parts.append(f"Paragraph Density: {density:.1f} per page")
        
        # Structural complexity
        complexity = self._calculate_complexity(features)
        parts.append(f"Complexity Score: {complexity:.2f}")
        
        # Content type indicators
        indicators = self._detect_content_type(features)
        parts.append(f"Content Indicators: {', '.join(indicators)}")
        
        return "\n".join(parts)
    
    def _extract_table_features(self, features: DocumentFeatures) -> List[str]:
        """Extract table features as descriptive strings."""
        table_texts = []
        
        for i, table in enumerate(features.tables):
            # Table dimensions
            desc = f"Table {i+1}: {table.row_count} rows x {table.col_count} columns"
            
            # Table header
            if table.content:
                header = " | ".join(str(cell) for cell in table.content[0] if cell)
                desc += f"\nHeader: {header}"
            
            # Table structure pattern
            if table.row_count > 0 and table.col_count > 0:
                row_pattern = f"{table.row_count}R"
                col_pattern = f"{table.col_count}C"
                desc += f"\nPattern: {row_pattern}x{col_pattern}"
            
            table_texts.append(desc)
        
        return table_texts
    
    def _chunk_text(self, text: str, max_size: Optional[int] = None, overlap: Optional[int] = None) -> List[str]:
        """Split text into overlapping chunks."""
        max_size = max_size or self.config.max_chunk_size
        overlap = overlap or self.config.chunk_overlap
        
        chunks = []
        words = text.split()
        current_chunk = []
        current_length = 0
        
        for word in words:
            current_chunk.append(word)
            current_length += len(word) + 1
            
            if current_length >= max_size:
                chunks.append(" ".join(current_chunk))
                overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                current_chunk = overlap_words[:]
                current_length = sum(len(w) + 1 for w in current_chunk)
        
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def _describe_section_structure(self, sections: List[Any], depth: int = 0) -> str:
        """Create a text description of section hierarchy."""
        descriptions = []
        
        for section in sections:
            indent = "  " * depth
            if section.heading:
                desc = f"{indent}[H{section.heading.level}] {section.heading.text[:30]}"
            else:
                desc = f"{indent}[Body] {section.content[:30]}..."
            
            descriptions.append(desc)
            
            if section.subsections:
                sub_desc = self._describe_section_structure(section.subsections, depth + 1)
                descriptions.append(sub_desc)
        
        return "\n".join(descriptions)
    
    def _calculate_complexity(self, features: DocumentFeatures) -> float:
        """Calculate document structural complexity score."""
        score = 0.0
        
        # Heading depth diversity
        if features.headings:
            levels = set(h.level for h in features.headings)
            score += len(levels) * 0.5
        
        # Table complexity
        if features.tables:
            avg_rows = sum(t.row_count for t in features.tables) / len(features.tables)
            avg_cols = sum(t.col_count for t in features.tables) / len(features.tables)
            score += (avg_rows * 0.1 + avg_cols * 0.2)
        
        # Section nesting depth
        max_depth = self._get_max_depth(features.sections)
        score += max_depth * 0.3
        
        # Content density
        if features.page_count > 0:
            density = features.paragraph_count / features.page_count
            score += min(density * 0.05, 2.0)
        
        return round(score, 2)
    
    def _get_max_depth(self, sections: List[Any], current_depth: int = 0) -> int:
        """Get maximum section nesting depth."""
        if not sections:
            return current_depth
        
        max_depth = current_depth
        for section in sections:
            if section.subsections:
                depth = self._get_max_depth(section.subsections, current_depth + 1)
                max_depth = max(max_depth, depth)
        
        return max_depth
    
    def _detect_content_type(self, features: DocumentFeatures) -> List[str]:
        """Detect document content type indicators."""
        indicators = []
        text = features.clean_text.lower()
        headings_text = " ".join(h.text.lower() for h in features.headings)
        
        # Check for form indicators
        form_patterns = [
            r'\b(name|date|signature|email|phone|address)\b',
            r'\b(form|application|registration)\b',
            r'\[\s*\]|\(\s*\)|_____',
        ]
        if any(re.search(p, text) for p in form_patterns):
            indicators.append("form-like")
        
        # Check for report indicators
        report_patterns = [
            r'\b(executive summary|introduction|conclusion|recommendation)\b',
            r'\b(report|analysis|findings)\b',
        ]
        if any(re.search(p, text) for p in report_patterns):
            indicators.append("report-like")
        
        # Check for table-heavy
        if features.table_count >= 3:
            indicators.append("table-heavy")
        
        # Check for structured headings
        if len(features.headings) >= 5:
            indicators.append("highly-structured")
        
        # Check for short form
        if features.page_count <= 2 and features.paragraph_count <= 10:
            indicators.append("short-document")
        
        return indicators if indicators else ["unstructured"]
    
    def extract_batch(self, features_list: List[DocumentFeatures]) -> List[ExtractedFeatures]:
        """Extract features from multiple documents."""
        return [self.extract(f) for f in features_list]
