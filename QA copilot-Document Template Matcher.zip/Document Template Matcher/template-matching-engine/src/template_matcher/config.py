"""
Configuration Module v2 for Template Matching Engine.
Adds Excel support and scoring-v2 calibration parameters.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class DocumentConfig(BaseSettings):
    """Document parsing and processing configuration — with Excel support."""

    supported_docx_extensions: List[str] = [".docx", ".doc"]
    supported_pdf_extensions: List[str] = [".pdf"]
    supported_excel_extensions: List[str] = [".xlsx", ".xls", ".csv"]
    supported_extensions: List[str] = [
        ".docx", ".doc", ".pdf", ".xlsx", ".xls", ".csv",
    ]

    # Chunking parameters
    max_chunk_size: int = 512
    chunk_overlap: int = 128
    min_chunk_size: int = 50

    # Table extraction
    extract_tables_as_html: bool = True
    max_table_rows: int = 500

    # Image extraction for layout analysis
    extract_images: bool = True
    max_image_size: int = 2048

    # Heading detection
    heading_styles: List[str] = [
        "Heading 1", "Heading 2", "Heading 3",
        "Heading 4", "Heading 5", "Heading 6", "Title",
    ]
    heading_font_sizes: Dict[str, float] = {
        "title": 18.0, "h1": 16.0, "h2": 14.0, "h3": 12.0, "h4": 11.0,
    }

    class Config:
        env_prefix = "DOC_"


class EmbeddingConfig(BaseSettings):
    """Embedding model configuration."""

    # Primary embedding model (multi-modal, structure-aware)
    primary_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    # primary_model: str = "sentence-transformers/all-mpnet-base-v2"
    # primary_model: str = "BAAI/bge-large-en-v1.5"

    # Model for structure/layout embeddings
    structure_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Model for heading hierarchy embeddings
    heading_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Batch size for embedding generation
    batch_size: int = 32

    # Maximum sequence length
    max_seq_length: int = 512

    # Device: "cpu", "cuda", or "auto"
    device: str = "auto"

    # Normalize embeddings
    normalize_embeddings: bool = True

    # Embedding dimensions (auto-detected if None)
    embedding_dim: Optional[int] = None

    class Config:
        env_prefix = "EMBED_"


class VectorStoreConfig(BaseSettings):
    """Vector database configuration."""

    index_type: str = "HNSW"
    distance_metric: str = "cosine"

    hnsw_m: int = 32
    hnsw_ef_construction: int = 200
    hnsw_ef_search: int = 128

    ivf_nlist: int = 100
    pq_nbits: int = 8

    index_path: Optional[str] = "./vector_store.index"
    metadata_path: Optional[str] = "./vector_store_metadata.pkl"

    class Config:
        env_prefix = "VECTOR_"


class ScoringConfig(BaseSettings):
    """Similarity scoring configuration — v2 calibrated."""

    # Weight for different matching components (should sum to 1.0)
    content_weight: float = 0.35
    structure_weight: float = 0.25
    heading_weight: float = 0.20
    layout_weight: float = 0.15
    table_weight: float = 0.05

    # Top-K candidates
    top_k_vector: int = 10
    top_k_candidates: int = 5

    # Similarity thresholds
    high_confidence_threshold: float = 0.80
    medium_confidence_threshold: float = 0.60
    low_confidence_threshold: float = 0.40

    # Minimum score to consider a match
    min_match_score: float = 0.45

    # Sigmoid calibration parameters
    sigmoid_steepness: float = 6.0
    sigmoid_midpoint: float = 0.40

    # Content-quality penalties
    empty_doc_penalty: float = 0.70
    low_content_penalty: float = 0.40
    template_only_penalty: float = 0.50
    min_content_length: int = 80
    low_content_length: int = 200

    class Config:
        env_prefix = "SCORE_"


class LLMConfig(BaseSettings):
    """LLM re-ranking configuration."""

    provider: str = "openrouter"
    model: str = "openai/gpt-3.5-turbo"
    temperature: float = 0.1
    max_tokens: int = 500

    api_key: Optional[str] = Field(default=None, env="OPENROUTER_API_KEY")
    api_base: Optional[str] = Field(default=None, env="OPENROUTER_BASE_URL")

    openrouter_site_url: Optional[str] = Field(default=None, env="OPENROUTER_SITE_URL")
    openrouter_site_name: Optional[str] = Field(default="TemplateMatcher", env="OPENROUTER_SITE_NAME")

    enable_reranking: bool = True
    enable_explanation: bool = True
    max_docs_per_call: int = 3
    max_retries: int = 3
    retry_delay: float = 1.0

    local_model_path: Optional[str] = None

    class Config:
        env_prefix = "LLM_"

    def get_api_base(self) -> Optional[str]:
        if self.api_base:
            return self.api_base
        if self.provider == "openrouter":
            return "https://openrouter.ai/api/v1"
        elif self.provider == "openai":
            return "https://api.openai.com/v1"
        return None

    def get_api_key_env(self) -> str:
        if self.provider == "openrouter":
            return "OPENROUTER_API_KEY"
        elif self.provider == "openai":
            return "OPENAI_API_KEY"
        return "LLM_API_KEY"


class LoggingConfig(BaseSettings):
    """Structured logging configuration."""

    log_level: str = "INFO"
    json_mode: bool = False
    log_file: Optional[str] = None
    include_correlation: bool = True

    class Config:
        env_prefix = "LOG_"


class AppConfig(BaseSettings):
    """Main application configuration — v2 with Excel and logging."""

    root_dir: str = "./sample_data"
    templates_folder: str = "Templates"
    output_dir: str = "./output"
    log_level: str = "INFO"
    num_workers: int = 4
    show_progress: bool = True

    document: DocumentConfig = DocumentConfig()
    embedding: EmbeddingConfig = EmbeddingConfig()
    vector_store: VectorStoreConfig = VectorStoreConfig()
    scoring: ScoringConfig = ScoringConfig()
    llm: LLMConfig = LLMConfig()
    logging: LoggingConfig = LoggingConfig()

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# ── Global singleton ────────────────────────────────────────────────────────
_config_instance: Optional[AppConfig] = None


def get_config() -> AppConfig:
    global _config_instance
    if _config_instance is None:
        _config_instance = AppConfig()
    return _config_instance


def reload_config() -> AppConfig:
    global _config_instance
    _config_instance = AppConfig()
    return _config_instance


def set_config(cfg: AppConfig):
    global _config_instance
    _config_instance = cfg