"""
Embedding Generation Module
Generates dense vector embeddings for different document feature types.
Supports multiple embedding models and caching.
"""

import hashlib
import pickle
from pathlib import Path
from typing import Dict, List, Optional, Union, Any

import numpy as np
from sentence_transformers import SentenceTransformer

from template_matcher.config import get_config, EmbeddingConfig
from template_matcher.feature_extractor import ExtractedFeatures


class EmbeddingGenerator:
    """Generates embeddings for document features using sentence-transformers."""
    
    def __init__(self, config: Optional[EmbeddingConfig] = None):
        self.config = config or get_config().embedding
        self.models: Dict[str, SentenceTransformer] = {}
        self._embedding_cache: Dict[str, np.ndarray] = {}
        
        # Initialize primary model
        self._load_model("primary", self.config.primary_model)
    
    def _load_model(self, model_key: str, model_name: str) -> SentenceTransformer:
        """Load a sentence transformer model."""
        if model_key not in self.models:
            device = self.config.device
            if device == "auto":
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
            
            model = SentenceTransformer(model_name, device=device)
            model.max_seq_length = self.config.max_seq_length
            self.models[model_key] = model
        
        return self.models[model_key]
    
    def _get_model(self, feature_type: str = "primary") -> SentenceTransformer:
        """Get appropriate model for feature type."""
        if feature_type == "structure":
            return self._load_model("structure", self.config.structure_model)
        elif feature_type == "heading":
            return self._load_model("heading", self.config.heading_model)
        else:
            return self.models["primary"]
    
    def _get_cache_key(self, texts: Union[str, List[str]], feature_type: str) -> str:
        """Generate cache key for embeddings."""
        if isinstance(texts, list):
            text_str = "|".join(texts)
        else:
            text_str = texts
        
        model_name = self.config.primary_model
        if feature_type == "structure":
            model_name = self.config.structure_model
        elif feature_type == "heading":
            model_name = self.config.heading_model
        
        key_data = f"{model_name}:{feature_type}:{text_str}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def generate(
        self,
        texts: Union[str, List[str]],
        feature_type: str = "primary",
        batch_size: Optional[int] = None,
        show_progress: bool = False,
    ) -> np.ndarray:
        """
        Generate embeddings for given texts.
        
        Args:
            texts: Single text or list of texts to embed
            feature_type: Type of features (primary, structure, heading)
            batch_size: Batch size for encoding
            show_progress: Whether to show progress bar
            
        Returns:
            numpy array of embeddings (shape: [n_texts, embedding_dim])
        """
        if isinstance(texts, str):
            texts = [texts]
        
        if not texts:
            return np.array([])
        
        batch_size = batch_size or self.config.batch_size
        model = self._get_model(feature_type)
        
        # Check cache for all texts
        embeddings_list = []
        texts_to_encode = []
        indices_to_fill = []
        
        for i, text in enumerate(texts):
            cache_key = self._get_cache_key(text, feature_type)
            if cache_key in self._embedding_cache:
                embeddings_list.append((i, self._embedding_cache[cache_key]))
            else:
                texts_to_encode.append(text)
                indices_to_fill.append(i)
        
        # Generate embeddings for uncached texts
        if texts_to_encode:
            new_embeddings = model.encode(
                texts_to_encode,
                batch_size=batch_size,
                show_progress_bar=show_progress,
                convert_to_numpy=True,
                normalize_embeddings=self.config.normalize_embeddings,
            )
            
            # Cache new embeddings
            for idx, text, emb in zip(indices_to_fill, texts_to_encode, new_embeddings):
                cache_key = self._get_cache_key(text, feature_type)
                self._embedding_cache[cache_key] = emb
                embeddings_list.append((idx, emb))
        
        # Sort by original index and stack
        embeddings_list.sort(key=lambda x: x[0])
        embeddings = np.stack([emb for _, emb in embeddings_list])
        
        return embeddings
    
    def generate_for_document(self, features: ExtractedFeatures) -> Dict[str, np.ndarray]:
        """
        Generate embeddings for all feature types of a document.
        
        Args:
            features: ExtractedFeatures from feature extractor
            
        Returns:
            Dictionary mapping feature type to embeddings array
        """
        embeddings = {}
        
        # Content embeddings
        if features.content_features:
            embeddings["content"] = self.generate(
                features.content_features,
                feature_type="primary",
            )
        
        # Structure embeddings
        if features.structure_features:
            embeddings["structure"] = self.generate(
                [features.structure_features],
                feature_type="structure",
            )
        
        # Heading embeddings
        if features.heading_features:
            embeddings["heading"] = self.generate(
                features.heading_features,
                feature_type="heading",
            )
        
        # Layout embeddings
        if features.layout_features:
            embeddings["layout"] = self.generate(
                [features.layout_features],
                feature_type="primary",
            )
        
        # Table embeddings
        if features.table_features:
            embeddings["table"] = self.generate(
                features.table_features,
                feature_type="primary",
            )
        
        return embeddings
    
    def generate_batch(
        self,
        features_list: List[ExtractedFeatures],
        show_progress: bool = True,
    ) -> List[Dict[str, np.ndarray]]:
        """
        Generate embeddings for multiple documents.
        
        Args:
            features_list: List of ExtractedFeatures
            show_progress: Whether to show progress bar
            
        Returns:
            List of embedding dictionaries
        """
        results = []
        
        iterator = features_list
        if show_progress:
            from tqdm import tqdm
            iterator = tqdm(iterator, desc="Generating embeddings")
        
        for features in iterator:
            embeddings = self.generate_for_document(features)
            results.append(embeddings)
        
        return results
    
    def get_embedding_dim(self) -> int:
        """Get the dimension of generated embeddings."""
        if self.config.embedding_dim:
            return self.config.embedding_dim
        
        # Get dimension by generating a test embedding
        test_embedding = self.generate(["test"], feature_type="primary")
        dim = test_embedding.shape[1]
        self.config.embedding_dim = dim
        return dim
    
    def clear_cache(self):
        """Clear the embedding cache."""
        self._embedding_cache.clear()
    
    def save_cache(self, path: str):
        """Save embedding cache to disk."""
        cache_path = Path(path)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_path, 'wb') as f:
            pickle.dump(self._embedding_cache, f)
    
    def load_cache(self, path: str):
        """Load embedding cache from disk."""
        cache_path = Path(path)
        if cache_path.exists():
            with open(cache_path, 'rb') as f:
                self._embedding_cache = pickle.load(f)


class EmbeddingAggregator:
    """Aggregates multiple embeddings into a single vector representation."""
    
    def __init__(self, config: Optional[EmbeddingConfig] = None):
        self.config = config or get_config().embedding
    
    def aggregate(
        self,
        embeddings: Dict[str, np.ndarray],
        weights: Optional[Dict[str, float]] = None,
    ) -> np.ndarray:
        """
        Aggregate multiple embeddings into a single vector.
        
        Args:
            embeddings: Dictionary of feature type -> embeddings
            weights: Optional weights for each feature type
            
        Returns:
            Aggregated embedding vector
        """
        if not embeddings:
            raise ValueError("No embeddings to aggregate")
        
        # Default weights
        if weights is None:
            weights = {
                "content": 0.35,
                "structure": 0.25,
                "heading": 0.20,
                "layout": 0.15,
                "table": 0.05,
            }
        
        # Normalize weights for present features
        present_features = set(embeddings.keys())
        filtered_weights = {k: v for k, v in weights.items() if k in present_features}
        
        total_weight = sum(filtered_weights.values())
        if total_weight == 0:
            # Equal weighting if no overlap
            filtered_weights = {k: 1.0 / len(present_features) for k in present_features}
        else:
            filtered_weights = {k: v / total_weight for k, v in filtered_weights.items()}
        
        # Aggregate embeddings
        aggregated = None
        for feature_type, emb in embeddings.items():
            weight = filtered_weights.get(feature_type, 0)
            
            # Mean pool if multiple embeddings
            if len(emb.shape) > 1 and emb.shape[0] > 1:
                emb = np.mean(emb, axis=0, keepdims=True)
            
            if aggregated is None:
                aggregated = weight * emb
            else:
                aggregated += weight * emb
        
        # Normalize
        norm = np.linalg.norm(aggregated)
        if norm > 0:
            aggregated = aggregated / norm
        
        return aggregated.flatten()
    
    def aggregate_batch(
        self,
        embeddings_list: List[Dict[str, np.ndarray]],
        weights: Optional[Dict[str, float]] = None,
    ) -> np.ndarray:
        """
        Aggregate embeddings for multiple documents.
        
        Args:
            embeddings_list: List of embedding dictionaries
            weights: Optional weights
            
        Returns:
            Array of aggregated embeddings [n_docs, embedding_dim]
        """
        aggregated = []
        for embeddings in embeddings_list:
            agg = self.aggregate(embeddings, weights)
            aggregated.append(agg)
        
        return np.stack(aggregated)
