"""
Document Parsing Engine
Handles ingestion and parsing of .docx and .pdf files.
Extracts content, structure, headings, tables, and layout features.
"""

import re
import io
import base64
import hashlib
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Union
from abc import ABC, abstractmethod
import docx
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
import fitz  # PyMuPDF
import pdfplumber

from template_matcher.config import get_config, DocumentConfig


@dataclass
class TableData:
    """Represents extracted table data."""
    content: List[List[str]]
    row_count: int
    col_count: int
    html_representation: Optional[str] = None
    text_representation: Optional[str] = None
    
    def __post_init__(self):
        if self.text_representation is None:
            self.text_representation = self._to_text()
        if self.html_representation is None:
            self.html_representation = self._to_html()
    
    def _to_text(self) -> str:
        """Convert table to text representation."""
        lines = []
        for row in self.content:
            lines.append(" | ".join(str(cell) for cell in row if cell))
        return "\n".join(lines)
    
    def _to_html(self) -> str:
        """Convert table to HTML representation."""
        rows = []
        for i, row in enumerate(self.content):
            tag = "th" if i == 0 else "td"
            cells = " ".join(f"<{tag}>{cell}</{tag}>" for cell in row if cell)
            rows.append(f"<tr>{cells}</tr>")
        return f"<table>{''.join(rows)}</table>"


@dataclass
class HeadingInfo:
    """Represents a document heading with hierarchy info."""
    text: str
    level: int  # 1-6 for H1-H6, 0 for title
    style_name: Optional[str] = None
    font_size: Optional[float] = None
    position: int = 0  # Position in document (paragraph index)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "level": self.level,
            "style_name": self.style_name,
            "font_size": self.font_size,
            "position": self.position,
        }


@dataclass
class Section:
    """Represents a document section with heading and content."""
    heading: Optional[HeadingInfo]
    content: str
    level: int
    subsections: List["Section"] = field(default_factory=list)
    tables: List[TableData] = field(default_factory=list)
    
    def get_full_text(self) -> str:
        """Get full text including heading and all subsections."""
        parts = []
        if self.heading:
            parts.append(self.heading.text)
        parts.append(self.content)
        for sub in self.subsections:
            parts.append(sub.get_full_text())
        return "\n\n".join(parts)


@dataclass
class DocumentFeatures:
    """Comprehensive document feature representation."""
    file_path: str
    file_name: str
    file_type: str  # "docx" or "pdf"
    file_size: int
    
    # Content
    full_text: str
    clean_text: str  # Preprocessed text
    
    # Structure
    headings: List[HeadingInfo]
    sections: List[Section]
    
    # Tables
    tables: List[TableData]
    table_count: int
    
    # Layout
    page_count: int
    paragraph_count: int
    average_paragraph_length: float
    font_info: Dict[str, Any]
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Content chunks for embedding
    content_chunks: List[str] = field(default_factory=list)
    heading_chunks: List[str] = field(default_factory=list)
    structure_signature: str = ""  # Structural fingerprint
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "file_path": self.file_path,
            "file_name": self.file_name,
            "file_type": self.file_type,
            "file_size": self.file_size,
            "headings": [h.to_dict() for h in self.headings],
            "table_count": self.table_count,
            "page_count": self.page_count,
            "paragraph_count": self.paragraph_count,
            "average_paragraph_length": self.average_paragraph_length,
            "font_info": self.font_info,
            "metadata": self.metadata,
            "structure_signature": self.structure_signature,
        }


class BaseParser(ABC):
    """Abstract base class for document parsers."""
    
    @abstractmethod
    def parse(self, file_path: Path) -> DocumentFeatures:
        """Parse a document and return extracted features."""
        pass
    
    @abstractmethod
    def supports(self, file_path: Path) -> bool:
        """Check if this parser supports the given file."""
        pass


class DocxParser(BaseParser):
    """Parser for Microsoft Word documents (.docx)."""
    
    def __init__(self, config: Optional[DocumentConfig] = None):
        self.config = config or get_config().document
    
    def supports(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in self.config.supported_docx_extensions
    
    def parse(self, file_path: Path) -> DocumentFeatures:
        """Parse a DOCX file and extract all features."""
        doc = Document(str(file_path))
        
        # Extract headings
        headings = self._extract_headings(doc)
        
        # Extract tables
        tables = self._extract_tables(doc)
        
        # Extract paragraphs and build sections
        paragraphs = doc.paragraphs
        full_text = "\n".join(p.text for p in paragraphs)
        
        # Build hierarchical sections
        sections = self._build_sections(doc, headings)
        
        # Extract font information
        font_info = self._extract_font_info(doc)
        
        # Generate structure signature
        structure_signature = self._generate_structure_signature(headings, tables)
        
        # Generate content chunks
        content_chunks = self._create_content_chunks(full_text, sections)
        heading_chunks = self._create_heading_chunks(headings)
        
        return DocumentFeatures(
            file_path=str(file_path),
            file_name=file_path.name,
            file_type="docx",
            file_size=file_path.stat().st_size,
            full_text=full_text,
            clean_text=self._preprocess_text(full_text),
            headings=headings,
            sections=sections,
            tables=tables,
            table_count=len(tables),
            page_count=len(doc.sections),
            paragraph_count=len(paragraphs),
            average_paragraph_length=len(full_text) / max(len(paragraphs), 1),
            font_info=font_info,
            metadata=self._extract_metadata(doc),
            content_chunks=content_chunks,
            heading_chunks=heading_chunks,
            structure_signature=structure_signature,
        )
    
    def _extract_headings(self, doc: Document) -> List[HeadingInfo]:
        """Extract all headings from the document with hierarchy."""
        headings = []
        position = 0
        
        for para in doc.paragraphs:
            style_name = para.style.name if para.style else ""
            
            # Check if paragraph is a heading
            is_heading = False
            level = 0
            
            if style_name in self.config.heading_styles:
                # Map style name to level
                if "Title" in style_name:
                    level = 0
                else:
                    # Extract number from "Heading X"
                    match = re.search(r'Heading\s+(\d+)', style_name)
                    if match:
                        level = int(match.group(1))
                    else:
                        level = 1
                is_heading = True
            
            # Also check font size for heading detection
            if not is_heading and para.runs:
                font_size = None
                for run in para.runs:
                    if run.font.size:
                        font_size = run.font.size.pt if run.font.size else None
                        break
                
                if font_size and font_size >= self.config.heading_font_sizes.get("h3", 12.0):
                    is_heading = True
                    if font_size >= self.config.heading_font_sizes.get("title", 18.0):
                        level = 0
                    elif font_size >= self.config.heading_font_sizes.get("h1", 16.0):
                        level = 1
                    elif font_size >= self.config.heading_font_sizes.get("h2", 14.0):
                        level = 2
                    else:
                        level = 3
            
            if is_heading and para.text.strip():
                headings.append(HeadingInfo(
                    text=para.text.strip(),
                    level=level,
                    style_name=style_name,
                    font_size=font_size if 'font_size' in locals() else None,
                    position=position,
                ))
            
            position += 1
        
        return headings
    
    def _extract_tables(self, doc: Document) -> List[TableData]:
        """Extract all tables from the document."""
        tables = []
        
        for table in doc.tables:
            content = []
            for row in table.rows:
                row_data = [cell.text.strip() for cell in row.cells]
                content.append(row_data)
            
            if content:
                tables.append(TableData(
                    content=content,
                    row_count=len(content),
                    col_count=max(len(row) for row in content),
                ))
        
        return tables
    
    def _build_sections(self, doc: Document, headings: List[HeadingInfo]) -> List[Section]:
        """Build hierarchical sections from document structure."""
        if not headings:
            # No headings found, treat entire document as one section
            content = "\n".join(p.text for p in doc.paragraphs)
            return [Section(heading=None, content=content, level=0)]
        
        sections = []
        current_section = None
        section_stack = []
        
        paragraphs = doc.paragraphs
        heading_idx = 0
        current_content = []
        
        for i, para in enumerate(paragraphs):
            if heading_idx < len(headings) and headings[heading_idx].position == i:
                # Save previous section content
                if current_section is not None:
                    current_section.content = "\n".join(current_content)
                    current_content = []
                
                # Create new section for this heading
                heading = headings[heading_idx]
                new_section = Section(
                    heading=heading,
                    content="",
                    level=heading.level,
                )
                
                # Manage hierarchy
                while section_stack and section_stack[-1].level >= heading.level:
                    section_stack.pop()
                
                if section_stack:
                    section_stack[-1].subsections.append(new_section)
                else:
                    sections.append(new_section)
                
                section_stack.append(new_section)
                current_section = new_section
                heading_idx += 1
            else:
                if para.text.strip():
                    current_content.append(para.text)
        
        # Save last section content
        if current_section is not None:
            current_section.content = "\n".join(current_content)
        
        return sections if sections else [Section(heading=None, content="\n".join(p.text for p in paragraphs), level=0)]
    
    def _extract_font_info(self, doc: Document) -> Dict[str, Any]:
        """Extract font usage information."""
        fonts = {}
        font_sizes = []
        
        for para in doc.paragraphs:
            for run in para.runs:
                if run.font.name:
                    fonts[run.font.name] = fonts.get(run.font.name, 0) + 1
                if run.font.size:
                    font_sizes.append(run.font.size.pt)
        
        return {
            "used_fonts": fonts,
            "dominant_font": max(fonts, key=fonts.get) if fonts else None,
            "average_font_size": sum(font_sizes) / len(font_sizes) if font_sizes else None,
            "font_size_range": (min(font_sizes), max(font_sizes)) if font_sizes else None,
        }
    
    def _extract_metadata(self, doc: Document) -> Dict[str, Any]:
        """Extract document metadata."""
        core_props = doc.core_properties
        return {
            "title": core_props.title,
            "author": core_props.author,
            "created": str(core_props.created) if core_props.created else None,
            "modified": str(core_props.modified) if core_props.modified else None,
            "subject": core_props.subject,
        }
    
    def _preprocess_text(self, text: str) -> str:
        """Clean and preprocess text."""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep structure
        text = re.sub(r'[^\w\s\.\,\;\:\-\(\)\[\]\{\}\/\|\\]', '', text)
        return text.strip()
    
    def _generate_structure_signature(self, headings: List[HeadingInfo], tables: List[TableData]) -> str:
        """Generate a structural fingerprint of the document."""
        parts = []
        
        # Add heading hierarchy
        for h in headings:
            parts.append(f"H{h.level}:{h.text[:30]}")
        
        # Add table signatures
        for t in tables:
            header = "|".join(t.content[0]) if t.content else ""
            parts.append(f"T[{t.row_count}x{t.col_count}]:{header[:30]}")
        
        return "; ".join(parts)
    
    def _create_content_chunks(self, full_text: str, sections: List[Section]) -> List[str]:
        """Create semantic chunks from document content."""
        chunks = []
        max_size = self.config.max_chunk_size
        overlap = self.config.chunk_overlap
        
        # First, try section-based chunking
        for section in sections:
            section_text = section.get_full_text()
            if len(section_text) <= max_size:
                chunks.append(section_text)
            else:
                # Split section into smaller chunks
                words = section_text.split()
                current_chunk = []
                current_length = 0
                
                for word in words:
                    current_chunk.append(word)
                    current_length += len(word) + 1
                    
                    if current_length >= max_size:
                        chunks.append(" ".join(current_chunk))
                        # Keep overlap words
                        overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                        current_chunk = overlap_words[:]
                        current_length = sum(len(w) + 1 for w in current_chunk)
                
                if current_chunk:
                    chunks.append(" ".join(current_chunk))
        
        # If no chunks from sections, use sliding window on full text
        if not chunks:
            words = full_text.split()
            current_chunk = []
            current_length = 0
            
            for word in words:
                current_chunk.append(word)
                current_length += len(word) + 1
                
                if current_length >= max_size:
                    chunks.append(" ".join(current_chunk))
                    overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                    current_chunk = overlap_words[:]
                    current_length = sum(len(w) + 1 for w in current_chunk)
            
            if current_chunk:
                chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def _create_heading_chunks(self, headings: List[HeadingInfo]) -> List[str]:
        """Create chunks from heading hierarchy."""
        chunks = []
        for h in headings:
            chunks.append(f"Heading Level {h.level}: {h.text}")
        return chunks


class PDFParser(BaseParser):
    """Parser for PDF documents using PyMuPDF and pdfplumber."""
    
    def __init__(self, config: Optional[DocumentConfig] = None):
        self.config = config or get_config().document
    
    def supports(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in self.config.supported_pdf_extensions
    
    def parse(self, file_path: Path) -> DocumentFeatures:
        """Parse a PDF file and extract all features."""
        # Use both libraries for comprehensive extraction
        fitz_features = self._parse_with_fitz(file_path)
        plumber_features = self._parse_with_plumber(file_path)
        
        # Merge features (prioritize pdfplumber for text, fitz for layout)
        full_text = plumber_features.get("text", "") or fitz_features.get("text", "")
        headings = self._extract_headings_from_text(full_text)
        tables = plumber_features.get("tables", [])
        
        # Build sections
        sections = self._build_sections_from_headings(full_text, headings)
        
        # Extract font info
        font_info = fitz_features.get("font_info", {})
        
        # Generate structure signature
        structure_signature = self._generate_structure_signature(headings, tables)
        
        # Create chunks
        content_chunks = self._create_content_chunks(full_text, sections)
        heading_chunks = self._create_heading_chunks(headings)
        
        # Get page count
        page_count = fitz_features.get("page_count", 0)
        
        # Count paragraphs
        paragraphs = [p for p in full_text.split('\n') if p.strip()]
        
        return DocumentFeatures(
            file_path=str(file_path),
            file_name=file_path.name,
            file_type="pdf",
            file_size=file_path.stat().st_size,
            full_text=full_text,
            clean_text=self._preprocess_text(full_text),
            headings=headings,
            sections=sections,
            tables=tables,
            table_count=len(tables),
            page_count=page_count,
            paragraph_count=len(paragraphs),
            average_paragraph_length=len(full_text) / max(len(paragraphs), 1),
            font_info=font_info,
            metadata=fitz_features.get("metadata", {}),
            content_chunks=content_chunks,
            heading_chunks=heading_chunks,
            structure_signature=structure_signature,
        )
    
    def _parse_with_fitz(self, file_path: Path) -> Dict[str, Any]:
        """Parse PDF using PyMuPDF for layout and font info."""
        doc = fitz.open(str(file_path))
        
        text_parts = []
        font_info = {"used_fonts": {}, "dominant_font": None}
        
        for page in doc:
            text_parts.append(page.get_text())
            
            # Extract font information
            blocks = page.get_text("dict")["blocks"]
            for block in blocks:
                if "lines" in block:
                    for line in block["lines"]:
                        for span in line["spans"]:
                            font_name = span.get("font", "Unknown")
                            font_info["used_fonts"][font_name] = font_info["used_fonts"].get(font_name, 0) + 1
        
        if font_info["used_fonts"]:
            font_info["dominant_font"] = max(font_info["used_fonts"], key=font_info["used_fonts"].get)
        
        metadata = {
            "title": doc.metadata.get("title", ""),
            "author": doc.metadata.get("author", ""),
            "subject": doc.metadata.get("subject", ""),
            "creator": doc.metadata.get("creator", ""),
        }
        
        return {
            "text": "\n".join(text_parts),
            "page_count": len(doc),
            "font_info": font_info,
            "metadata": metadata,
        }
    
    def _parse_with_plumber(self, file_path: Path) -> Dict[str, Any]:
        """Parse PDF using pdfplumber for tables and structured content."""
        text_parts = []
        tables = []
        
        with pdfplumber.open(str(file_path)) as pdf:
            for page in pdf.pages:
                # Extract text
                text = page.extract_text()
                if text:
                    text_parts.append(text)
                
                # Extract tables
                page_tables = page.extract_tables()
                for table_data in page_tables:
                    if table_data:
                        tables.append(TableData(
                            content=table_data,
                            row_count=len(table_data),
                            col_count=max(len(row) for row in table_data),
                        ))
        
        return {
            "text": "\n\n".join(text_parts),
            "tables": tables,
        }
    
    def _extract_headings_from_text(self, text: str) -> List[HeadingInfo]:
        """Extract headings from PDF text using heuristics."""
        headings = []
        lines = text.split('\n')
        position = 0
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            is_heading = False
            level = 1
            
            # Heuristic 1: Short lines in ALL CAPS
            if line.isupper() and len(line) < 100 and len(line.split()) < 10:
                is_heading = True
                level = 1 if len(line) < 50 else 2
            
            # Heuristic 2: Lines ending with numbers (section numbering)
            elif re.match(r'^\d+(\.\d+)*\s+', line):
                is_heading = True
                match = re.match(r'^(\d+(?:\.\d+)*)', line)
                if match:
                    parts = match.group(1).split('.')
                    level = min(len(parts), 6)
            
            # Heuristic 3: Lines starting with Roman numerals
            elif re.match(r'^[IVX]+[.\)]\s+', line):
                is_heading = True
                level = 1
            
            # Heuristic 4: Lines with common heading patterns
            elif re.match(r'^(Chapter|Section|Part|Appendix)\s+\d+', line, re.IGNORECASE):
                is_heading = True
                level = 1
            
            if is_heading:
                headings.append(HeadingInfo(
                    text=line,
                    level=level,
                    style_name="PDF_Extracted",
                    position=position,
                ))
            
            position += 1
        
        return headings
    
    def _build_sections_from_headings(self, text: str, headings: List[HeadingInfo]) -> List[Section]:
        """Build sections from extracted headings and text."""
        if not headings:
            return [Section(heading=None, content=text, level=0)]
        
        sections = []
        lines = text.split('\n')
        heading_positions = {h.position: h for h in headings}
        
        current_content = []
        current_section = None
        section_stack = []
        
        for i, line in enumerate(lines):
            if i in heading_positions:
                # Save previous section
                if current_section is not None:
                    current_section.content = "\n".join(current_content)
                    current_content = []
                
                heading = heading_positions[i]
                new_section = Section(
                    heading=heading,
                    content="",
                    level=heading.level,
                )
                
                while section_stack and section_stack[-1].level >= heading.level:
                    section_stack.pop()
                
                if section_stack:
                    section_stack[-1].subsections.append(new_section)
                else:
                    sections.append(new_section)
                
                section_stack.append(new_section)
                current_section = new_section
            else:
                if line.strip():
                    current_content.append(line)
        
        if current_section is not None:
            current_section.content = "\n".join(current_content)
        
        return sections if sections else [Section(heading=None, content=text, level=0)]
    
    def _preprocess_text(self, text: str) -> str:
        """Clean and preprocess text."""
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s\.\,\;\:\-\(\)\[\]\{\}\/\|\\]', '', text)
        return text.strip()
    
    def _generate_structure_signature(self, headings: List[HeadingInfo], tables: List[TableData]) -> str:
        """Generate a structural fingerprint of the document."""
        parts = []
        for h in headings:
            parts.append(f"H{h.level}:{h.text[:30]}")
        for t in tables:
            header = "|".join(t.content[0]) if t.content else ""
            parts.append(f"T[{t.row_count}x{t.col_count}]:{header[:30]}")
        return "; ".join(parts)
    
    def _create_content_chunks(self, full_text: str, sections: List[Section]) -> List[str]:
        """Create semantic chunks from document content."""
        chunks = []
        max_size = self.config.max_chunk_size
        overlap = self.config.chunk_overlap
        
        for section in sections:
            section_text = section.get_full_text()
            if len(section_text) <= max_size:
                chunks.append(section_text)
            else:
                words = section_text.split()
                current_chunk = []
                current_length = 0
                
                for word in words:
                    current_chunk.append(word)
                    current_length += len(word) + 1
                    
                    if current_length >= max_size:
                        chunks.append(" ".join(current_chunk))
                        overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                        current_chunk = overlap_words[:]
                        current_length = sum(len(w) + 1 for w in current_chunk)
                
                if current_chunk:
                    chunks.append(" ".join(current_chunk))
        
        if not chunks:
            words = full_text.split()
            current_chunk = []
            current_length = 0
            
            for word in words:
                current_chunk.append(word)
                current_length += len(word) + 1
                
                if current_length >= max_size:
                    chunks.append(" ".join(current_chunk))
                    overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                    current_chunk = overlap_words[:]
                    current_length = sum(len(w) + 1 for w in current_chunk)
            
            if current_chunk:
                chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def _create_heading_chunks(self, headings: List[HeadingInfo]) -> List[str]:
        """Create chunks from heading hierarchy."""
        chunks = []
        for h in headings:
            chunks.append(f"Heading Level {h.level}: {h.text}")
        return chunks


class DocumentParser:
    """Main document parser that routes to appropriate parser."""
    
    def __init__(self, config: Optional[DocumentConfig] = None):
        self.config = config or get_config().document
        self.parsers = [
            DocxParser(self.config),
            PDFParser(self.config),
        ]
    
    def parse(self, file_path: Union[str, Path]) -> DocumentFeatures:
        """
        Parse a document and return comprehensive features.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            DocumentFeatures with all extracted information
            
        Raises:
            ValueError: If file type is not supported
            FileNotFoundError: If file does not exist
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        for parser in self.parsers:
            if parser.supports(file_path):
                return parser.parse(file_path)
        
        raise ValueError(
            f"Unsupported file type: {file_path.suffix}. "
            f"Supported types: {self.config.supported_extensions}"
        )
    
    def parse_directory(self, directory: Union[str, Path], recursive: bool = True) -> List[DocumentFeatures]:
        """
        Parse all documents in a directory.
        
        Args:
            directory: Directory path
            recursive: Whether to search recursively
            
        Returns:
            List of DocumentFeatures for all parsed documents
        """
        directory = Path(directory)
        features_list = []
        
        pattern = "**/*" if recursive else "*"
        
        for ext in self.config.supported_extensions:
            for file_path in directory.glob(f"{pattern}{ext}"):
                try:
                    features = self.parse(file_path)
                    features_list.append(features)
                except Exception as e:
                    print(f"Error parsing {file_path}: {e}")
        
        return features_list
    
    def supports_file(self, file_path: Union[str, Path]) -> bool:
        """Check if a file is supported."""
        file_path = Path(file_path)
        return file_path.suffix.lower() in self.config.supported_extensions
