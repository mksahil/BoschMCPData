"""
Vector Database Module
Manages vector storage and similarity search using FAISS.
Supports multiple index types and persistent storage.
"""

import pickle
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import faiss

from template_matcher.config import get_config, VectorStoreConfig


logger = logging.getLogger(__name__)


class VectorStore:
    """
    FAISS-based vector database for efficient similarity search.
    Supports multiple index types and metadata storage.
    """
    
    def __init__(self, config: Optional[VectorStoreConfig] = None):
        self.config = config or get_config().vector_store
        self.index: Optional[faiss.Index] = None
        self.metadata: Dict[int, Dict[str, Any]] = {}
        self.embedding_dim: Optional[int] = None
        self._id_counter: int = 0
    
    def _create_index(self, dim: int) -> faiss.Index:
        """
        Create a FAISS index based on configuration.
        """
        metric = self._get_metric()
        index_type = self.config.index_type.upper()
    
        if index_type == "FLAT":
           base_index = faiss.IndexFlatIP(dim) if metric == faiss.METRIC_INNER_PRODUCT else faiss.IndexFlatL2(dim)
           index = faiss.IndexIDMap(base_index)  # ✅ Wrap with IDMap
    
        elif index_type == "IVF":
            quantizer = faiss.IndexFlatL2(dim)
            nlist = min(self.config.ivf_nlist, max(1, self._id_counter // 39))
            base_index = faiss.IndexIVFFlat(quantizer, dim, nlist, metric)
            index = faiss.IndexIDMap(base_index)  # ✅ Wrap with IDMap
            self._needs_training = True
    
        elif index_type == "IVFPQ":
            quantizer = faiss.IndexFlatL2(dim)
            nlist = min(self.config.ivf_nlist, max(1, self._id_counter // 39))
            base_index = faiss.IndexIVFPQ(
            quantizer, dim, nlist,
            self.config.pq_nbits, 8,
            metric,
            )
            index = faiss.IndexIDMap(base_index)  # ✅ Wrap with IDMap
            self._needs_training = True
    
        elif index_type == "HNSW":
            base_index = faiss.IndexHNSWFlat(dim, self.config.hnsw_m, metric)
            base_index.hnsw.efConstruction = self.config.hnsw_ef_construction
            base_index.hnsw.efSearch = self.config.hnsw_ef_search
            index = faiss.IndexIDMap(base_index)  # ✅ Wrap with IDMap
    
        else:
            logger.warning(f"Unknown index type {index_type}, using Flat")
            base_index = faiss.IndexFlatL2(dim)
            index = faiss.IndexIDMap(base_index)  # ✅ Wrap with IDMap
    
        return index
    
    def _get_metric(self) -> int:
        """Get FAISS metric constant from config."""
        metric_map = {
            "cosine": faiss.METRIC_INNER_PRODUCT,  # Use IP with normalized vectors
            "l2": faiss.METRIC_L2,
            "inner_product": faiss.METRIC_INNER_PRODUCT,
        }
        return metric_map.get(self.config.distance_metric.lower(), faiss.METRIC_INNER_PRODUCT)
    
    def add_vectors(
        self,
        vectors: np.ndarray,
        metadata: Optional[List[Dict[str, Any]]] = None,
        ) -> List[int]:
        """
        Add vectors to the index.
        
        Args:
            vectors: Array of shape [n_vectors, dim]
            metadata: Optional list of metadata dicts for each vector
            
        Returns:
            List of assigned IDs
        """
        if vectors.ndim == 1:
            vectors = vectors.reshape(1, -1)
        
        n_vectors, dim = vectors.shape
        
        # Initialize index if needed
        if self.index is None:
            self.embedding_dim = dim
            self.index = self._create_index(dim)
            self._needs_training = False
        
        # Check dimension
        if dim != self.embedding_dim:
            raise ValueError(f"Dimension mismatch: expected {self.embedding_dim}, got {dim}")
        
        # Normalize for cosine similarity
        if self.config.distance_metric.lower() == "cosine":
            norms = np.linalg.norm(vectors, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1, norms)
            vectors = vectors / norms
        
        # Train if needed (for IVF indexes)
        if hasattr(self, '_needs_training') and self._needs_training and len(vectors) >= 100:
            self.index.train(vectors)
            self._needs_training = False
        
        # Add vectors
        ids = np.arange(self._id_counter, self._id_counter + n_vectors, dtype=np.int64)
        
        if hasattr(self.index, 'add_with_ids'):
            self.index.add_with_ids(vectors, ids)
        else:
            self.index.add(vectors)
            # For flat indexes, IDs are implicit
        
        # Store metadata
        if metadata:
            for i, meta in enumerate(metadata):
                self.metadata[int(ids[i])] = meta
        
        assigned_ids = ids.tolist()
        self._id_counter += n_vectors
        
        return assigned_ids
    
    def search(
        self,
        query: np.ndarray,
        k: int = 10,
        filter_fn: Optional[callable] = None,
        ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Search for nearest neighbors.
        
        Args:
            query: Query vector of shape [dim] or [n_queries, dim]
            k: Number of results to return
            filter_fn: Optional filter function for metadata
            
        Returns:
            Tuple of (distances, ids) arrays
        """
        if self.index is None or self.index.ntotal == 0:
            return np.array([]), np.array([])
        
        if query.ndim == 1:
            query = query.reshape(1, -1)
        
        # Normalize for cosine similarity
        if self.config.distance_metric.lower() == "cosine":
            norms = np.linalg.norm(query, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1, norms)
            query = query / norms
        
        # Search with oversampling if filtering
        search_k = k * 3 if filter_fn else k
        search_k = min(search_k, self.index.ntotal)
        
        distances, ids = self.index.search(query, search_k)
        
        # Apply metadata filter if provided
        if filter_fn:
            filtered_distances = []
            filtered_ids = []
            
            for dist_row, id_row in zip(distances, ids):
                f_dist = []
                f_ids = []
                for d, i in zip(dist_row, id_row):
                    meta = self.metadata.get(int(i), {})
                    if filter_fn(meta):
                        f_dist.append(d)
                        f_ids.append(i)
                    if len(f_dist) >= k:
                        break
                
                # Pad if needed
                while len(f_dist) < k:
                    f_dist.append(-1)
                    f_ids.append(-1)
                
                filtered_distances.append(f_dist[:k])
                filtered_ids.append(f_ids[:k])
            
            distances = np.array(filtered_distances)
            ids = np.array(filtered_ids)
        
        return distances, ids
    
    def get_metadata(self, ids: np.ndarray) -> List[Dict[str, Any]]:
        """Get metadata for given IDs."""
        return [self.metadata.get(int(i), {}) for i in ids.flatten()]
    
    def remove_vectors(self, ids: List[int]):
        """
        Remove vectors by ID.
        Note: Only supported by certain index types.
        """
        if hasattr(self.index, 'remove_ids'):
            ids_array = np.array(ids, dtype=np.int64)
            self.index.remove_ids(faiss.IDSelectorBatch(ids_array))
            for i in ids:
                self.metadata.pop(i, None)
        else:
            logger.warning("Index type does not support removal. Rebuild index instead.")
    
    def save(self, index_path: Optional[str] = None, metadata_path: Optional[str] = None):
        """
        Save index and metadata to disk.
        
        Args:
            index_path: Path for index file
            metadata_path: Path for metadata file
        """
        index_path = index_path or self.config.index_path
        metadata_path = metadata_path or self.config.metadata_path
        
        if index_path and self.index is not None:
            Path(index_path).parent.mkdir(parents=True, exist_ok=True)
            faiss.write_index(self.index, str(index_path))
            logger.info(f"Index saved to {index_path}")
        
        if metadata_path:
            Path(metadata_path).parent.mkdir(parents=True, exist_ok=True)
            with open(metadata_path, 'wb') as f:
                pickle.dump({
                    'metadata': self.metadata,
                    'id_counter': self._id_counter,
                    'embedding_dim': self.embedding_dim,
                }, f)
            logger.info(f"Metadata saved to {metadata_path}")
    
    def load(self, index_path: Optional[str] = None, metadata_path: Optional[str] = None):
        """
        Load index and metadata from disk.
        
        Args:
            index_path: Path for index file
            metadata_path: Path for metadata file
        """
        index_path = index_path or self.config.index_path
        metadata_path = metadata_path or self.config.metadata_path
        
        if index_path and Path(index_path).exists():
            self.index = faiss.read_index(str(index_path))
            self.embedding_dim = self.index.d
            logger.info(f"Index loaded from {index_path}")
        
        if metadata_path and Path(metadata_path).exists():
            with open(metadata_path, 'rb') as f:
                data = pickle.load(f)
                self.metadata = data['metadata']
                self._id_counter = data['id_counter']
                self.embedding_dim = data.get('embedding_dim', self.embedding_dim)
            logger.info(f"Metadata loaded from {metadata_path}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get index statistics."""
        return {
            "total_vectors": self.index.ntotal if self.index else 0,
            "embedding_dim": self.embedding_dim,
            "metadata_entries": len(self.metadata),
            "index_type": self.config.index_type,
            "distance_metric": self.config.distance_metric,
        }
    
    def __len__(self) -> int:
        """Return number of vectors in index."""
        return self.index.ntotal if self.index else 0


class MultiIndexVectorStore:
    """
    Manages multiple vector stores for different feature types.
    Enables type-specific similarity search.
    """
    
    def __init__(self, config: Optional[VectorStoreConfig] = None):
        self.config = config or get_config().vector_store
        self.stores: Dict[str, VectorStore] = {}
    
    def get_or_create_store(self, feature_type: str) -> VectorStore:
        """Get or create a vector store for a feature type."""
        if feature_type not in self.stores:
            store_config = VectorStoreConfig(**self.config.model_dump())
            if self.config.index_path:
                store_config.index_path = f"{self.config.index_path}_{feature_type}"
            if self.config.metadata_path:
                store_config.metadata_path = f"{self.config.metadata_path}_{feature_type}"
            
            self.stores[feature_type] = VectorStore(store_config)
        
        return self.stores[feature_type]
    
    def add_document(
        self,
        doc_id: str,
        embeddings: Dict[str, np.ndarray],
        metadata: Optional[Dict[str, Any]] = None,
        ) -> Dict[str, List[int]]:
        """
        Add a document's embeddings across all feature types.
        
        Args:
            doc_id: Document identifier
            embeddings: Dictionary of feature_type -> embeddings
            metadata: Document metadata
            
        Returns:
            Dictionary of assigned IDs per feature type
        """
        assigned_ids = {}
        
        for feature_type, vectors in embeddings.items():
            store = self.get_or_create_store(feature_type)
            
            # Add document ID to metadata
            meta_list = []
            if vectors.ndim == 1:
                n = 1
            else:
                n = vectors.shape[0]
            
            for i in range(n):
                meta = {
                    "doc_id": doc_id,
                    "feature_type": feature_type,
                    "chunk_idx": i,
                    **(metadata or {}),
                }
                meta_list.append(meta)
            
            ids = store.add_vectors(vectors, meta_list)
            assigned_ids[feature_type] = ids
        
        return assigned_ids
    
    def search(
        self,
        query_embeddings: Dict[str, np.ndarray],
        k: int = 10,
        weights: Optional[Dict[str, float]] = None,
        ) -> List[Dict[str, Any]]:
        """
        Search across all feature types and merge results.
        
        Args:
            query_embeddings: Dictionary of feature_type -> query embeddings
            k: Number of results
            weights: Feature type weights
            
        Returns:
            List of search results with scores
        """
        all_results = []
        weights = weights or {
            "content": 0.35,
            "structure": 0.25,
            "heading": 0.20,
            "layout": 0.15,
            "table": 0.05,
        }
        
        for feature_type, query in query_embeddings.items():
            if feature_type not in self.stores:
                continue
            
            store = self.stores[feature_type]
            distances, ids = store.search(query, k=k)
            
            if distances.size == 0:
                continue
            
            weight = weights.get(feature_type, 0.2)
            
            # Convert distances to scores (FAISS returns distances, lower is better)
            # For inner product, higher is better
            if store.config.distance_metric.lower() == "cosine":
                scores = distances.flatten()
            else:
                scores = 1.0 / (1.0 + distances.flatten())
            
            meta_list = store.get_metadata(ids)
            
            for score, meta in zip(scores, meta_list):
                all_results.append({
                    "doc_id": meta.get("doc_id", ""),
                    "score": float(score) * weight,
                    "feature_type": feature_type,
                    "metadata": meta,
                })
        
        # Merge results by doc_id
        merged = {}
        for result in all_results:
            doc_id = result["doc_id"]
            if doc_id not in merged:
                merged[doc_id] = {
                    "doc_id": doc_id,
                    "total_score": 0,
                    "feature_scores": {},
                    "metadata": result["metadata"],
                }
            merged[doc_id]["total_score"] += result["score"]
            merged[doc_id]["feature_scores"][result["feature_type"]] = result["score"]
        
        # Sort by total score
        sorted_results = sorted(merged.values(), key=lambda x: x["total_score"], reverse=True)
        
        return sorted_results[:k]
    
    def save(self, base_path: Optional[str] = None):
        """Save all indexes."""
        for feature_type, store in self.stores.items():
            if base_path:
                index_path = f"{base_path}_{feature_type}.index"
                meta_path = f"{base_path}_{feature_type}.pkl"
                store.save(index_path, meta_path)
            else:
                store.save()
    
    def load(self, base_path: Optional[str] = None):
        """Load all indexes."""
        for feature_type in ["content", "structure", "heading", "layout", "table"]:
            store = self.get_or_create_store(feature_type)
            if base_path:
                index_path = f"{base_path}_{feature_type}.index"
                meta_path = f"{base_path}_{feature_type}.pkl"
                store.load(index_path, meta_path)
            else:
                store.load()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics for all stores."""
        return {
            feature_type: store.get_stats()
            for feature_type, store in self.stores.items()
        }
