"""
Excel & CSV Parsing Engine
==========================
Extracts tabular structure, headers, formulas, metadata, and sheet names
from .xlsx, .xls, and .csv files.  Produces DocumentFeatures compatible
with the existing embedding and scoring pipeline.
"""

import csv
import logging
import itertools
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field

import numpy as np

from template_matcher.config import get_config, DocumentConfig
from template_matcher.document_parser import (
    DocumentFeatures, TableData, HeadingInfo, Section,
)


logger = logging.getLogger(__name__)

# Optional imports — fail gracefully if libraries not installed
try:
    import openpyxl
    from openpyxl import load_workbook
    _HAS_OPENPYXL = True
except ImportError:
    _HAS_OPENPYXL = False
    logger.warning("openpyxl not installed — .xlsx/.xls support disabled")

try:
    import xlrd
    _HAS_XLRD = True
except ImportError:
    _HAS_XLRD = False
    logger.debug("xlrd not installed — legacy .xls support disabled")


@dataclass
class ExcelSheetInfo:
    """Metadata about a single Excel sheet."""
    name: str
    row_count: int
    col_count: int
    header_row: Optional[List[str]] = None
    formulas: List[str] = field(default_factory=list)
    merged_cells: List[str] = field(default_factory=list)


class ExcelParser:
    """
    Unified parser for Excel (.xlsx, .xls) and CSV files.
    Produces DocumentFeatures so Excel files flow through the same
    embedding + scoring pipeline as DOCX and PDF.
    """

    SUPPORTED_EXTENSIONS = {".xlsx", ".xls", ".csv"}

    def __init__(self, config: Optional[DocumentConfig] = None):
        self.config = config or get_config().document

    # ── dispatcher ──────────────────────────────────────────────────────────

    def parse(self, file_path: Path) -> DocumentFeatures:
        """Parse an Excel or CSV file into DocumentFeatures."""
        ext = file_path.suffix.lower()
        t0 = logger.isEnabledFor(logging.DEBUG)

        if ext == ".csv":
            features = self._parse_csv(file_path)
        elif ext == ".xls" and _HAS_XLRD:
            features = self._parse_xls(file_path)
        elif ext in (".xlsx", ".xls") and _HAS_OPENPYXL:
            features = self._parse_xlsx(file_path)
        else:
            raise ValueError(
                f"Cannot parse {ext}: required libraries not installed. "
                f"Run: pip install openpyxl xlrd"
            )

        logger.info(
            "Parsed Excel/CSV  %s  →  %d chars, %d sheets/tables, %d headings",
            file_path.name,
            len(features.full_text),
            features.table_count,
            len(features.headings),
        )
        return features

    def supports(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in self.SUPPORTED_EXTENSIONS

    # ── .xlsx parser (openpyxl) ─────────────────────────────────────────────

    def _parse_xlsx(self, file_path: Path) -> DocumentFeatures:
        wb = load_workbook(str(file_path), data_only=False)
        all_text_parts: List[str] = []
        tables: List[TableData] = []
        headings: List[HeadingInfo] = []
        sheet_infos: List[ExcelSheetInfo] = []
        all_formulas: List[str] = []

        # First pass — extract sheet names as headings
        for idx, sheet_name in enumerate(wb.sheetnames):
            headings.append(HeadingInfo(
                text=sheet_name,
                level=1,
                style_name="Sheet",
                position=idx,
            ))

        # Second pass — extract content from each sheet
        for sheet in wb.worksheets:
            if sheet.max_row == 0:
                continue

            sheet_header = None
            formulas: List[str] = []
            rows_data: List[List[str]] = []

            for row in sheet.iter_rows(
                min_row=1, max_row=sheet.max_row,
                max_col=sheet.max_column,
                values_only=False,
            ):
                row_vals: List[str] = []
                for cell in row:
                    val = cell.value
                    if val is None:
                        row_vals.append("")
                    else:
                        row_vals.append(str(val))
                        # Capture formulas
                        if cell.data_type == "f":
                            formulas.append(str(val))
                rows_data.append(row_vals)

            if not rows_data:
                continue

            # Detect header row (first non-empty row)
            header_row = next(
                (r for r in rows_data if any(cell.strip() for cell in r)),
                None,
            )
            if header_row:
                sheet_header = [c.strip() for c in header_row if c.strip()]

            # Build sheet text representation
            sheet_text = f"\n--- Sheet: {sheet.title} ---\n"
            for r in rows_data:
                line = " | ".join(c for c in r if c)
                if line:
                    sheet_text += line + "\n"
            all_text_parts.append(sheet_text)

            # Create TableData
            if rows_data:
                tables.append(TableData(
                    content=rows_data,
                    row_count=len(rows_data),
                    col_count=max(len(r) for r in rows_data),
                    text_representation=sheet_text,
                ))

            # Collect sheet metadata
            merged = [str(mc) for mc in sheet.merged_cells.ranges]
            sheet_infos.append(ExcelSheetInfo(
                name=sheet.title,
                row_count=sheet.max_row,
                col_count=sheet.max_column,
                header_row=sheet_header,
                formulas=formulas,
                merged_cells=merged,
            ))
            all_formulas.extend(formulas)

        # Build sections (one per sheet)
        sections = self._build_sections_from_sheets(sheet_infos, all_text_parts)

        full_text = "\n".join(all_text_parts)
        clean_text = self._clean_text(full_text)

        # Extract column headers as additional headings
        for si in sheet_infos:
            if si.header_row:
                for h in si.header_row:
                    headings.append(HeadingInfo(
                        text=h,
                        level=2,
                        style_name="ColumnHeader",
                    ))

        # Font / metadata
        font_info = self._extract_xlsx_metadata(wb, file_path)

        return DocumentFeatures(
            file_path=str(file_path),
            file_name=file_path.name,
            file_type="xlsx",
            file_size=file_path.stat().st_size,
            full_text=full_text,
            clean_text=clean_text,
            headings=headings,
            sections=sections,
            tables=tables,
            table_count=len(tables),
            page_count=len(wb.sheetnames),
            paragraph_count=sum(si.row_count for si in sheet_infos),
            average_paragraph_length=len(full_text) / max(sum(si.row_count for si in sheet_infos), 1),
            font_info=font_info,
            metadata={
                "sheet_names": wb.sheetnames,
                "sheet_count": len(wb.sheetnames),
                "formula_count": len(all_formulas),
                "sample_formulas": all_formulas[:10],
            },
            content_chunks=self._create_chunks(full_text),
            heading_chunks=[h.text for h in headings],
            structure_signature=self._generate_signature(sheet_infos),
        )

    # ── .xls parser (xlrd) ──────────────────────────────────────────────────

    def _parse_xls(self, file_path: Path) -> DocumentFeatures:
        if not _HAS_XLRD:
            raise ImportError("xlrd is required for .xls files.  Run: pip install xlrd")

        wb = xlrd.open_workbook(str(file_path), formatting_info=True)
        all_text_parts: List[str] = []
        tables: List[TableData] = []
        headings: List[HeadingInfo] = []
        sheet_infos: List[ExcelSheetInfo] = []

        for idx, sheet_name in enumerate(wb.sheet_names()):
            headings.append(HeadingInfo(
                text=sheet_name, level=1, style_name="Sheet", position=idx,
            ))

        for sheet_idx in range(wb.nsheets):
            sheet = wb.sheet_by_index(sheet_idx)
            if sheet.nrows == 0:
                continue

            rows_data: List[List[str]] = []
            for row_idx in range(sheet.nrows):
                row_vals = [str(sheet.cell_value(row_idx, c)) for c in range(sheet.ncols)]
                rows_data.append(row_vals)

            sheet_text = f"\n--- Sheet: {sheet.name} ---\n"
            for r in rows_data:
                line = " | ".join(c for c in r if c)
                if line:
                    sheet_text += line + "\n"
            all_text_parts.append(sheet_text)

            if rows_data:
                tables.append(TableData(
                    content=rows_data,
                    row_count=len(rows_data),
                    col_count=max(len(r) for r in rows_data),
                    text_representation=sheet_text,
                ))

            header_row = next(
                (r for r in rows_data if any(c.strip() for c in r)), None
            )
            sheet_infos.append(ExcelSheetInfo(
                name=sheet.name,
                row_count=sheet.nrows,
                col_count=sheet.ncols,
                header_row=[c.strip() for c in header_row] if header_row else None,
            ))

        sections = self._build_sections_from_sheets(sheet_infos, all_text_parts)
        full_text = "\n".join(all_text_parts)

        return DocumentFeatures(
            file_path=str(file_path),
            file_name=file_path.name,
            file_type="xls",
            file_size=file_path.stat().st_size,
            full_text=full_text,
            clean_text=self._clean_text(full_text),
            headings=headings,
            sections=sections,
            tables=tables,
            table_count=len(tables),
            page_count=wb.nsheets,
            paragraph_count=sum(si.row_count for si in sheet_infos),
            average_paragraph_length=len(full_text) / max(sum(si.row_count for si in sheet_infos), 1),
            font_info={"used_fonts": {}, "dominant_font": None},
            metadata={
                "sheet_names": wb.sheet_names(),
                "sheet_count": wb.nsheets,
            },
            content_chunks=self._create_chunks(full_text),
            heading_chunks=[h.text for h in headings],
            structure_signature=self._generate_signature(sheet_infos),
        )

    # ── .csv parser ─────────────────────────────────────────────────────────

    def _parse_csv(self, file_path: Path) -> DocumentFeatures:
        rows_data: List[List[str]] = []
        all_text_parts: List[str] = []

        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            for row in reader:
                cleaned = [c.strip() for c in row]
                rows_data.append(cleaned)

        # Detect header
        header_row = next(
            (r for r in rows_data if any(c for c in r)), None
        )
        header_vals = [c for c in header_row if c] if header_row else []

        # Build text
        text_lines = []
        for r in rows_data:
            line = " | ".join(c for c in r if c)
            if line:
                text_lines.append(line)
        full_text = "\n".join(text_lines)

        # Headings from header row
        headings = []
        if header_vals:
            headings.append(HeadingInfo(
                text=f"CSV Header: {', '.join(header_vals[:10])}",
                level=1,
                style_name="CSV_Header",
            ))

        # Single table
        tables = []
        if rows_data:
            tables.append(TableData(
                content=rows_data,
                row_count=len(rows_data),
                col_count=max(len(r) for r in rows_data),
                text_representation=full_text,
            ))

        sections = [
            Section(
                heading=headings[0] if headings else None,
                content=full_text,
                level=0,
            )
        ]

        return DocumentFeatures(
            file_path=str(file_path),
            file_name=file_path.name,
            file_type="csv",
            file_size=file_path.stat().st_size,
            full_text=full_text,
            clean_text=self._clean_text(full_text),
            headings=headings,
            sections=sections,
            tables=tables,
            table_count=len(tables),
            page_count=1,
            paragraph_count=len(rows_data),
            average_paragraph_length=len(full_text) / max(len(rows_data), 1),
            font_info={"used_fonts": {}, "dominant_font": None},
            metadata={
                "header_row": header_vals,
                "row_count": len(rows_data),
                "col_count": max(len(r) for r in rows_data) if rows_data else 0,
            },
            content_chunks=self._create_chunks(full_text),
            heading_chunks=[h.text for h in headings],
            structure_signature=f"CSV:{len(rows_data)}x{max(len(r) for r in rows_data) if rows_data else 0}",
        )

    # ── helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _clean_text(text: str) -> str:
        import re
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    @staticmethod
    def _create_chunks(text: str, max_size: int = 512, overlap: int = 128) -> List[str]:
        chunks = []
        words = text.split()
        current = []
        length = 0
        for word in words:
            current.append(word)
            length += len(word) + 1
            if length >= max_size:
                chunks.append(" ".join(current))
                overlap_words = current[-overlap:] if len(current) > overlap else current
                current = overlap_words[:]
                length = sum(len(w) + 1 for w in current)
        if current:
            chunks.append(" ".join(current))
        return chunks

    @staticmethod
    def _build_sections_from_sheets(
        sheet_infos: List[ExcelSheetInfo],
        text_parts: List[str],
    ) -> List[Section]:
        sections = []
        for si, text in zip(sheet_infos, text_parts):
            heading = HeadingInfo(text=f"Sheet: {si.name}", level=1, style_name="Sheet")
            sections.append(Section(heading=heading, content=text, level=1))
        if not sections:
            sections.append(Section(heading=None, content="\n".join(text_parts), level=0))
        return sections

    @staticmethod
    def _generate_signature(sheet_infos: List[ExcelSheetInfo]) -> str:
        parts = []
        for si in sheet_infos:
            hdr = "|".join(si.header_row[:5]) if si.header_row else "no_header"
            parts.append(f"S[{si.name}:{si.row_count}x{si.col_count}:{hdr}]")
        return "; ".join(parts)

    @staticmethod
    def _extract_xlsx_metadata(wb: Any, file_path: Path) -> Dict[str, Any]:
        props = wb.properties
        return {
            "used_fonts": {},
            "dominant_font": None,
            "creator": props.creator,
            "title": props.title,
            "created": str(props.created) if props.created else None,
            "modified": str(props.modified) if props.modified else None,
        }