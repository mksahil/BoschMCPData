#!/usr/bin/env python3
"""
Template Document Matching System v2 — Runner Script
=====================================================
Usage:
    python run_matching_v2.py --templates ./Templates --documents ./Folder_A --output ./output
    python run_matching_v2.py --templates ./Templates --document ./file.xlsx --output ./output
    python run_matching_v2.py --templates ./Templates --documents ./Folder_A --log-level DEBUG
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import Optional

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from template_matcher.config import get_config
from template_matcher.pipeline_logger import setup_logging, set_correlation_id
from template_matcher.matcher_pipeline import TemplateMatchingPipeline, PipelineConfig


def create_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="GenAI Template Document Matching System v2",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Index templates and match all documents
  python run_matching_v2.py -t ./Templates -d ./Folder_A -o ./output

  # Match a single Excel file
  python run_matching_v2.py -t ./Templates -f ./data/report.xlsx -o ./output

  # Debug logging with correlation tracking
  python run_matching_v2.py -t ./Templates -d ./Folder_A --log-level DEBUG

  # Disable LLM (faster, no API key)
  python run_matching_v2.py -t ./Templates -d ./Folder_A --no-llm

  # Save and reuse index
  python run_matching_v2.py -t ./Templates --save-index ./index.faiss
  python run_matching_v2.py -d ./Folder_A --load-index ./index.faiss
        """,
    )

    parser.add_argument("-t", "--templates", help="Directory containing template documents")

    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument("-d", "--documents", help="Directory containing documents to match")
    input_group.add_argument("-f", "--document", help="Single document to match")

    parser.add_argument("-o", "--output", default="./output", help="Output directory")
    parser.add_argument("--save-index", help="Save vector index to path")
    parser.add_argument("--load-index", help="Load vector index from path")
    parser.add_argument("--no-llm", action="store_true", help="Disable LLM re-ranking")
    parser.add_argument("--no-vector-search", action="store_true", help="Disable vector search")
    parser.add_argument("--no-evidence-reasons", action="store_true", help="Disable evidence-based reasons")
    parser.add_argument("--top-k", type=int, default=5, help="Top-K candidates")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--json-logs", action="store_true", help="Output structured JSON logs")
    parser.add_argument("--log-file", help="Write logs to file")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    return parser


def validate_args(args: argparse.Namespace) -> bool:
    if not args.load_index and not args.templates:
        print("ERROR: Either --templates or --load-index must be specified")
        return False
    if not args.documents and not args.document:
        print("ERROR: Either --documents or --document must be specified")
        return False
    if args.templates and not Path(args.templates).exists():
        print(f"ERROR: Templates directory not found: {args.templates}")
        return False
    if args.documents and not Path(args.documents).exists():
        print(f"ERROR: Documents directory not found: {args.documents}")
        return False
    if args.document and not Path(args.document).exists():
        print(f"ERROR: Document not found: {args.document}")
        return False
    return True


def print_results(results: list, output_dir: str):
    print("\n" + "=" * 90)
    print("TEMPLATE MATCHING RESULTS v2")
    print("=" * 90)
    print(f"\n{'Input File':<30} {'Matched Template':<25} {'Score':<10} {'Conf':<10} {'Quality':<12}")
    print("-" * 90)

    for result in results:
        score_pct = f"{result.similarity_score:.1%}"
        quality = "ISSUE" if (result.is_low_content or result.is_template_only) else "OK"
        print(f"{result.input_file:<30} {result.matched_template:<25} "
              f"{score_pct:<10} {result.confidence:<10} {quality:<12}")

    print("\n" + "=" * 90)
    print("DETAILED RESULTS")
    print("=" * 90)

    for i, result in enumerate(results, 1):
        print(f"\n{i}. {result.input_file}")
        print(f"   Matched:    {result.matched_template}")
        print(f"   Score:      {result.similarity_score:.2%}")
        print(f"   Confidence: {result.confidence}")
        print(f"   Time:       {result.scoring_time_ms:.1f}ms")

        if result.is_low_content or result.is_template_only:
            issues = []
            if result.is_low_content:
                issues.append("low content")
            if result.is_template_only:
                issues.append("template-only")
            print(f"   ⚠️  Quality:  {', '.join(issues)}")

        print(f"   Reason:     {result.reason}")

        if result.explanation and result.explanation.fragments:
            print(f"   Evidence:")
            for frag in result.explanation.fragments[:5]:
                conf_marker = "✓" if frag.confidence > 0.7 else "~"
                print(f"      {conf_marker} {frag.statement}")

        if result.alternatives:
            print(f"   Alternatives:")
            for alt in result.alternatives:
                print(f"      - {alt['template']}: {alt['score']:.4f}")

    print(f"\n{'=' * 90}")
    print(f"Results saved to: {output_dir}")
    print("=" * 90 + "\n")


def main():
    parser = create_argument_parser()
    args = parser.parse_args()

    # Setup logging
    setup_logging(
        level=args.log_level,
        json_mode=args.json_logs,
        log_file=args.log_file,
    )

    if not validate_args(args):
        parser.print_help()
        sys.exit(1)

    config = get_config()
    if args.no_llm:
        config.llm.enable_reranking = False
        config.llm.enable_explanation = False

    pipeline_config = PipelineConfig(
        use_vector_search=not args.no_vector_search,
        use_llm_reranking=not args.no_llm,
        use_evidence_reasons=not args.no_evidence_reasons,
        top_k_candidates=args.top_k,
        output_dir=args.output,
    )

    pipeline = TemplateMatchingPipeline(config=config, pipeline_config=pipeline_config)

    if args.load_index:
        pipeline.load_index(args.load_index)

    if args.templates:
        stats = pipeline.index_templates(args.templates)
        print(f"Indexed {stats['templates_indexed']} templates")

    if args.save_index:
        pipeline.save_index(args.save_index)

    results = []
    if args.document:
        results = [pipeline.match_document(args.document)]
    elif args.documents:
        results = pipeline.match_documents(args.documents)

    if results:
        output_files = pipeline.save_results(results, args.output)
        print_results(results, args.output)
        print("Output files:")
        for ft, fp in output_files.items():
            print(f"  {ft}: {fp}")


if __name__ == "__main__":
    main()