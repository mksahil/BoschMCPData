# Template Matching Results

Total documents processed: 2

## 1. Global_Customer_Proposal_Template2.docx

**Matched Template:** QST_SOW_Global_Customer_Proposal_Template.docx

**Similarity Score:** 91.71%

**Confidence:** High

**Reason:** 'Global_Customer_Proposal_Template2.docx' matches 'QST_SOW_Global_Customer_Proposal_Template.docx' (92% similarity). Identical heading found: 'Table of Contents'. 100% of template chunks have a matching query chunk Formatting and visual presentation are closely matched.

**Detailed Scores:**

- Content: 0.9879
- Structure: 0.9707
- Heading: 0.9842
- Layout: 0.9851
- Table: 0.9543

**Evidence:**

- ✓ Both documents contain identical sections for 'Table of Contents', '5. Technical Overview', '5.1 Functional Requirements', '5.2 Non Functional Requirements', '5.3 Architecture Considerations'.
- ~ Similar section names found: ' 5.1 Functional Requirements', ' 5.2 Non Functional Requirements', ' 6. Project Estimation'.
- ✓ Identical heading found: 'Table of Contents'.
- ~ Similar heading: '6. Project Estimation' ≈ '3. Project Description'.
- ✓ 100% of template chunks have a matching query chunk
- ~ Similar table structure (2x5 vs 3x5).
- ~ Similar table structure (2x5 vs 3x5).
- ✓ Matching table with identical dimensions 2x5.
- ✓ Matching table with identical dimensions 10x2.
- ✓ Matching table with identical dimensions 4x4.
- ✓ Matching table with identical dimensions 6x3.
- ~ Similar table structure (6x3 vs 4x3).
- ~ Similar table structure (6x3 vs 4x3).
- ~ Similar table structure (6x3 vs 4x3).
- ~ Similar table structure (6x3 vs 4x3).
- ~ Similar table structure (4x3 vs 6x3).
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ~ Similar table structure (4x3 vs 6x3).
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ~ Similar table structure (4x3 vs 6x3).
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ~ Similar table structure (4x3 vs 6x3).
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 23x3.
- ✓ Document organization patterns are strongly aligned.
- ✓ Formatting and visual presentation are closely matched.

**Alternative Matches:**

- QST-Risk Management Plan template.xls: 0.8465 (Medium)

**Pipeline Time:** 3526.4ms

---

## 2. Project_Proposal.docx

**Matched Template:** QST_SOW_Global_Customer_Proposal_Template.docx

**Similarity Score:** 76.16%

**Confidence:** Medium

**Reason:** 'Project_Proposal.docx' matches 'QST_SOW_Global_Customer_Proposal_Template.docx' (76% similarity). Formatting and visual presentation are closely matched. Document organization patterns are strongly aligned. Matching table with identical dimensions 4x3.

**Detailed Scores:**

- Content: 0.4300
- Structure: 0.9009
- Heading: 0.8680
- Layout: 0.9236
- Table: 0.8891

**Evidence:**

- ~ Similar section names found: ' Executive Summary'.
- ~ Similar heading: 'Executive Summary' ≈ '2. Executive Summary'.
- ~ 22% of template chunks have a matching query chunk
- ~ Similar table structure (4x3 vs 6x3).
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Matching table with identical dimensions 4x3.
- ✓ Document organization patterns are strongly aligned.
- ✓ Formatting and visual presentation are closely matched.

**Alternative Matches:**

- QST-Risk Management Plan template.xls: 0.6203 (Low)

**Pipeline Time:** 1732.4ms

---

