# Template Matching Engine - Architecture Document

## 1. System Overview

The Template Matching Engine is a GenAI-powered document analysis system that matches user documents against template documents with high accuracy, even when wording differs significantly.

## 2. Core Components

### 2.1 Document Parser (`document_parser.py`)

**Purpose**: Extract content, structure, and metadata from documents.

**Supported Formats**:
- DOCX (Microsoft Word)
- PDF (Portable Document Format)
- Extensible to scanned documents via OCR

**Extraction Pipeline**:
```
Document File
    |
    v
[Format Detection]
    |
    v
[Content Extraction] --> Full text, paragraphs
[Structure Extraction] --> Headings, sections, hierarchy
[Table Extraction] --> Tabular data as HTML/text
[Layout Extraction] --> Fonts, formatting, dimensions
[Metadata Extraction] --> Author, dates, title
    |
    v
DocumentFeatures (dataclass)
```

**Key Classes**:
- `DocumentParser`: Main entry point, routes to format-specific parsers
- `DocxParser`: Parses Word documents using python-docx
- `PDFParser`: Parses PDFs using PyMuPDF + pdfplumber

### 2.2 Feature Extractor (`feature_extractor.py`)

**Purpose**: Transform parsed documents into multi-modal feature representations.

**Feature Types**:

| Feature | Description | Text Representation |
|---------|-------------|-------------------|
| Content | Semantic text chunks | Paragraphs with context |
| Structure | Document organization | Heading hierarchy + sections |
| Headings | Section hierarchy | Level-labeled headings |
| Layout | Formatting patterns | Font info, dimensions |
| Tables | Tabular structures | Table dimensions + headers |

**Output**: `ExtractedFeatures` with unified text representations for embedding.

### 2.3 Embedding Generator (`embeddings.py`)

**Purpose**: Convert text features into dense vector representations.

**Models**:
- Default: `sentence-transformers/all-MiniLM-L6-v2`
- Recommended: `BAAI/bge-large-en-v1.5`
- Alternative: `sentence-transformers/all-mpnet-base-v2`

**Features**:
- Model caching (load once, reuse)
- Embedding caching (avoid recomputation)
- Batch processing for efficiency
- GPU acceleration support
- Configurable sequence length

**Output**: Dictionary of feature type -> embedding arrays

### 2.4 Vector Store (`vector_store.py`)

**Purpose**: Efficient similarity search using FAISS.

**Index Types**:

| Index | Use Case | Memory | Speed |
|-------|----------|--------|-------|
| Flat | Small scale (< 1000) | Low | Exact |
| HNSW | Medium scale, fast search | Medium | Fast |
| IVF | Large scale | Low | Fast |
| IVFPQ | Very large scale | Very Low | Fastest |

**Features**:
- Multi-index support (one per feature type)
- Metadata storage and filtering
- Persistent storage (save/load)
- Distance metrics: Cosine, L2, Inner Product

### 2.5 Similarity Scorer (`similarity_scorer.py`)

**Purpose**: Compute comprehensive similarity scores across dimensions.

**Scoring Dimensions**:

```
Content Score (35%)
  - Max pairwise chunk similarity
  - Mean top-5 similarity
  - Chunk coverage analysis

Structure Score (25%)
  - Structure fingerprint comparison
  - Section hierarchy alignment

Heading Score (20%)
  - Heading semantic similarity
  - Order preservation analysis

Layout Score (15%)
  - Font/formatting comparison
  - Document dimension similarity

Table Score (5%)
  - Table structure comparison
  - Header semantic similarity
```

**Aggregation**: Weighted average with configurable weights.

**Confidence Calculation**:
- Score magnitude
- Cross-dimension consistency
- Feature coverage

### 2.6 LLM Re-ranker (`llm_reranker.py`)

**Purpose**: Final validation and explanation generation.

**Process**:
1. Receive top-K candidates from similarity scorer
2. Build context with document previews and scores
3. Call LLM for holistic analysis
4. Parse structured response (JSON)
5. Adjust scores and generate explanation

**Fallback**: If LLM unavailable, uses score-based ranking with automated reasoning.

**Output**: `MatchResult` with detailed explanation.

### 2.7 Pipeline Orchestrator (`matcher_pipeline.py`)

**Purpose**: Coordinate all components into end-to-end workflow.

**Workflow**:
```
1. Index Templates
   Parse --> Extract Features --> Generate Embeddings --> Store in FAISS

2. Match Documents
   Parse --> Extract Features --> Generate Embeddings
      |
      v
   Vector Search (top-K candidates)
      |
      v
   Similarity Scoring (detailed scores)
      |
      v
   LLM Re-ranking (final decision + explanation)
      |
      v
   MatchResult
```

## 3. Data Flow

```
Template Documents                          Input Documents
      |                                           |
      v                                           v
[Document Parser]                        [Document Parser]
      |                                           |
      v                                           v
[DocumentFeatures]                       [DocumentFeatures]
      |                                           |
      v                                           v
[Feature Extractor]                      [Feature Extractor]
      |                                           |
      v                                           v
[ExtractedFeatures]                      [ExtractedFeatures]
      |                                           |
      v                                           v
[Embedding Generator]                    [Embedding Generator]
      |                                           |
      v                                           v
[Vector Store] <------ Query --------------- Embeddings
(Indexed)                                       |
      |                                         v
      |                              [Similarity Scorer]
      |                                         |
      |                              [LLM Re-ranker]
      |                                         |
      +-------> MatchResult <-------------------+
```

## 4. Configuration System

All components use a hierarchical configuration:

```python
AppConfig
├── DocumentConfig      # Parsing parameters
├── EmbeddingConfig     # Model selection, batch size
├── VectorStoreConfig   # Index type, distance metric
├── ScoringConfig       # Weights, thresholds
├── LLMConfig           # Model, API keys
└── CacheConfig         # Cache type, TTL
```

Configuration sources (in priority order):
1. Environment variables
2. .env file
3. Default values

## 5. Performance Characteristics

### Throughput
- **Document Parsing**: ~50-100 docs/sec (depends on size)
- **Embedding Generation**: ~2000-4000 chunks/sec (CPU), ~10000+ (GPU)
- **Vector Search**: < 1ms per query (HNSW, 1000 templates)
- **Full Pipeline**: ~2-5 seconds per document end-to-end

### Memory Usage
- **Embedding Model**: ~80MB (MiniLM) to ~1.3GB (BGE-large)
- **Vector Index**: ~4KB per template (768-dim embeddings)
- **Cache**: Configurable (default: 1GB max)

### Scalability
- **Templates**: FAISS supports billions of vectors
- **Documents**: Batch processing for throughput
- **Horizontal**: Stateless design enables horizontal scaling

## 6. Extensibility

### Adding New Document Formats

1. Create a new parser class inheriting from `BaseParser`
2. Implement `parse()` and `supports()` methods
3. Register in `DocumentParser.parsers` list

### Adding New Feature Types

1. Add extraction method in `FeatureExtractor`
2. Add embedding generation in `EmbeddingGenerator`
3. Add scoring method in `SimilarityScorer`
4. Update weights in `ScoringConfig`

### Custom Embedding Models

1. Update `EmbeddingConfig` with model name
2. Ensure model is compatible with sentence-transformers
3. Adjust `embedding_dim` if needed

## 7. Error Handling

### Graceful Degradation
- LLM unavailable: Falls back to score-based ranking
- Missing features: Adjusts weights automatically
- Parse errors: Logs error, continues processing
- Cache miss: Computes on-demand

### Retry Logic
- LLM calls: 3 retries with exponential backoff
- Vector operations: Wrapped in try/except
- File operations: Validation before processing

## 8. Monitoring

### Metrics
- Documents processed (counter)
- Processing time (histogram)
- Cache hit rate (gauge)
- Match confidence distribution (histogram)
- Error rate (counter)

### Logging
- Structured JSON logging
- Per-document trace IDs
- Component-level debug logging
- Performance timing logs
