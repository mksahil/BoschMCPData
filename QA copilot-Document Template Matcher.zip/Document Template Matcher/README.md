# GenAI Template Document Matching Engine

A production-ready, AI-powered document matching system that intelligently identifies which template each incoming document is derived from - even when wording changes significantly but the underlying structure and intent remain the same.

## Overview

This solution goes far beyond simple keyword matching. It uses a multi-modal approach combining:

- **Semantic Content Analysis** - Understanding meaning, not just keywords
- **Structural Pattern Recognition** - Document organization and hierarchy
- **Heading Hierarchy Matching** - Section structure comparison
- **Layout Analysis** - Formatting and visual patterns
- **Table Structure Comparison** - Tabular data patterns
- **LLM-Powered Re-ranking** - Final validation with explainable AI

## Architecture

```
+----------------------------------------------------------+
|                    INPUT DOCUMENTS                        |
+----------------------------------------------------------+
                          |
                    [Document Parser]
                          |
         +----------------+----------------+
         |                |                |
    [DOCX Parser]   [PDF Parser]   [Future: Scanned]
         |                |                |
         +----------------+----------------+
                          |
                 [Document Features]
        (content, headings, tables, layout)
                          |
                    [Feature Extractor]
                          |
         +----------------+----------------+
         |                |                |
   [Content]      [Structure]      [Headings]
   Features        Features         Features
         |                |                |
         +----------------+----------------+
                          |
                 [Embedding Generator]
            (sentence-transformers)
                          |
         +----------------+----------------+
         |                |                |
   [Content]      [Structure]      [Headings]
   Embeddings      Embeddings       Embeddings
         |                |                |
         +----------------+----------------+
                          |
                   [Vector Store]
                     (FAISS)
                          |
         +----------------+----------------+
         |                |                |
   [Content]      [Structure]      [Headings]
     Index          Index            Index
                          |
                    [Similarity Scorer]
                          |
         +----------------+----------------+
         |                |                |
   [Weighted]       [Max]           [Ensemble]
   Aggregation    Aggregation      Aggregation
                          |
                    [LLM Re-ranker]
                 (Explainable AI)
                          |
                   [Match Results]
              (template, score, reason)
```

## Project Structure

```
template-matching-engine/
├── src/
│   └── template_matcher/
│       ├── __init__.py              # Package initialization
│       ├── config.py                # Centralized configuration
│       ├── document_parser.py       # DOCX/PDF parsing engine
│       ├── feature_extractor.py     # Multi-modal feature extraction
│       ├── embeddings.py            # Embedding generation
│       ├── vector_store.py          # FAISS vector database
│       ├── similarity_scorer.py     # Hierarchical scoring engine
│       ├── llm_reranker.py          # LLM re-ranking & explainability
│       └── matcher_pipeline.py      # Main orchestration pipeline
├── requirements.txt                 # Python dependencies
├── run_matching.py                  # CLI runner script
├── sample_data/                     # Sample documents
│   ├── Templates/
│   │   ├── Template_1.docx          # Weekly Report
│   │   ├── Template_2.docx          # Risk Assessment
│   │   ├── Template_3.docx          # Meeting Minutes
│   │   ├── Template_4.docx          # Audit Form
│   │   ├── Template_5.docx          # Project Proposal
│   │   └── Template_6.docx          # Incident Report
│   ├── Folder_A/
│   │   ├── Weekly_Report_May.docx
│   │   └── Platform_Team_Weekly.docx
│   ├── Folder_B/
│   │   ├── Risk_Assessment.docx
│   │   └── Audit_Form.docx
│   └── Folder_C/
│       ├── Meeting_Minutes.docx
│       └── Project_Proposal.docx
├── config/
│   └── default.yaml                 # Default configuration
├── tests/                           # Unit tests
├── docs/                            # Documentation
└── README.md                        # This file
```

## Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Language** | Python 3.9+ | Core implementation |
| **Document Parsing** | python-docx, PyMuPDF, pdfplumber | DOCX and PDF parsing |
| **Embeddings** | sentence-transformers | Dense vector generation |
| **Vector DB** | FAISS | Similarity search |
| **LLM** | OpenAI GPT-3.5/4 | Re-ranking and explanation |
| **NLP** | spaCy, NLTK | Text preprocessing |
| **ML** | scikit-learn | Similarity metrics |
| **API** | FastAPI (optional) | REST API serving |
| **Caching** | diskcache, Redis | Embedding cache |
| **Monitoring** | structlog, prometheus | Observability |

## Embedding Model Recommendation

The system supports multiple embedding models:

### Default: all-MiniLM-L6-v2
- **Speed**: Fast (~4000 sentences/sec)
- **Quality**: Good baseline
- **Size**: ~80MB
- **Use case**: Development and moderate-scale production

### Recommended: BAAI/bge-large-en-v1.5
- **Speed**: Moderate (~1000 sentences/sec)
- **Quality**: Excellent for semantic search
- **Size**: ~1.3GB
- **Use case**: High-accuracy production deployments

### Alternative: all-mpnet-base-v2
- **Speed**: Moderate (~2000 sentences/sec)
- **Quality**: Better than MiniLM
- **Size**: ~420MB
- **Use case**: Balanced performance/quality

## Vector Database Recommendation

### Primary: FAISS (Facebook AI Similarity Search)
- **Index Types**: Flat, IVF, HNSW, IVFPQ
- **Distance Metrics**: Cosine, L2, Inner Product
- **Performance**: Billions of vectors, sub-millisecond search
- **Deployment**: CPU and GPU support

### Alternative: Milvus/Chroma
- **Use case**: When distributed deployment needed
- **Features**: Built-in metadata filtering, cloud-native

## Installation

### Prerequisites
- Python 3.9+
- pip

### Install Dependencies

```bash
pip install -r requirements.txt
```

### Environment Variables (Optional)

```bash
# For LLM re-ranking (optional but recommended)
export OPENAI_API_KEY="your-api-key"

# For Redis caching (optional)
export REDIS_URL="redis://localhost:6379/0"

# Configuration overrides
export EMBED_MODEL="BAAI/bge-large-en-v1.5"
export LLM_MODEL="gpt-4"
```

## Usage

### Basic Usage

```bash
# Index templates and match all documents
python run_matching.py --templates ./Templates --documents ./Folder_A --output ./output
```

### Single Document Matching

```bash
python run_matching.py --templates ./Templates --document ./Folder_A/File_A1.docx --output ./output
```

### Without LLM (Faster, No API Key)

```bash
python run_matching.py --templates ./Templates --documents ./Folder_A --no-llm --output ./output
```

### Save and Reuse Index

```bash
# First run: index templates and save
python run_matching.py --templates ./Templates --save-index ./index.faiss

# Subsequent runs: just load index
python run_matching.py --load-index ./index.faiss --documents ./Folder_A --output ./output
```

### Programmatic Usage

```python
from template_matcher import TemplateMatchingPipeline, PipelineConfig

# Initialize pipeline
pipeline = TemplateMatchingPipeline()

# Index templates
stats = pipeline.index_templates("./Templates")
print(f"Indexed {stats['templates_indexed']} templates")

# Match single document
result = pipeline.match_document("./Folder_A/Weekly_Report_May.docx")
print(f"Match: {result.matched_template} ({result.similarity_score:.2%})")
print(f"Reason: {result.reason}")

# Match directory
results = pipeline.match_documents("./Folder_A")

# Save results
pipeline.save_results(results, "./output")
```

## Output Format

### JSON Output

```json
{
  "input_file": "Weekly_Report_May.docx",
  "matched_template": "Template_1.docx",
  "similarity_score": 0.94,
  "confidence": "High",
  "reason": "Document structure, section hierarchy, and semantic content closely match Template_1.",
  "detailed_scores": {
    "content": 0.92,
    "structure": 0.95,
    "heading": 0.96,
    "layout": 0.89,
    "table": 0.91
  },
  "alternatives": [
    {"template": "Template_3.docx", "score": 0.45, "confidence": "Low"}
  ]
}
```

### CSV Output

| Input File | Matched Template | Score | Confidence | Reason |
|------------|-----------------|-------|------------|---------|
| Weekly_Report_May.docx | Template_1.docx | 94% | High | Strong content and structure match |
| Risk_Assessment.docx | Template_2.docx | 89% | High | Risk analysis table and heading structure match |

## Similarity Scoring Strategy

The scoring engine uses a weighted multi-dimensional approach:

| Dimension | Weight | Description |
|-----------|--------|-------------|
| **Content** | 35% | Semantic similarity of document text |
| **Structure** | 25% | Document organization patterns |
| **Headings** | 20% | Section hierarchy and naming |
| **Layout** | 15% | Formatting and visual patterns |
| **Tables** | 5% | Table structure and content |

### Scoring Methodology

1. **Content Scoring**: Uses maximum pairwise chunk similarity + coverage analysis
2. **Structure Scoring**: Cosine similarity of structure fingerprints
3. **Heading Scoring**: Best match + ordering preservation analysis
4. **Layout Scoring**: Formatting pattern comparison
5. **Table Scoring**: Structural + semantic table comparison

### Confidence Levels

| Level | Threshold | Description |
|-------|-----------|-------------|
| **High** | >= 0.85 | Strong match across multiple dimensions |
| **Medium** | >= 0.70 | Good match with some variance |
| **Low** | >= 0.55 | Moderate match, review recommended |
| **Very Low** | < 0.55 | Weak match, manual review needed |

## LLM Re-ranking Strategy

The LLM re-ranking layer provides:

1. **Final Validation**: Cross-checks vector search results
2. **Explanation Generation**: Human-readable match reasoning
3. **Score Adjustment**: Fine-tunes scores based on holistic analysis
4. **Feature Identification**: Lists key matching features

### When LLM is Unavailable

The system gracefully degrades to score-based ranking with automated reason generation.

## Performance Optimization

### Caching
- **Embedding Cache**: Avoids recomputing embeddings for previously seen documents
- **Disk Persistence**: Cache survives between runs
- **TTL Support**: Automatic cache expiration

### Vector Search Optimization
- **HNSW Index**: Sub-millisecond search for thousands of templates
- **Batch Processing**: Efficient bulk embedding generation
- **GPU Acceleration**: CUDA support for embedding generation and search

### Scalability Recommendations

| Scale | Templates | Strategy |
|-------|-----------|----------|
| Small | < 100 | HNSW index, single machine |
| Medium | 100-1000 | HNSW index, cached embeddings |
| Large | 1000-10000 | IVFPQ index, parallel processing |
| Very Large | 10000+ | Distributed FAISS, sharding |

## Future PDF Support

The architecture already supports PDF documents through:
- PyMuPDF for layout and font extraction
- pdfplumber for table and structured text extraction
- Automatic heading detection via heuristics

Enable by simply adding PDF files - no code changes needed.

## API Deployment (Optional)

```python
# app.py
from fastapi import FastAPI
from template_matcher import TemplateMatchingPipeline

app = FastAPI()
pipeline = TemplateMatchingPipeline()
pipeline.index_templates("./Templates")

@app.post("/match")
async def match_document(file: UploadFile):
    result = pipeline.match_document(file.file)
    return result.to_dict()
```

## Testing

```bash
# Run unit tests
pytest tests/

# Run with sample data
python run_matching.py --templates ./sample_data/Templates --documents ./sample_data/Folder_A --no-llm
```

## Configuration

All aspects of the system are configurable via:

1. **Environment Variables**: `EMBED_MODEL`, `LLM_MODEL`, etc.
2. **Config Files**: YAML/JSON configuration files
3. **Programmatic**: Pass config objects to components

See `src/template_matcher/config.py` for all options.

## Monitoring

The system includes:
- Structured logging with structlog
- Performance metrics via prometheus-client
- Detailed scoring breakdowns for explainability

## License

MIT License - See LICENSE file for details.
