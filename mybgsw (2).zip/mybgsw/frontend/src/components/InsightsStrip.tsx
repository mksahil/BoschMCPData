import { TrendingUp, DollarSign, Clock, Utensils } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface Insight {
  id: string;
  icon: React.ElementType;
  text: string;
  action?: () => void;
}

const insights: Insight[] = [
  {
    id: "1",
    icon: Clock,
    text: "Your effort this week: 37 / 42 hrs logged",
  },
  {
    id: "2",
    icon: DollarSign,
    text: "₹3,200 pending reimbursement under JKL",
  },
  {
    id: "3",
    icon: TrendingUp,
    text: "Next shuttle leaves in 12 mins",
  },
  {
    id: "4",
    icon: Utensils,
    text: "Lunch menu: Paneer Butter Masala + Rice",
  },
];

export const InsightsStrip = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  return (
    <div className="bg-card border-b border-border shadow-card relative">
      {/* Coming Soon Overlay */}
      <div className="absolute inset-0 bg-background/60 backdrop-blur-[1px] z-10 flex items-center justify-center">
        <span className="text-xs font-medium text-muted-foreground bg-card/90 px-3 py-1 rounded-full border border-border">
          🚧 Coming Soon
        </span>
      </div>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between overflow-hidden">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="font-medium">Live Insights</span>
          </div>
          
          <div className="flex-1 mx-4 overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {insights.map((insight) => {
                const Icon = insight.icon;
                return (
                  <div
                    key={insight.id}
                    className="flex items-center gap-2 min-w-full justify-center cursor-pointer group"
                    onClick={() => {
                      setCurrentIndex((prev) => (prev + 1) % insights.length);
                    }}
                    // this fixed: Rule S1082 - Missing keyboard listener
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        setCurrentIndex((prev) => (prev + 1) % insights.length);
                      }
                    }}
                    tabIndex={0}
                    role="button"
                  >
                    <Icon className="w-4 h-4 text-primary group-hover:text-primary-light transition-colors" />
                    <span className="text-sm text-foreground group-hover:text-primary transition-colors">
                      {insight.text}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex gap-1.5">
            {insights.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={cn(
                  "w-1.5 h-1.5 rounded-full transition-all duration-300",
                  index === currentIndex
                    ? "bg-primary w-6"
                    : "bg-border hover:bg-primary/50"
                )}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
