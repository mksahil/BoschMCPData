import { useState, useEffect } from "react";
import { Users, RefreshCw, Loader2, AlertCircle, X, ExternalLink, MapPin, CheckCircle2 } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { API_BASE_URL } from "@/config";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

interface CommunityLocation {
  id: number;
  name: string;
  code: string;
}

interface Community {
  id: number;
  name: string;
  description: string;
  members: number;
  color: string;
  icon: string | null;
  category: string;
  locations: CommunityLocation[];
}

// Get a nice emoji based on community name
const getCommunityEmoji = (name: string): string => {
  if (!name) return '👥';
  const lowerName = name.toLowerCase();
  if (lowerName.includes('bike') || lowerName.includes('cyco')) return '🚴';
  if (lowerName.includes('art') || lowerName.includes('motion')) return '🎨';
  if (lowerName.includes('cricket')) return '🏏';
  if (lowerName.includes('run')) return '🏃';
  if (lowerName.includes('photo') || lowerName.includes('pixture')) return '📸';
  if (lowerName.includes('garden') || lowerName.includes('bio')) return '🌱';
  if (lowerName.includes('mind') || lowerName.includes('buddies')) return '🧠';
  if (lowerName.includes('path')) return '🧭';
  if (lowerName.includes('women')) return '👩';
  return '👥';
};

export const CommunityCard = () => {
  const { user } = useAuth();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [viewAll, setViewAll] = useState(false);
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [joining, setJoining] = useState(false);
  const [joinSuccess, setJoinSuccess] = useState<string | null>(null);

  const handleJoinCommunity = async (community: Community, location: CommunityLocation) => {
    setJoining(true);
    setJoinSuccess(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
        },
        body: JSON.stringify({
          communityId: community.id,
          locationId: location.id,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setJoinSuccess(data.message || `Successfully joined ${community.name}!`);
        toast.success(data.message || `Successfully joined ${community.name}!`);
      } else {
        toast.error(data.message || data.error || 'Failed to join community');
      }
    } catch (err) {
      console.error('Error joining community:', err);
      toast.error('Unable to join community. Please try again.');
    } finally {
      setJoining(false);
      setShowLocationPicker(false);
    }
  };

  const fetchCommunities = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/list?page=1&pageSize=10`);
      const data = await response.json();

      if (data.success && data.communities) {
        setCommunities(data.communities);
        setTotalCount(data.totalCount || data.communities.length);
      } else {
        setError('Failed to load communities');
      }
    } catch (err) {
      console.error('Error fetching communities:', err);
      setError('Unable to connect to community service');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCommunities();
  }, []);

  if (loading) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <span className="ml-2 text-sm text-muted-foreground">Loading communities...</span>
        </div>
      </DashboardCard>
    );
  }

  if (error) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex flex-col items-center justify-center py-6 text-center">
          <AlertCircle className="w-8 h-8 text-destructive mb-2" />
          <p className="text-sm text-muted-foreground mb-3">{error}</p>
          <button
            onClick={fetchCommunities}
            className="flex items-center gap-1 text-xs text-primary hover:underline"
          >
            <RefreshCw className="w-3 h-3" /> Retry
          </button>
        </div>
      </DashboardCard>
    );
  }

  const displayedCommunities = viewAll ? communities : communities.slice(0, 6);

  return (
    <DashboardCard
      title="Community & Events"
      icon={Users}
      action={
        <button
          onClick={fetchCommunities}
          className="p-1 hover:bg-secondary rounded transition-colors"
          title="Refresh"
        >
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      }
    >
      <div className="space-y-2 relative">
        {/* Detail popup overlay */}
        {selectedCommunity && (
          <div className="absolute inset-0 z-10 bg-card rounded-lg border border-border shadow-elevated animate-in fade-in slide-in-from-bottom-2 duration-200 overflow-y-auto">
            <div className="p-4">
              {/* Header with close button */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{getCommunityEmoji(selectedCommunity.name)}</span>
                  <div>
                    <h4 className="text-sm font-bold text-foreground">{selectedCommunity.name}</h4>
                    {selectedCommunity.category && !selectedCommunity.category.startsWith('#') && selectedCommunity.category !== 'General' && (
                      <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded mt-0.5 inline-block">
                        {selectedCommunity.category}
                      </span>
                    )}
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); setSelectedCommunity(null); setShowLocationPicker(false); setJoinSuccess(null); }}
                  className="p-1 hover:bg-secondary rounded-full transition-colors flex-shrink-0"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              {/* Color accent bar */}
              <div
                className="w-full h-1 rounded-full mb-3"
                style={{ backgroundColor: selectedCommunity.color || 'hsl(var(--primary))' }}
              />

              {/* Description */}
              <div className="mb-3">
                <p className="text-xs font-medium text-foreground mb-1">About</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {selectedCommunity.description && !selectedCommunity.description.startsWith('#')
                    ? selectedCommunity.description
                    : 'No description available for this community.'}
                </p>
              </div>

              {/* Stats */}
              <div className="flex items-center gap-4 mb-3 p-2 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-primary" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">{selectedCommunity.members}</p>
                    <p className="text-[10px] text-muted-foreground">Members</p>
                  </div>
                </div>
              </div>

              {/* Join section */}
              {joinSuccess ? (
                <div className="flex items-center gap-2 p-2.5 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <p className="text-xs text-green-700 dark:text-green-400">{joinSuccess}</p>
                </div>
              ) : showLocationPicker ? (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-foreground flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> Select your location
                  </p>
                  <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
                    {selectedCommunity.locations && selectedCommunity.locations.length > 0 ? (
                      selectedCommunity.locations.map((loc) => (
                        <button
                          key={loc.id}
                          disabled={joining}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleJoinCommunity(selectedCommunity, loc);
                          }}
                          className="w-full text-left px-3 py-2 text-xs bg-secondary/50 hover:bg-primary/10 hover:text-primary rounded-md transition-colors flex items-center justify-between disabled:opacity-50"
                        >
                          <span>{loc.name}</span>
                          {joining ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <span className="text-[10px] text-muted-foreground">{loc.code}</span>
                          )}
                        </button>
                      ))
                    ) : (
                      <p className="text-xs text-muted-foreground py-2">No locations available.</p>
                    )}
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setShowLocationPicker(false); }}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setJoinSuccess(null);
                    setShowLocationPicker(true);
                  }}
                  className="w-full py-2 px-3 text-xs font-medium bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5" />
                  Join Community
                </button>
              )}

            </div>
          </div>
        )}

        {/* Community description */}
        <p className="text-xs text-muted-foreground mb-3">
          Join Bosch communities to connect with colleagues, share interests, and participate in events.
        </p>

        {/* Community count header */}
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-border">
          <span className="text-xs text-muted-foreground">
            {totalCount} Active Communities
          </span>
        </div>

        <div className={cn(
          "space-y-2 overflow-y-auto pr-1 transition-all duration-300",
          viewAll ? "max-h-[400px]" : "max-h-[280px]"
        )}>
          {displayedCommunities.filter(c => c && c.name).map((community) => (
            <div
              key={community.id}
              className="p-3 bg-secondary/50 hover:bg-secondary rounded-lg transition-colors cursor-pointer group"
              style={{ borderLeft: `3px solid ${community.color || 'hsl(var(--primary))'}` }}
              onClick={() => setSelectedCommunity(community)}
              // this fixed: Rule S1082 - Missing keyboard listener
              onKeyDown={(e) => e.key === 'Enter' && setSelectedCommunity(community)}
              tabIndex={0}
              role="button"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">{getCommunityEmoji(community.name)}</span>
                <h4 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                  {community.name}
                </h4>
              </div>
              {community.description && !community.description.startsWith('#') && (
                <p className="text-xs text-muted-foreground mb-1.5 line-clamp-2">
                  {community.description.length > 80
                    ? community.description.substring(0, 80) + '...'
                    : community.description}
                </p>
              )}
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {community.members} members
                </span>
                {community.category && community.category !== 'General' && !community.category.startsWith('#') && (
                  <span className="bg-primary/10 text-primary px-2 py-0.5 rounded">
                    {community.category}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* View all link */}
        {totalCount > 6 && (
          <div className="pt-2 border-t border-border">
            <button
              onClick={() => setViewAll(!viewAll)}
              className="w-full text-xs text-primary hover:underline font-medium py-1 flex items-center justify-center gap-1"
            >
              {viewAll ? "Show less" : `View all ${totalCount} communities`} {viewAll ? "↑" : "→"}
            </button>
          </div>
        )}
      </div>
    </DashboardCard>
  );
};
