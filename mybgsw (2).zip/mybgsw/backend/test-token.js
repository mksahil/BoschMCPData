const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
    rejectUnauthorized: false
});

async function runTest() {
    // this fixed: Issue #9 - Hardcoded Secret
    const token = process.env.TEST_JWT_TOKEN || '';
    const clientId = process.env.BOSCH_CLIENT_ID || 'BE3B36B4-ED49-490E-94BB-7F34E86499BF';
    const baseUrl = 'https://dev.boschassociatearena.com/api';

    try {
        console.log('Testing JWT generation with frontend token...');
        const response = await axios.get(`${baseUrl}/Token/GenrateTokenDetails`, {
            params: { clientID: clientId },
            headers: { 'Authorization': `Bearer ${token}` },
            httpsAgent
        });
        console.log('SUCCESS:', response.data);
    } catch (error) {
        if (error.response) {
            console.error('FAILED (401 expected):', error.response.status);
            console.error('Data:', error.response.data);
        } else {
            console.error('FAILED (other):', error.message);
        }
    }
}

runTest();
