const path = require('path');
// Load .env from the backend directory
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const fs = require('fs-extra');
const https = require('https');
const axios = require('axios');
const { format } = require('date-fns');
const boschAuthService = require('./services/bosch-auth-service');
const communityService = require('./services/community-service');
const conversationContextService = require('./services/conversation-context-service');
const conversationDbService = require('./services/conversation-db-service');
const mcpServiceManager = require('./services/mcp-service-manager');
const mcpDiscoveryService = require('./services/mcp-discovery-service');
const GenericMCPClient = require('./services/generic-mcp-client');

// Disable SSL certificate verification for dev environments (Bosch Arena API has self-signed cert)
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
const defaultCorsOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:8080',
  'https://my-bgsw-ai-dev.azurewebsites.net'
];
const configuredCorsOrigins = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(origin => origin.trim()).filter(Boolean)
  : defaultCorsOrigins;

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) {
      return callback(null, true);
    }

    if (configuredCorsOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error(`CORS not allowed for origin: ${origin}`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Employee-Number']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Ensure logs directory exists
const logsDir = path.join(__dirname, 'logs');
const sessionsDir = path.join(logsDir, 'sessions');
fs.ensureDirSync(logsDir);
fs.ensureDirSync(sessionsDir);

// Root endpoint for health checks
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    service: 'MyBGSW Backend API',
    timestamp: new Date().toISOString(),
    endpoints: ['/api/health', '/api/canteen/query', '/api/entryexit/query', '/api/logs']
  });
});

// Helper function to get log file path for today
const getDailyLogFile = () => {
  const today = format(new Date(), 'yyyy-MM-dd');
  return path.join(logsDir, `${today}_activity.json`);
};

// Helper function to get session log file
const getSessionLogFile = (sessionId) => {
  return path.join(sessionsDir, `${sessionId}.json`);
};

// API endpoint to log user activities
app.post('/api/logs', async (req, res) => {
  try {
    const logEntry = {
      ...req.body,
      serverTimestamp: new Date().toISOString(),
      ip: req.ip || req.connection.remoteAddress
    };

    // Filter out unwanted events at the server level too
    const blockedActions = ['mouse_activity', 'scroll_behavior', 'hover_event', 'scroll_depth', 'idle_detection'];
    if (blockedActions.includes(logEntry.action)) {
      console.log(`Blocked unwanted log: ${logEntry.action}`);
      return res.json({ success: true, blocked: true }); // Return success but don't save
    }

    // Write to daily log file
    const dailyLogFile = getDailyLogFile();
    await fs.appendFile(dailyLogFile, JSON.stringify(logEntry) + '\n');

    // Also write to session-specific log
    if (logEntry.sessionId) {
      if (!/^[a-zA-Z0-9_-]+$/.test(logEntry.sessionId)) {
        return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
      }
      // this fixed: Issue #2 - Path Traversal
      const sessionLogFile = path.resolve(getSessionLogFile(logEntry.sessionId));
      if (!sessionLogFile.startsWith(path.resolve(sessionsDir))) {
        return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
      }
      await fs.appendFile(sessionLogFile, JSON.stringify(logEntry) + '\n');
    }

    console.log(`Logged: ${logEntry.action}`);
    res.json({ success: true });
  } catch (error) {
    console.error('Error logging activity:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get logs (for viewer)
app.get('/api/logs', async (req, res) => {
  try {
    const { date, sessionId, limit = 100 } = req.query;

    // Strict validation to prevent Path Traversal
    if (sessionId && !/^[a-zA-Z0-9_-]+$/.test(sessionId)) {
      return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
    }
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    let logFile;
    if (sessionId) {
      logFile = getSessionLogFile(sessionId);
    } else if (date) {
      logFile = path.join(logsDir, `${date}_activity.json`);
    } else {
      logFile = getDailyLogFile();
    }

    // [SQ-FIX] Issue #1 (Rule S2083): Path injection containment check
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.json({ logs: [] });
    }

    // Read file and parse logs
    const content = await fs.readFile(resolvedLogFile, 'utf-8');
    const logs = content
      .trim()
      .split('\n')
      .filter(line => line)
      .map(line => {
        try {
          return JSON.parse(line);
        } catch (e) {
          return null;
        }
      })
      .filter(log => log !== null);

    // Return last 'limit' logs
    const limitedLogs = logs.slice(-limit);
    res.json({ logs: limitedLogs, total: logs.length });
  } catch (error) {
    console.error('Error retrieving logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get all sessions
app.get('/api/sessions', async (req, res) => {
  try {
    const sessionFiles = await fs.readdir(sessionsDir);
    const sessions = sessionFiles
      .filter(file => file.endsWith('.json'))
      .map(file => file.replace('.json', ''));

    res.json({ sessions });
  } catch (error) {
    console.error('Error retrieving sessions:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to download logs
app.get('/api/logs/download', async (req, res) => {
  try {
    const { date, format: exportFormat = 'json' } = req.query;

    // Strict validation to prevent Path Traversal and HTTP Header CRLF Injection
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    const logFile = date
      ? path.join(logsDir, `${date}_activity.json`)
      : getDailyLogFile();

    // [SQ-FIX] Issue #1 (Rule S2083): Path injection containment check
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.status(404).json({ error: 'Log file not found' });
    }

    if (exportFormat === 'json') {
      res.download(resolvedLogFile);
    } else if (exportFormat === 'csv') {
      // Convert to CSV format
      const content = await fs.readFile(resolvedLogFile, 'utf-8');
      const logs = content
        .trim()
        .split('\n')
        .filter(line => line)
        .map(line => JSON.parse(line));

      // Create CSV
      const csv = [
        'Timestamp,SessionID,Action,Page,Details',
        ...logs.map(log =>
          `"${log.timestamp}","${log.sessionId}","${log.action}","${log.page}","${JSON.stringify(log.details || {}).replace(/"/g, '""')}"`
        )
      ].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      // this fixed: Issue #3 - HTTP Header Injection
      const safeFilename = (date || 'today').replace(/[\r\n]/g, '');
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}_logs.csv"`);
      res.send(csv);
    }
  } catch (error) {
    console.error('Error downloading logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Import MCP client - use HTTP client for deployed Canteen MCP, stdio for local
const { getClient: getHttpClient } = require('./mcp-client-http');
const { getClient: getStdioClient } = require('./mcp-client-stdio');

// Determine which canteen client to use based on environment
const isDeployedCanteen = process.env.CANTEEN_MCP_URL &&
  !process.env.CANTEEN_MCP_URL.includes('localhost');

const getClient = isDeployedCanteen ? getHttpClient : getStdioClient;
console.log(`Using ${isDeployedCanteen ? 'HTTP' : 'stdio'} client for Canteen MCP`);

// Import intelligent canteen handler
const { processIntelligentQuery } = require('./intelligent-canteen');

// Import Entry/Exit MCP client
const { getEntryExitV2Client } = require('./entryexit-mcp-v2-client');

// Store conversation contexts (in production, use Redis or similar)
const conversationContexts = new Map();

// Canteen query endpoint
app.post('/api/canteen/query', async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('Processing canteen query:', query);
    console.log('Auth token present:', !!authToken);
    console.log('Employee number:', empNumber);

    // Get or create conversation context
    let context = conversationContexts.get(sessionId) || {};

    // If locationId is provided (user selected location), update context
    if (locationId) {
      context.location_id = locationId;
      context.location = locationId === 1 ? 'bangalore' : 'coimbatore';
      conversationContexts.set(sessionId, context);
    }

    // Get MCP client instance
    const mcpClient = await getClient();

    // Process query with intelligence
    const result = await processIntelligentQuery(query, mcpClient, context);

    // Update context if location was determined
    if (result.location_id) {
      context.location_id = result.location_id;
      context.location = result.location;
      conversationContexts.set(sessionId, context);
    }

    res.json({
      response: result.response,
      needs_location: result.needs_location,
      location_id: result.location_id,
      menuData: result.menuData, // Include structured menu data for CafeteriaCard
      success: true
    });

  } catch (error) {
    console.error('Canteen query error:', error);
    res.status(500).json({
      error: 'Failed to process canteen query',
      details: 'Error details securely logged'
    });
  }
});

// Import Entry/Exit services
const entryExitService = require('./services/entry-exit-service-v2');

// ============= ENTRY/EXIT TIME TRACKING ENDPOINTS =============

// Main endpoint for time tracking queries
app.post('/api/time-tracking/query', async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Query is required'
      });
    }

    // Use default employee number if not provided
    const empNum = employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';

    console.log(`Time tracking query for employee ${empNum}: ${query}`);

    const result = await entryExitService.getEmployeeTimeData(empNum, query);

    res.json({
      success: true,
      employeeNumber: empNum,
      response: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Time tracking query error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process time tracking query',
      details: 'Error details securely logged'
    });
  }
});

// Quick endpoint for today's entry time
app.get('/api/time-tracking/today-entry/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayEntry(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today entry:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Quick endpoint for today's exit time
app.get('/api/time-tracking/today-exit/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayExit(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today exit:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Get today's working hours
app.get('/api/time-tracking/today-hours/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today hours:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Get weekly attendance summary
app.get('/api/time-tracking/weekly-summary/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getWeeklyHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get weekly summary:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Get monthly report
app.get('/api/time-tracking/monthly-report/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const currentDate = new Date();
    const month = req.query.month || (currentDate.getMonth() + 1);
    const year = req.query.year || currentDate.getFullYear();

    const result = await entryExitService.getMonthlyReport(empNum, month, year);
    res.json({
      success: true,
      employeeNumber: empNum,
      month,
      year,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get monthly report:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Check if late today
app.get('/api/time-tracking/late-check/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.checkLateToday(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to check late status:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Get attendance statistics
app.get('/api/time-tracking/stats/:employeeNumber?', async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const period = req.query.period || 'this month';

    const result = await entryExitService.getAttendanceStats(empNum, period);
    res.json({
      success: true,
      employeeNumber: empNum,
      period,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get attendance stats:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Admin endpoint to clear cache
app.post('/api/time-tracking/cache/clear', (req, res) => {
  const { employeeNumber } = req.body;
  entryExitService.clearCache(employeeNumber);
  res.json({
    success: true,
    message: employeeNumber ?
      `Cache cleared for employee ${employeeNumber}` :
      'All cache cleared'
  });
});

// Admin endpoint to get cache stats
app.get('/api/time-tracking/cache/stats', (req, res) => {
  const stats = entryExitService.getCacheStats();
  res.json({ success: true, stats });
});

// ============= ADMIN API ENDPOINTS =============

// Smart Discovery Endpoint
app.post('/api/admin/services/discover', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    // [SQ-FIX] Issue #3 (Rule S5144): SSRF Protocol Validation
    try {
      const parsedUrl = new URL(url);
      if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
        return res.status(400).json({ success: false, error: 'Invalid URL protocol. Only HTTP and HTTPS are allowed.' });
      }
    } catch (e) {
      return res.status(400).json({ success: false, error: 'Invalid URL format' });
    }

    console.log(`[AdminAPI] Discovering service at: ${url}`);
    const analysis = await mcpDiscoveryService.discover(url);
    res.json({ success: true, analysis });
  } catch (error) {
    console.error('Discovery error:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Get all configured services

// Get all configured services
app.get('/api/admin/services', (req, res) => {
  try {
    const services = mcpServiceManager.getAllServices();
    res.json({ success: true, services });
  } catch (error) {
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Add or update a service
app.post('/api/admin/services', async (req, res) => {
  try {
    const serviceConfig = req.body;
    // Basic validation
    if (!serviceConfig.id || !serviceConfig.name || !serviceConfig.baseUrl) {
      return res.status(400).json({ error: 'Missing required fields: id, name, baseUrl' });
    }

    const savedService = await mcpServiceManager.addService(serviceConfig);
    res.json({ success: true, service: savedService });
  } catch (error) {
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Delete a service
app.delete('/api/admin/services/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const removed = await mcpServiceManager.removeService(id);
    if (removed) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, error: 'Service not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Get employee name from Entry/Exit MCP
app.get('/api/time-tracking/employee-name', async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting employee name for:', empNum);

    const entryExitV2Client = getEntryExitV2Client();
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_employee_name', {}, empNum);

    // Parse the result - MCP returns content array
    let name = 'Unknown';
    if (result && result.content) {
      const content = result.content[0];
      if (content && content.text) {
        try {
          const parsed = JSON.parse(content.text);
          name = parsed.name || parsed.employee_name || 'Unknown';
        } catch (e) {
          name = content.text;
        }
      }
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      name: name,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get employee name:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Get current check-in/out status from Entry/Exit MCP
app.get('/api/time-tracking/current-status', async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting current status for:', empNum);

    const entryExitV2Client = getEntryExitV2Client();
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_current_status', {}, empNum);

    // Parse the result - MCP returns content array or structuredContent
    let status = 'unknown';
    let lastSwipe = null;
    let location = null;

    // Try structuredContent first (more reliable)
    if (result && result.structuredContent) {
      const data = result.structuredContent;
      status = data.status || 'unknown';
      // last_swipe is an object with time, status, location
      if (data.last_swipe) {
        lastSwipe = data.last_swipe.time || null;
        location = data.last_swipe.location || null;
      }
    } else if (result && result.content) {
      const content = result.content[0];
      if (content && content.text) {
        try {
          const parsed = JSON.parse(content.text);
          status = parsed.status || parsed.current_status || 'unknown';
          // last_swipe is an object with time, status, location
          if (parsed.last_swipe) {
            lastSwipe = parsed.last_swipe.time || null;
            location = parsed.last_swipe.location || null;
          }
        } catch (e) {
          // Try to parse simple text response
          const text = content.text.toLowerCase();
          if (text.includes('in') || text.includes('checked in')) {
            status = 'IN';
          } else if (text.includes('out') || text.includes('checked out')) {
            status = 'OUT';
          }
        }
      }
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      status: status,
      lastSwipe: lastSwipe,
      location: location,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get current status:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// ============= COMMUNITY API ENDPOINTS =============

/**
 * GET /api/community/list - Get list of communities from MCP
 */
app.get('/api/community/list', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;

    console.log(`[Community API] Fetching communities: page=${page}, pageSize=${pageSize}`);

    const data = await communityService.getCommunityList(page, pageSize);

    // Use flattenCommunities for consistent parsing across MCP/legacy responses
    const flat = communityService.flattenCommunities(data);
    const communities = flat.map(c => ({
      id: c.communityId,
      name: c.name,
      description: c.description || '',
      members: c.members || 0,
      color: c.color || '#007bc0',
      icon: c.imageUrl || null,
      category: 'General',
      locations: (c.locations || []).map(l => ({
        id: l.id,
        name: l.name,
        code: l.code
      }))
    }));

    res.json({
      success: true,
      communities: communities,
      totalCount: communities.length,
      page: page,
      pageSize: pageSize
    });
  } catch (error) {
    console.error('[Community API] Error:', error.message);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred',
      communities: []
    });
  }
});

/**
 * POST /api/community/register - Register user to a community
 */
app.post('/api/community/register', async (req, res) => {
  try {
    const { communityId, locationId } = req.body;
    const authToken = req.headers['authorization'];

    if (!communityId || !locationId) {
      return res.status(400).json({ success: false, error: 'communityId and locationId are required' });
    }
    if (!authToken) {
      return res.status(401).json({ success: false, error: 'Authorization header is required' });
    }

    console.log(`[Community API] Registering: communityId=${communityId}, locationId=${locationId}`);

    const result = await communityService.registerUserToCommunity(
      Number(communityId),
      Number(locationId),
      { authToken }
    );

    const parsed = typeof result === 'string' ? JSON.parse(result) : result;
    res.json({
      success: parsed?.IsSuccess || false,
      message: parsed?.Message || '',
      data: parsed
    });
  } catch (error) {
    console.error('[Community API] Register error:', error.message);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred'
    });
  }
});

// Entry/Exit query endpoint for AI Chat
app.post('/api/entryexit/query', async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    // Use employee number from header if available, else from body, else default
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Processing entry/exit query:', query);
    console.log('Employee number:', empNumber);
    console.log('Auth token present:', !!authToken);

    // Use the new V2 AI-powered client that properly uses MCP tools
    const entryExitV2Client = getEntryExitV2Client();

    // Process the query using AI (chat endpoint) or intelligent tool selection
    // Pass the employee number from headers/body
    const result = await entryExitV2Client.processQueryWithAI(query, empNumber);

    res.json({
      response: result.response,
      employeeNumber: result.employeeNumber,
      method: result.method,
      tool_used: result.tool,
      success: result.success
    });

  } catch (error) {
    console.error('Entry/Exit query error:', error);
    res.status(500).json({
      error: 'Failed to process entry/exit query',
      details: 'Error details securely logged',
      response: "I'm having trouble accessing the attendance system. Please try again later or check the HR portal directly."
    });
  }
});

// Health check - Enhanced to check Entry/Exit MCP
app.get('/api/health', async (req, res) => {
  const health = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    services: {
      server: true,
      entryExit: false
    }
  };

  // Test Entry/Exit MCP connection
  try {
    await entryExitService.getEmployeeTimeData(routingContext.employeeNumber || 'test', 'test');
    health.services.entryExit = true;
  } catch (error) {
    health.services.entryExit = false;
    health.status = 'DEGRADED';
  }

  res.json(health);
});

// Authentication endpoint - Proxy to Bosch Arena API
// Authentication endpoint - Proxy to Bosch Arena API
app.post('/api/auth/login', async (req, res) => {
  let username = '';
  try {
    const { username: reqUsername, password, isPreEncrypted } = req.body;
    username = reqUsername; // Store for error handling scope

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    console.log('Login attempt for user:', username);
    console.log('Using boschAuthService for secure login...');
    console.log('Password is pre-encrypted:', isPreEncrypted ? 'Yes' : 'No (will encrypt)');

    // Use the service - pass isPreEncrypted flag to skip double-encryption
    const loginResponse = await boschAuthService.login(username, password, null, isPreEncrypted === true);

    console.log('Login successful for user:', username);

    // Store user tokens in cache for A2A agent calls
    try {
      console.log('--- STARTING JWT GENERATION AND CACHE DURING LOGIN ---');
      const oauthToken = loginResponse.access_token;
      console.log('OAuth Token to cache:', oauthToken?.substring(0, 50) + '...');
      const expiresIn = loginResponse.expires_in;
      const tokenResult = await boschAuthService.storeUserTokens(username, oauthToken, expiresIn);

      // Add session ID to response so frontend can use it
      loginResponse.sessionId = tokenResult.sessionId;
      console.log(`User ${username} tokens SUCCESSFULLY generated and cached with session ID: ${tokenResult.sessionId}`);
    } catch (tokenError) {
      console.error('--- FAILED to cache user tokens during login! ---');
      console.error('Error:', tokenError.message);
      // Continue anyway - login was successful
    }

    res.json(loginResponse);

  } catch (error) {
    console.error('Login proxy error:', error.message);

    // Handle axios error responses
    if (error.response) {
      const errorData = error.response.data;
      console.log('Login failed for user:', username, 'Status:', error.response.status);
      return res.status(error.response.status).json({
        error: errorData.error_description || errorData.error || 'Login failed'
      });
    }

    res.status(500).json({
      error: 'Authentication service unavailable. Please try again later.'
    });
  }
});

// ============= UNIFIED SMART CHAT ENDPOINT =============
// Import all services for smart routing
const intelligentRouter = require('./services/intelligent-router');
// communityService already imported at top of file
const travelService = require('./services/travel-service');
const seatbookingService = require('./services/seatbooking-service');
const bannerService = require('./services/banner-service');

/**
 * GET /api/chat/history - Get chat history for a user (7 days context)
 */
app.get('/api/chat/history', async (req, res) => {
  try {
    const { employeeNumber } = req.query;
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber) {
      return res.status(400).json({ error: 'Employee number is required' });
    }

    console.log(`[Chat History] Fetching history for ${empNumber}`);
    const history = await conversationContextService.loadContext(empNumber);

    res.json({
      success: true,
      history: history || []
    });
  } catch (error) {
    console.error('Error fetching chat history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch chat history'
    });
  }
});

/**
 * Privacy guard: Detect if a query is asking about another colleague's personal data
 * Returns { isColleagueQuery: boolean, reason: string }
 *
 * DESIGN PRINCIPLES:
 * 1. Queries about the LOGGED-IN USER's own data -> ALLOW
 * 2. Queries that EXPLICITLY reference another person (name, pronoun, relationship) -> BLOCK
 * 3. Queries that try to access BULK / ALL employee data -> BLOCK
 * 4. Ambiguous queries with NO explicit other-person reference -> ALLOW (assume self)
 *
 * ALLOW: "give me entry exit times", "my attendance", "show me today's hours", "when did I come"
 * BLOCK: "Rahul's attendance", "my friend's entry time", "his hours", "show all employee attendance",
 *        "who came late today", "list everyone's attendance", "team attendance"
 */
function detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName) {
  const q = query.toLowerCase().trim();
  const original = query.trim();

  // --- helpers ---
  const loggedInNames = [];
  if (loggedInUserName) {
    const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
    loggedInNames.push(...parts, loggedInUserName.toLowerCase());
  }
  const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

  // this fixed: Issue #13 & 15 - RegEx DOS (Avoid dynamic regex construction)
  const personalDataPattern = /(entry|exit|attendance|check\.?in|check\.?out|swipe|leave|payslip|salary|pay|compensation|working hours|work hours|hours worked|time tracking|late|absent|shift|overtime|schedule|booking|seat|travel|effort|performance|appraisal|data|details|info|information|record|records)/i;
  const hasPersonalData = personalDataPattern.test(q);

  // Self-reference tokens
  const selfPattern = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i am)\b/i;
  const hasSelfRef = selfPattern.test(q);

  // Colleague / relationship words
  const colleaguePattern = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|subordinate|buddy|peer|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i;
  const hasColleagueWord = colleaguePattern.test(q);

  // --- FAST PATH: self-reference with NO colleague word AND no other-person name -> ALLOW ---
  // We must NOT fast-path if the query also contains another person's name.
  // e.g. "show me entry exit of vaishnav" has 'me' but also 'vaishnav'
  if (hasSelfRef && !hasColleagueWord) {
    // Check for "of/for <name>" pattern (case-insensitive)
    const hasOfForName = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
    let otherNameDetected = false;
    if (hasOfForName) {
      const candidate = hasOfForName[1].toLowerCase();
      const safeWords = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
        'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
        'week', 'month', 'year', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
        'bangalore', 'coimbatore', 'bosch', 'india', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'lunch', 'dinner', 'breakfast',
        'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
        'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
        'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat',
        'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
        'data', 'record', 'records', 'report', 'log', 'hours', 'working',
        'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
        'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
        'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
        'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips']);
      if (!safeWords.has(candidate) && !isOwnName(candidate)) {
        otherNameDetected = true;
      }
    }
    // Check for possessive name: "vaishnav's entry"
    const hasPossessiveName = q.match(/(\w{3,})(?:'s|s')\s+/i);
    if (hasPossessiveName && !isOwnName(hasPossessiveName[1])) {
      const pName = hasPossessiveName[1].toLowerCase();
      const skipPossessive = new Set(['today', 'yesterday', 'tomorrow', 'it', 'that', 'this', 'there', 'here',
        'what', 'let', 'don', 'doesn', 'didn', 'won', 'today', 'week', 'month', 'year', 'last', 'next',
        'swipe', 'entry', 'exit', 'time', 'check', 'clock', 'shift', 'who', 'where', 'when', 'how']);
      if (!skipPossessive.has(pName)) otherNameDetected = true;
    }
    if (!otherNameDetected) {
      return { isColleagueQuery: false, reason: '' };
    }
    // Otherwise fall through to full checks
  }

  // --- CHECK 1: Bulk / collective data requests -> BLOCK ---
  const bulkPatterns = /\b(all\s+employee|every\s*one|everybody|team\s+attendance|team\s+entry|team\s+exit|department\s+attendance|who\s+all\s+came|who\s+came|who\s+left|who\s+is\s+absent|list\s+of\s+employees|employee\s+list|how\s+many\s+employees|how\s+many\s+people|all\s+staff|entire\s+team|full\s+team|whole\s+team|all\s+members|group\s+attendance|others?\s+attendance|others?\s+entry|others?\s+exit)\b/i;
  if (bulkPatterns.test(q)) {
    return { isColleagueQuery: true, reason: 'Bulk / collective data request' };
  }

  // --- CHECK 2: Impersonation detection -> BLOCK ---
  // "I am Rahul, show entry time", "my name is Priya, give attendance"
  const impersonation = q.match(/\b(?:i\s+am|i'm|my\s+name\s+is|this\s+is)\s+([a-z]+)/i);
  if (impersonation) {
    const claimedName = impersonation[1].toLowerCase();
    const skipWords = new Set(['looking', 'asking', 'checking', 'wondering', 'interested', 'trying', 'requesting', 'here', 'logged', 'the', 'a', 'an', 'not', 'also', 'just']);
    if (!isOwnName(claimedName) && !skipWords.has(claimedName)) {
      return { isColleagueQuery: true, reason: `Possible impersonation: ${impersonation[1]}` };
    }
  }

  // --- CHECK 3: Employee number for someone else -> BLOCK ---
  const empNumMatches = q.match(/\b(\d{7,8})\b/g);
  if (empNumMatches) {
    for (const num of empNumMatches) {
      if (num !== loggedInEmployeeNumber) {
        return { isColleagueQuery: true, reason: `Contains different employee number: ${num}` };
      }
    }
  }

  // --- CHECK 4: Explicit colleague / relationship words -> BLOCK ---
  if (hasColleagueWord) {
    return { isColleagueQuery: true, reason: 'Explicit colleague / relationship reference' };
  }

  // --- CHECK 5: Third-person pronouns with personal data -> BLOCK ---
  const thirdPerson = /\b(his|her|their|he|she|they)\b/i;
  if (thirdPerson.test(q) && hasPersonalData) {
    return { isColleagueQuery: true, reason: 'Third-person pronoun with personal data' };
  }

  // --- CHECK 6: "details/information about <someone>" -> BLOCK ---
  const aboutMatch = q.match(/\b(?:details?|information|info)\s+(?:about|on|of)\s+([a-z'']+(?:\s+[a-z'']+)?)/i);
  if (aboutMatch) {
    const target = aboutMatch[1].toLowerCase();
    const safeSelf = new Set(['me', 'myself', 'my', 'mine']);
    if (!safeSelf.has(target) && !isOwnName(target)) {
      return { isColleagueQuery: true, reason: `Asking about someone: ${aboutMatch[1]}` };
    }
  }

  // --- CHECK 7: Possessive name pattern: "Rahul's attendance" -> BLOCK ---
  const nonNames = new Set([
    'the', 'what', 'when', 'where', 'who', 'which', 'how', 'show', 'get', 'tell', 'give', 'find', 'fetch', 'list',
    'today', 'yesterday', 'tomorrow', 'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'thank',
    'hello', 'hi', 'hey', 'time', 'times', 'entry', 'exit', 'late', 'early', 'morning', 'evening', 'night',
    'afternoon', 'seat', 'travel', 'it', 'that', 'this', 'there', 'here', 'let', 'can', 'could', 'would', 'should',
    'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look', 'all', 'any', 'some', 'these', 'those', 'last',
    'next', 'first', 'second', 'working', 'hours', 'attendance', 'schedule', 'booking', 'details', 'information',
    'info', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
    'november', 'december', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
    'bangalore', 'coimbatore', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'india', 'bosch', 'one', 'day', 'days',
    'don', 'doesn', 'didn', 'won', 'wasn', 'aren', 'isn', 'haven', 'hasn', 'shouldn', 'wouldn', 'couldn', 'today',
    'office', 'home', 'shift', 'request', 'pending', 'approved', 'status', 'canteen', 'menu', 'food', 'lunch',
    'dinner', 'breakfast', 'snack', 'now', 'just', 'been', 'also', 'very', 'work', 'log', 'report', 'data',
    'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'overtime',
    'record', 'records', 'whole', 'entire', 'past', 'previous', 'each', 'every',
    'did', 'was', 'were', 'has', 'had', 'have',
    'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
    // Common AI-generated query starters (imperative verbs & descriptors)
    'provide', 'retrieve', 'display', 'generate', 'calculate', 'access', 'return', 'summarize', 'include',
    'share', 'pull', 'extract', 'compile', 'compute', 'present', 'load', 'read', 'query', 'search',
    'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
    'monthly', 'daily', 'weekly', 'annual', 'yearly', 'summary', 'period', 'range', 'between', 'during',
    'employee', 'user', 'member', 'staff', 'person', 'individual',
    'attendance', 'absences', 'presence', 'duration', 'login', 'logout', 'break',
    'second', 'third', 'fourth', 'fifth', 'quarter', 'half',
    'june', 'july', 'august', 'september', 'october', 'november', 'december',
    'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips', 'pune', 'delhi', 'bangalore',
    'start', 'end', 'date', 'dates', 'being', 'mode', 'with', 'from', 'to', 'into', 'for'
  ]);

  const possessiveRe = /(\w+)(?:'s|s')\s+/gi;
  for (const m of q.matchAll(possessiveRe)) {
    const name = m[1].toLowerCase();
    if (name.length > 2 && !nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
      return { isColleagueQuery: true, reason: `Possessive name: ${m[1]}` };
    }
  }

  // --- CHECK 8: "of/for <Name>" pattern -> BLOCK ---
  const ofForRe = /\b(?:of|for)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b/g;
  for (const m of original.matchAll(ofForRe)) {
    const name = m[1].toLowerCase();
    if (!nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
      return { isColleagueQuery: true, reason: `of/for <Name>: ${m[1]}` };
    }
  }

  // --- CHECK 9: Capitalized name near personal data (no self-ref) -> BLOCK ---
  if (!hasSelfRef) {
    const capNameRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(capNameRe)) {
      const name = m[1].toLowerCase();
      if (!nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
        // proximity check: name within 40 chars of a personal data keyword
        const idx = m.index;
        const window = original.substring(Math.max(0, idx - 40), idx + m[1].length + 40);
        if (personalDataPattern.test(window)) {
          return { isColleagueQuery: true, reason: `Capitalized name near personal data: ${m[1]}` };
        }
      }
    }
  }

  // --- CHECK 10: "for <Name>" without personal data keywords (follow-up evasion) -> BLOCK ---
  // Catches: "can you do it for vaishnavi", "do it for Rahul", "same for Priya"
  const forNameEvasion = q.match(/\bfor\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\s*\??$/i);
  if (forNameEvasion) {
    const name = forNameEvasion[1].toLowerCase();
    const safeForTargets = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
      'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
      'week', 'month', 'year', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
      'bangalore', 'coimbatore', 'bosch', 'india',
      'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'lunch', 'dinner', 'breakfast',
      'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
      'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
      'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat',
      'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
      'data', 'record', 'records', 'report', 'log', 'hours', 'working',
      'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
      'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
      'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
      'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips']);
    if (!safeForTargets.has(name) && !isOwnName(name)) {
      return { isColleagueQuery: true, reason: `"for <Name>" evasion: ${forNameEvasion[1]}` };
    }
  }

  // --- CHECK 11: Indirect phrasing ("tell about", "show details of") with a name -> BLOCK ---
  const indirectMatch = original.match(/\b(?:tell|show|give|get|fetch|find|display|check)\s+(?:me\s+)?(?:about|details?\s+(?:of|about|for))\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/);
  if (indirectMatch) {
    const name = indirectMatch[1].toLowerCase();
    if (!nonNames.has(name) && !isOwnName(name)) {
      return { isColleagueQuery: true, reason: `Indirect phrasing about: ${indirectMatch[1]}` };
    }
  }

  // DEFAULT: No explicit other-person reference -> treat as self-query -> ALLOW
  return { isColleagueQuery: false, reason: '' };
}

function isExplicitBannerQuery(queryText) {
  return /\b(?:what'?s\s+new|company\s+news|(?:latest|newest|recent|new|upcoming|current|present|ongoing)\s+(?:banners?|announcements?|news|promotions?)|(?:bosch|bgsw|company)\s+(?:banners?|announcements?|news|promotions?)|(?:banner|announcement|news|promotion)(?:s)?(?:\s+(?:image|images|detail|details|info))?|(?:upcoming|current|present|company|bosch|bgsw)\s+events?|events?\s+(?:in|on|of)\s+(?:bosch|bgsw|company))\b/i.test(String(queryText || ''));
}

function isExplicitCommunityQuery(queryText) {
  const q = String(queryText || '').toLowerCase();
  return /\bcommunity\b|\bcommunities\b|\bassociate\s*arena\b/i.test(q);
}


/**
 * Unified chat endpoint with intelligent routing
 * Routes queries to appropriate MCP service using OpenAI classification
 */
app.post('/api/chat', async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber, conversationHistory } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber || empNumber.trim() === '') {
      console.log('[UnifiedChat] REJECTED: No user identity (employeeNumber) provided');
      return res.status(401).json({
        error: 'Authentication required',
        response: "Please log in to your Bosch account to access the AI Travel Assistant and other personal services."
      });
    }

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('\n========== UNIFIED CHAT REQUEST ==========');
    console.log('Query:', query);
    console.log('Session:', sessionId);
    console.log('Employee:', empNumber);
    console.log('Auth present:', !!authToken);
    console.log('Auth token (first 60 chars):', authToken ? authToken.substring(0, 60) + '...' : 'NONE');
    console.log('Conversation history:', conversationHistory?.length || 0, 'messages');

    // ===== CONVERSATION CONTEXT ORCHESTRATION =====

    // Step 0: Initialize context (load history if needed)
    await conversationContextService.initializeContext(sessionId, empNumber);

    // Step 0.5: Add user message to conversation context
    conversationContextService.addMessage(sessionId, 'user', query, {
      employeeNumber: empNumber,
      locationId
    });

    // Step 1: PRIVACY CHECK FIRST (on original query before rewriting)
    // This catches explicit friend/colleague requests before they get rewritten with names
    const explicitBannerQuery = isExplicitBannerQuery(query);
    const explicitCommunityQuery = isExplicitCommunityQuery(query);
    console.log(`[UnifiedChat] Processing query for Employee: ${empNumber}, User: ${req.body.userName || 'Unknown'}`);
    const colleagueQueryCheck = (explicitBannerQuery || explicitCommunityQuery)
      ? { isColleagueQuery: false, reason: '' }
      : detectColleagueQuery(query, empNumber, req.body.userName);
    if (colleagueQueryCheck.isColleagueQuery) {
      console.log('[Privacy] Blocked colleague data query:', colleagueQueryCheck.reason);

      // Save the privacy response to conversation context
      const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

      conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
        blocked: true,
        reason: 'colleague_privacy'
      });

      // Save to DB
      let conversationId = null;
      try {
        conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
      } catch (dbErr) {
        console.error('[Privacy] DB save error:', dbErr.message);
      }

      return res.json({
        response: privacyResponse,
        service: 'privacy_guard',
        serviceName: 'Privacy Protection',
        success: true,
        conversationId
      });
    }

    // Step 2a: Quick check for simple greetings - route them directly to general
    const greetingKeywords = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings'];
    const lowerQuery = query.toLowerCase().trim();
    const isSimpleGreeting = lowerQuery.length < 20 && greetingKeywords.some(greeting => lowerQuery.includes(greeting));

    if (isSimpleGreeting) {
      console.log('[Routing] Simple greeting detected, routing to general: "' + query + '"');
      const generalResponse = await intelligentRouter.generateGeneralResponse(query, conversationHistory);
      return res.json({
        success: true,
        response: generalResponse,
        service: 'general',
        serviceName: 'General Assistant'
      });
    }

    // Step 2b: Check if this is a follow-up query and rewrite it with context
    console.log('[Context] Checking for follow-up with sessionId:', sessionId);
    const contextResult = await conversationContextService.rewriteQueryWithContext(
      sessionId,
      query,
      conversationHistory
    );

    const effectiveQuery = contextResult.rewrittenQuery;
    const wasRewritten = contextResult.wasRewritten;

    console.log('[Context] Was rewritten:', wasRewritten);
    console.log('[Context] Effective query:', effectiveQuery);

    if (wasRewritten) {
      console.log('[Context] Original query:', query);
      console.log('[Context] Rewritten query:', effectiveQuery);
      console.log('[Context] Inferred service:', contextResult.inferredService);
    }

    // Step 2c: NARROW PRIVACY CHECK on the rewritten query
    // ONLY check for explicit name injection (possessive "Rahul's" or
    // We do NOT run the full detectColleagueQuery here because AI-rewritten queries
    // might introduce words like "Provide" (capitalized) which trip the privacy guard falsely.
    // We only check for explicit name injection patterns.
    const strictEvasionRe = /\b([A-Z][a-z]{2,})(?:'s|s')\s+(?:entry|exit|attendance|time|swipe|leave|record|data|details|info|information)/g;
    const strictForEvasionRe = /\b(?:of|for)\s+([A-Z][a-z]{2,})\b/g;

    if (wasRewritten && effectiveQuery !== query && !isExplicitBannerQuery(effectiveQuery) && !isExplicitCommunityQuery(effectiveQuery)) {
      const loggedInNames = [];
      if (req.body.userName) {
        req.body.userName.toLowerCase().split(/\s+/).filter(Boolean).forEach(p => loggedInNames.push(p));
        loggedInNames.push(req.body.userName.toLowerCase());
      }
      const isOwnNameRewrite = (n) => loggedInNames.includes(n.toLowerCase());

      // Known safe words that aren't person names
      const rewriteSafe = new Set([
        'me', 'myself', 'today', 'yesterday', 'tomorrow', 'now', 'free', 'monday', 'tuesday', 'wednesday',
        'thursday', 'friday', 'saturday', 'sunday', 'week', 'month', 'year', 'this', 'that', 'next', 'last',
        'bangalore', 'coimbatore', 'bosch', 'india', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune',
        'kolkata', 'goa', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august',
        'september', 'october', 'november', 'december', 'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug',
        'sep', 'oct', 'nov', 'dec', 'entry', 'exit', 'time', 'times', 'attendance', 'check', 'leave',
        'travel', 'booking', 'seat', 'swipe', 'swiped', 'data', 'record', 'records', 'report', 'log',
        'hours', 'working', 'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any',
        'every', 'each', 'all', 'days', 'day', 'lunch', 'dinner', 'breakfast', 'business', 'personal',
        'official', 'work', 'home', 'office', 'anyone', 'everyone', 'nothing', 'everything',
        'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
        // Common AI rewrite verbs and descriptors
        'provide', 'retrieve', 'display', 'generate', 'show', 'give', 'tell', 'fetch', 'list', 'find',
        'get', 'share', 'compile', 'present', 'summarize', 'include', 'access', 'return', 'load',
        'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
        'monthly', 'daily', 'weekly', 'annual', 'summary', 'period', 'range', 'between', 'during',
        'employee', 'user', 'member', 'staff', 'person', 'individual', 'duration', 'more', 'additional'
      ]);

      let nameInjected = false;
      let nameInjectedReason = '';

      // Only block: possessive "Name's data" injected into rewrite
      const possMatch = effectiveQuery.match(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g);
      if (possMatch) {
        for (const m of possMatch) {
          const name = m.replace(/('s|s')\s*$/i, '').trim().toLowerCase();
          if (!rewriteSafe.has(name) && !isOwnNameRewrite(name)) {
            nameInjected = true;
            nameInjectedReason = `Possessive name injected in rewrite: ${m.trim()}`;
            break;
          }
        }
      }

      // Only block: explicit "for <ProperName>" at end of sentence (evasion pattern)
      if (!nameInjected) {
        const forNameMatch = effectiveQuery.match(/\bfor\s+([A-Z][a-z]{3,}(?:\s+[A-Z][a-z]{3,})?)\s*[?.!]?$/);
        if (forNameMatch) {
          const name = forNameMatch[1].toLowerCase();
          if (!rewriteSafe.has(name) && !isOwnNameRewrite(name)) {
            nameInjected = true;
            nameInjectedReason = `Name injected via "for <Name>" evasion: ${forNameMatch[1]}`;
          }
        }
      }

      if (nameInjected) {
        console.log('[Privacy] Blocked REWRITTEN query (name injection):', nameInjectedReason);
        console.log('[Privacy] Original was:', query);
        console.log('[Privacy] Rewritten was:', effectiveQuery);

        const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

        conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
          blocked: true,
          reason: 'colleague_privacy_rewritten'
        });

        let conversationId = null;
        try {
          conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
        } catch (dbErr) {
          console.error('[Privacy] DB save error:', dbErr.message);
        }

        return res.json({
          response: privacyResponse,
          service: 'privacy_guard',
          serviceName: 'Privacy Protection',
          success: true,
          conversationId
        });
      }
    }

    // Step 3: Classify the query using AI (use rewritten query for better classification)
    // If context already inferred a service, use that as a hint
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/i;
    const isIdentityQuery = identityPattern.test(effectiveQuery);

    let classification = { service: 'general', serviceName: 'General Assistant' };
    if (!isIdentityQuery) {
      classification = await intelligentRouter.routeQuery(
        effectiveQuery,
        conversationHistory
      );
    } else {
      console.log('[Routing] Identity query detected, forcing entryexit service');
      classification = { service: 'entryexit', serviceName: 'Entry/Exit Time Tracking' };
    }

    // Override classification if context inference is strong
    let finalService = classification.service;
    const explicitBannerQueryFromEffectiveQuery = isExplicitBannerQuery(effectiveQuery);
    if (!isIdentityQuery && explicitBannerQueryFromEffectiveQuery) {
      finalService = 'banner';
    }

    if (!isIdentityQuery && wasRewritten && contextResult.inferredService && contextResult.inferredService !== 'general') {
      console.log('[Context] Using inferred service:', contextResult.inferredService);
      finalService = explicitBannerQueryFromEffectiveQuery ? 'banner' : contextResult.inferredService;
    }

    console.log('Classification:', finalService, '-', classification.serviceName);

    // Step 3: Route to appropriate service
    let result;
    const routingContext = {
      sessionId,
      authToken: authToken ? authToken.replace('Bearer ', '') : null,
      employeeNumber: empNumber,
      locationId
    };

    // Use finalService for routing (accounts for context-inferred service)
    switch (finalService) {
      case 'canteen':
        // Use existing canteen logic with context-aware query
        const mcpClient = await getClient();
        let canteenContext = conversationContexts.get(sessionId) || {};
        if (locationId) {
          canteenContext.location_id = locationId;
          canteenContext.location = locationId === 1 ? 'bangalore' : 'coimbatore';
          conversationContexts.set(sessionId, canteenContext);
        }
        // Use effectiveQuery (rewritten with context) instead of original query
        const canteenResult = await processIntelligentQuery(effectiveQuery, mcpClient, canteenContext);
        if (canteenResult.location_id) {
          canteenContext.location_id = canteenResult.location_id;
          canteenContext.location = canteenResult.location;
          conversationContexts.set(sessionId, canteenContext);
        }
        result = {
          success: true,
          response: canteenResult.response,
          service: 'canteen',
          serviceName: 'Canteen Menu',
          needs_location: canteenResult.needs_location,
          location_id: canteenResult.location_id,
          menuData: canteenResult.menuData
        };
        break;

      case 'entryexit':
        // Use existing entry/exit logic with context-aware query
        const entryExitV2Client = getEntryExitV2Client();
        // Use effectiveQuery (rewritten with context) instead of original query
        const entryExitResult = await entryExitV2Client.processQueryWithAI(effectiveQuery, empNumber);
        result = {
          success: entryExitResult.success,
          response: entryExitResult.response,
          service: 'entryexit',
          serviceName: 'Entry/Exit Time Tracking',
          employeeNumber: entryExitResult.employeeNumber,
          tool_used: entryExitResult.tool
        };
        break;

      case 'travel':
        // Ensure userName and identity metadata are correctly propagated
        if (req.body.userName) {
          routingContext.userName = req.body.userName;
        }

        // Resolve tokens for the user
        try {
          if (routingContext.authToken) {
            console.log(`[UnifiedChat] Resolving tokens for Travel Service (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken);
            if (userTokens) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.sessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token and Session ID successfully attached to routingContext (Travel)');
            }
          } else {
            console.log('[UnifiedChat] No authToken provided, travel-service will fallback to Service Account (Votan)');
          }
        } catch (tokenError) {
          console.log('[UnifiedChat] Token resolution warning:', tokenError.message);
        }

        // Use effectiveQuery for context-aware processing
        const travelResult = await travelService.processQuery(effectiveQuery, routingContext);
        result = {
          success: travelResult.success,
          response: travelResult.response,
          service: 'travel',
          serviceName: 'Travel Assistant',
          data: travelResult.data
        };
        break;

      case 'seatbooking':
        // Resolve tokens for the user
        try {
          if (routingContext.authToken) {
            console.log('[UnifiedChat] resolving tokens for seat booking...');
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken);
            if (userTokens) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.sessionId = userTokens.sessionId;
              console.log('[UnifiedChat] Tokens resolved and added to context');
            }
          } else {
            // defensive log - absence of auth header means we will not touch cache
            console.log('[UnifiedChat] no auth token provided; cannot resolve user tokens');
          }
        } catch (tokenError) {
          console.error('[UnifiedChat] ERROR resolving tokens for seat booking:', tokenError.message);
          console.error('[UnifiedChat] Proceeding without explicit tokens - Seat Booking service will handle fallback or failure.');
        }

        // Use effectiveQuery for context-aware processing
        const seatResult = await seatbookingService.processQuery(effectiveQuery, routingContext);
        result = {
          success: seatResult.success,
          response: seatResult.response,
          service: 'seatbooking',
          serviceName: 'Seat Booking',
          data: seatResult.data
        };
        break;

      case 'community':
        // Use effectiveQuery for context-aware processing
        const communityResult = await communityService.processQuery(effectiveQuery, routingContext);
        result = {
          success: communityResult.success,
          response: communityResult.response,
          service: 'community',
          serviceName: 'Bosch Community',
          data: communityResult.data
        };
        break;

      case 'banner':
        // Use effectiveQuery for context-aware processing
        const bannerResult = await bannerService.processBannerQuery(effectiveQuery);
        result = {
          success: !bannerResult.error,
          response: bannerResult.response,
          service: 'banner',
          serviceName: 'Company News/Snippets',
          banners: bannerResult.banners,
          hasBannerImages: bannerResult.hasBannerImages
        };
        break;

      case 'general':
        // Use effectiveQuery for context-aware processing
        // Get full context including persisted history
        const generalContext = conversationContextService.getContext(sessionId);
        const fullHistory = generalContext && generalContext.messages.length > 0 ? generalContext.messages : conversationHistory;

        const generalResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fullHistory);
        result = {
          success: true,
          response: generalResponse,
          service: 'general',
          serviceName: 'General Assistant'
        };
        break;

      default:
        // Check if it's a dynamic service
        const serviceConfig = mcpServiceManager.getService(finalService);
        if (serviceConfig) {
          try {
            const genericClient = new GenericMCPClient(serviceConfig);
            // Pass context
            const dynamicContext = {
              sessionId,
              employeeNumber: empNumber,
              locationId,
              history: conversationHistory
            };

            const dynamicResult = await genericClient.processQuery(effectiveQuery, dynamicContext);

            result = {
              success: dynamicResult.success,
              response: dynamicResult.response,
              service: finalService,
              serviceName: serviceConfig.name,
              data: dynamicResult.originalData
            };
          } catch (err) {
            console.error(`Error invoking dynamic service ${finalService}:`, err);
            // Fallback to general if dynamic service fails
            const fallbackContext = conversationContextService.getContext(sessionId);
            const fallbackHistory = fallbackContext && fallbackContext.messages.length > 0 ? fallbackContext.messages : conversationHistory;
            const fallbackResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fallbackHistory);
            result = {
              success: true,
              response: fallbackResponse,
              service: 'general',
              serviceName: 'General Assistant (Fallback)'
            };
          }
        } else {
          // Unknown service, default to general
          const unknownContext = conversationContextService.getContext(sessionId);
          const unknownHistory = unknownContext && unknownContext.messages.length > 0 ? unknownContext.messages : conversationHistory;
          const unknownResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, unknownHistory);
          result = {
            success: true,
            response: unknownResponse,
            service: 'general',
            serviceName: 'General Assistant'
          };
        }
        break;
    }

    // ===== UPDATE CONVERSATION CONTEXT =====
    // Step 4: Store the AI response and update context metadata
    const topic = conversationContextService.extractTopicFromResponse(result.response, result.service);
    const dateInQuery = conversationContextService.extractDate(effectiveQuery);

    // Extract month reference from the query (e.g. "February 2026" → "2026-02")
    const monthNames = {
      january: '01', jan: '01', february: '02', feb: '02', march: '03', mar: '03',
      april: '04', apr: '04', may: '05', june: '06', jun: '06', july: '07', jul: '07',
      august: '08', aug: '08', september: '09', sep: '09', october: '10', oct: '10',
      november: '11', nov: '11', december: '12', dec: '12'
    };
    let monthInQuery = null;
    const monthRegex = /\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\b(?:\s+(\d{4}))?/i;
    const monthMatch = effectiveQuery.match(monthRegex);
    if (monthMatch) {
      const mNum = monthNames[monthMatch[1].toLowerCase()];
      const mYear = monthMatch[2] || new Date().getFullYear().toString();
      monthInQuery = `${mYear}-${mNum}`;
    }

    conversationContextService.addMessage(sessionId, 'assistant', result.response, {
      service: result.service,
      topic: topic,
      date: dateInQuery,
      month: monthInQuery,
      locationId: result.location_id || locationId
    });

    // Update service context for future follow-ups
    conversationContextService.updateServiceContext(sessionId, {
      service: result.service,
      topic: topic,
      date: dateInQuery,
      month: monthInQuery,
      locationId: result.location_id || locationId
    });

    console.log('[Context] Updated context - Service:', result.service, 'Topic:', topic, 'Date:', dateInQuery);
    console.log('Response service:', result.service);
    console.log('==========================================\n');

    // Include context info in response for debugging (optional)
    result.contextInfo = {
      wasRewritten: wasRewritten,
      originalQuery: wasRewritten ? query : undefined,
      effectiveQuery: wasRewritten ? effectiveQuery : undefined
    };

    // ===== PERSIST TO MS SQL AZURE DB =====
    // Save conversation to database (non-blocking, don't fail the response)
    let conversationId = null;
    try {
      // Generate a proper UUID for the session if the frontend sessionId isn't UUID format
      const { v4: uuidv4, validate: uuidValidate } = require('uuid');
      const dbSessionId = uuidValidate(sessionId) ? sessionId : uuidv4();

      conversationId = await conversationDbService.saveConversation(
        dbSessionId,
        result.service || 'web',
        query,
        result.response || ''
      );
    } catch (dbError) {
      console.error('[ConversationDB] Failed to persist (non-fatal):', dbError.message);
    }

    // Include conversationId in response for feedback reference
    result.conversationId = conversationId;

    res.json(result);

  } catch (error) {
    console.error('Unified chat error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process query',
      details: 'Error details securely logged',
      response: "I'm having trouble processing your request right now. Please try again."
    });
  }
});

/**
 * POST /api/chat/feedback - Submit feedback for a conversation
 * Body: { conversationId: number, feedback: number }
 * feedback: -1 = thumbs down, 0 = no feedback, 1 = thumbs up
 */
app.post('/api/chat/feedback', async (req, res) => {
  try {
    const { conversationId, feedback } = req.body;

    if (!conversationId) {
      return res.status(400).json({ error: 'conversationId is required' });
    }

    if (![-1, 0, 1].includes(feedback)) {
      return res.status(400).json({ error: 'feedback must be -1, 0, or 1' });
    }

    console.log(`[Feedback] Updating conversation ${conversationId} with feedback: ${feedback}`);
    const success = await conversationDbService.updateFeedback(conversationId, feedback);

    if (success) {
      res.json({ success: true, message: 'Feedback saved' });
    } else {
      res.status(404).json({ success: false, error: 'Conversation not found or DB unavailable' });
    }
  } catch (error) {
    console.error('Feedback error:', error);
    res.status(500).json({ success: false, error: 'Failed to save feedback' });
  }
});

// Get available services
app.get('/api/services', (req, res) => {
  const servicesMap = intelligentRouter.getAllServices();
  const servicesList = Object.entries(servicesMap).map(([id, s]) => ({
    id: id,
    name: s.name,
    icon: s.icon || 'ðŸ¤–', // Default icon if none provided
    description: s.description,
    isDynamic: !!s.isDynamic
  }));

  res.json({
    services: servicesList
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Logs will be stored in: ${logsDir}`);
  console.log(`Entry/Exit MCP URL: ${process.env.ENTRYEXIT_MCP_URL || 'Using default URL'}`);
  console.log(`Smart routing enabled with services: canteen, entryexit, travel, seatbooking, community, banner`);
});