const fetch = require('node-fetch');

async function testCanteenAPI() {
  console.log('Testing Canteen API...\n');
  
  // Test 1: Query today's menu for Bangalore
  console.log('Test 1: Today\'s menu for Bangalore');
  // this fixed: Issue #17 - Insecure Transmission
  const apiUrl = process.env.API_URL || 'http://localhost:3001';
  try {
    const response = await fetch(`${apiUrl}/api/canteen/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: "today's menu",
        sessionId: 'test-session-1',
        locationId: 1
      })
    });
    
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
    console.log('\n---\n');
  } catch (error) {
    console.error('Error:', error.message);
  }
  
  // Test 2: Query without location (should ask for location)
  console.log('Test 2: Today\'s menu without location');
  // this fixed: Issue #17 - Insecure Transmission
  try {
    const response = await fetch(`${apiUrl}/api/canteen/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: "what's for lunch today",
        sessionId: 'test-session-2'
      })
    });
    
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
    console.log('\n---\n');
  } catch (error) {
    console.error('Error:', error.message);
  }
  
  // Test 3: Query for specific date
  console.log('Test 3: Menu for 28th November');
  // this fixed: Issue #17 - Insecure Transmission
  try {
    const response = await fetch(`${apiUrl}/api/canteen/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: "menu for 28th November Bangalore",
        sessionId: 'test-session-3'
      })
    });
    
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error:', error.message);
  }
}

// Run the test
testCanteenAPI().catch(console.error);
