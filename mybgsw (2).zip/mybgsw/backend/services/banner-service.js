const axios = require('axios');

const https = require('https');

const path = require('path');

if (!process.env.BANNER_MCP_URL) {

  require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

}

const BANNER_MCP_URL = process.env.BANNER_MCP_URL;

const DEFAULT_BANNER_LIST_LIMIT = Number.parseInt(process.env.BANNER_DEFAULT_LIST_LIMIT || '10', 10);

const AZURE_OPENAI_ENDPOINT = process.env.AZURE_OPENAI_ENDPOINT;

const AZURE_OPENAI_DEPLOYMENT = process.env.AZURE_OPENAI_DEPLOYMENT;

const AZURE_OPENAI_API_VERSION = process.env.AZURE_OPENAI_API_VERSION || '2024-12-01-preview';

const AZURE_OPENAI_API_KEY = process.env.AZURE_OPENAI_API_KEY;

const BANNER_MCP_PROTOCOL_VERSION = process.env.BANNER_MCP_PROTOCOL_VERSION || '2025-03-26';

const BANNER_MCP_CLIENT_NAME = process.env.BANNER_MCP_CLIENT_NAME || 'mybgs-banner-client';

const BANNER_MCP_CLIENT_VERSION = process.env.BANNER_MCP_CLIENT_VERSION || '1.0.0';

const BANNER_MCP_INSECURE_TLS = process.env.BANNER_MCP_INSECURE_TLS === 'true';

const AZURE_OPENAI_INSECURE_TLS = process.env.AZURE_OPENAI_INSECURE_TLS === 'true';

const FIELD_ALIASES = {

  title: 'title',

  titles: 'title',

  name: 'title',

  names: 'title',

  description: 'description',

  descriptions: 'description',

  details: 'description',

  detail: 'description',

  tagline: 'tagline',

  taglines: 'tagline',

  tag: 'tag',

  tags: 'tag',

  image: 'image_data_url',

  images: 'image_data_url',

  picture: 'image_data_url',

  pictures: 'image_data_url',

  photo: 'image_data_url',

  photos: 'image_data_url',

  image_data_url: 'image_data_url',

  image_url: 'image_data_url',

  banner_id: 'banner_id',

  id: 'banner_id',

  ordinal: 'ordinal',

  order: 'ordinal',

  number: 'ordinal',

  end_date: 'end_date',

  date: 'end_date',

  time: 'end_date',

};

const BANNER_DETAIL_FIELDS = ['title', 'description', 'tagline', 'tag', 'banner_id', 'end_date'];

const BANNER_IMAGE_ONLY_FIELDS = ['image_data_url'];

const BANNER_DEFAULT_FIELDS = ['description', 'image_data_url'];

const IDENTITY_FIELDS = ['ordinal', 'title'];

const ORDINAL_TOKEN_SOURCE = 'first|second|third|fourth|fifth|1st|2nd|3rd|4th|5th|one|two|three|four|five|\\d+(?:st|nd|rd|th)?';

const ORDINAL_LIST_SOURCE = `(?:${ORDINAL_TOKEN_SOURCE})(?:\\s*(?:,|and)\\s*(?:${ORDINAL_TOKEN_SOURCE}))+`;

const STRUCTURED_SELECTOR_SOURCE = `(?:${ORDINAL_TOKEN_SOURCE}|last|banner\\s+number|all\\s+banners?|all\\s+the\\s+banners?)(?:\\s+number\\s+banner|\\s+banners?)?`;

const NEGATIVE_IMAGE_INTENT_PATTERN = /\b(?:without|no|exclude|excluding)\s+(?:image|images|picture|pictures|photo|photos)\b/i;

const ALL_DETAILS_INTENT_PATTERN = /\b(?:all|full|complete|entire)\s+(?:detail\w*|info(?:rmation)?|fields?|data)\b|\b(?:detail\w*|info(?:rmation)?|fields?|data)\s+of\s+all\b|\bevery\s+detail\w*\b|\ball\s+(?:the\s+)?(?:present\s+|current\s+)?banners?\b.*\bdetail\w*\b|\bdetail\w*\b.*\ball\s+(?:the\s+)?(?:present\s+|current\s+)?banners?\b|\beverything\b|\ball\s+data\b|\blatest\b.*\bbanner\b.*\bdetail\w*\b|\bbanner\b.*\bdetail\w*\b.*\blatest\b/i;

const LATEST_BANNER_INTENT_PATTERN = /\b(?:latest|newest|recent|most\s+latest)\b.*\bbanner\b|\bbanner\b.*\b(?:latest|newest|recent)\b/i;

const DATE_ONLY_INTENT_PATTERN = /\b(?:no\s+time|without\s+time|date\s+only|only\s+date|end\s+date\s+only)\b/i;

const SEARCH_NOISE_WORDS = [

  'show', 'give', 'find', 'only',  'image', 'images', 'banner', 'banners', 'event', 'events', 'current', 'upcoming', 'bosch', 'bgsw', 'company',

];

const SEARCH_NOISE_PATTERN = new RegExp(`\\b(?:basic\\s+info|${SEARCH_NOISE_WORDS.join('|')})\\b`, 'gi');

const ORDINAL_WORD_MAP = {

  first: 1,

  '1st': 1,

  one: 1,

  single: 1,

  second: 2,

  '2nd': 2,

  two: 2,

  third: 3,

  '3rd': 3,

  three: 3,

  fourth: 4,

  '4th': 4,

  four: 4,

  fifth: 5,

  '5th': 5,

  five: 5,

};

let mcpSessionId = null;

function getOptionalHttpsAgent(targetUrl, allowInsecureTls = false) {

  if (!/^https:/i.test(String(targetUrl || ''))) {

    return undefined;

  }

  return new https.Agent({ rejectUnauthorized: !allowInsecureTls });

}

function getBannerMcpUrl() {

  if (!BANNER_MCP_URL) {

    throw new Error('BANNER_MCP_URL is not configured.');

  }

  return BANNER_MCP_URL;

}

function parseMcpResponse(rawPayload) {

  if (typeof rawPayload !== 'string') {

    return rawPayload;

  }

  const lines = rawPayload.split(/\r?\n/);

  let parsedPayload = null;

  for (const line of lines) {

    const trimmedLine = line.trim();

    if (!trimmedLine.startsWith('data:')) {

      continue;

    }

    const jsonText = trimmedLine.slice(5).trim();

    try {

      parsedPayload = JSON.parse(jsonText);

    } catch (_error) {

      // Ignore non-JSON SSE lines.

    }

  }

  if (parsedPayload) {

    return parsedPayload;

  }

  try {

    return JSON.parse(rawPayload);

  } catch (_error) {

    return { raw: rawPayload };

  }

}

function extractToolResult(mcpPayload) {

  if (!mcpPayload || !mcpPayload.result) {

    return mcpPayload;

  }

  const toolResult = mcpPayload.result;

  if (!Array.isArray(toolResult.content)) {

    return toolResult;

  }

  for (const contentItem of toolResult.content) {

    if (contentItem.type !== 'text' || !contentItem.text) {

      continue;

    }

    try {

      return JSON.parse(contentItem.text);

    } catch (_error) {

      return { response: contentItem.text };

    }

  }

  return toolResult;

}

async function initializeMcpSession() {

  const initializePayload = {

    jsonrpc: '2.0',

    id: 1,

    method: 'initialize',

    params: {

      protocolVersion: BANNER_MCP_PROTOCOL_VERSION,

      capabilities: {},

      clientInfo: { name: BANNER_MCP_CLIENT_NAME, version: BANNER_MCP_CLIENT_VERSION },

    },

  };

  const bannerMcpUrl = getBannerMcpUrl();

  const response = await axios.post(bannerMcpUrl, initializePayload, {

    headers: {

      Accept: 'application/json, text/event-stream',

      'Content-Type': 'application/json',

    },

    proxy: false,

    timeout: 45000,

    httpsAgent: getOptionalHttpsAgent(bannerMcpUrl, BANNER_MCP_INSECURE_TLS),

    transformResponse: [(data) => data],

  });

  mcpSessionId = response.headers['mcp-session-id'] || null;

  return mcpSessionId;

}

async function callBannerTool(toolName, toolArguments = {}) {

  if (!mcpSessionId) {

    await initializeMcpSession();

  }

  const bannerMcpUrl = getBannerMcpUrl();

  try {

    const response = await axios.post(bannerMcpUrl, {

      jsonrpc: '2.0',

      id: Date.now(),

      method: 'tools/call',

      params: {

        name: toolName,

        arguments: toolArguments,

      },

    }, {

      headers: {

        Accept: 'application/json, text/event-stream',

        'Content-Type': 'application/json',

        ...(mcpSessionId ? { 'mcp-session-id': mcpSessionId } : {}),

      },

      proxy: false,

      timeout: 45000,

      httpsAgent: getOptionalHttpsAgent(bannerMcpUrl, BANNER_MCP_INSECURE_TLS),

      transformResponse: [(data) => data],

    });

    return extractToolResult(parseMcpResponse(response.data));

  } catch (error) {

    mcpSessionId = null;

    throw error;

  }

}

function extractOrdinals(queryText) {

  const ordinals = new Set();

  const ordinalPattern = new RegExp(`\\b(${ORDINAL_TOKEN_SOURCE})\\b`, 'gi');

  for (const match of queryText.matchAll(ordinalPattern)) {

    const token = match[1].toLowerCase();

    const mappedValue = ORDINAL_WORD_MAP[token];

    if (mappedValue) {

      ordinals.add(mappedValue);

      continue;

    }

    const numericValue = Number.parseInt(token, 10);

    if (!Number.isNaN(numericValue) && numericValue > 0) {

      ordinals.add(numericValue);

    }

  }

  return [...ordinals].sort((left, right) => left - right);

}

function extractDateAfterFilter(queryText) {

  const dateMatch = queryText.match(/\b(?:after|since)\s+(\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{4})\b/i);

  return dateMatch ? dateMatch[1] : null;

}

function parseCountToken(token) {

  if (!token) {

    return null;

  }

  const normalized = String(token).toLowerCase();

  const mapped = ORDINAL_WORD_MAP[normalized];

  if (mapped) {

    return mapped;

  }

  const numericValue = Number.parseInt(normalized.replace(/(st|nd|rd|th)$/i, ''), 10);

  return Number.isInteger(numericValue) && numericValue > 0 ? numericValue : null;

}

function dedupeValues(values) {

  return [...new Set((values || []).filter(Boolean))];

}

function dedupeOrdinals(values) {

  return dedupeValues(values)

    .map((value) => Number.parseInt(value, 10))

    .filter((value) => Number.isInteger(value) && value > 0)

    .sort((left, right) => left - right);

}

function isImageField(fieldName) {

  return fieldName === 'image_data_url' || fieldName === 'image';

}

function hasNegativeImageIntent(queryText) {

  return NEGATIVE_IMAGE_INTENT_PATTERN.test(queryText);

}

function hasAllDetailsIntent(queryText) {

  return ALL_DETAILS_INTENT_PATTERN.test(queryText);

}

function hasLatestBannerIntent(queryText) {

  return LATEST_BANNER_INTENT_PATTERN.test(queryText);

}

function isCompanyEventIntent(queryText) {

  return /\b(?:event|events)\b/i.test(String(queryText || ''))
&& /\b(?:bgsw|bosch|company|upcoming|current|present)\b/i.test(String(queryText || ''));

}

function normalizeSearchText(value) {

  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');

}

function isSearchNoiseToken(token) {

  return SEARCH_NOISE_WORDS.includes(String(token || '').toLowerCase());

}

function stripSearchNoise(value) {

  return String(value || '')

    .replace(SEARCH_NOISE_PATTERN, ' ')

    .replace(/\s+/g, ' ')

    .trim();

}

function extractSearchTokens(value) {

  return dedupeValues(

    String(value || '')

      .toLowerCase()

      .split(/[^a-z0-9]+/)

      .map((token) => token.trim())

      .filter((token) => token.length >= 2 && !isSearchNoiseToken(token))

  );

}

function extractMeaningfulSearchPhrase(queryText) {

  const cleaned = stripSearchNoise(queryText);

  // Also strip common English stop words that carry no search meaning

  const STOP_WORDS = /\b(which|what|are|is|the|in|a|an|of|to|for|and|or|on|at|by|with|from|about|how|do|does|did|can|could|would|should|will|shall|may|might|tell|me|my|all|any|some|these|those|there|here|that|this|please|thanks|thank|you|your|it|its|be|been|being|have|has|had|was|were|am|i|we|they|them|their|our|us|no|not|but|so|if|than|then|when|where|who|whom|whose|why|up|out|as|get|got|let)\b/gi;

  const meaningful = cleaned.replace(STOP_WORDS, ' ').replace(/[^a-zA-Z0-9]+/g, ' ').trim();

  return meaningful.length >= 3 ? meaningful : '';

}

function filterBannersByMeaningfulSearch(banners, queryText) {

  const phrase = extractMeaningfulSearchPhrase(queryText);

  if (!phrase) {

    return [];

  }

  const normalizedTokens = extractSearchTokens(phrase);

  if (normalizedTokens.length === 0) {

    return [];

  }

  return (banners || []).filter((banner) => {

    const haystack = normalizeSearchText([

      banner.title,

      banner.description,

      banner.tagline,

      banner.tag,

      banner.banner_id,

      banner.ordinal,

    ].filter(Boolean).join(' '));

    return normalizedTokens.every((token) => haystack.includes(token));

  });

}

async function resolveNoResultBannerFallback(query, bannerPlan, originalQueryResult) {

  const queryText = String(query || '');

  const requestedFields = dedupeValues([

    ...(bannerPlan?.query?.fields || []),

    ...BANNER_DETAIL_FIELDS,

    'image_data_url',

    'ordinal',

    'title',

  ]);

  const broadResult = await callBannerTool('query_banners', {

    active_only: bannerPlan?.query?.active_only !== false,

    include_images: true,

    fields: requestedFields,

    sort_by: isCompanyEventIntent(queryText) || hasLatestBannerIntent(queryText) ? 'end_date' : (bannerPlan?.query?.sort_by || 'ordinal'),

    sort_order: bannerPlan?.query?.sort_order || 'asc',

    offset: 0,

  });

  const broadBanners = Array.isArray(broadResult?.banners) ? broadResult.banners : [];

  if (broadBanners.length === 0) {

    return originalQueryResult;

  }

  const matchedBanners = filterBannersByMeaningfulSearch(broadBanners, queryText);

  if (matchedBanners.length > 0) {

    return {

      ...broadResult,

      banners: matchedBanners,

      returned_count: matchedBanners.length,

      total_matched: matchedBanners.length,

    };

  }

  if (isCompanyEventIntent(queryText) && !extractMeaningfulSearchPhrase(queryText)) {

    return broadResult;

  }

  return originalQueryResult;

}

function extractRequestedOrdinalsFromQueryUsed(queryUsed) {

  if (!queryUsed) {

    return [];

  }

  const ordinalValues = [];

  const queryList = Array.isArray(queryUsed) ? queryUsed : [queryUsed];

  queryList.forEach((item) => {

    if (Array.isArray(item?.ordinals)) {

      ordinalValues.push(...item.ordinals);

    }

    if (Array.isArray(item?.selector?.ordinals)) {

      ordinalValues.push(...item.selector.ordinals);

    }

  });

  return dedupeOrdinals(ordinalValues);

}

function buildBannerAvailabilityMessage(totalAvailable, requestedOrdinals) {

  const total = Number.isInteger(totalAvailable) ? totalAvailable : null;

  const ordinals = dedupeOrdinals(requestedOrdinals || []);

  if (total === 0) {

    return 'There are no banners available right now.';

  }

  if (!total || ordinals.length === 0) {

    return null;

  }

  const missingOrdinals = ordinals.filter((ordinal) => ordinal > total);

  if (missingOrdinals.length === 0) {

    return null;

  }

  if (missingOrdinals.length === 1) {

    return `Only ${total} banner${total === 1 ? '' : 's'} ${total === 1 ? 'is' : 'are'} present right now. Banner ${missingOrdinals[0]} is not available.`;

  }

  return `Only ${total} banners are present right now. Banners ${missingOrdinals.join(', ')} are not available.`;

}

function attachBannerAvailabilityMessage(result, queryUsed, fallbackQueryResult = null) {

  const baseResult = result || {};

  const rawResult = baseResult.rawResult || fallbackQueryResult || {};

  const availabilityMessage = buildBannerAvailabilityMessage(

    rawResult?.total_available,

    extractRequestedOrdinalsFromQueryUsed(queryUsed),

  );

  if (!availabilityMessage) {

    return baseResult;

  }

  if (!Array.isArray(baseResult.banners) || baseResult.banners.length === 0) {

    return {

      ...baseResult,

      response: availabilityMessage,

    };

  }

  return {

    ...baseResult,

    response: `${availabilityMessage}\n\n${baseResult.response}`,

  };

}

function normalizeFieldList(fields) {

  return dedupeValues((fields || []).map((field) => FIELD_ALIASES[String(field).trim().toLowerCase()] || null));

}

function hasExplicitFieldIntent(queryText) {

  return /\b(?:title|titles|name|names|description|descriptions|detail\w*|tagline|taglines|tag|tags|banner[\s_-]*id|id|image|images|picture|pictures|photo|photos|expiry|end\s*date|date|time)\b/i.test(String(queryText || ''));

}

function extractRequestedFields(queryText) {

  const fields = [];

  const negativeImageIntent = hasNegativeImageIntent(queryText);

  const allDetailsIntent = hasAllDetailsIntent(queryText);

  const expiryIntent = /\bexpiry\b|\bexpir\w*\b|\bend\s*date\b|\bdate\s*wise\b|\bdate\b|\btime\b|\bwhen\b|\bending\b/i.test(queryText);

  if (allDetailsIntent) {

    fields.push('title', 'description', 'tagline', 'tag', 'banner_id', 'end_date');

  }

  if (/\btitle(?:s)?\b|\bname(?:s)?\b/i.test(queryText)) {

    fields.push('title');

  }

  if (/\bdescription(?:s)?\b/i.test(queryText) || (!expiryIntent && /\bdetail(?:s)?\b/i.test(queryText))) {

    fields.push('description');

  }

  if (/\btagline(?:s)?\b/i.test(queryText)) {

    fields.push('tagline');

  }

  if (/\btag(?:s)?\b/i.test(queryText)) {

    fields.push('tag');

  }

  if (/\bbanner[\s_-]*id\b|\bid\b/i.test(queryText)) {

    fields.push('banner_id');

  }

  if (!negativeImageIntent && /\bimage(?:s)?\b|\bpicture(?:s)?\b|\bphoto(?:s)?\b/i.test(queryText)) {

    fields.push('image_data_url');

  }

  if (expiryIntent) {

    fields.push('end_date');

  }

  return dedupeValues(fields);

}

function splitQueryIntoClauses(queryText) {

  return String(queryText || '')

    .split(/\b(?:with|and then|also|plus)\b|,/i)

    .map((part) => part.trim())

    .filter(Boolean);

}

function splitStructuredQueryIntoClauses(queryText) {

  return String(queryText || '')

    .split(new RegExp(`\\s+and\\s+(?=(?:the\\s+)?(?:(?:image(?:s)?|title(?:s)?|expiry|end\\s*date|detail\\w*|banner_id)\\b.*?${STRUCTURED_SELECTOR_SOURCE}|${STRUCTURED_SELECTOR_SOURCE}\\b.*?(?:image(?:s)?|title(?:s)?|expiry|end\\s*date|detail\\w*|banner_id)))|,(?=\\s*(?:the\\s+)?${STRUCTURED_SELECTOR_SOURCE})`, 'i'))

    .map((part) => part.trim())

    .filter(Boolean);

}

function extractExplicitBannerOrdinals(queryText) {

  const ordinals = new Set();

  const patterns = [

    new RegExp(`\\b(${ORDINAL_TOKEN_SOURCE})\\s+(?:number\\s+)?banners?\\b`, 'gi'),

    new RegExp(`\\bbanner\\s+number\\s+(${ORDINAL_TOKEN_SOURCE})\\b`, 'gi'),

    new RegExp(`\\b(${ORDINAL_LIST_SOURCE})\\s+(?:number\\s+)?banners?\\b`, 'gi'),

  ];

  for (const pattern of patterns) {

    for (const match of queryText.matchAll(pattern)) {

      const ordinalTokens = String(match[1] || '').split(/\s*(?:,|and)\s*/i);

      for (const token of ordinalTokens) {

        const parsed = parseCountToken(token);

        if (parsed) {

          ordinals.add(parsed);

        }

      }

    }

  }

  return [...ordinals].sort((left, right) => left - right);

}

function hasDateOnlyIntent(queryText) {

  return DATE_ONLY_INTENT_PATTERN.test(String(queryText || ''));

}

function formatBannerEndDate(endDate, dateOnly = false) {

  if (!endDate) {

    return endDate;

  }

  if (!dateOnly) {

    return endDate;

  }

  const parsedDate = new Date(endDate);

  if (!Number.isNaN(parsedDate.getTime())) {

    return parsedDate.toLocaleDateString('en-US');

  }

  return String(endDate).replace(/\s+\d{1,2}:\d{2}:\d{2}\s*(?:AM|PM)?$/i, '').trim();

}

function extractSectionSelector(queryText) {

  const text = String(queryText || '').toLowerCase();

  const explicitOrdinals = extractExplicitBannerOrdinals(text);

  const fallbackOrdinals = extractOrdinals(text);

  const firstCountMatch = text.match(/\bfirst\s+(one|two|three|four|five|\d+)\b/i);

  const lastCountMatch = text.match(/\blast\s+(one|two|three|four|five|\d+)\b/i);

  const lastBannerMatch = text.match(/\blast\s+banner\b/i);

  const latestBannerMatch = hasLatestBannerIntent(text);

  if (explicitOrdinals.length > 0) {

    return {

      mode: 'ordinals',

      ordinals: explicitOrdinals,

    };

  }

  if (lastCountMatch) {

    return {

      mode: 'range',

      limit: parseCountToken(lastCountMatch[1]),

      sort_by: 'ordinal',

      sort_order: 'desc',

    };

  }

  if (lastBannerMatch) {

    return {

      mode: 'range',

      limit: 1,

      sort_by: 'ordinal',

      sort_order: 'desc',

    };

  }

  if (latestBannerMatch) {

    return {

      mode: 'range',

      limit: 1,

      sort_by: 'end_date',

      sort_order: 'desc',

    };

  }

  if (firstCountMatch) {

    return {

      mode: 'range',

      limit: parseCountToken(firstCountMatch[1]),

      sort_by: 'ordinal',

      sort_order: 'asc',

    };

  }

  if (fallbackOrdinals.length > 0) {

    return {

      mode: 'ordinals',

      ordinals: fallbackOrdinals,

    };

  }

  return {

    mode: 'all',

  };

}

function extractSortPreferences(queryText) {

  const text = String(queryText || '').toLowerCase();

  if (/\balphabet(?:ical|ically)?\b|\balphabet\s+order\b|\ba\s*to\s*z\b/i.test(text)) {

    return { sort_by: 'title', sort_order: 'asc' };

  }

  if (/\bexpiry\s*date\s*wise\b|\bend\s*date\s*wise\b|\bdate\s*wise\b/i.test(text)) {

    return {

      sort_by: 'end_date',

      sort_order: /\bdesc(?:ending)?\b/i.test(text) ? 'desc' : 'asc',

    };

  }

  return null;

}

function shouldUseDeterministicSections(queryText) {

  return splitStructuredQueryIntoClauses(queryText).length > 1

    || extractExplicitBannerOrdinals(queryText).length > 1

    || /\blast\b/i.test(queryText)

    || hasLatestBannerIntent(queryText)

    || /\balphabet(?:ical|ically)?\b|\balphabet\s+order\b|\ba\s*to\s*z\b/i.test(queryText)

    || /\bexpiry\s*date\s*wise\b|\bend\s*date\s*wise\b|\bdate\s*wise\b/i.test(queryText);

}

function inheritSharedSectionIntent(sections) {

  return (sections || []).map((section, index, list) => {

    const hasOnlyFallbackDescription = section.implicitFields && section.fields.length === 1 && section.fields[0] === 'description';

    if (!hasOnlyFallbackDescription || hasExplicitFieldIntent(section.clause) || section.selector.mode !== 'ordinals') {

      return section;

    }

    const donorSection = list.slice(index + 1).find((candidate) => candidate.fields.length > 0 && !candidate.implicitFields);

    if (!donorSection) {

      return section;

    }

    return {

      ...section,

      fields: [...donorSection.fields],

      include_images: donorSection.include_images,

      imageOnly: donorSection.imageOnly,

      dateOnly: donorSection.dateOnly,

      implicitFields: false,

    };

  });

}

function mergeContinuationSections(sections) {

  const mergedSections = [];

  (sections || []).forEach((section) => {

    const previousSection = mergedSections[mergedSections.length - 1];

    const isContinuation = previousSection
&& section.selector.mode === 'all'
&& hasExplicitFieldIntent(section.clause)
&& !hasAllDetailsIntent(section.clause)
&& !hasLatestBannerIntent(section.clause)
&& !/\ball\s+(?:the\s+)?(?:present\s+|current\s+)?banners?\b/i.test(section.clause)
&& !/\blast\b/i.test(section.clause)
&& extractExplicitBannerOrdinals(section.clause).length === 0
&& previousSection.selector.mode === 'ordinals';

    if (!isContinuation) {

      mergedSections.push(section);

      return;

    }

    previousSection.fields = dedupeValues([...previousSection.fields, ...section.fields]);

    previousSection.include_images = previousSection.include_images || section.include_images;

    previousSection.imageOnly = previousSection.fields.length > 0 && previousSection.fields.every(isImageField);

    previousSection.dateOnly = previousSection.dateOnly || section.dateOnly;

    previousSection.implicitFields = false;

  });

  return mergedSections;

}

// Resolve which normalized banners belong to a presentation section.

function getSectionBanners(normalizedBanners, section) {

  if (Array.isArray(section.normalizedBanners)) {

    return section.normalizedBanners;

  }

  if (Array.isArray(section.ordinals) && section.ordinals.length > 0) {

    return normalizedBanners.filter((banner) => section.ordinals.includes(banner.ordinal));

  }

  return normalizedBanners;

}

function buildDeterministicSections(queryText) {

  const clauses = splitStructuredQueryIntoClauses(queryText);

  const sections = clauses.map((clause) => {

    const fields = extractRequestedFields(clause);

    const allDetailsIntent = hasAllDetailsIntent(clause);

    const negativeImageIntent = hasNegativeImageIntent(clause);

    const selector = extractSectionSelector(clause);

    const sortPreferences = extractSortPreferences(clause) || {};

    const wantsImages = !negativeImageIntent && fields.some(isImageField);

    const dateOnly = hasDateOnlyIntent(clause);

    let normalizedFields;

    let implicitFields = false;

    if (allDetailsIntent) {

      normalizedFields = [...BANNER_DETAIL_FIELDS];

      if (wantsImages) {

        normalizedFields.push('image_data_url');

      }

    } else if (fields.length > 0) {

      normalizedFields = [...fields];

    } else if (sortPreferences.sort_by === 'end_date') {

      normalizedFields = ['end_date'];

    } else {

      normalizedFields = [...BANNER_DEFAULT_FIELDS];

      implicitFields = true;

    }

    if (negativeImageIntent) {

      normalizedFields = normalizedFields.filter((field) => !isImageField(field));

    }

    const imageOnly = normalizedFields.length > 0 && normalizedFields.every(isImageField);

    return {

      clause,

      fields: normalizeFieldList(normalizedFields),

      include_images: !negativeImageIntent && normalizedFields.some(isImageField),

      imageOnly,

      dateOnly,

      implicitFields,

      selector,

      sort_by: sortPreferences.sort_by || selector.sort_by || 'ordinal',

      sort_order: sortPreferences.sort_order || selector.sort_order || 'asc',

    };

  });

  return mergeContinuationSections(inheritSharedSectionIntent(sections));

}

async function executeDeterministicSections(queryText) {

  const sections = buildDeterministicSections(queryText);

  const mergedBanners = new Map();

  const presentationSections = [];

  let lastQueryResult = null;

  for (const section of sections) {

    const sectionFields = dedupeValues([

      ...section.fields,

      'ordinal',

      'title',

    ]);

    const toolArguments = {

      active_only: true,

      include_images: section.include_images,

      fields: sectionFields,

      offset: 0,

      sort_by: section.sort_by,

      sort_order: section.sort_order,

    };

    if (section.selector.mode === 'ordinals' && section.selector.ordinals.length > 0) {

      toolArguments.ordinals = section.selector.ordinals;

      toolArguments.limit = section.selector.ordinals.length;

    } else if (section.selector.mode === 'range' && section.selector.limit) {

      toolArguments.limit = section.selector.limit;

    }

    const queryResult = await callBannerTool('query_banners', toolArguments);

    lastQueryResult = queryResult;

    const sectionBanners = Array.isArray(queryResult?.banners) ? queryResult.banners : [];

    sectionBanners.forEach((banner, index) => {

      const key = banner.ordinal ?? banner.banner_id ?? banner.id ?? `${section.sort_by}-${index}`;

      const existing = mergedBanners.get(key) || {};

      mergedBanners.set(key, {

        ...existing,

        ...banner,

      });

    });

    presentationSections.push({

      fields: section.fields,

      dateOnly: section.dateOnly,

      normalizedBanners: sectionBanners.map((banner, index) => normalizeBannerRecord(banner, index)),

    });

  }

  const mergedBannerList = [...mergedBanners.values()];

  const queryUsed = sections.map((section) => ({

    fields: section.fields,

    include_images: section.include_images,

    selector: section.selector,

    sort_by: section.sort_by,

    sort_order: section.sort_order,

  }));

  const formattedResult = formatBannerQueryResult({

    success: true,

    banners: mergedBannerList,

    total_available: lastQueryResult?.total_available,

  }, {

    showEndDate: sections.some((section) => section.fields.includes('end_date')),

    sections: presentationSections,

  });

  return {

    ...attachBannerAvailabilityMessage(formattedResult, queryUsed, lastQueryResult),

    queryUsed,

    querySource: 'deterministic-parser',

  };

}

function buildFallbackSections(queryText, overallDisplayFields) {

  const clauses = splitQueryIntoClauses(queryText);

  const sections = clauses.map((clause) => {

    const ordinals = extractOrdinals(clause);

    const fields = extractRequestedFields(clause);

    if (ordinals.length === 0 && fields.length === 0) {

      return null;

    }

    return {

      ordinals: ordinals.length > 0 ? ordinals : undefined,

      fields: fields.length > 0 ? fields : overallDisplayFields,

    };

  }).filter(Boolean);

  if (sections.length > 1) {

    return sections;

  }

  return [];

}

function normalizePresentationSection(section, fallbackFields) {

  const ordinals = dedupeOrdinals(section?.ordinals || []);

  const fields = normalizeFieldList(section?.fields || fallbackFields || []);

  return {

    ordinals: ordinals.length > 0 ? ordinals : undefined,

    fields: fields.length > 0 ? fields : normalizeFieldList(fallbackFields || []),

  };

}

function buildBannerPlan(query, structuredBannerQuery = null) {

  const queryText = String(query || '');

  const queryLower = queryText.toLowerCase();

  const extractedOrdinals = extractOrdinals(queryLower);

  const extractedFields = extractRequestedFields(queryLower);

  const negativeImageIntent = hasNegativeImageIntent(queryLower);

  const allDetailsIntent = hasAllDetailsIntent(queryLower);

  const dateFrom = extractDateAfterFilter(queryLower);

  const wantsImage = !negativeImageIntent && extractedFields.includes('image_data_url');

  const wantsBannerId = extractedFields.includes('banner_id');

  const wantsDescription = extractedFields.includes('description');

  const wantsTagline = extractedFields.includes('tagline');

  const wantsTag = extractedFields.includes('tag');

  const wantsDate = extractedFields.includes('end_date');

  const wantsTitlesOnly = /\btitle(?:s)?\s+only\b|\bonly\s+title(?:s)?\b/i.test(queryLower);

  const wantsImageOnly = wantsImage && !wantsDescription && !wantsTagline && !wantsTag && !wantsBannerId && !wantsDate && !wantsTitlesOnly && !allDetailsIntent;

  const wantsRecent = /\brecent(?:ly)?\b|\blatest\b|\bnew(?:est)?\b|\brecent banner events\b/i.test(queryLower);

  const wantsAlphabetical = /\balphabet(?:ical|ically)?\b|\ba to z\b/i.test(queryLower);

  const firstCountMatch = queryLower.match(/\bfirst\s+(two|three|four|five|2|3|4|5)\b/);

  const structuredQuery = structuredBannerQuery?.query && typeof structuredBannerQuery.query === 'object'

    ? structuredBannerQuery.query

    : (structuredBannerQuery && typeof structuredBannerQuery === 'object' ? structuredBannerQuery : null);

  const structuredPresentation = structuredBannerQuery?.presentation && typeof structuredBannerQuery.presentation === 'object'

    ? structuredBannerQuery.presentation

    : null;

  const explicitFieldSelection = extractedFields.length > 0 || wantsTitlesOnly || wantsDescription || wantsTagline || wantsTag || wantsBannerId || wantsImage || wantsDate || allDetailsIntent;

  const broadQuery = !explicitFieldSelection;

  let defaultDisplayFields;

  if (allDetailsIntent) {

    defaultDisplayFields = [...BANNER_DETAIL_FIELDS];

  } else if (wantsTitlesOnly) {

    defaultDisplayFields = ['title'];

  } else if (wantsImage && !wantsDescription && !wantsTagline && !wantsTag && !wantsBannerId && !wantsDate) {

    defaultDisplayFields = [...BANNER_IMAGE_ONLY_FIELDS];

  } else if (broadQuery || wantsRecent) {

    defaultDisplayFields = ['description', 'image_data_url'];

  } else {

    defaultDisplayFields = extractedFields.filter((field) => field !== 'ordinal');

  }

  if (defaultDisplayFields.length === 0) {

    defaultDisplayFields = [...BANNER_DEFAULT_FIELDS];

  }

  const fallbackSections = buildFallbackSections(queryLower, defaultDisplayFields)

    .map((section) => normalizePresentationSection(section, defaultDisplayFields));

  let sections = Array.isArray(structuredPresentation?.sections)

    ? structuredPresentation.sections.map((section) => normalizePresentationSection(section, defaultDisplayFields))

    : [];

  if (allDetailsIntent) {

    sections = [];

  } else if (negativeImageIntent || wantsImageOnly || fallbackSections.length > 0) {

    sections = fallbackSections;

  }

  const mergedOrdinals = dedupeOrdinals([

    ...(structuredQuery?.ordinals || []),

    ...extractedOrdinals,

    ...sections.flatMap((section) => section.ordinals || []),

  ]);

  if (sections.length === 0) {

    sections = [normalizePresentationSection({

      ordinals: mergedOrdinals,

      fields: defaultDisplayFields,

    }, defaultDisplayFields)];

  }

  const sectionFields = sections.flatMap((section) => section.fields || []);

  const includeImages = !negativeImageIntent && (Boolean(structuredQuery?.include_images)

    || broadQuery

    || sectionFields.some(isImageField)

    || wantsImage);

  const showEndDate = Boolean(structuredPresentation?.show_end_date) || wantsDate;

  let queryFields = normalizeFieldList([

    ...(structuredQuery?.fields || []),

    ...sectionFields,

    ...IDENTITY_FIELDS,

  ]);

  if (includeImages) {

    queryFields = dedupeValues([...queryFields, 'image_data_url', 'title']);

  } else {

    queryFields = queryFields.filter((field) => !isImageField(field));

  }

  if (wantsBannerId || sectionFields.includes('banner_id') || (structuredQuery?.fields || []).includes('banner_id')) {

    queryFields = dedupeValues([...queryFields, 'banner_id']);

  }

  if (showEndDate) {

    queryFields = dedupeValues([...queryFields, 'end_date']);

  } else {

    queryFields = queryFields.filter((field) => field !== 'end_date');

  }

  let limit = Number.isInteger(structuredQuery?.limit) ? structuredQuery.limit : undefined;

  if (!limit && firstCountMatch) {

    const countToken = firstCountMatch[1];

    limit = Number.parseInt(countToken, 10) || ORDINAL_WORD_MAP[countToken] || undefined;

  } else if (!limit && mergedOrdinals.length > 0) {

    limit = mergedOrdinals.length;

  }

  let sortBy = structuredQuery?.sort_by || 'ordinal';

  let sortOrder = structuredQuery?.sort_order || 'asc';

  if (wantsRecent || dateFrom) {

    sortBy = 'end_date';

    sortOrder = 'desc';

  } else if (!structuredQuery?.sort_by && wantsAlphabetical) {

    sortBy = 'title';

    sortOrder = 'asc';

  }

  return {

    query: {

      active_only: structuredQuery?.active_only !== false,

      include_images: includeImages,

      fields: queryFields,

      ordinals: mergedOrdinals.length > 0 ? mergedOrdinals : undefined,

      limit,

      offset: Number.isInteger(structuredQuery?.offset) ? structuredQuery.offset : 0,

      sort_by: sortBy,

      sort_order: sortOrder,

      title_contains: stripSearchNoise(structuredQuery?.title_contains) || undefined,

      description_contains: stripSearchNoise(structuredQuery?.description_contains) || undefined,

      tag_contains: stripSearchNoise(structuredQuery?.tag_contains) || undefined,

      search_text: stripSearchNoise(structuredQuery?.search_text) || undefined,

      date_from: structuredQuery?.date_from || dateFrom || undefined,

      date_to: structuredQuery?.date_to || undefined,

    },

    presentation: {

      showEndDate,

      sections,

    },

  };

}

function isAzureOpenAiConfigured() {

  return Boolean(AZURE_OPENAI_ENDPOINT && AZURE_OPENAI_DEPLOYMENT && AZURE_OPENAI_API_KEY);

}

async function buildBannerQueryWithLlm(query) {

  if (!isAzureOpenAiConfigured()) {

    return null;

  }

  const endpoint = `${AZURE_OPENAI_ENDPOINT.replace(/\/$/, '')}/openai/deployments/${AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${AZURE_OPENAI_API_VERSION}`;

  const systemPrompt = [

    'You convert natural language banner requests into strict JSON for a banner query tool and response presentation plan.',

    'Return only valid JSON with no markdown and no explanation.',

    'Top-level keys allowed: query, presentation.',

    'query is optional and may contain only: ordinals, fields, active_only, include_images, limit, offset, sort_by, sort_order, title_contains, description_contains, tag_contains, search_text, date_from, date_to.',

    'presentation is optional and may contain only: show_end_date, sections.',

    'presentation.sections must be an array of objects with only: ordinals, fields.',

    'Allowed field values everywhere: title, description, tagline, tag, end_date, image, image_data_url, ordinal, banner_id, has_image.',

    'Use ordinals for phrases like first, second, third, 1st, 2nd, 3rd.',

    'For mixed requests like image of second banner and title of third banner, create separate presentation sections and include all referenced ordinals in query.ordinals.',

    'If the user asks for only image, use image_data_url in presentation fields.',

    'For broad banner requests like latest or recent banners, include images by default even if the user did not explicitly ask for images.',

    'Do not ask to show end_date unless the user explicitly asked for date or time.',

    'When images are requested, make sure the query can still identify banners by title.',

    'If the request is broad and no explicit limit is given, do not invent a strict limit.',

  ].join(' ');

  const response = await axios.post(endpoint, {

    messages: [

      { role: 'system', content: systemPrompt },

      { role: 'user', content: query },

    ],

    temperature: 0,

    response_format: { type: 'json_object' },

  }, {

    headers: {

      'api-key': AZURE_OPENAI_API_KEY,

      'Content-Type': 'application/json',

    },

    timeout: 20000,

    httpsAgent: getOptionalHttpsAgent(endpoint, AZURE_OPENAI_INSECURE_TLS),

  });

  const llmText = response.data?.choices?.[0]?.message?.content;

  if (!llmText) {

    return null;

  }

  try {

    return JSON.parse(llmText);

  } catch (_error) {

    return null;

  }

}

function buildBannerQuery(query, structuredBannerQuery = null) {

  return buildBannerPlan(query, structuredBannerQuery).query;

}

function applyExplicitIntentOverrides(query, bannerPlan) {

  const queryText = String(query || '').toLowerCase();

  const allDetailsIntent = hasAllDetailsIntent(queryText);

  const negativeImageIntent = hasNegativeImageIntent(queryText);

  const requestedFields = extractRequestedFields(queryText);

  const wantsImage = requestedFields.includes('image_data_url') && !negativeImageIntent;

  const wantsImageOnly = wantsImage
&& !requestedFields.includes('description')
&& !requestedFields.includes('tagline')
&& !requestedFields.includes('tag')
&& !requestedFields.includes('banner_id')
&& !requestedFields.includes('end_date')
&& !requestedFields.includes('title');

  if (allDetailsIntent) {

    bannerPlan.query.fields = dedupeValues([

      ...bannerPlan.query.fields,

      ...BANNER_DETAIL_FIELDS,

      ...(negativeImageIntent ? [] : ['image_data_url']),

      'ordinal',

    ]);

    bannerPlan.query.include_images = !negativeImageIntent;

    bannerPlan.presentation.showEndDate = true;

    bannerPlan.presentation.sections = [normalizePresentationSection({

      ordinals: bannerPlan.query.ordinals,

      fields: BANNER_DETAIL_FIELDS,

    }, BANNER_DETAIL_FIELDS)];

  }

  if (negativeImageIntent) {

    bannerPlan.query.include_images = false;

    bannerPlan.query.fields = bannerPlan.query.fields.filter((field) => !isImageField(field));

    bannerPlan.presentation.sections = bannerPlan.presentation.sections.map((section) => ({

      ...section,

      fields: (section.fields || []).filter((field) => !isImageField(field)),

    }));

  }

  if (wantsImageOnly) {

    bannerPlan.query.include_images = true;

    bannerPlan.query.fields = dedupeValues(['image_data_url', 'ordinal', 'title']);

    bannerPlan.presentation.showEndDate = false;

    bannerPlan.presentation.sections = [normalizePresentationSection({

      ordinals: bannerPlan.query.ordinals,

      fields: BANNER_IMAGE_ONLY_FIELDS,

    }, BANNER_IMAGE_ONLY_FIELDS)];

  }

  return bannerPlan;

}

function dataUrlToBase64(value) {

  if (!value || typeof value !== 'string') {

    return null;

  }

  const match = value.match(/^data:image\/[a-zA-Z0-9.+-]+;base64,(.+)$/);

  return match ? match[1] : null;

}

function normalizeBannerRecord(banner, index) {

  const imageDataUrl = banner.image_data_url || banner.image_url || null;

  const imageBase64 = banner.image_base64 || dataUrlToBase64(imageDataUrl);

  return {

    id: banner.banner_id ?? banner.id ?? banner.ordinal ?? index + 1,

    ordinal: banner.ordinal ?? index + 1,

    bannerId: banner.banner_id ?? banner.id ?? null,

    title: banner.title || banner.tagline || banner.description || `Banner ${banner.ordinal ?? index + 1}`,

    description: banner.description || banner.tagline || '',

    tagline: banner.tagline || banner.description || '',

    tag: banner.tag || '',

    endDate: banner.end_date || null,

    hasImage: Boolean(banner.has_image || imageBase64 || imageDataUrl),

    imagePreview: imageBase64 ? imageBase64.substring(0, 200) : null,

    imageBase64,

    imageDataUrl,

  };

}

function formatBannerQueryResult(queryResult, presentation = null) {

  if (!queryResult || queryResult.success === false) {

    return {

      response: '📢 **Banner Service**\n\nUnable to fetch banners at the moment. Please try again later.',

      service: 'banner',

      banners: [],

      error: true,

      rawResult: queryResult,

    };

  }

  const banners = Array.isArray(queryResult.banners) ? queryResult.banners : [];

  if (banners.length === 0) {

    return {

      response: 'No banners matched your request.',

      service: 'banner',

      banners: [],

      hasBannerImages: false,

      rawResult: queryResult,

    };

  }

  const normalizedBanners = banners.map((banner, index) => normalizeBannerRecord(banner, index));

  const effectivePresentation = presentation && Array.isArray(presentation.sections)

    ? presentation

    : { showEndDate: false, sections: [{ fields: ['description', 'image_data_url'] }] };

  const renderBannerBlock = (banner, sectionFields = [], dateOnly = false) => {

    const fields = normalizeFieldList(sectionFields);

    const lines = [];

    lines.push(`**${banner.ordinal}. ${banner.title}**`);

    if (fields.includes('banner_id') && banner.bannerId !== null && banner.bannerId !== undefined && banner.bannerId !== '') {

      lines.push(`   Banner ID: ${banner.bannerId}`);

    }

    if (fields.includes('description') && banner.description) {

      lines.push(`   ${banner.description}`);

    }

    if (fields.includes('tagline') && banner.tagline && banner.tagline !== banner.description) {

      lines.push(`   Tagline: ${banner.tagline}`);

    }

    if (fields.includes('tag') && banner.tag && banner.tag !== '#Banners') {

      lines.push(`   Tag: ${banner.tag}`);

    }

    if ((fields.includes('end_date') || effectivePresentation.showEndDate) && banner.endDate) {

      lines.push(`   End Date: ${formatBannerEndDate(banner.endDate, dateOnly)}`);

    }

    return lines.length > 0 ? lines.join('\n') : null;

  };

  const renderedBlocks = [];

  const bannersWithRichText = new Set();

  effectivePresentation.sections.forEach((section) => {

    const sectionFields = normalizeFieldList(section.fields);

    const imageOnlySection = sectionFields.length > 0 && sectionFields.every(isImageField);

    if (imageOnlySection) {

      return;

    }

    const matchingBanners = getSectionBanners(normalizedBanners, section);

    matchingBanners.forEach((banner) => {

      bannersWithRichText.add(String(banner.ordinal));

    });

  });

  effectivePresentation.sections.forEach((section) => {

    const sectionFields = normalizeFieldList(section.fields);

    const imageOnlySection = sectionFields.length > 0 && sectionFields.every(isImageField);

    const matchingBanners = getSectionBanners(normalizedBanners, section);

    matchingBanners.forEach((banner) => {

      if (imageOnlySection && bannersWithRichText.has(String(banner.ordinal))) {

        return;

      }

      const block = renderBannerBlock(banner, section.fields, Boolean(section.dateOnly));

      if (block) {

        renderedBlocks.push(block);

      }

    });

  });

  const responseText = renderedBlocks.length > 0

    ? `📢 **Banner Results (${normalizedBanners.length})**\n\n${renderedBlocks.join('\n\n')}\n`

    : `📢 **Banner Results (${normalizedBanners.length})**`;

  return {

    response: responseText,

    service: 'banner',

    banners: normalizedBanners,

    hasBannerImages: normalizedBanners.some((banner) => Boolean(banner.imageDataUrl || banner.imageBase64)),

    rawResult: queryResult,

  };

}

async function getBannerDetails(limit = DEFAULT_BANNER_LIST_LIMIT, offset = 0) {

  const queryResult = await callBannerTool('query_banners', {

    active_only: true,

    include_images: true,

    fields: ['title', 'description', 'tag', 'image_data_url', 'ordinal', 'banner_id'],

    limit,

    offset,

  });

  return formatBannerQueryResult(queryResult);

}

async function processBannerQuery(query, structuredBannerQuery = null) {

  try {

    if (shouldUseDeterministicSections(query)) {

      return await executeDeterministicSections(query);

    }

    let llmBannerQuery = structuredBannerQuery || null;

    if (!llmBannerQuery) {

      try {

        llmBannerQuery = await buildBannerQueryWithLlm(query);

      } catch (_error) {

        llmBannerQuery = null;

      }

    }

    const bannerPlan = applyExplicitIntentOverrides(query, buildBannerPlan(query, llmBannerQuery));

    let queryResult = await callBannerTool('query_banners', bannerPlan.query);

    if (!Array.isArray(queryResult?.banners) || queryResult.banners.length === 0) {

      queryResult = await resolveNoResultBannerFallback(query, bannerPlan, queryResult);

    }

    const formattedResult = attachBannerAvailabilityMessage(

      formatBannerQueryResult(queryResult, bannerPlan.presentation),

      bannerPlan.query,

      queryResult,

    );

    return {

      ...formattedResult,

      queryUsed: bannerPlan.query,

      querySource: llmBannerQuery ? 'llm' : 'fallback-parser',

    };

  } catch (error) {

    return {

      response: '📢 **Banner Service**\n\nUnable to fetch banners at the moment. Please try again later.',

      service: 'banner',

      banners: [],

      hasBannerImages: false,

      error: true,

      details: error.message,

    };

  }

}

module.exports = {

  getBannerDetails,

  processBannerQuery,

  buildBannerQuery,

};

 