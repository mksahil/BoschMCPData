/**
 * Conversation Context Service
 * Maintains conversation context for AI orchestration
 * Enables follow-up queries like "what about yesterday?" to work correctly
 */

const { createOpenAIClient, getChatModelName } = require('./openai-client');
const fs = require('fs-extra');
const path = require('path');

class ConversationContextService {
  constructor() {
    // Store conversation contexts by sessionId
    // In production, use Redis or similar for persistence
    this.contexts = new Map();

    // Maximum number of messages to keep per session
    this.maxHistoryLength = 10;

    // Context expiry time (30 minutes)
    this.contextExpiryMs = 30 * 60 * 1000;

    // Initialize OpenAI for context analysis
    this._openai = null;

    // Directory for storing conversation history
    // In Azure/Cloud, use an absolute path to a mounted persistent volume via env var
    this.dataDir = process.env.CHAT_HISTORY_DIR || path.join(__dirname, '../data/conversations');
    fs.ensureDirSync(this.dataDir);
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Get or create a conversation context for a session
   */
  getContext(sessionId) {
    if (!this.contexts.has(sessionId)) {
      this.contexts.set(sessionId, {
        sessionId,
        messages: [],
        lastService: null,
        lastTopic: null,
        lastDate: null,
        lastMonth: null,
        locationId: null,
        employeeNumber: null,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    return this.contexts.get(sessionId);
  }

  /**
   * Initialize context for a user (load history)
   */
  async initializeContext(sessionId, employeeNumber) {
    if (!employeeNumber) return this.getContext(sessionId);

    // If context doesn't exist or is empty, try to load from disk
    let context = this.getContext(sessionId);

    if (context.messages.length === 0) {
      const history = await this.loadContext(employeeNumber);
      if (history && history.length > 0) {
        console.log(`[ConversationContext] Loaded ${history.length} messages for user ${employeeNumber}`);
        // Add loaded messages to current session context
        context.messages = history;
        context.employeeNumber = employeeNumber;

        // Restore context state (last service, topic, etc.) from the most recent relevant message
        // Scan backwards to find the last message with service info
        for (let i = history.length - 1; i >= 0; i--) {
          const msg = history[i];
          if (msg.service || msg.topic || msg.locationId) {
            context.lastService = msg.service || context.lastService;
            context.lastTopic = msg.topic || context.lastTopic;
            context.lastDate = msg.date || context.lastDate;
            context.locationId = msg.locationId || context.locationId;
            // Once we found the most recent state, we can stop for service/topic
            // But date might be in a different message, so maybe just take the last valid one for each?
            // simpler: just find the last AI response with metadata
            if (msg.role === 'assistant' && msg.service) break;
          }
        }

        this.contexts.set(sessionId, context);
      }
    }

    return context;
  }

  /**
   * Save context to disk
   */
  async saveContext(employeeNumber, messages) {
    if (!employeeNumber || !/^[a-zA-Z0-9_\-]+$/.test(employeeNumber.toString())) return;

    try {
      const filePath = path.join(this.dataDir, `${employeeNumber}.json`);
      
      // [SQ-FIX] Issue #4 (Rule S2083): Explicit containment check to satisfy static analysis
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(path.resolve(this.dataDir))) {
        throw new Error('Invalid path traversal attempt');
      }

      await fs.writeJson(resolvedPath, messages, { spaces: 2 });
    } catch (error) {
      console.error(`[ConversationContext] Failed to save context for ${employeeNumber}:`, error.message);
    }
  }

  /**
   * Load context from disk
   */
  async loadContext(employeeNumber) {
    if (!employeeNumber || !/^[a-zA-Z0-9_\-]+$/.test(employeeNumber.toString())) return [];

    try {
      const filePath = path.join(this.dataDir, `${employeeNumber}.json`);
      
      // [SQ-FIX] Issue #4 (Rule S2083): Explicit containment check to satisfy static analysis
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(path.resolve(this.dataDir))) {
        throw new Error('Invalid path traversal attempt');
      }

      if (await fs.pathExists(resolvedPath)) {
        const messages = await fs.readJson(resolvedPath);

        // Filter out messages older than 7 days
        const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
        let activeMessages = messages.filter(msg => {
          const timestamp = new Date(msg.timestamp).getTime();
          return timestamp > sevenDaysAgo;
        });

        // Optimization: Keep only the last 100 messages
        if (activeMessages.length > 100) {
          activeMessages = activeMessages.slice(-100);
        }

        // If we filtered out messages, save the cleaned up version
        if (activeMessages.length !== messages.length) {
          await this.saveContext(employeeNumber, activeMessages);
        }

        return activeMessages;
      }
    } catch (error) {
      console.error(`[ConversationContext] Failed to load context for ${employeeNumber}:`, error.message);
    }
    return [];
  }

  /**
   * Add a message to the conversation context
   */
  addMessage(sessionId, role, content, metadata = {}) {
    const context = this.getContext(sessionId);

    context.messages.push({
      role,
      content,
      timestamp: Date.now(),
      ...metadata
    });

    // Keep only the last N messages in memory for immediate context
    // But we'll persist more to disk

    context.updatedAt = Date.now();

    // Update context metadata if provided
    if (metadata.service) {
      context.lastService = metadata.service;
    }
    if (metadata.topic) {
      context.lastTopic = metadata.topic;
    }
    if (metadata.date) {
      context.lastDate = metadata.date;
    }
    if (metadata.month) {
      context.lastMonth = metadata.month;
    }
    if (metadata.locationId) {
      context.locationId = metadata.locationId;
    }
    if (metadata.employeeNumber) {
      context.employeeNumber = metadata.employeeNumber;
    }

    // Persist to disk if we have an employee number
    if (context.employeeNumber) {
      // We want to save all messages (not just the limited in-memory window)
      // So we'll reload, append, and save, or just append to what we have if we know it's complete
      // For simplicity and correctness with the 7-day window, let's load-merge-save async
      this.saveContextWithHistory(context.employeeNumber, {
        role,
        content,
        timestamp: Date.now(),
        ...metadata
      });
    }

    return context;
  }

  /**
   * Helper to append message to persistent storage
   */
  async saveContextWithHistory(employeeNumber, newMessage) {
    try {
      // Load existing full history
      let history = await this.loadContext(employeeNumber);

      // Add new message
      history.push(newMessage);

      // Save back (filter for 7 days happens in loadContext, but we can also enforce here)
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      history = history.filter(msg => new Date(msg.timestamp).getTime() > sevenDaysAgo);

      // Optimization: Enforce 100 message limit
      if (history.length > 100) {
        history = history.slice(-100);
      }

      await this.saveContext(employeeNumber, history);
    } catch (error) {
      console.error('[ConversationContext] Error in saveContextWithHistory:', error);
    }
  }

  /**
   * Update context with service-specific metadata after processing
   */
  updateServiceContext(sessionId, serviceData) {
    const context = this.getContext(sessionId);

    if (serviceData.service) {
      context.lastService = serviceData.service;
    }
    if (serviceData.topic) {
      context.lastTopic = serviceData.topic;
    }
    if (serviceData.date) {
      context.lastDate = serviceData.date;
    }
    if (serviceData.month) {
      context.lastMonth = serviceData.month;
    }
    if (serviceData.locationId) {
      context.locationId = serviceData.locationId;
    }

    context.updatedAt = Date.now();
    return context;
  }

  /**
   * Check if a query is a follow-up question
   * Follow-up queries are short, context-dependent questions
   */
  isFollowUpQuery(query) {
    const lowerQuery = query.toLowerCase().trim();

    // Common follow-up patterns
    const followUpPatterns = [
      /^(what|how) about/i,                    // "what about yesterday", "how about tomorrow"
      /^and\s+(what|how|the|for)/i,            // "and what about...", "and for yesterday"
      /^(yesterday|tomorrow|today|last|next|this)\b/i,  // starts with time reference
      /^(week|month|year)\b/i,                 // starts with time period
      /^(same|similar)\b/i,                    // "same for yesterday"
      /^(more|less|other)\b/i,                 // "more details", "other dates"
      /^(when|where|why|who|how much|how many)\?*$/i,  // simple questions
      /^that\s/i,                              // "that one", "that day"
      /^it\s/i,                                // "it was..."
      /^the\s+(same|other|previous|next)/i,   // "the same for...", "the previous day"
      /^show\s+(me\s+)?(more|that|this)/i,    // "show me more"
      /^\?$/,                                  // just a question mark
      /^ok\s+(and|but|what)/i,                // "ok and what about"
      /^(yes|yeah|sure|ok)[\s,]+(and|but|what)/i, // "yes, and what about"
      /^\d{1,2}(st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, // just a date like "30th November"
      /^on\s+\d{1,2}/i,                        // "on 10th"
      /^for\s+(yesterday|tomorrow|today|\d)/i, // "for yesterday", "for 10th"
    ];

    // Short queries (less than 6 words without clear subject) are often follow-ups
    const wordCount = query.split(/\s+/).length;
    const hasSubject = /menu|food|entry|exit|attendance|travel|seat|booking|community|banner|swipe|punch|who am i|my name|what is my name|employee name|identify me/i.test(query);

    // Check against patterns
    for (const pattern of followUpPatterns) {
      if (pattern.test(lowerQuery)) {
        console.log('[ConversationContext] Matched follow-up pattern:', pattern);
        return true;
      }
    }

    // Short queries without clear subject are likely follow-ups
    if (wordCount <= 4 && !hasSubject) {
      console.log('[ConversationContext] Short query without subject, treating as follow-up');
      return true;
    }

    return false;
  }

  /**
   * Rewrite a follow-up query to include context from previous conversation
   * This is the key method for context-aware responses
   */
  async rewriteQueryWithContext(sessionId, query, conversationHistory = []) {
    const context = this.getContext(sessionId);
    const lowerQuery = query.toLowerCase();
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/;

    console.log('[ConversationContext] Processing query:', query);
    console.log('[ConversationContext] Session:', sessionId);
    console.log('[ConversationContext] Stored context:', {
      lastService: context.lastService,
      lastTopic: context.lastTopic,
      lastDate: context.lastDate,
      messageCount: context.messages?.length || 0
    });
    console.log('[ConversationContext] Conversation history length:', conversationHistory?.length || 0);

    // If no previous context AND no conversation history, return query as-is
    if (!context.lastService && (!conversationHistory || conversationHistory.length === 0)) {
      console.log('[ConversationContext] No context available, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    // Identity queries should not be rewritten as follow-ups
    if (identityPattern.test(lowerQuery)) {
      console.log('[ConversationContext] Identity query detected, skipping rewrite');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: 'entryexit'
      };
    }

    // Check if this might be a follow-up
    const isFollowUp = this.isFollowUpQuery(query);
    console.log('[ConversationContext] Is follow-up query:', isFollowUp);

    if (!isFollowUp) {
      console.log('[ConversationContext] Not a follow-up, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    console.log('[ConversationContext] === FOLLOW-UP DETECTED ===');
    console.log('[ConversationContext] Original query:', query);
    console.log('[ConversationContext] Last service:', context.lastService);
    console.log('[ConversationContext] Last topic:', context.lastTopic);

    // Use AI to rewrite the query with context
    try {
      // Use full context messages which includes loaded history
      // We look back 10 messages to catch context
      const recentMessages = context.messages.length > 0 ? context.messages : conversationHistory;
      const historyToUse = recentMessages.slice(-10);

      const recentHistory = historyToUse.map(msg =>
        `${msg.role === 'user' ? 'User' : 'Assistant'}: ${(msg.content || '').substring(0, 500)}`
      ).join('\n');

      const systemPrompt = `You are a context-aware query rewriter. Given a follow-up question and conversation history, rewrite the query to be self-contained and explicit.

CONVERSATION HISTORY:
${recentHistory}

CONTEXT:
- Last service used: ${context.lastService || 'unknown'}
- Last topic discussed: ${context.lastTopic || 'unknown'}
- Last date mentioned: ${context.lastDate || 'not specified'}
- Last month referenced: ${context.lastMonth || 'not specified'}

RULES:
1. If the user asks "what about yesterday?" after asking about today's menu, rewrite to "What is the canteen menu for yesterday?"
2. If the user asks "and tomorrow?" after asking about entry time, rewrite to "What was my entry time tomorrow?" (or correct grammar)
3. If the user asks "same for last week?", understand the previous query topic and rewrite accordingly
4. If the user says "that month", "that month's details", "in that month", or "for that month", replace it with the actual month name from context (e.g., "February 2026")
5. Preserve any specific details the user mentions in the follow-up
6. Make the rewritten query complete and understandable without context
7. Also identify which service should handle this query

Respond in JSON format:
{
  "rewrittenQuery": "the complete, self-contained query",
  "inferredService": "canteen|entryexit|travel|seatbooking|community|banner|general",
  "explanation": "brief explanation of what context was used"
}`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Follow-up question: "${query}"` }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content);

      console.log('[ConversationContext] Rewritten query:', result.rewrittenQuery);
      console.log('[ConversationContext] Inferred service:', result.inferredService);

      return {
        rewrittenQuery: result.rewrittenQuery,
        originalQuery: query,
        wasRewritten: true,
        inferredService: result.inferredService,
        explanation: result.explanation
      };

    } catch (error) {
      console.error('[ConversationContext] Error rewriting query:', error.message);

      // Fallback: simple context injection
      return this.fallbackRewrite(query, context);
    }
  }

  /**
   * Fallback query rewriting when AI is unavailable
   */
  fallbackRewrite(query, context) {
    const lowerQuery = query.toLowerCase().trim();
    let rewrittenQuery = query;
    let inferredService = context.lastService;

    // Handle date-based follow-ups
    const datePatterns = {
      'yesterday': 'yesterday',
      'tomorrow': 'tomorrow',
      'today': 'today',
      'last week': 'last week',
      'this week': 'this week',
      'last month': 'last month',
      'this month': 'this month'
    };

    for (const [pattern, dateStr] of Object.entries(datePatterns)) {
      if (lowerQuery.includes(pattern) || lowerQuery === pattern || lowerQuery === `what about ${pattern}?`) {
        // Add topic context
        if (context.lastService === 'canteen') {
          rewrittenQuery = `What is the canteen menu for ${dateStr}?`;
        } else if (context.lastService === 'entryexit') {
          rewrittenQuery = `What was my entry/exit time ${dateStr}?`;
        } else if (context.lastTopic) {
          rewrittenQuery = `${context.lastTopic} for ${dateStr}`;
        }
        break;
      }
    }

    // Handle "what about X" patterns
    if (lowerQuery.startsWith('what about') || lowerQuery.startsWith('and what about')) {
      const subject = query.replace(/^(and\s+)?what about\s*/i, '').replace(/\?$/, '').trim();
      if (context.lastService === 'canteen') {
        rewrittenQuery = `What is the canteen menu for ${subject}?`;
      } else if (context.lastService === 'entryexit') {
        rewrittenQuery = `What was my entry/exit time for ${subject}?`;
      }
    }

    return {
      rewrittenQuery,
      originalQuery: query,
      wasRewritten: rewrittenQuery !== query,
      inferredService
    };
  }

  /**
   * Extract topic from an AI response for context tracking
   */
  extractTopicFromResponse(response, service) {
    const topics = {
      canteen: ['menu', 'food', 'breakfast', 'lunch', 'dinner', 'snacks'],
      entryexit: ['entry time', 'exit time', 'attendance', 'working hours', 'swipe'],
      travel: ['travel plan', 'trip', 'booking', 'settlement'],
      seatbooking: ['desk', 'seat', 'workspace', 'booking'],
      community: ['community', 'group', 'club'],
      banner: ['banner', 'announcement', 'news']
    };

    const serviceTopics = topics[service] || [];
    const lowerResponse = response.toLowerCase();

    for (const topic of serviceTopics) {
      if (lowerResponse.includes(topic)) {
        return topic;
      }
    }

    return service; // Default to service name as topic
  }

  /**
   * Extract date from query or response
   */
  extractDate(text) {
    const lowerText = text.toLowerCase();

    if (lowerText.includes('today')) return 'today';
    if (lowerText.includes('yesterday')) return 'yesterday';
    if (lowerText.includes('tomorrow')) return 'tomorrow';

    // Try to find date patterns
    const dateMatch = text.match(/(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})|(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*\d{0,4})/i);
    if (dateMatch) {
      return dateMatch[0];
    }

    return null;
  }

  /**
   * Get conversation history for API responses
   */
  getMessageHistory(sessionId) {
    const context = this.getContext(sessionId);
    return context.messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }

  /**
   * Clean up expired contexts
   */
  cleanupExpiredContexts() {
    const now = Date.now();
    for (const [sessionId, context] of this.contexts.entries()) {
      if (now - context.updatedAt > this.contextExpiryMs) {
        this.contexts.delete(sessionId);
        console.log('[ConversationContext] Cleaned up expired context:', sessionId);
      }
    }
  }

  /**
   * Clear context for a session
   */
  clearContext(sessionId) {
    this.contexts.delete(sessionId);
  }
}

module.exports = new ConversationContextService();
