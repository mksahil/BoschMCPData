/**
 * Seat Booking Service
 * Calls the Seat Booking MCP Server (A2A Agent) for desk/workspace reservations
 * Uses A2A Protocol (Google Agent-to-Agent) - JSON-RPC 2.0
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

class SeatBookingService {
  constructor() {
    // A2A Host Agent URL (Seat Booking Agent)
    this.apiUrl = process.env.SEATBOOKING_API_URL || 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    this.agentCardPath = '/.well-known/agent.json';

    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.agentCard = null;
  }

  /**
   * Fetch the agent card from the Seat Booking A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) {
      return this.agentCard;
    }

    try {
      console.log(`[SeatBooking] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(
        `${this.apiUrl}${this.agentCardPath}`,
        { httpsAgent, timeout: 30000 }
      );
      this.agentCard = response.data;
      console.log('[SeatBooking] Agent card fetched successfully:', this.agentCard.name);
      return this.agentCard;
    } catch (error) {
      console.error('[SeatBooking] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Call the Seat Booking A2A Agent using proper A2A protocol
   * Based on the working sba2aclient.py implementation
   */
  async callSeatBookingAPI(message, employeeNumber, userOAuthToken, files = [], explicitJwtToken = null, explicitSessionId = null) {
    try {
      console.log(`[SeatBooking] Calling A2A Seat Booking Agent at: ${this.apiUrl}`);
      console.log(`[SeatBooking] Query: ${message.substring(0, 50)}...`);
      console.log(`[SeatBooking] Employee Number: ${employeeNumber}`);
      console.log(`[SeatBooking] User OAuth Token provided: ${!!userOAuthToken}`);
      console.log(`[SeatBooking] Explicit JWT Token provided: ${!!explicitJwtToken}`);

      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;

      // Strategy 1: Use explicit tokens if provided (primary strategy)
      if (jwtToken && sessionId) {
        console.log('[SeatBooking] Using EXPLICIT user tokens (passed from caller)');
      }

      // Strategy 2: If an OAuth token was supplied, we may still have cached
      // JWT/sessionId from an earlier login.  We will only use the cache when
      // the provided OAuth token matches what was stored there.  This prevents
      // an attacker from supplying only an employee number and piggybacking on
      // another user's cached credentials.
      if (!jwtToken && userOAuthToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userOAuthToken);
        if (cachedTokens) {
          console.log('[SeatBooking] Using CACHED user tokens (stored at login)');
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
        }
      }

      // Strategy 3: If we still don't have a JWT and an OAuth token is
      // available, convert it and cache the result.  This covers the normal
      // login->booking flow where the frontend sends the user token on each
      // request.
      if (!jwtToken && userOAuthToken) {
        try {
          console.log('[SeatBooking] Converting user OAuth token to JWT...');
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userOAuthToken);
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
          console.log('[SeatBooking] User JWT Token generated and cached');
        } catch (jwtError) {
          console.log('[SeatBooking] Failed to convert user OAuth token to JWT:', jwtError.message);
          // Fall through to error
        }
      }

      // No more fallback strategies — user MUST be authenticated
      if (!jwtToken) {
        console.warn('[SeatBooking] No valid authentication tokens available. User must log in.');
        throw new Error('AUTH_REQUIRED');
      }

      // Ensure we have a session ID for this user
      if (!sessionId && employeeNumber) {
        sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);
      }

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      console.log(`[SeatBooking] Using session ID: ${sessionId}`);
      console.log('[SeatBooking] JWT Token (first 50 chars):', jwtToken?.substring(0, 50) + '...');

      // Build auth metadata as per A2A protocol (matches sba2aclient.py)
      const authMetadata = {};
      if (jwtToken || sessionId) {
        authMetadata.auth = {
          token: jwtToken,
          session_id: sessionId
        };
      }

      // A2A Protocol: SendMessageRequest format (matches working curl test)
      // IMPORTANT: metadata goes at params level, NOT inside message
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          message: {
            messageId: messageId,
            role: 'user',
            parts: [
              {
                type: 'text',
                text: message
              }
            ]
          },
          metadata: authMetadata
        }
      };

      console.log('[SeatBooking] A2A Request:', JSON.stringify(a2aRequest).substring(0, 300) + '...');

      const response = await axios.post(
        this.apiUrl,
        a2aRequest,
        {
          headers: {
            'accept': 'application/json',
            'Content-Type': 'application/json'
          },
          httpsAgent,
          timeout: 300000 // 5 minutes (A2A agents can take time)
        }
      );

      console.log(`[SeatBooking] A2A Response received`);

      // A2A Response format: { jsonrpc: '2.0', id: '...', result: { ... } }
      const a2aResult = response.data;

      if (a2aResult.error) {
        console.error('[SeatBooking] A2A Error:', a2aResult.error);
        throw new Error(a2aResult.error.message || 'A2A request failed');
      }

      // Extract the task result
      const taskResult = a2aResult.result;
      console.log('[SeatBooking] Task status:', taskResult?.status?.state);

      return taskResult;
    } catch (error) {
      console.error('[SeatBooking] API error:', error.message);
      if (error.response) {
        console.error('[SeatBooking] Response status:', error.response.status);
        console.error('[SeatBooking] Response data:', JSON.stringify(error.response.data).substring(0, 500));
      }
      throw error;
    }
  }

  /**
   * Process a seat booking query
   */
  /**
   * Check if query is asking about another person's seat booking data.
   * Only block EXPLICIT other-person references. Assume self if ambiguous.
   */
  isQueryAboutOtherPerson(query) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    const personalDataKeywords = ['seat', 'desk', 'booking', 'reserve', 'reserved', 'floor', 'zone', 'location', 'book', 'booked', 'workstation'];
    const hasPersonalData = personalDataKeywords.some(kw => q.includes(kw));
    if (!hasPersonalData) return false;

    const hasSelfRef = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i\sam)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i.test(q);

    // Self-ref without colleague word AND no other-person name → ALLOW
    if (hasSelfRef && !hasColleagueWord) {
      let otherName = false;
      const ofFor = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
      if (ofFor) {
        const safe = new Set(['me', 'myself', 'today', 'yesterday', 'tomorrow', 'now', 'free',
          'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
          'week', 'month', 'year', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
          'bangalore', 'coimbatore', 'bosch', 'india',
          'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa',
          'seat', 'desk', 'booking', 'reserve', 'reserved', 'floor', 'zone', 'location', 'workstation',
          'building', 'block', 'wing', 'cabin', 'cabins', 'workspace', 'room',
          'business', 'personal', 'work', 'home', 'office', 'full', 'half', 'day', 'first', 'second',
          'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', 'january', 'february']);
        if (!safe.has(ofFor[1].toLowerCase())) otherName = true;
      }
      const poss = q.match(/(\w{3,})(?:'s|s')\s+/i);
      if (poss) {
        const skip = new Set(['today', 'yesterday', 'tomorrow', 'it', 'that', 'this', 'there', 'here',
          'what', 'let', 'don', 'doesn', 'didn', 'won', 'week', 'month', 'year', 'last', 'next']);
        if (!skip.has(poss[1].toLowerCase())) otherName = true;
      }
      if (!otherName) return false;
    }

    // Bulk requests
    if (/\b(all\s+(?:seat|desk|booking)|every\s*one|everybody|team\s+booking|who\s+(?:all\s+)?(?:booked|reserved|sits)|list\s+(?:all|every)|show\s+(?:all|every|each)\s+(?:employee|people|person|staff|member))\b/i.test(q)) {
      console.log('[SeatBooking] Privacy: blocked bulk/collective request');
      return true;
    }

    if (hasColleagueWord) {
      console.log('[SeatBooking] Privacy: blocked colleague word + booking data');
      return true;
    }

    if (/\b(his|her|their|them|him)\b/i.test(q)) {
      console.log('[SeatBooking] Privacy: blocked third-person pronoun');
      return true;
    }

    // Possessive name: "Rahul's booking"
    const possessives = [...original.matchAll(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g)];
    if (possessives.length > 0) {
      console.log(`[SeatBooking] Privacy: blocked possessive name: ${possessives[0][1]}`);
      return true;
    }

    // "of/for <Name>" (case-insensitive to catch "for vaishnavi")
    const safeTargets = new Set(['me', 'myself', 'today', 'yesterday', 'tomorrow', 'monday', 'tuesday', 'wednesday',
      'thursday', 'friday', 'saturday', 'sunday', 'week', 'month', 'year', 'next', 'last', 'this', 'coming', 'past', 'previous', 'current',
      'bangalore', 'coimbatore', 'bosch', 'india',
      'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa',
      'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'free', 'approval', 'review', 'nothing',
      'building', 'block', 'floor', 'zone', 'wing', 'cabin', 'cabins', 'workspace', 'workstation', 'room',
      'seat', 'desk', 'booking', 'march', 'april', 'may', 'june', 'july', 'august', 'september',
      'october', 'november', 'december', 'january', 'february', 'full', 'half', 'day', 'first', 'second']);
    const ofForMatches = [...q.matchAll(/\b(?:of|for)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\b/gi)];
    for (const m of ofForMatches) {
      const nameLC = m[1].toLowerCase();
      // Check each word individually for multi-word matches like "building floor"
      const words = nameLC.split(/\s+/);
      const allSafe = words.every(w => safeTargets.has(w));
      if (!allSafe) {
        console.log(`[SeatBooking] Privacy: blocked of/for name: ${m[1]}`);
        return true;
      }
    }

    // Capitalized name near booking data (no self-ref)
    if (!hasSelfRef) {
      const nonNames = new Set(['the', 'what', 'when', 'where', 'how', 'which', 'who', 'why',
        'show', 'get', 'tell', 'give', 'find', 'list', 'display', 'fetch', 'are', 'is', 'was', 'were', 'has', 'have', 'had', 'does', 'did',
        'today', 'yesterday', 'tomorrow', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
        'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september',
        'october', 'november', 'december', 'bangalore', 'coimbatore', 'india', 'bosch',
        'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa',
        'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'hello', 'time', 'times',
        'seat', 'seats', 'desk', 'floor', 'zone', 'book', 'booking', 'booked', 'reserve', 'reserved', 'location', 'workstation',
        'building', 'block', 'wing', 'cabin', 'cabins', 'workspace', 'room', 'full', 'half', 'available',
        'can', 'could', 'would', 'should', 'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look',
        'all', 'any', 'some', 'this', 'that', 'these', 'those', 'last', 'next', 'first', 'second',
        'many', 'much', 'more', 'most', 'every', 'each', 'there', 'here',
        'cancel', 'system', 'context', 'current', 'date', 'ist',
        'raise', 'plan', 'create', 'modify', 'update', 'submit', 'apply', 'request',
        'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
        'snacks', 'snack', 'menu', 'food', 'canteen', 'coming']);
      const allCapNames = [...original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)];
      for (const m of allCapNames) {
        if (!nonNames.has(m[1].toLowerCase()) && m[1].length > 3) {
          console.log(`[SeatBooking] Privacy: blocked capitalized name: ${m[1]}`);
          return true;
        }
      }
    }

    // DEFAULT: no explicit other-person reference → ALLOW
    return false;
  }

  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId } = context;

      // Privacy check: Block queries about other people's seat booking data
      if (this.isQueryAboutOtherPerson(query)) {
        console.log('[SeatBooking] Privacy check: Blocking query about colleague seat data');
        return {
          success: false,
          response: "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their seat bookings or any other personal data. If you need information about a colleague's booking, please ask them directly or contact HR."
        };
      }

      // Get dates in IST for replacement in strict YYYY-MM-DD format
      const getISTFormattedDate = (offsetDays = 0) => {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        // Convert to IST
        const istTime = d.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
        const istDate = new Date(istTime);
        const yyyy = istDate.getFullYear();
        const mm = String(istDate.getMonth() + 1).padStart(2, '0');
        const dd = String(istDate.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
      };

      const todayStr = getISTFormattedDate(0);
      const tomorrowStr = getISTFormattedDate(1);

      // Explicitly replace 'today' and 'tomorrow' in the query to force correct date resolution
      // Use YYYY-MM-DD format as A2A/Dialogflow agents parse it natively without ambiguity.
      let explicitQuery = query;
      explicitQuery = explicitQuery.replace(/\btoday\b/gi, todayStr);
      explicitQuery = explicitQuery.replace(/\btomorrow\b/gi, tomorrowStr);

      console.log(`[SeatBooking] Rewrote query: "${query}" -> "${explicitQuery}"`);

      // Inject current date/time context as backup
      const now = new Date().toLocaleString("en-IN", {
        timeZone: "Asia/Kolkata",
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      console.log(`[SeatBooking] Adding date context: ${now}`);

      const contextQuery = `[System Context: Current Date/Time (IST): ${now}] ${explicitQuery}`;

      // Call the Seat Booking A2A Agent with proper authentication
      const result = await this.callSeatBookingAPI(contextQuery, employeeNumber, authToken, [], jwtToken, sessionId);

      // Format the response
      const response = this.formatSeatBookingResponse(result, query);

      return {
        success: true,
        response,
        data: result
      };
    } catch (error) {
      console.error('Seat Booking query error:', error);

      // Check if user is not authenticated
      if (error.message === 'AUTH_REQUIRED') {
        return {
          success: false,
          response: "💺 **Seat Booking**\n\nYou need to be logged in to use the seat booking service. Please log in with your Bosch credentials and try again.",
          error: 'Authentication required'
        };
      }

      // Check if it's an auth error
      if (error.response && error.response.status === 401) {
        return {
          success: false,
          response: "I need you to be logged in to access seat booking services. Please log in and try again.",
          error: 'Authentication required'
        };
      }

      // Check for A2A protocol errors
      if (error.message && error.message.includes('A2A')) {
        return {
          success: false,
          response: `💺 **Seat Booking**\n\nThere was an issue communicating with the seat booking agent.\n\nError: ${error.message}`,
          error: error.message
        };
      }

      return {
        success: false,
        response: `💺 **Seat Booking**\n\nI'm having trouble connecting to the seat booking system.\n\n**Alternative options:**\n1. Visit the Bosch Seat Booking portal directly\n2. Contact your facility management team`,
        error: error.message
      };
    }
  }

  /**
   * Format seat booking A2A response for display
   */
  formatSeatBookingResponse(result, query) {
    if (!result) {
      return "I couldn't get a response from the seat booking system. Please try again.";
    }

    // Extract text from A2A response structures
    let responseText = null;

    // A2A task response: status.message.parts[].text
    if (result.status?.message?.parts) {
      const textPart = result.status.message.parts.find(p => p.kind === 'text' || p.type === 'text');
      if (textPart) {
        responseText = textPart.text;
      }
    }

    // A2A history format: history[last].parts[].text (get last non-processing agent message)
    if (!responseText && result.history && Array.isArray(result.history)) {
      const agentMessages = result.history.filter(h => h.role === 'agent');
      for (let i = agentMessages.length - 1; i >= 0; i--) {
        const msg = agentMessages[i];
        if (msg?.parts) {
          const textPart = msg.parts.find(p => p.kind === 'text' || p.type === 'text');
          if (textPart && textPart.text && textPart.text !== 'Processing...') {
            responseText = textPart.text;
            break;
          }
        }
      }
    }

    // Direct message parts
    if (!responseText && result.message?.parts) {
      const textPart = result.message.parts.find(p => p.kind === 'text' || p.type === 'text');
      if (textPart) {
        responseText = textPart.text;
      }
    }

    // Simple response field
    if (!responseText && result.response) {
      responseText = result.response;
    }

    // If we extracted a response, format it nicely
    if (responseText) {
      // Skip "Processing..." messages
      if (responseText === 'Processing...') {
        return `💺 **Seat Booking Assistant**\n\nThe booking system is still processing your request. Please try again in a moment.`;
      }
      return `💺 **Seat Booking Assistant**\n\n${responseText}`;
    }

    // Return raw response if structure is unknown (for debugging)
    console.log('[SeatBooking] Unknown response structure:', JSON.stringify(result).substring(0, 500));
    return `💺 **Seat Booking Assistant**\n\nReceived response from booking system but couldn't parse it properly. Please try again.`;
  }

  /**
   * Book a seat
   */
  async bookSeat(details, context = {}) {
    const message = `Book a seat with the following details:
- Date: ${details.date}
- Location: ${details.location || 'Bangalore office'}
- Floor: ${details.floor || 'Any'}
${details.preferences ? `- Preferences: ${details.preferences}` : ''}`;

    return this.processQuery(message, context);
  }

  /**
   * Cancel a booking
   */
  async cancelBooking(bookingId, context = {}) {
    const message = `Cancel my seat booking with ID: ${bookingId}`;
    return this.processQuery(message, context);
  }

  /**
   * Get my bookings
   */
  async getMyBookings(context = {}) {
    const message = `Show me my current seat bookings`;
    return this.processQuery(message, context);
  }

  /**
   * Check seat availability
   */
  async checkAvailability(date, location, context = {}) {
    const message = `Check seat availability for ${date} at ${location || 'Bangalore office'}`;
    return this.processQuery(message, context);
  }
}

module.exports = new SeatBookingService();
