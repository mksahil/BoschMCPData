const axios = require('axios');
const https = require('https');

// Disable SSL verification for Azure APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

/**
 * Service V2 for integrating with Entry/Exit MCP Server
 * Uses the deployed MCP server on Azure
 */
class EntryExitServiceV2 {
  constructor() {
    // Use new deployed MCP server URL
    this.mcpEndpoint = process.env.ENTRYEXIT_MCP_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/mcp';
    
    console.log('[EntryExit] MCP Endpoint:', this.mcpEndpoint);
    
    // Cache for frequently requested data
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    
    // MCP session ID
    this.mcpSessionId = null;
  }
  
  /**
   * Initialize MCP session
   */
  async initializeMCPSession() {
    try {
      console.log('[EntryExit] Initializing MCP session...');
      
      const initPayload = {
        jsonrpc: "2.0",
        method: "initialize",
        params: {
          protocolVersion: "2024-11-05",
          capabilities: {},
          clientInfo: { name: "mybgs-companion", version: "1.0.0" }
        },
        id: 1
      };

      const response = await axios.post(this.mcpEndpoint, initPayload, {
        headers: {
          'Accept': 'application/json, text/event-stream',
          'Content-Type': 'application/json'
        },
        timeout: 30000,
        httpsAgent,
        transformResponse: [(data) => data]
      });

      // Extract session ID from response headers
      this.mcpSessionId = response.headers['mcp-session-id'];
      console.log('[EntryExit] MCP session initialized:', this.mcpSessionId);
      
      return this.mcpSessionId;
    } catch (error) {
      console.error('[EntryExit] Failed to initialize MCP session:', error.message);
      throw error;
    }
  }

  /**
   * Get cache key for a query
   */
  getCacheKey(employeeNumber, query) {
    return `${employeeNumber}:${query}`;
  }

  /**
   * Check if cached data is still valid
   */
  isCacheValid(cacheEntry) {
    if (!cacheEntry) return false;
    return Date.now() - cacheEntry.timestamp < this.cacheTimeout;
  }

  /**
   * Parse SSE response data
   */
  parseSSEResponse(sseData) {
    if (typeof sseData !== 'string') return sseData;
    
    console.log('[EntryExit] Parsing SSE response, length:', sseData?.length);
    
    // Handle different line endings
    const lines = sseData.split(/\r?\n/);
    let result = null;
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      // Check for data: prefix (with or without space after colon)
      if (trimmedLine.startsWith('data:')) {
        const jsonStr = trimmedLine.substring(5).trim();
        try {
          result = JSON.parse(jsonStr);
          console.log('[EntryExit] Successfully parsed SSE data');
        } catch (e) {
          // Not JSON, might be plain text
          result = { answer: jsonStr };
        }
      }
    }
    
    // If no SSE format found, try parsing the whole thing as JSON
    if (!result) {
      try {
        result = JSON.parse(sseData);
        console.log('[EntryExit] Parsed as direct JSON');
      } catch (e) {
        console.log('[EntryExit] Not valid JSON either');
      }
    }
    
    return result;
  }

  /**
   * Query the MCP endpoint using SSE format
   */
  async queryMCP(employeeNumber, toolName, args = {}) {
    try {
      console.log(`[EntryExit] Calling MCP tool: ${toolName}`, args);
      
      // Initialize session if needed
      if (!this.mcpSessionId) {
        await this.initializeMCPSession();
      }
      
      const toolCallPayload = {
        jsonrpc: "2.0",
        method: "tools/call",
        params: {
          name: toolName,
          arguments: args
        },
        id: Date.now()
      };

      const response = await axios.post(this.mcpEndpoint, toolCallPayload, {
        headers: {
          'Accept': 'application/json, text/event-stream',
          'Content-Type': 'application/json',
          'mcp-session-id': this.mcpSessionId,
          'X-Employee-Number': employeeNumber
        },
        timeout: 30000,
        httpsAgent,
        transformResponse: [(data) => data]
      });

      const result = this.parseSSEResponse(response.data);
      
      // Handle MCP tool response format
      if (result?.result?.content && Array.isArray(result.result.content)) {
        for (const item of result.result.content) {
          if (item.type === 'text' && item.text) {
            try {
              return JSON.parse(item.text);
            } catch (e) {
              return { answer: item.text };
            }
          }
        }
      }
      
      return result?.result || result;
    } catch (error) {
      console.error('[EntryExit] MCP call failed:', error.message);
      // Reset session on failure
      this.mcpSessionId = null;
      throw error;
    }
  }

  /**
   * Query the MCP endpoint for entry/exit data
   */
  async queryChat(employeeNumber, query) {
    const cacheKey = this.getCacheKey(employeeNumber, query);
    const cachedData = this.cache.get(cacheKey);
    
    // Check cache first
    if (this.isCacheValid(cachedData)) {
      console.log('[EntryExit] Returning cached data for:', query);
      return cachedData.data;
    }

    try {
      console.log(`[EntryExit] Querying MCP for employee ${employeeNumber}: ${query}`);
      
      // Use the MCP endpoint with proper session management
      const result = await this.queryMCP(employeeNumber, 'get_current_status', {
        employee_id: employeeNumber
      });
      
      // Cache the response
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });

      return result;
    } catch (mcpError) {
      console.error('[EntryExit] MCP error:', mcpError.message);
      
      // Return cached data if available, even if expired
      if (cachedData) {
        console.log('[EntryExit] Returning expired cache due to error');
        return cachedData.data;
      }
      
      throw new Error(`Failed to query Entry/Exit server: ${mcpError.message}`);
    }
  }

  /**
   * Main method to get employee time data
   */
  async getEmployeeTimeData(employeeNumber, query) {
    try {
      const response = await this.queryChat(employeeNumber, query);
      return response;
    } catch (error) {
      console.error('Error getting employee time data:', error);
      throw error;
    }
  }

  /**
   * Clear cache for an employee
   */
  clearCache(employeeNumber) {
    let cleared = 0;
    for (const [key] of this.cache.entries()) {
      if (key.startsWith(`${employeeNumber}:`)) {
        this.cache.delete(key);
        cleared++;
      }
    }
    return cleared;
  }

  /**
   * Get cache statistics
   */
  getCacheStats() {
    let valid = 0;
    let expired = 0;
    const now = Date.now();

    for (const [, value] of this.cache.entries()) {
      if (now - value.timestamp < this.cacheTimeout) {
        valid++;
      } else {
        expired++;
      }
    }

    return {
      total: this.cache.size,
      valid,
      expired,
      cacheTimeout: this.cacheTimeout
    };
  }
}

module.exports = new EntryExitServiceV2();