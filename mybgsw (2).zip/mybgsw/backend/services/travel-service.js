/**
 * Travel Service
 * Calls the Travel MCP Server (A2A Agent) for travel planning and settlements
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

class TravelService {
  constructor() {
    // A2A Host Agent URL (Travel Agent) - Using TRAVEL_API_URL as primary (working endpoint)
    this.apiUrl = process.env.TRAVEL_API_URL || 'https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    this.agentCardPath = '/.well-known/agent.json';
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.agentCard = null;
  }

  /**
   * Fetch the agent card from the Travel A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) {
      return this.agentCard;
    }

    try {
      console.log(`[Travel] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(
        `${this.apiUrl}${this.agentCardPath}`,
        { httpsAgent, timeout: 30000 }
      );
      this.agentCard = response.data;
      console.log('[Travel] Agent card fetched successfully');
      return this.agentCard;
    } catch (error) {
      console.error('[Travel] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Call the Travel A2A Agent using proper A2A protocol
   * Based on the working Travelagent_test_client.py implementation
   */
  async callTravelAPI(message, employeeNumber, userToken, files = [], explicitJwtToken = null, explicitSessionId = null) {
    try {
      console.log(`[Travel] Calling A2A Travel Agent at: ${this.apiUrl}`);
      console.log(`[Travel] Query: ${message.substring(0, 50)}...`);
      console.log(`[Travel] Employee Number: ${employeeNumber}`);
      console.log(`[Travel] User OAuth Token provided: ${!!userToken}`);
      console.log(`[Travel] Explicit JWT Token provided: ${!!explicitJwtToken}`);

      // Get Bosch Arena JWT token and session ID for authentication
      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;

      // Strategy 1: Use explicit tokens if provided (primary strategy)
      if (jwtToken && sessionId) {
        console.log(`[Travel] Using EXPLICIT user tokens (JWT Source: ${explicitJwtToken ? 'Frontend Context' : 'Internal Bridge'})`);
      }

      // Strategy 2: If the caller supplied a user OAuth token we may have cached
      // JWT/sessionId for them.  Only use the cache when the provided token matches
      // what was stored; otherwise we treat it as missing and fall through.
      if (!jwtToken && userToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userToken);
        if (cachedTokens) {
          console.log('[Travel] Using CACHED user tokens (stored at login)');
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
          console.log('[Travel] Cached JWT Token (first 50 chars):', jwtToken?.substring(0, 50) + '...');
          // console.log('[Travel] Cached Session ID:', sessionId);
        }
      }

      // Strategy 3: If we still don't have a JWT and a valid OAuth token is
      // available, convert it and cache the result – this is the normal path when
      // the frontend includes the token on each request.
      if (!jwtToken && userToken) {
        try {
          console.log('[Travel] Converting user OAuth token to JWT...');
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userToken);
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
          console.log('[Travel] User JWT Token generated and cached');
          console.log('[Travel] User JWT Token (first 50 chars):', jwtToken?.substring(0, 50) + '...');
        } catch (userAuthError) {
          console.log('[Travel] Failed to convert user OAuth token to JWT:', userAuthError.message);
          // Fall through to service account
        }
      }

      // Strategy 4: Fall back to service account token (last resort)
      if (!jwtToken) {
        try {
          console.log('[Travel] Using service account JWT token (fallback)');
          jwtToken = await boschAuthService.getServiceToken();
          // Use provided sessionId or generate a persistent one
          if (!sessionId) {
            sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);
          }
          console.log('[Travel] Service JWT Token (first 50 chars):', jwtToken?.substring(0, 50) + '...');
        } catch (authError) {
          console.log('[Travel] Could not get service token, proceeding without auth:', authError.message);
        }
      }

      // Ensure we have a session ID (use persistent one for this user)
      if (!sessionId) {
        sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);
      }

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      console.log('[Travel] FULL Session ID:', sessionId);
      console.log('[Travel] FULL JWT Token:', jwtToken);

      // Build auth metadata as per A2A protocol (matches working curl test)
      const authMetadata = {};
      if (jwtToken || sessionId) {
        authMetadata.auth = {
          session_id: sessionId
        };
        if (jwtToken) {
          authMetadata.auth.token = jwtToken;
        }
      }

      // A2A Protocol: SendMessageRequest format (matches working curl test)
      // IMPORTANT: metadata goes at params level, NOT inside message
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          message: {
            messageId: messageId,
            role: 'user',
            parts: [
              {
                type: 'text',
                text: message
              }
            ]
          },
          metadata: authMetadata
        }
      };

      console.log('[Travel] A2A Request:', JSON.stringify(a2aRequest).substring(0, 300) + '...');

      const response = await axios.post(
        this.apiUrl,
        a2aRequest,
        {
          headers: {
            'accept': 'application/json',
            'Content-Type': 'application/json'
          },
          httpsAgent,
          timeout: 120000 // 2 minute timeout for travel queries
        }
      );

      // Log EXACT response from the travel a2a agent (full, untruncated)
      console.log(`[Travel] A2A response received (FULL):`, JSON.stringify(response.data, null, 2));
      console.log(`[Travel] A2A response headers:`, JSON.stringify(response.headers, null, 2));
      console.log(`[Travel] A2A response status:`, response.status);

      // Parse A2A response (matches Python client response handling)
      const a2aResult = response.data;

      // Try to extract text from various A2A response formats
      let responseText = null;

      // Format 1: result.status.message.parts[].text (Task response)
      if (a2aResult.result?.status?.message?.parts) {
        const textPart = a2aResult.result.status.message.parts.find(p => p.kind === 'text' || p.type === 'text');
        if (textPart) {
          responseText = textPart.text;
          console.log('[Travel] Extracted text from: result.status.message.parts');
        }
      }

      // Format 2: result.message.parts[].text (Direct message response)
      if (!responseText && a2aResult.result?.message?.parts) {
        const textPart = a2aResult.result.message.parts.find(p => p.kind === 'text' || p.type === 'text');
        if (textPart) {
          responseText = textPart.text;
          console.log('[Travel] Extracted text from: result.message.parts');
        }
      }

      // Format 3: result.history[last agent].parts[].text (History-based response)
      // Check both 'role' and 'kind' fields — some A2A agents use role='agent',
      // others omit role and only set kind='message'.  In the latter case, pick the
      // last history entry whose text differs from the user's original message.
      if (!responseText && a2aResult.result?.history && Array.isArray(a2aResult.result.history)) {
        const history = a2aResult.result.history;
        console.log('[Travel] History entries:', history.length, '| roles:', history.map(h => h.role || h.kind || 'unknown'));

        // Try role-based lookup first
        let lastAgentMessage = [...history].reverse().find(h => h.role === 'agent');

        // Fallback: pick the last entry that isn't the user's own message
        if (!lastAgentMessage && history.length > 1) {
          lastAgentMessage = [...history].reverse().find(h => {
            if (h.role === 'user') return false;
            // If no role, check it's not the echo of the user query
            const txt = h.parts?.find(p => p.kind === 'text' || p.type === 'text')?.text || '';
            return txt !== message && txt !== 'Processing...';
          });
        }

        if (lastAgentMessage?.parts) {
          const textPart = lastAgentMessage.parts.find(p => p.kind === 'text' || p.type === 'text');
          if (textPart && textPart.text && textPart.text !== 'Processing...') {
            responseText = textPart.text;
            console.log('[Travel] Extracted text from: result.history (last agent entry)');
          }
        }
      }

      // Format 4: result.artifacts[].parts[].text (Artifact-based response)
      if (!responseText && a2aResult.result?.artifacts && Array.isArray(a2aResult.result.artifacts)) {
        for (const artifact of a2aResult.result.artifacts) {
          if (artifact.parts) {
            const textPart = artifact.parts.find(p => p.kind === 'text' || p.type === 'text');
            if (textPart && textPart.text) {
              responseText = textPart.text;
              console.log('[Travel] Extracted text from: result.artifacts');
              break;
            }
          }
        }
      }

      if (responseText) {
        return { response: responseText, raw: a2aResult };
      }

      // Log the full structure to help debug
      console.log('[Travel] Could not extract text. Full result keys:', JSON.stringify(Object.keys(a2aResult.result || {})));
      console.log('[Travel] Full response (first 1000 chars):', JSON.stringify(a2aResult).substring(0, 1000));

      return a2aResult.result || a2aResult;
    } catch (error) {
      console.error('[Travel] API error:', error.message);
      if (error.response) {
        console.error('[Travel] Response status:', error.response.status);
        // Log EXACT error response (full, untruncated)
        console.error('[Travel] Response data (FULL):', JSON.stringify(error.response.data, null, 2));
        console.error('[Travel] Response headers:', JSON.stringify(error.response.headers, null, 2));
      }
      throw error;
    }
  }

  /**
   * Process a travel-related query
   */
  /**
   * Check if query is asking about another person's travel data.
   * Only block EXPLICIT other-person references. Assume self if ambiguous.
   */
  isQueryAboutOtherPerson(query) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    const personalDataKeywords = ['travel', 'booking', 'trip', 'flight', 'hotel', 'itinerary', 'destination', 'booked', 'book', 'expense', 'settlement', 'reimbursement'];
    const hasPersonalData = personalDataKeywords.some(kw => q.includes(kw));
    if (!hasPersonalData) return false;

    const hasSelfRef = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i\sam)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|co-worker|team\s?mate|boss|manager|reportee|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i.test(q);

    // Self-ref without colleague word AND no other-person name → ALLOW
    if (hasSelfRef && !hasColleagueWord) {
      let otherName = false;
      const ofFor = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
      if (ofFor) {
        const safe = new Set(['me','myself','today','yesterday','tomorrow','now','free',
          'monday','tuesday','wednesday','thursday','friday','saturday','sunday',
          'week','month','year','this','that','next','last','coming','previous','past','current',
          'bangalore','coimbatore','bosch','india',
          'delhi','mumbai','chennai','hyderabad','pune','kolkata','goa',
          'travel','booking','trip','flight','hotel','destination','expense','business','personal','leisure','official','work','home','office',
          'raise','book','plan','create','cancel','modify','update','submit','apply','request',
          'building','block','wing','cabin','cabins','workspace','room','floor','half',
          'snacks','snack','menu','food','canteen','bus','cab','train','stay','oneway','roundtrip',
          'jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec',
          'january','february','march','april','may','june','july','august','september','october','november','december',
          'full','day','days','first','second','return']);
        if (!safe.has(ofFor[1].toLowerCase())) otherName = true;
      }
      const poss = q.match(/(\w{3,})(?:'s|s')\s+/i);
      if (poss) {
        const skip = new Set(['today','yesterday','tomorrow','it','that','this','there','here',
          'what','let','don','doesn','didn','won','week','month','year','last','next']);
        if (!skip.has(poss[1].toLowerCase())) otherName = true;
      }
      if (!otherName) return false;
    }

    // Bulk requests
    if (/\b(all\s+(?:travel|trip|booking|expense)|every\s*one|everybody|team\s+travel|who\s+(?:all\s+)?(?:travel|booked|went)|list\s+(?:all|every)|show\s+(?:all|every|each)\s+(?:employee|people|person|staff|member))\b/i.test(q)) {
      console.log('[Travel] Privacy: blocked bulk/collective request');
      return true;
    }

    if (hasColleagueWord) {
      console.log('[Travel] Privacy: blocked colleague word + travel data');
      return true;
    }

    if (/\b(his|her|their|them|him)\b/i.test(q)) {
      console.log('[Travel] Privacy: blocked third-person pronoun');
      return true;
    }

    // Possessive name: "Rahul's travel"
    const possessives = [...original.matchAll(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g)];
    if (possessives.length > 0) {
      console.log(`[Travel] Privacy: blocked possessive name: ${possessives[0][1]}`);
      return true;
    }

    // "of/for <Name>" (case-insensitive to catch "for vaishnavi")
    const safeTargets = new Set(['me','myself','today','yesterday','tomorrow','monday','tuesday','wednesday',
      'thursday','friday','saturday','sunday','week','month','year','bangalore','coimbatore','bosch','india',
      'delhi','mumbai','chennai','hyderabad','pune','kolkata','goa','business','personal','leisure',
      'official','work','home','office','free','approval','review','nothing','lunch','dinner','breakfast',
      'building','block','floor','zone','wing','cabin','cabins','workspace','workstation','room',
      'seat','desk','booking','march','april','may','june','july','august','september',
      'october','november','december','january','february','full','half','day','first','second',
      'raise','book','plan','create','cancel','modify','update','submit','apply','request',
      'snacks','snack','menu','food','canteen','bus','cab','train','stay','flight','hotel','trip',
      'return','oneway','roundtrip','travel','expense','settlement','reimbursement',
      'jan','feb','mar','apr','jun','jul','aug','sep','oct','nov','dec','the','same','dates','location','destination','coming','next','last','this','past','previous','current']);
    const ofForMatches = [...q.matchAll(/\b(?:of|for)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\b/gi)];
    for (const m of ofForMatches) {
      const nameLC = m[1].toLowerCase();
      // Check each word individually for multi-word matches like "snacks today"
      const words = nameLC.split(/\s+/);
      const allSafe = words.every(w => safeTargets.has(w));
      if (!allSafe) {
        console.log(`[Travel] Privacy: blocked of/for name: ${m[1]}`);
        return true;
      }
    }

    // Capitalized name near travel data (no self-ref)
    if (!hasSelfRef) {
      const nonNames = new Set(['the','what','when','where','how','show','get','tell','give','today',
        'yesterday','tomorrow','monday','tuesday','wednesday','thursday','friday','saturday','sunday',
        'january','february','march','april','may','june','july','august','september',
        'october','november','december','bangalore','coimbatore','india','bosch',
        'delhi','mumbai','chennai','hyderabad','pune','kolkata','goa',
        'week','month','year','total','average','please','thanks','hello','time','times',
        'travel','trip','flight','hotel','booking','booked','itinerary','destination','expense',
        'can','could','would','should','will','need','want','like','check','see','view','look',
        'all','any','some','this','that','these','those','last','next','first','second',
        'cancel','system','context','current','date','ist','settlement','reimbursement',
        'raise','book','plan','create','modify','update','submit','apply','request','display',
        'provide','retrieve','generate','calculate','summarize','return',
        'building','block','wing','cabin','cabins','workspace','room','floor','half',
        'snacks','snack','menu','food','canteen','bus','cab','train','stay','oneway','roundtrip',
        'jan','feb','mar','apr','jun','jul','aug','sep','oct','nov','dec',
        'detailed','complete','full','specific','exact','accurate','recent','comprehensive',
        'monthly','daily','weekly','annual','yearly','summary','period','range','between','during','coming']);
      const allCapNames = [...original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)];
      for (const m of allCapNames) {
        if (!nonNames.has(m[1].toLowerCase()) && m[1].length > 3) {
          console.log(`[Travel] Privacy: blocked capitalized name: ${m[1]}`);
          return true;
        }
      }
    }

    // DEFAULT: no explicit other-person reference → ALLOW
    return false;
  }

  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId, userName } = context;

      // Privacy check: Block queries about other people's travel data
      if (this.isQueryAboutOtherPerson(query)) {
        console.log('[Travel] Privacy check: Blocking query about colleague travel data');
        return {
          success: false,
          response: "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their travel bookings or any other personal data. If you need information about a colleague's travel, please ask them directly or contact HR."
        };
      }

      let finalQuery = query;
      if (userName) {
        // Prepend context about the user's name to help the agent address them correctly
        finalQuery = `My name is ${userName}. ${query}`;
      } else {
        console.log('[TravelService] WARNING: No userName in context, A2A Agent might use fallback name');
      }

      console.log(`[TravelService] Final prompt for A2A: "${finalQuery.substring(0, 100)}..."`);
      // Call the Travel AI API with proper authentication
      const result = await this.callTravelAPI(finalQuery, employeeNumber, authToken, [], jwtToken, sessionId);

      // Format the response
      const response = this.formatTravelResponse(result, query);

      return {
        success: true,
        response,
        data: result
      };
    } catch (error) {
      console.error('Travel query error:', error);

      // Check if it's an auth error
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        return {
          success: false,
          response: `✈️ **Travel Assistant**\n\nThe travel service requires specific authentication that's not yet configured for this portal.\n\n**To manage travel:**\n1. Visit the BGSW Travel portal directly\n2. Or contact your travel coordinator\n\n_We're working on integrating this feature fully._`,
          error: 'Authentication required'
        };
      }

      return {
        success: false,
        response: `✈️ **Travel Assistant**\n\nI'm having trouble connecting to the travel system.\n\n**Alternative options:**\n1. Visit the BGSW Travel portal directly\n2. Contact your travel coordinator`,
        error: error.message
      };
    }
  }

  /**
   * Format travel API response for display
   */
  formatTravelResponse(result, query) {
    if (!result) {
      return "I couldn't get a response from the travel system. Please try again.";
    }

    // Extract text from various A2A response structures
    let responseText = null;

    // A2A task response: status.message.parts[].text
    if (result.status?.message?.parts) {
      const textPart = result.status.message.parts.find(p => p.kind === 'text' || p.type === 'text');
      if (textPart) {
        responseText = textPart.text;
      }
    }

    // A2A history format: history[last agent].parts[].text
    if (!responseText && result.history && Array.isArray(result.history)) {
      // Try role-based lookup first
      let lastAgentMessage = [...result.history].reverse().find(h => h.role === 'agent');

      // Fallback: pick the last entry that isn't the user's own message
      if (!lastAgentMessage && result.history.length > 1) {
        lastAgentMessage = [...result.history].reverse().find(h => {
          if (h.role === 'user') return false;
          const txt = h.parts?.find(p => p.kind === 'text' || p.type === 'text')?.text || '';
          return txt !== 'Processing...';
        });
      }

      if (lastAgentMessage?.parts) {
        const textPart = lastAgentMessage.parts.find(p => p.kind === 'text' || p.type === 'text');
        if (textPart && textPart.text && textPart.text !== 'Processing...') {
          responseText = textPart.text;
        }
      }
    }

    // A2A artifacts format: artifacts[].parts[].text
    if (!responseText && result.artifacts && Array.isArray(result.artifacts)) {
      for (const artifact of result.artifacts) {
        if (artifact.parts) {
          const textPart = artifact.parts.find(p => p.kind === 'text' || p.type === 'text');
          if (textPart && textPart.text) {
            responseText = textPart.text;
            break;
          }
        }
      }
    }

    // Direct message parts
    if (!responseText && result.message?.parts) {
      const textPart = result.message.parts.find(p => p.kind === 'text' || p.type === 'text');
      if (textPart) {
        responseText = textPart.text;
      }
    }

    // Simple response field
    if (!responseText && result.response) {
      responseText = result.response;
    }

    // Backend API returns 'item' field with the response
    if (!responseText && result.item) {
      responseText = result.item;
    }

    // If there's a message string field
    if (!responseText && typeof result.message === 'string') {
      responseText = result.message;
    }

    // If we extracted a response, format it nicely
    if (responseText) {
      // Skip "Processing..." messages
      if (responseText === 'Processing...') {
        return `✈️ **Travel Assistant**\n\nThe travel agent is still processing your request. Please try again in a moment.`;
      }
      return `✈️ **Travel Assistant**\n\n${responseText}`;
    }

    // Return raw response if structure is unknown (for debugging)
    console.log('[Travel] Unknown response structure (FULL):', JSON.stringify(result, null, 2));
    console.log('[Travel] Result keys:', Object.keys(result));
    console.log('[Travel] Result type:', typeof result);
    return `✈️ **Travel Assistant**\n\nReceived response from travel system but couldn't parse it properly. Please try again.`;
  }

  /**
   * Create a new travel plan
   */
  async createTravelPlan(details, context = {}) {
    const message = `Create a new travel plan with the following details:
- Destination: ${details.destination}
- Start Date: ${details.startDate}
- End Date: ${details.endDate}
- Purpose: ${details.purpose}
${details.additionalDetails ? `- Additional Details: ${details.additionalDetails}` : ''}`;

    return this.processQuery(message, context);
  }

  /**
   * Submit travel settlement
   */
  async submitSettlement(tripId, expenses, context = {}) {
    const message = `Submit travel settlement for trip ID: ${tripId}. Expenses: ${expenses}`;
    return this.processQuery(message, context);
  }

  /**
   * Get travel status
   */
  async getTravelStatus(tripId, context = {}) {
    const message = `What is the status of my travel request with ID: ${tripId}?`;
    return this.processQuery(message, context);
  }
}

module.exports = new TravelService();
