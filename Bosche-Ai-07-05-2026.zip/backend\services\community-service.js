/**
* Community Service
* Calls the Community MCP Server to get community information
*/

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');
const configService = require('./config-service');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

class CommunityService {
  constructor() {
    // Use deployed Community MCP Server (base URL); endpoint can be /mcp or root
    this.mcpBaseUrl = process.env.COMMUNITY_MCP_URL;
    this.mcpUrl = this.mcpBaseUrl;
    this.cache = new Map();
    this.cacheTimeout = 10 * 60 * 1000; // 10 minutes
    this.mcpSessionId = null;
  }

  /**
   * Build candidate MCP endpoints for compatibility with different deployments.
   */
  getMcpEndpointCandidates() {
    const base = this.mcpBaseUrl.replace(/\/$/, '');
    if (base.endsWith('/mcp')) {
      return [base, base.replace(/\/mcp$/, '')];
    }
    return [`${base}/mcp`, base];
  }

  /**
   * Initialize MCP session
   */
  async initializeMCPSession() {
    console.log('[Community] Initializing MCP session...');

    const initPayload = {
      jsonrpc: "2.0",
      method: "initialize",
      params: {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: { name: "mybgs-companion", version: "1.0.0" }
      },
      id: 1
    };

    let lastError = null;
    for (const endpoint of this.getMcpEndpointCandidates()) {
      try {
        const response = await axios.post(endpoint, initPayload, {
          headers: {
            'Accept': 'application/json, text/event-stream',
            'Content-Type': 'application/json'
          },
          timeout: 30000,
          httpsAgent,
          transformResponse: [(data) => data]
        });

        this.mcpUrl = endpoint;
        this.mcpSessionId = response.headers['mcp-session-id'] || response.headers['x-mcp-session-id'] || null;
        console.log('[Community] MCP session initialized at:', this.mcpUrl, 'session:', this.mcpSessionId || 'none');
        return this.mcpSessionId;
      } catch (error) {
        lastError = error;
        console.log(`[Community] MCP init failed at ${endpoint}: ${error.message}`);
      }
    }

    console.error('[Community] Failed to initialize MCP session on all endpoints');
    throw lastError || new Error('Failed to initialize community MCP session');
  }

  /**
   * Get cache key
   */
  getCacheKey(page, pageSize) {
    return `community:${page}:${pageSize}`;
  }

  /**
   * Check if cache is valid
   */
  isCacheValid(cacheEntry) {
    if (!cacheEntry) return false;
    return Date.now() - cacheEntry.timestamp < this.cacheTimeout;
  }

  /**
   * Parse SSE response data
   */
  parseSSEResponse(sseData) {
    if (typeof sseData !== 'string') return sseData;

    const lines = sseData.split('\n');
    let result = null;

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          result = JSON.parse(line.substring(6));
        } catch (e) {
          result = { answer: line.substring(6) };
        }
      }
    }

    return result;
  }

  /**
   * Parse MCP tool response to plain object/string.
   */
  parseMcpToolResponse(rawData) {
    const result = this.parseSSEResponse(rawData);
    const mcpResult = result?.result || result;

    // Common shape: { content: [{ type: 'text', text: '...json...' }] }
    if (mcpResult?.content && Array.isArray(mcpResult.content)) {
      for (const item of mcpResult.content) {
        if (item.type === 'text' && item.text) {
          try {
            return JSON.parse(item.text);
          } catch (e) {
            return item.text;
          }
        }
      }
    }

    // Alternate shape: { structuredContent: { result: '...json...' } }
    if (mcpResult?.structuredContent?.result) {
      const parsed = this.tryParseJson(mcpResult.structuredContent.result);
      if (parsed) return parsed;
    }

    return mcpResult;
  }

  tryParseJson(value) {
    if (typeof value !== 'string') return null;
    try {
      return JSON.parse(value);
    } catch (e) {
      return null;
    }
  }

  normalizeText(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  flattenCommunities(data) {
    let parsed = data;

    if (typeof parsed === 'string') {
      const parsedString = this.tryParseJson(parsed);
      if (parsedString) parsed = parsedString;
    }

    if (parsed?.structuredContent?.result) {
      const structured = this.tryParseJson(parsed.structuredContent.result);
      if (structured) parsed = structured;
    }

    if (parsed?.content && Array.isArray(parsed.content)) {
      for (const item of parsed.content) {
        if (item?.type === 'text' && item?.text) {
          const parsedText = this.tryParseJson(item.text);
          if (parsedText) {
            parsed = parsedText;
            break;
          }
        }
      }
    }

    const communities = [];

    if (parsed?.ResponseData && Array.isArray(parsed.ResponseData)) {
      parsed.ResponseData.forEach(group => {
        const groupMembers = group?.MembersCount;
        if (Array.isArray(group?.CommunityDetails)) {
          if (group.CommunityDetails.length > 0) {
            console.log('[Community] Raw community keys:', Object.keys(group.CommunityDetails[0]));
          }
          group.CommunityDetails.forEach(c => {
            communities.push({
              communityId: c?.CommunityId,
              name: c?.CommunityName || c?.Name || '',
              description: c?.Description || '',
              members: c?.CommunityMembers ?? c?.MembersCount ?? groupMembers ?? null,
              color: c?.Colour || c?.colour || null,
              imageUrl: c?.ImageUrl || null,
              locations: Array.isArray(c?.CommunityLocations)
                ? c.CommunityLocations.map(l => ({
                  id: l?.Id,
                  name: l?.LocationName || '',
                  code: l?.LocationCode || ''
                }))
                : []
            });
          });
        }
      });
      return communities;
    }

    const list = Array.isArray(parsed)
      ? parsed
      : (Array.isArray(parsed?.communities) ? parsed.communities
        : (Array.isArray(parsed?.data) ? parsed.data
          : (Array.isArray(parsed?.items) ? parsed.items : [])));

    list.forEach(c => {
      communities.push({
        communityId: c?.communityId ?? c?.CommunityId ?? c?.id ?? null,
        name: c?.name || c?.CommunityName || c?.Name || '',
        description: c?.description || c?.Description || '',
        members: c?.members ?? c?.memberCount ?? c?.MembersCount ?? c?.CommunityMembers ?? null,
        color: c?.color || c?.Colour || null,
        imageUrl: c?.imageUrl || c?.ImageUrl || null,
        locations: Array.isArray(c?.locations)
          ? c.locations.map(l => ({
            id: l?.id ?? l?.Id ?? null,
            name: l?.name || l?.LocationName || '',
            code: l?.code || l?.LocationCode || ''
          }))
          : []
      });
    });

    return communities;
  }

  getLocationAliases(nameOrCode) {
    const n = this.normalizeText(nameOrCode);
    const aliases = new Set([n]);
    if (n.includes('bengaluru')) aliases.add('bangalore');
    if (n.includes('bangalore')) aliases.add('bengaluru');
    if (n.includes('bgsw pun dta') || n === 'pun') aliases.add('pune');
    if (n === 'ban') aliases.add('bangalore');
    if (n === 'cob') aliases.add('coimbatore');
    if (n === 'hyd') aliases.add('hyderabad');
    return aliases;
  }

  resolveRegistrationFromQuery(query, communities) {
    const normalizedQuery = this.normalizeText(query);
    if (!normalizedQuery || !Array.isArray(communities) || communities.length === 0) {
      return { community: null, location: null };
    }

    const communityIdMatch = query.match(/community\s*id\s*[:=]?\s*(\d+)/i) || query.match(/community\s*(\d+)/i);
    const locationIdMatch = query.match(/location\s*id\s*[:=]?\s*(\d+)/i) || query.match(/location\s*(\d+)/i);
    const communityId = communityIdMatch ? parseInt(communityIdMatch[1], 10) : null;
    const locationId = locationIdMatch ? parseInt(locationIdMatch[1], 10) : null;

    let community = null;
    if (communityId) {
      community = communities.find(c => Number(c.communityId) === Number(communityId)) || null;
    }

    if (!community) {
      const scored = communities
        .map(c => {
          const cname = this.normalizeText(c.name);
          if (!cname) return { c, score: 0 };
          if (normalizedQuery.includes(cname)) return { c, score: 100 };

          const words = cname.split(' ').filter(w => w.length > 2 && !['community', 'club'].includes(w));
          const hitCount = words.filter(w => normalizedQuery.includes(w)).length;
          const score = words.length > 0 ? Math.round((hitCount / words.length) * 80) : 0;
          return { c, score };
        })
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score);

      if (scored.length > 0) {
        const top = scored[0];
        const next = scored[1];
        if (!next || top.score - next.score >= 15) {
          community = top.c;
        }
      }
    }

    let location = null;
    if (community) {
      if (locationId) {
        location = (community.locations || []).find(l => Number(l.id) === Number(locationId)) || null;
      }

      if (!location) {
        const candidates = (community.locations || []).map(l => {
          const aliases = [
            ...this.getLocationAliases(l.name),
            ...this.getLocationAliases(l.code)
          ];
          const matched = aliases.some(a => a && normalizedQuery.includes(a));
          return { l, matched };
        }).filter(x => x.matched);

        if (candidates.length === 1) {
          location = candidates[0].l;
        }
      }
    }

    return { community, location };
  }

  shouldShowAllCommunities(query) {
    const q = this.normalizeText(query);
    // Build regex from centralised config (editable via Admin UI)
    const communityKw = configService.getKeywordConfigSync().communityService;
    // [FIX | S2631 - ReDoS]: Use includes() instead of dynamic RegExp — no regex sink, no backtracking risk.
    const phrases = communityKw.listIntentPhrases || [
      'show all', 'list all', 'all communities', 'all active',
      'community list', 'active communities', 'what communities',
      'which communities', 'what are the communities',
      'show me communities', 'show communities', 'list communities'
    ];
    return phrases.some(p => q.toLowerCase().includes(p.toLowerCase()));
  }

  resolveSpecificCommunitiesFromQuery(query, communities) {
    const q = this.normalizeText(query);
    if (!q || !Array.isArray(communities) || communities.length === 0) {
      return [];
    }

    // Allow explicit CommunityId lookup in natural language.
    const idMatch = query.match(/community\s*id\s*[:=]?\s*(\d+)/i) || query.match(/\bid\s*[:=]?\s*(\d+)\b/i);
    if (idMatch) {
      const id = Number(idMatch[1]);
      const byId = communities.filter(c => Number(c.communityId) === id);
      if (byId.length > 0) return byId;
    }

    const genericWords = new Set([
      'community', 'communities', 'about', 'details', 'detail', 'information', 'info', 'tell', 'show', 'give',
      'me', 'the', 'for', 'of', 'on', 'in', 'at', 'to', 'please', 'available', 'active', 'join', 'register',
      'list', 'all', 'which', 'what', 'is', 'are', 'can', 'i'
    ]);

    const queryWords = q
      .split(' ')
      .map(w => w.trim())
      .filter(w => w.length > 2 && !genericWords.has(w));

    const scored = communities
      .map(c => {
        const cname = this.normalizeText(c.name);
        if (!cname) return { c, score: 0 };

        if (q.includes(cname)) {
          return { c, score: 100 };
        }

        const nameWords = cname.split(' ').filter(w => w.length > 2 && !genericWords.has(w));
        const matches = nameWords.filter(w => queryWords.includes(w)).length;
        if (matches === 0) return { c, score: 0 };

        const score = Math.round((matches / Math.max(nameWords.length, 1)) * 80);
        return { c, score };
      })
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score);

    if (scored.length === 0) return [];

    // Return tied best matches, otherwise just top one.
    const topScore = scored[0].score;
    const nearTop = scored.filter(x => x.score >= topScore - 10 && x.score >= 50).map(x => x.c);
    return nearTop.length > 0 ? nearTop : [scored[0].c];
  }

  /**
   * Post a JSON-RPC payload to MCP endpoint candidates.
   */
  async postMcpPayload(payload, extraHeaders = {}) {
    const endpoints = [this.mcpUrl, ...this.getMcpEndpointCandidates()].filter(Boolean);
    const tried = new Set();
    let lastError = null;

    for (const endpoint of endpoints) {
      if (tried.has(endpoint)) continue;
      tried.add(endpoint);

      try {
        const response = await axios.post(endpoint, payload, {
          headers: {
            'Accept': 'application/json, text/event-stream',
            'Content-Type': 'application/json',
            ...(this.mcpSessionId ? { 'mcp-session-id': this.mcpSessionId } : {}),
            ...extraHeaders
          },
          httpsAgent,
          timeout: 30000,
          transformResponse: [(data) => data]
        });

        this.mcpUrl = endpoint;
        this.mcpSessionId = response.headers['mcp-session-id'] || response.headers['x-mcp-session-id'] || this.mcpSessionId;
        return response;
      } catch (error) {
        lastError = error;
        console.log(`[Community] MCP request failed at ${endpoint}: ${error.message}`);
      }
    }

    throw lastError || new Error('MCP request failed on all endpoints');
  }

  /**
   * Resolves the best available authorization header, falling back to service account if needed.
   * This mirrors the logic in travel-service.js to handle cases where user JWT minting fails.
   */
  async resolveSafeAuthToken(context = {}) {
    const { jwtToken, authToken, employeeNumber } = context;

    // Strategy 1: Raw OAuth token from frontend (Preferred for Community legacy APIs)
    if (authToken) {
      console.log(`[Community] Using direct OAuth authToken (Employee: ${employeeNumber})`);
      return this.normalizeAuthHeader(authToken);
    }

    // Strategy 2: Explicit JWT from server.js resolution
    if (jwtToken) {
      console.log(`[Community] Falling back to primary JWT token (Employee: ${employeeNumber})`);
      return this.normalizeAuthHeader(jwtToken);
    }

    // Strategy 3: Service Account Fallback
    console.log('[Community] No valid user tokens found. Requesting Service Account JWT fallback...');
    try {
      const serviceToken = await boschAuthService.getServiceToken();
      if (serviceToken) {
        console.log('[Community] Using Service Account JWT fallback (Votan)');
        return `Bearer ${serviceToken}`;
      }
    } catch (err) {
      console.error('[Community] Service Account fallback failed:', err.message);
    }

    return null;
  }

  /**
   * Ensure Authorization header uses Bearer scheme.
   */
  normalizeAuthHeader(authToken) {
    if (!authToken || typeof authToken !== 'string') return null;
    return authToken.toLowerCase().startsWith('bearer ') ? authToken : `Bearer ${authToken}`;
  }

  /**
   * Fetch community list from MCP Server or API
   */
  async getCommunityList(page = 1, pageSize = 10, context = {}) {
    const cacheKey = this.getCacheKey(page, pageSize);
    const cached = this.cache.get(cacheKey);

    if (this.isCacheValid(cached)) {
      console.log('[Community] Returning cached data');
      return cached.data;
    }

    try {
      console.log(`[Community] Fetching community list: page=${page}, pageSize=${pageSize}`);
      
      // Strategy 1-3: Resolve safe auth header
      const authHeader = await this.resolveSafeAuthToken(context);
      
      // Prepare headers
      const identityHeaders = {
        'X-Employee-Number': String(context.employeeNumber || ''),
        'X-User-Name': String(context.userName || 'Bosch User')
      };
      
      if (authHeader) {
        identityHeaders['Authorization'] = authHeader;
      }

      // Initialize session if needed
      if (!this.mcpSessionId) {
        try {
          await this.initializeMCPSession();
        } catch (initErr) {
          console.log('[Community] Continuing without MCP session initialization');
        }
      }

      // Call FastMCP tool: get_community_list (no arguments)
      const toolCallPayload = {
        jsonrpc: "2.0",
        method: "tools/call",
        params: {
          name: "get_community_list",
          arguments: {}
        },
        id: Date.now()
      };

      let response;
      try {
        response = await this.postMcpPayload(toolCallPayload, identityHeaders);

        console.log('[Community] MCP response received');
        const data = this.parseMcpToolResponse(response.data);

        // Cache the response
        this.cache.set(cacheKey, {
          data,
          timestamp: Date.now()
        });

        return data;
      } catch (mcpError) {
        console.log(`[Community] MCP failed: ${mcpError.message}, trying legacy API`);
        // Reset session on failure
        this.mcpSessionId = null;

        // Fallback to legacy Bosch Arena API
        const legacyUrl = 'https://dev.boschassociatearena.com/api/CommunityPlanet/GetCommunityList';
        response = await axios.get(legacyUrl, {
          params: { page, pageSize },
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json, text/plain, */*',
          },
          httpsAgent,
          timeout: 30000
        });

        const data = response.data;

        // Cache the response
        this.cache.set(cacheKey, {
          data,
          timestamp: Date.now()
        });

        return data;
      }
    } catch (error) {
      console.error('[Community] API error:', error.message);

      // Return cached data if available
      if (cached) {
        console.log('[Community] Returning expired cache due to error');
        return cached.data;
      }

      throw new Error(`Failed to fetch community list: ${error.message}`);
    }
  }

  /**
   * Register user to a community through MCP tool register_user_to_community.
   */
  async registerUserToCommunity(communityId, locationId, context = {}) {
    if (!Number.isInteger(communityId) || !Number.isInteger(locationId)) {
      throw new Error('communityId and locationId must be integers');
    }

    const tokenSource = context.jwtToken ? 'JWT' : (context.authToken ? 'OAuth' : 'None');
    console.log(`[Community] Registering with token source: ${tokenSource}`);
    
    // Strategy 1-3: Resolve safe auth header (with service account fallback)
    const authHeader = await this.resolveSafeAuthToken(context);
    
    if (!authHeader) {
      console.error('[Community] No authorization token found in context:', Object.keys(context));
      throw new Error('Authorization token is required to register to a community');
    }
    
    console.log(`[Community] Auth header length: ${authHeader.length}`);
    console.log(`[Community] Auth header present, length: ${authHeader.length}`);

    // Prepare extra identity headers for the MCP server
    const identityHeaders = {
      'Authorization': authHeader,
      'X-Employee-Number': String(context.employeeNumber || ''),
      'X-User-Name': String(context.userName || 'Bosch User')
    };

    if (!this.mcpSessionId) {
      try {
        await this.initializeMCPSession();
      } catch (initErr) {
        console.log('[Community] Continuing registration without MCP session initialization');
      }
    }

    const payload = {
      jsonrpc: '2.0',
      method: 'tools/call',
      params: {
        name: 'register_user_to_community',
        arguments: {
          community_id: communityId,
          location_id: locationId
        }
      },
      id: Date.now()
    };

    console.log(`[Community] Calling tool: register_user_to_community (ID: ${communityId}, Location: ${locationId})`);
    console.log(`[Community] Identity: Employee=${identityHeaders['X-Employee-Number']}, User=${identityHeaders['X-User-Name']}`);
    if (identityHeaders['Authorization']) {
      const auth = identityHeaders['Authorization'];
      console.log(`[Community] Auth Type: ${auth.split(' ')[0]}, Length: ${auth.length}`);
    }

    try {
      const response = await this.postMcpPayload(payload, identityHeaders);
      console.log('[Community] Registration tool response received');
      return this.parseMcpToolResponse(response.data);
    } catch (error) {
      // Session can expire; retry once with a fresh session
      this.mcpSessionId = null;
      try {
        await this.initializeMCPSession();
      } catch (initErr) {
        console.log('[Community] Retry registration without MCP session initialization');
      }
      const retryResponse = await this.postMcpPayload(payload, identityHeaders);

      return this.parseMcpToolResponse(retryResponse.data);
    }
  }

  /**
   * Format community data for display
   */
  formatCommunityResponse(data, query, options = {}) {
    console.log('Community API response structure:', JSON.stringify(data, null, 2).substring(0, 500));

    const communities = Array.isArray(options.communitiesOverride)
      ? options.communitiesOverride
      : this.flattenCommunities(data);
    const totalCount = communities.length;

    console.log(`Found ${communities.length} communities`);

    if (communities.length === 0) {
      return "I couldn't find any community information at the moment. Please try again later.";
    }

    const showFull = options.specificView || options.showAll;
    const heading = options.specificView
      ? '👥 **Community Details**\n\nHere is what I found:\n\n'
      : options.showAll
        ? `👥 **Bosch Communities** (${totalCount} active)\n\nHere are all the available communities with details:\n\n`
        : '👥 **Bosch Communities**\n\nHere are the available communities:\n\n';
    let response = heading;

    const displayLimit = showFull ? communities.length : Math.min(10, communities.length);
    communities.slice(0, displayLimit).forEach((community, index) => {
      const name = community.name || `Community ${index + 1}`;
      const communityId = community.communityId ?? 'N/A';
      response += `**${index + 1}. ${name}** (CommunityId: ${communityId})\n`;

      const desc = community.description;
      if (desc) {
        if (showFull) {
          response += `   ${desc}\n`;
        } else {
          const cleanDesc = desc.substring(0, 100);
          response += `   ${cleanDesc}${desc.length > 100 ? '...' : ''}\n`;
        }
      }

      const members = community.members;
      if (members) {
        response += `   👥 Members: ${members}\n`;
      }

      if (Array.isArray(community.locations) && community.locations.length > 0) {
        const locationText = community.locations
          .map(l => `${l.name || 'Unknown'} (LocationId: ${l.id ?? 'N/A'})`)
          .join(', ');
        response += `   📍 Locations: ${locationText}\n`;
      }

      response += '\n';
    });

    if (!showFull && totalCount > 10) {
      response += `\n_Showing 10 of ${totalCount} communities. Ask "show me all communities" to see the full list._`;
    }

    response += '\n\nTo join, click the **Join** button on a community card, or type naturally like: "join Art in Motion Community in Bangalore".';

    return response;
  }

  /**
   * Process a community-related query
   */
  async processQuery(query, context = {}) {
    try {
      // Determine what the user is asking for
      const lowerQuery = query.toLowerCase();

      // Check list intent FIRST — queries like "which communities can I join?" are list queries, not join requests
      const listIntent = this.shouldShowAllCommunities(query);

      // Only treat as registration if NOT a list/discovery query
      // Queries asking "which can I join" or "what communities to join" are discovery, not registration
      // Join-intent keywords from centralised config (editable via Admin UI)
      // [FIX | S2631 - ReDoS]: Use includes() instead of dynamic RegExp — no regex sink, no backtracking risk.
      const joinKws = configService.getKeywordConfigSync().communityService.joinIntentKeywords || [
        'join', 'register', 'enroll', 'enrol', 'subscribe', 'add me', 'sign me up'
      ];
      const hasJoinWord = joinKws.some(k => lowerQuery.includes(k.toLowerCase()));
      const isDiscoveryWithJoin = /\b(which|what|show|list|available|active|can i|how to|where)\b.*\b(join|register|enroll)\b/i.test(lowerQuery)
        || /\b(join|register|enroll)\b.*\b(which|what|available|active|communities|all)\b/i.test(lowerQuery);
      const isRegistrationIntent = hasJoinWord && !listIntent && !isDiscoveryWithJoin;

      // Handle join request via MCP tool register_user_to_community
      if (isRegistrationIntent) {
        const data = await this.getCommunityList(1, 50, context);
        const communities = this.flattenCommunities(data);
        const resolved = this.resolveRegistrationFromQuery(query, communities);

        if (!resolved.community) {
          const sample = communities.slice(0, 6)
            .map(c => `- ${c.name} (CommunityId: ${c.communityId})`)
            .join('\n');
          return {
            success: true,
            response: `I can register you directly using community and location names. I couldn't confidently identify the community from your message. Please mention the exact community name.\n\nExamples:\n- join Art in Motion Community in Bangalore\n- register me to Mind Buddies in Hyderabad\n\nSome available communities:\n${sample}`,
            data,
            page: 1,
            pageSize: 50
          };
        }

        if (!resolved.location) {
          const locations = (resolved.community.locations || [])
            .map(l => `- ${l.name} (LocationId: ${l.id})`)
            .join('\n');
          return {
            success: true,
            response: `I found the community **${resolved.community.name}** (CommunityId: ${resolved.community.communityId}), but I need the location. Please pick one of these locations:\n${locations}\n\nExample: join ${resolved.community.name} in Bengaluru`,
            data,
            page: 1,
            pageSize: 50
          };
        }

        const joinData = await this.registerUserToCommunity(
          Number(resolved.community.communityId),
          Number(resolved.location.id),
          context
        );

        // Parse the registration response
        let joinResponse;
        const parsed = typeof joinData === 'string' ? this.tryParseJson(joinData) : joinData;
        console.log('[Community] Registration Tool Raw Response:', JSON.stringify(parsed, null, 2));
        let isJoinSuccess = false;

        const msg = (parsed && (parsed.Message || parsed.ErrorMessage)) || '';
        const isAlreadyMember = /already\s+(registered|member|exists|enrolled|joined)/i.test(msg);

        if (isAlreadyMember) {
          joinResponse = `ℹ️ You are already a registered member of **${resolved.community.name}** (CommunityId: ${resolved.community.communityId}).`;
          isJoinSuccess = false; // Prevent +1 increment
        } else if (parsed && parsed.IsSuccess) {
          isJoinSuccess = true;
          joinResponse = `✅ You have been successfully registered to **${resolved.community.name}** at **${resolved.location.name}** (CommunityId: ${resolved.community.communityId}, LocationId: ${resolved.location.id}).`;
        } else if (parsed && (parsed.Message || parsed.ErrorMessage)) {
          joinResponse = `❌ Registration for **${resolved.community.name}** at **${resolved.location.name}** was not successful: ${msg}`;
        } else {
          const joinText = typeof joinData === 'string' ? joinData : JSON.stringify(joinData);
          joinResponse = `Registration submitted for **${resolved.community.name}** at **${resolved.location.name}** (CommunityId: ${resolved.community.communityId}, LocationId: ${resolved.location.id}).\n\nResponse: ${joinText}`;
        }

        let returnData;
        if (isJoinSuccess) {
          returnData = await this.applyOptimisticUpdate(Number(resolved.community.communityId), context);
          joinResponse += '\n\n_Note: The member count has been updated in your view to reflect your registration._';
        } else {
          returnData = await this.getCommunityList(1, 50, context);
        }

        return {
          success: true,
          response: joinResponse,
          data: returnData,
          page: 1,
          pageSize: 50
        };
      }

      let page = 1;
      let pageSize = 10;

      // Check if user wants more results
      if (lowerQuery.includes('more') || lowerQuery.includes('next')) {
        page = (context.communityPage || 1) + 1;
      }

      // Fetch all communities when user wants the full list
      if (listIntent || lowerQuery.includes('all')) {
        pageSize = 50;
      }

      const data = await this.getCommunityList(page, pageSize, context);
      const communities = this.flattenCommunities(data);
      const matches = this.resolveSpecificCommunitiesFromQuery(query, communities);

      // Detect if the user is asking about a specific community (not a general list)
      const isSpecificCommunityQuery = !listIntent && (
        /\b(?:tell|info|information|details?|about|describe)\b.*\bcommunity\b/i.test(lowerQuery)
        || /\bcommunity\b.*\b(?:tell|info|information|details?|about|describe)\b/i.test(lowerQuery)
        || /\b(?:tell me about|info on|info about|details of|details about|information on|information about|describe)\s+\w+/i.test(lowerQuery)
      );

      let response;
      // Specific community matches always take priority over list intent
      if (matches.length === 1) {
        response = this.formatCommunityResponse(data, query, {
          communitiesOverride: matches,
          specificView: true
        });
      } else if (matches.length > 1 && !listIntent) {
        response = this.formatCommunityResponse(data, query, {
          communitiesOverride: matches,
          specificView: true
        });
        response += '\n\nI found multiple close matches. Please mention the exact community name if you want just one.';
      } else if (matches.length === 0 && isSpecificCommunityQuery) {
        // User asked about a specific community but no match found
        const communityNames = communities.slice(0, 10).map(c => `- ${c.name}`).join('\n');
        response = `❌ Sorry, I don't have any information about that community. It may not exist in the Bosch Associate Arena.\n\nHere are the communities currently available:\n${communityNames}\n\nYou can ask about any of these communities for more details.`;
      } else if (listIntent) {
        response = this.formatCommunityResponse(data, query, { showAll: true });
      } else {
        response = this.formatCommunityResponse(data, query);
      }

      return {
        success: true,
        response,
        data,
        page,
        pageSize
      };
    } catch (error) {
      console.error('Community query error:', error);
      return {
        success: false,
        response: `I'm having trouble accessing community information right now. Error: ${error.message}`,
        error: error.message
      };
    }
  }

  /**
   * Refreshes the community list after a successful join so the UI reflects
   * the authoritative member count returned by the API.
   *
   * Previously this method applied a client-side +1 on top of a freshly
   * fetched list, which double-counted (API already reflected the new
   * member, then we added another). The API is authoritative — just clear
   * the cache and return the latest data.
   */
  async applyOptimisticUpdate(targetId, context = {}) {
    console.log(`[Community] Refreshing community list after join for ID: ${targetId}`);
    this.cache.clear();
    return await this.getCommunityList(1, 50, context);
  }

  /**
   * Clear cache
   */
  clearCache() {
    this.cache.clear();
    return { cleared: true };
  }
}

module.exports = new CommunityService();
