const http = require('http');

const options = {
  hostname: 'localhost',
  port: 8080,
  path: '/api/community/register',
  method: 'POST',
  headers: {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9",
    "authorization": "Bearer MzieGk4kqnShnjP_rm4FcIxtHL-s1CaUlSe8OwFWdFIx5Mt9tIdaN9xJi4AANJeDpQIISuacJfjB-YoqDmIh-abet3B_r4F2xthZQknYJjUrGlXdZBijWTa3aXYlPyhiITmk8Acwkyo5zL0sZ3ZnhT5MnDoFIjJLJZRoxx4SooGZ3RucJq7mKSjMNquhOeyw01v7HkRK98vODVVCoGhYfodULvWiXG2qDL1raGztcNPAm8BiGAUcElJOg86on-s1rpu95tZJ7nBLU0c99rBtDtQINMMR5Xod1w0gcW62N9RbSRtnvx68qqqpQzAmCZTe7Zph4hvUzBqLJcl4EL-Y49H_jXhnGtPuVFmnEBM_10SrVS13O3uogftnELUrL48u30QKaw5s6AfogIwqH8SJlT7yJWxwsjjiM29xUgpsLhY",
    "cache-control": "no-cache",
    "content-type": "application/json",
    "pragma": "no-cache"
  }
};

const req = http.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', data);
  });
});

req.on('error', (e) => {
  console.error(`Problem with request: ${e.message}`);
});

req.write(JSON.stringify({communityId:2, locationId:1}));
req.end();
