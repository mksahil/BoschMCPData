import { Home, Lightbulb, Zap, Users, GraduationCap, Heart, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { DarkModeToggle } from "./DarkModeToggle";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { useTheme } from "next-themes";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavigationProps {
  activeSection?: string;
  onSectionChange?: (section: string) => void;
  contextTitle?: string;
}

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "insights", label: "Insights", icon: Lightbulb },
  { id: "actions", label: "Actions", icon: Zap },
  { id: "mentorship", label: "Mentorship", icon: Users },
  { id: "learning", label: "Learning", icon: GraduationCap },
  { id: "wellness", label: "Wellness", icon: Heart },
];

export const Navigation = ({ activeSection = "home", onSectionChange, contextTitle }: NavigationProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getInitials = () => {
    if (user?.name && user.name.trim()) {
      const names = user.name.trim().split(' ');
      if (names.length >= 2) return `${names[0][0]}${names[1][0]}`.toUpperCase();
      return names[0].substring(0, 2).toUpperCase();
    }
    return user?.employeeNumber?.substring(0, 2) || 'U';
  };

  return (
    <div className="sticky top-0 z-50 w-full">
      {/* Bosch rainbow strip */}
      <div className="w-full h-1 relative overflow-hidden">
        <img src="/bosch-rainbow.svg" alt="" className="w-full h-full object-cover" />
      </div>
      {/* Full-width header bar */}
      <div
        className="w-full flex items-center justify-between px-5 h-14"
        style={{

          backdropFilter: "blur(20px) saturate(160%)",
          WebkitBackdropFilter: "blur(20px) saturate(160%)",

        }}
      >
        {/* Left: Logo + brand */}
        <div className="flex items-center gap-3 flex-shrink-0 min-w-[180px]">
          <img src="/bgsw-logo.png" alt="MyBGSW Logo" className="w-8 h-8 object-contain" />

          {/* myBGSW.Ai */}
          <h1
            className={cn("text-sm font-bold leading-none", isDark ? "text-white" : "text-black")}
          >
            {contextTitle || "myBGSW.Ai"}
          </h1>

          {/* Divider */}
          <div className="h-4 w-px bg-white/20 mx-1" />

          {/* BGSW block */}
          <div className="flex flex-col leading-none">
            <span className={cn("text-s font-bold tracking-wide", isDark ? "text-white" : "text-black")}>BGSW</span>
            <span className={cn(
              "text-[10px]",
              isDark ? "text-white" : "text-black"
            )}>
              alt_future
            </span>
          </div>
        </div>

        {/* Center: floating nav pill — liquid glass */}
        <div
          className="hidden md:rounded-full md:p-px md:flex"
          style={{
            background: isDark
              ? "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.06) 60%, rgba(255,255,255,0.02) 100%)"
              : "linear-gradient(180deg, rgba(255,255,255,0.90) 0%, rgba(255,255,255,0.40) 60%, rgba(200,200,210,0.20) 100%)",
          }}
        >
          <div
            className="flex items-center gap-0.5 px-1.5 py-1.5 rounded-full"
            style={{
              background: isDark ? "rgba(20,20,28,0.62)" : "rgba(225,225,235,0.20)",
              backdropFilter: isDark ? "blur(0px) saturate(200%)" : "none",
              WebkitBackdropFilter: isDark ? "blur(0px) saturate(200%)" : "none",
              boxShadow: isDark
                ? "inset 0 1.5px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.25), 0 8px 32px rgba(0,0,0,0.20)"
                : "inset 0 1.5px 0 rgba(255,255,255,0.95), inset 0 -1px 0 rgba(0,0,0,0.06), 0 8px 32px rgba(0,0,0,0.10)",
            }}
          >
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange?.(item.id)}
                  className={cn(
                    "px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-200 whitespace-nowrap",
                    isActive
                      ? isDark
                        ? "text-gray-900 shadow-sm"
                        : "text-gray-900 shadow-sm"
                      : isDark
                        ? "text-white/55 hover:text-white/90"
                        : "text-gray-500 hover:text-gray-800"
                  )}
                  style={isActive ? {
                    color: isDark ? "black" : "rgba(0, 136, 255, 1)",
                    background: isDark
                      ? "linear-gradient(180deg, rgba(255,255,255,0.95) 0%, rgba(220,220,230,0.90) 100%)"
                      : "linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(240,240,248,0.95) 100%)",
                    boxShadow: "0 1px 4px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.8)",
                  } : undefined}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: controls */}
        <div className="flex items-center gap-2 flex-shrink-0 min-w-[140px] justify-end">
          {user && (
            <div
              className="hidden sm:flex items-center px-2.5 py-1 rounded-full"
              style={{
                background: isDark ? "rgba(10,132,255,0.12)" : "rgba(10,132,255,0.08)",
                border: "1px solid rgba(10,132,255,0.22)",
              }}
            >
              <span className="text-[11px] font-medium text-[#0a84ff]">
                {user.employeeNumber}
              </span>
            </div>
          )}

          <DarkModeToggle />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 focus:outline-none"
                style={{
                  background: "linear-gradient(135deg, hsl(195 80% 45%), hsl(205 100% 50%))",
                  boxShadow: "0 0 10px rgba(10,132,255,0.30)",
                }}
              >
                <span className="text-white font-semibold text-xs">{getInitials()}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span className="font-semibold">{user?.name?.trim() || 'User'}</span>
                  <span className="text-xs text-muted-foreground font-normal">
                    Employee: {user?.employeeNumber}
                  </span>
                  {user?.entityName && (
                    <span className="text-xs text-muted-foreground font-normal">
                      Entity: {user.entityName}
                    </span>
                  )}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={handleLogout}
                className="text-destructive focus:text-destructive cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>


    </div>
  );
};
