/**
 * Rate limit test for POST /api/community/register
 * Max: 2 requests/min per key (no X-Employee-Number → keyed by IP)
 *
 * Run: node backend/test-rate-limit-register.js
 */

const BASE_URL = 'http://localhost:3001';
const TOTAL_REQUESTS = 12;

// Dummy payload — the endpoint validates communityId + locationId + Authorization
// so we send valid-looking values; a 400/401 from the app logic is fine,
// what matters is whether we get 429 from the rate limiter.
const PAYLOAD = { communityId: 1, locationId: 1 };

async function sendRequest(index, headers = {}) {
  const res = await fetch(`${BASE_URL}/api/community/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    body: JSON.stringify(PAYLOAD),
  });

  const status = res.status;
  const retryAfter = res.headers.get('Retry-After');
  const remaining = res.headers.get('RateLimit-Remaining');
  let body;
  try { body = await res.json(); } catch { body = null; }

  const tag = status === 429 ? '🚫 BLOCKED' : status < 400 ? '✅ ALLOWED' : `⚠️  APP ERR ${status}`;
  console.log(
    `  [${index}] ${tag}  status=${status}` +
    (remaining !== null ? `  remaining=${remaining}` : '') +
    (retryAfter ? `  retry-after=${retryAfter}s` : '') +
    (body?.error ? `  error="${body.error}"` : '')
  );
  return status;
}

async function runTest(label, headers) {
  console.log(`\n${'─'.repeat(60)}`);
  console.log(`TEST: ${label}`);
  console.log(`${'─'.repeat(60)}`);

  const statuses = [];
  for (let i = 1; i <= TOTAL_REQUESTS; i++) {
    const status = await sendRequest(i, headers);
    statuses.push(status);
  }

  const blocked = statuses.filter(s => s === 429).length;
  const allowed = statuses.filter(s => s !== 429).length;
  console.log(`\n  → ${allowed} allowed, ${blocked} blocked`);

  if (blocked > 0) {
    console.log('  ✅ Rate limiting is WORKING');
  } else {
    console.log('  ❌ Rate limiting did NOT trigger — check server config');
  }
}

(async () => {
  console.log('Rate Limit Test — /api/community/register');
  console.log(`Sending ${TOTAL_REQUESTS} requests, limit is 10/min\n`);

  // Test 1: no employee number header (falls back to IP-based key)
  await runTest('No X-Employee-Number header (IP key)', {});

  // Wait a moment so the IP bucket isn't still exhausted for test 2
  console.log('\n  (waiting 2s before next test batch...)');
  await new Promise(r => setTimeout(r, 2000));

  // Test 2: with employee number header (employee-keyed bucket)
  await runTest('With X-Employee-Number: 99999999 (employee key)', {
    "authorization": "Bearer MzieGk4kqnShnjP_rm4FcIxtHL-s1CaUlSe8OwFWdFIx5Mt9tIdaN9xJi4AANJeDpQIISuacJfjB-YoqDmIh-abet3B_r4F2xthZQknYJjUrGlXdZBijWTa3aXYlPyhiITmk8Acwkyo5zL0sZ3ZnhT5MnDoFIjJLJZRoxx4SooGZ3RucJq7mKSjMNquhOeyw01v7HkRK98vODVVCoGhYfodULvWiXG2qDL1raGztcNPAm8BiGAUcElJOg86on-s1rpu95tZJ7nBLU0c99rBtDtQINMMR5Xod1w0gcW62N9RbSRtnvx68qqqpQzAmCZTe7Zph4hvUzBqLJcl4EL-Y49H_jXhnGtPuVFmnEBM_10SrVS13O3uogftnELUrL48u30QKaw5s6AfogIwqH8SJlT7yJWxwsjjiM29xUgpsLhY",

  });

  console.log('\n' + '─'.repeat(60));
  console.log('Done.');
})();
