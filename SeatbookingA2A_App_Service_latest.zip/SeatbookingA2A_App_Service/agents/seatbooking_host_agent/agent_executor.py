"""
Host Agent Executor - Updated with proper auth extraction for MCP tools
"""

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.utils import new_task, new_agent_text_message
from agents.seatbooking_host_agent.agent import HostAgent
from a2a.server.tasks import TaskUpdater
from a2a.types import TaskState
import asyncio


class HostAgentExecutor(AgentExecutor):
    """
    Executor for the Host Agent that handles:
    - A2A protocol communication
    - Auth extraction from requests for MCP tool calls
    - Task state management
    """
    
    def __init__(self):
        self.agent = HostAgent()
        
    async def create(self):
        """Initialize the underlying agent."""
        await self.agent.create()
    
    def _extract_auth(self, request_context: RequestContext) -> dict | None:
        """
        Extract authentication info from the incoming A2A request.
        
        Looks for auth in multiple places:
        - request_context.message.metadata.auth
        - request_context.message.params.auth
        - HTTP headers passed through the request
        
        Returns:
            dict with keys: token/auth_token, session_id — or None if no auth found.
        """
        try:
            msg = getattr(request_context, "message", None)
            if msg is None:
                return None
            
            # Try metadata first
            meta = getattr(msg, "metadata", None)
            if isinstance(meta, dict):
                auth = meta.get("auth") or meta.get("authorization")
                if auth and isinstance(auth, dict):
                    return auth
            
            # Try params
            params = getattr(msg, "params", None)
            if isinstance(params, dict):
                auth = params.get("auth") or params.get("authorization")
                if auth and isinstance(auth, dict):
                    return auth
            
            # Try extracting from parts/content if structured
            parts = getattr(msg, "parts", None)
            if parts and isinstance(parts, list):
                for part in parts:
                    if hasattr(part, "metadata") and isinstance(part.metadata, dict):
                        part_auth = part.metadata.get("auth")
                        if part_auth and isinstance(part_auth, dict):
                            return part_auth
            
            # Try direct attributes on message
            auth_from_attrs = {}
            if hasattr(msg, "auth_token") and msg.auth_token:
                auth_from_attrs["auth_token"] = msg.auth_token
            if hasattr(msg, "session_id") and msg.session_id:
                auth_from_attrs["session_id"] = msg.session_id
            if auth_from_attrs:
                return auth_from_attrs
                
        except Exception as e:
            print(f"⚠️ Error extracting auth: {e}")
        
        # Explicitly return None — NOT an empty dict — so callers can detect missing auth
        return None
        
    async def execute(
        self, 
        request_context: RequestContext, 
        event_queue: EventQueue
    ) -> str:
        """
        Execute the agent with the user's query.
        
        Args:
            request_context: Contains the user input and task info
            event_queue: Queue for sending status updates
            
        Returns:
            Final response string from the agent
        """
        query = request_context.get_user_input()
        auth = self._extract_auth(request_context)
        if auth:
            print(f"🔐 Auth: session_id={str(auth.get('session_id', ''))[:20]}... token=<present>")
        else:
            print(f"🔐 Auth: No auth found")
        # ── Auth guard ────────────────────────────────────────────────────────
        # Reject any request that arrives without a token AND session_id.
        # This prevents the agent from falling back to the last caller's stale
        # credentials stored in _current_auth / _last_auth_signature.
        missing = []
        if not auth:
            missing = ["token", "session_id"]
        else:
            token_val = auth.get("token") or auth.get("auth_token") or auth.get("authorization")
            session_val = auth.get("session_id") or auth.get("session")
            if not token_val:
                missing.append("token")
            if not session_val:
                missing.append("session_id")

        if missing:
            session_val_dbg = auth.get("session_id") or auth.get("session") if auth else None
            token_val_dbg = auth.get("token") or auth.get("auth_token") or auth.get("authorization") if auth else None
            print(f"🔍 [Auth Debug] session_id={session_val_dbg!r} | auth_token={token_val_dbg!r}")
            print(f"🚫 Request rejected — missing auth fields: {missing}")
            task = request_context.current_task
            if not task:
                task = new_task(request_context.message)
                await event_queue.enqueue_event(task)
            updater = TaskUpdater(event_queue, task.id, task.context_id)
            await updater.update_status(
                TaskState.failed,
                new_agent_text_message(
                    f"Authentication required: missing {', '.join(missing)}. "
                    "Please provide a valid 'token' and 'session_id' in the request metadata.",
                    task.context_id,
                    task.id,
                )
            )
            return
        # ─────────────────────────────────────────────────────────────────────
        
        print(f"🔐 Auth extracted: session_id={str(auth.get('session_id', ''))[:20]}... token=<present>")
        
        # Get or create task
        task = request_context.current_task
        if not task:
            task = new_task(request_context.message)
            await event_queue.enqueue_event(task)
        
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        
        try:
            # Invoke agent with auth for MCP tool authentication
            final_result = None
            
            async for item in self.agent.invoke(
                query=query,
                session_id=task.context_id,
                auth=auth
            ):
                is_task_complete = item.get("is_task_complete", False)
                
                if not is_task_complete:
                    message = item.get("updates", "Processing your request...")
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(message, task.context_id, task.id)
                    )
                else:
                    final_result = item.get("content", "")
                    
                    # Debug: print what we got
                    print(f"📤 Final result received: {final_result[:100] if final_result else 'EMPTY'}...")
                    
                    if not final_result:
                        final_result = "I processed your request but no text response was generated."
                    
                    await updater.update_status(
                        TaskState.completed,
                        new_agent_text_message(final_result, task.context_id, task.id)
                    )
                    return final_result
                
                await asyncio.sleep(0.1)
            
            # If we exit the loop without returning, something went wrong
            if final_result is None:
                final_result = "Agent completed but no response was captured."
                await updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(final_result, task.context_id, task.id)
                )
                return final_result
                
        except Exception as e:
            error_message = f"Error during agent execution: {e}"
            print(f"❌ {error_message}")
            await updater.update_status(
                TaskState.failed,
                new_agent_text_message(error_message, task.context_id, task.id)
            )
            raise
        
    async def cancel(self):
        """Handle cleanup when execution is cancelled."""
        try:
            if hasattr(self.agent, "shutdown"):
                await self.agent.shutdown()
        except Exception as e:
            print(f"⚠️ Error during cancel: {e}")