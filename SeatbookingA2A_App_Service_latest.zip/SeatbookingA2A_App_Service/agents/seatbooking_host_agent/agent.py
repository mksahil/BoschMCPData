"""
Host Agent - Fixed to avoid MCP session issues
"""

import os 
from utilities.common.file_loader import load_instruction_file
from google.adk.agents import LlmAgent
from google.adk import Runner
from google.adk.artifacts import InMemoryArtifactService
from google.adk.sessions import InMemorySessionService
from google.adk.memory import InMemoryMemoryService
from google.adk.tools.function_tool import FunctionTool
from collections.abc import AsyncIterable
from google.genai import types
from utilities.mcp import mcp_connect
from utilities.a2a import agent_discovery, agent_connector
from dotenv import load_dotenv
from a2a.types import AgentCard
from uuid import uuid4
# from google.adk.models.lite_llm import LiteLlm


load_dotenv()

# Azure settings from env
# AZURE_API_KEY = os.getenv("AZURE_API_KEY")
# AZURE_API_BASE= os.getenv("AZURE_API_BASE")
# AZURE_API_VERSION = os.getenv("AZURE_API_VERSION")


# os.environ["AZURE_API_KEY"] = AZURE_API_KEY
# os.environ["AZURE_API_BASE"] = AZURE_API_BASE
# os.environ["AZURE_API_VERSION"] = AZURE_API_VERSION

        

class HostAgent:
    """
    Orchestrator agent.
    """
    
    def __init__(self):
        file_path = os.path.dirname(__file__)
        self.SYSTEM_INSTRUCTION = load_instruction_file(file_path + "/instructions.txt")
        self.DESCRIPTION = load_instruction_file(file_path + "/description.txt")
        
        self.mcp_connector = mcp_connect.MCPConnector()
        self.agent_discovery = agent_discovery.AgentDiscovery()
        self._mcp_tools_loaded = False
        self._last_auth_signature: tuple[str | None, str | None] | None = None
        self._current_auth: dict | None = None
    
    async def create(self):
        self.agent = await self.build_agent(mcp_tools=[])
        self.user_id = "host_agent"
        self.runner = Runner(
            app_name=self.agent.name,
            agent=self.agent,
            artifact_service=InMemoryArtifactService(),
            session_service=InMemorySessionService(),
            memory_service=InMemoryMemoryService()
        )
        self._mcp_tools_loaded = True

    async def shutdown(self) -> None:
        """Shutdown the host agent and cleanup resources."""
        try:
            if hasattr(self.mcp_connector, "close_all"):
                await self.mcp_connector.close_all()
        except Exception as e:
            print(f"Warning: error during HostAgent.shutdown: {e}")
    
    async def list_agents(self) -> list[AgentCard]:
        """A2A tool: return the list of agent cards."""
        cards: list[AgentCard] = await self.agent_discovery.list_agent_cards()
        cards_info = [card.model_dump(exclude_none=True)['name'] for card in cards]
        print("🌴🌴🌴 Identified agent cards:", cards_info)
        return [card.model_dump(exclude_none=True) for card in cards]
    
    async def delegate_task(self, agent_name: str, message: str) -> str:
        """Delegate a message to another A2A agent identified by name."""
        cards: list[AgentCard] = await self.agent_discovery.list_agent_cards()

        matched_card = None
        for card in cards:
            if card.name.lower() == agent_name.lower():
                matched_card = card
                break

        if matched_card is None:
            return "Agent not found"

        connector = agent_connector.AgentConnector(matched_card)
        used_auth = getattr(self, "_current_auth", {}) or {}
        session_id = used_auth.get("session_id") or str(uuid4())
        return await connector.send_task(message=message, session_id=session_id, auth=used_auth)
        
    async def build_agent(self, mcp_tools: list | None = None) -> LlmAgent:
        if mcp_tools is None:
            mcp_tools = await self.mcp_connector.get_tools()
        await self.list_agents()
        tools = self._compose_tool_list(mcp_tools)
        
        return LlmAgent(
            name="HostAgent",
            model='gemini-2.5-flash',#LiteLlm(model="azure/gpt-4o-mini")
            instruction=self.SYSTEM_INSTRUCTION,
            description=self.DESCRIPTION,
            tools=tools
        )
    
    def _compose_tool_list(self, mcp_tools: list) -> list:
        """Always include built-in orchestration tools."""
        return [
            FunctionTool(self.delegate_task),
            FunctionTool(self.list_agents),
            *mcp_tools
        ]
    
    def _auth_signature(self, auth: dict | None) -> tuple[str | None, str | None] | None:
        if not auth:
            return None
        token = auth.get("token") or auth.get("auth_token") or auth.get("authorization")
        session = auth.get("session_id") or auth.get("session")
        token = token.strip() if isinstance(token, str) else token
        session = session.strip() if isinstance(session, str) else session
        return (token, session)
    
    async def _ensure_mcp_tools(self, auth: dict | None) -> None:
        """
        Ensure MCP connections are initialized with the latest request auth.
        Reloads toolsets when the token/session combo changes.

        Raises:
            ValueError: if auth is None or missing required token/session_id fields.
        """
        auth_sig = self._auth_signature(auth)

        # Hard fail — do NOT silently return and let the caller keep the stale session.
        if not auth_sig or not auth_sig[0] or not auth_sig[1]:
            raise ValueError(
                "MCP tools require a valid 'token' and 'session_id' in the auth payload. "
                "Request is missing one or both values."
            )
        
        if self._mcp_tools_loaded and auth_sig == self._last_auth_signature:
            # Same credentials — reuse cached toolset for efficiency.
            return
        
        force_reload = self._mcp_tools_loaded
        tools = await self.mcp_connector.get_tools(
            auth=auth,
            force_reload=force_reload
        )
        print(
            f"🔄 Refreshed MCP tools with auth "
            f"(token={'present' if auth_sig[0] else 'missing'}, "
            f"session={'present' if auth_sig[1] else 'missing'})"
        )
        self.agent.tools = self._compose_tool_list(tools)
        if hasattr(self, "runner"):
            self.runner.agent = self.agent
        self._mcp_tools_loaded = True
        self._last_auth_signature = auth_sig
    
    def _extract_text_from_event(self, event) -> str:
        """Extract text content from an ADK event."""
        if not event.content or not event.content.parts:
            return ""
        
        text_parts = []
        for part in event.content.parts:
            if hasattr(part, 'text') and part.text:
                text_parts.append(str(part.text))
            elif isinstance(part, str):
                text_parts.append(part)
        
        return "\n".join(text_parts)
        
    async def invoke(self, query: str, session_id: str = None, auth=None) -> AsyncIterable[dict]:
        """
        Invoke the agent with the given query.
        
        Auth is validated and stored for each individual request.
        Raises ValueError if auth is absent or incomplete, which the executor
        catches and converts into a TaskState.failed response.
        """
        # Always reset _current_auth to the current request's auth.
        # NEVER leave a stale value from a previous request.
        self._current_auth = auth if auth else {}
        await self._ensure_mcp_tools(self._current_auth or None)

        # Get or create session
        session = await self.runner.session_service.get_session(
            app_name=self.agent.name,
            user_id=self.user_id,
            session_id=session_id
        )
        
        if not session:
            session = await self.runner.session_service.create_session(
                app_name=self.agent.name,
                user_id=self.user_id,
                session_id=session_id
            )
        
        user_content = types.Content(
            role="user",
            parts=[types.Part.from_text(text=query)]
        )
        
        final_response = ""
        
        try:
            async for event in self.runner.run_async(
                user_id=self.user_id,
                session_id=session_id,
                new_message=user_content
            ):
                if event.is_final_response():
                    final_response = self._extract_text_from_event(event)
                    
                    if not final_response:
                        final_response = "I processed your request."
                    
                    print(f"📦 Final result received: {final_response[:100]}...")
                    
                    yield {
                        "is_task_complete": True,
                        "content": final_response
                    }
                else:
                    update_text = self._extract_text_from_event(event)
                    yield {
                        "is_task_complete": False,
                        "updates": update_text or "Processing..."
                    }
        except Exception as e:
            print(f"❌ Error in invoke: {e}")
            import traceback
            traceback.print_exc()
            yield {
                "is_task_complete": True,
                "content": f"Error processing request: {str(e)}"
            }