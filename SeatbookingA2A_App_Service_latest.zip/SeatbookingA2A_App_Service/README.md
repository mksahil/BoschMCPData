## MCP + A2A Agentic AI for Travel usecase

- create Travel_host agent (http://localhost:8080)
- create one mcp server (Travel Fast API Endpoint) (http://localhost:10000)
- create a command interaction program to send message to the host agent and get response
- Create a simple UI (streamlit) to send message to the host agent and get response

## How to Run

1. Ensure your machine installs uv
2. Open project in VSCode. Switch the project root path as current working path
3. Type "uv sync"
4. Type "source .venv/bin/activate"
5. Input GOOGLE_API_KEY to .env file (Acquire key from https://aistudio.google.com/apikey, other settings could keep unchanged)<br>


6. Type "make run-all" to start all the programs.


## TODO:

- wrap them in containers and deploy
