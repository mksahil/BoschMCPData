import os
import uuid

import httpx
from a2a.client import A2ACardResolver, A2AClient
from a2a.types import (
    AgentCard,
    Message,
    MessageSendParams,
    Part,
    Role,
    SendMessageRequest,
    TextPart,
)

PUBLIC_AGENT_CARD_PATH = "/.well-known/agent.json"


# BASE_URL = "https://bshtravela2aagent.politesand-fec4ae6b.centralindia.azurecontainerapps.io"
# BASE_URL = "http://localhost:10000"

BASE_URL = "https://seatbookingagent.thankfulground-23b51839.centralindia.azurecontainerapps.io"

SESSION_ID = "0ade26c3-5f4a-425c-85f7-18035c78dabb"
AUTH_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJWYVBaSzJYZmtUcmFqU0J6bTl2c2ZnPT0iLCJhdWQiOlsicEplZGJ3YTJkRkNKNUNLNXpnRjl5MWdZcUNDZkI4bU1YNjYveXMyZGpKYXp3Zlk4L0o3V0IzYUxJOGFESWkySSIsInBKZWRid2EyZEZDSjVDSzV6Z0Y5eTFnWXFDQ2ZCOG1NWDY2L3lzMmRqSmF6d2ZZOC9KN1dCM2FMSThhRElpMkkiXSwibmFtZSI6InZTOVQ2alVyU2RrSHF0WlM0NFFVL1FrZmlVa25POUVNbUdldU95c2VmMW89IiwiZ2l2ZW5fbmFtZSI6IkdaWGxSeWZPMi9wMEVNN1dGNnpMYmM3SU11dG1zcFFyT3cwY2ZLalpVcTQ9IiwiaWF0IjoxNzYzNjIwMTE2LCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL2V4cGlyYXRpb24iOiIxMi8yMS8yMDI1IDY6Mjg6MzYgQU0iLCJleHAiOjE3NjYyOTg1MTZ9.PW19glLgmxVkBPP3ytY-wnZ-6xS2XzTqj05RNaAxwpAFuhXuM-eCCuppV2zv88nZ_Wji5cFTzulpZYoNKKchn1lF78QfUZwMHLBNpkwllprHXzUZc3jGax4866AIzSiDvvmnrufS2NvdMpfuqKeKoyO8DGbfbZnwXyIa9kitq_KpNRjCP9vzFrzFLoqgmq4mn25Ae0oeb5tNQZIwwz8ePi5aAm_WrTlOJh6OvVP3Z5RXc5uCynU7NbpXFZziNpZcgJX8gdzes2OeyVtX80-UzJEUyKXDGBH70WLXQDIReeXQNXQsW5_-LdkOsD5E7XYctEKTqlzN_ZyYpkhJmdoXkA"




HTTP_TIMEOUT = httpx.Timeout(300.0)


async def main() -> None:
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as httpx_client:
        # Initialize A2ACardResolver
        resolver = A2ACardResolver(
            httpx_client=httpx_client,
            base_url=BASE_URL,
        )

        final_agent_card_to_use: AgentCard | None = None

        try:
            print(
                f"Fetching public agent card from: {BASE_URL}{PUBLIC_AGENT_CARD_PATH}"
            )
            _public_card = await resolver.get_agent_card()
            print("Fetched public agent card")
            print(_public_card.model_dump_json(indent=2))

            final_agent_card_to_use = _public_card
            final_agent_card_to_use = _public_card
            final_agent_card_to_use.url = BASE_URL   # ensure JSON-RPC posts hit localhost
            
            print(final_agent_card_to_use)
            

        except Exception as e:
            print(f"Error fetching public agent card: {e}")
            raise RuntimeError("Failed to fetch public agent card")

        client = A2AClient(
            httpx_client=httpx_client, agent_card=final_agent_card_to_use
        )
        print("A2AClient initialized")

        session_id = SESSION_ID
        message_metadata = None
        if AUTH_TOKEN and session_id:
            auth_payload = {"session_id": session_id}
            if AUTH_TOKEN:
                auth_payload["token"] = AUTH_TOKEN
            message_metadata = {"auth": auth_payload}

        message_payload = Message(
            role=Role.user,
            messageId=str(uuid.uuid4()),
            contextId=session_id,
            metadata=message_metadata,
            parts=[Part(root=TextPart(text="Hi. Book a seat"))],
        )
        request = SendMessageRequest(
            id=str(uuid.uuid4()),
            params=MessageSendParams(
                message=message_payload,
            ),
        )
        print("Sending message")

        response = await client.send_message(request)
        print("Response:")
        print(response.model_dump_json(indent=2))


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())