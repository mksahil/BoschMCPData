"""
Tests for auth enforcement in A2A agent.

Verifies:
1. _extract_auth() returns None (not {}) when auth is absent from metadata.
2. _auth_signature() correctly detects incomplete/missing auth.
3. _ensure_mcp_tools() raises ValueError instead of silently continuing.
4. execute() rejects requests missing token or session_id with TaskState.failed.
5. Stale auth from a prior request is NOT reused for a new unauthenticated request.
6. Streamlit UI guard logic blocks sends when fields are blank.

Run with: uv run pytest tests/test_auth_enforcement.py -v
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from agents.seatbooking_host_agent.agent_executor import HostAgentExecutor
from agents.seatbooking_host_agent.agent import HostAgent
from a2a.server.agent_execution import RequestContext
from a2a.server.events import EventQueue
from a2a.types import TaskState


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

class _FakeMessage:
    """Minimal message-like object that mimics a2a.types.Message for auth extraction."""
    def __init__(self, metadata):
        self.metadata = metadata
        self.params = None
        self.parts = []
        self.role = "user"
        self.messageId = "test-msg-id"
        self.contextId = "test-ctx-id"


def _make_context(metadata) -> MagicMock:
    """Build a RequestContext mock with a real _FakeMessage so attribute access works."""
    ctx = MagicMock(spec=RequestContext)
    ctx.message = _FakeMessage(metadata)
    ctx.current_task = None
    ctx.get_user_input.return_value = "Book a seat"
    return ctx


def _make_event_queue() -> MagicMock:
    queue = MagicMock(spec=EventQueue)
    queue.enqueue_event = AsyncMock()
    return queue


def _make_fake_task() -> MagicMock:
    task = MagicMock()
    task.id = "task-001"
    task.context_id = "ctx-001"
    return task


# ─────────────────────────────────────────────────────────────────────────────
# 1. _extract_auth unit tests
# ─────────────────────────────────────────────────────────────────────────────

class TestExtractAuth:
    def setup_method(self):
        self.executor = HostAgentExecutor.__new__(HostAgentExecutor)

    def test_returns_none_when_metadata_is_none(self):
        ctx = _make_context(metadata=None)
        assert self.executor._extract_auth(ctx) is None

    def test_returns_none_when_metadata_has_no_auth_key(self):
        ctx = _make_context(metadata={"other": "stuff"})
        assert self.executor._extract_auth(ctx) is None

    def test_returns_auth_dict_from_metadata(self):
        auth_data = {"token": "mytoken", "session_id": "sess-123"}
        ctx = _make_context(metadata={"auth": auth_data})
        assert self.executor._extract_auth(ctx) == auth_data

    def test_returns_none_when_auth_value_is_empty_dict(self):
        ctx = _make_context(metadata={"auth": {}})
        assert self.executor._extract_auth(ctx) is None

    def test_returns_none_when_metadata_is_empty_dict(self):
        """Regression: used to return {} — must now return None."""
        ctx = _make_context(metadata={})
        result = self.executor._extract_auth(ctx)
        assert result is None, f"Expected None, got {result!r}"

    def test_never_returns_empty_dict(self):
        """The stale-fallback bug was caused by returning {} which confused 'auth or {}'."""
        for meta in [None, {}, {"no_auth": True}]:
            ctx = _make_context(metadata=meta)
            result = self.executor._extract_auth(ctx)
            assert result != {}, f"Must not return empty dict for metadata={meta!r}"


# ─────────────────────────────────────────────────────────────────────────────
# 2. _auth_signature unit tests
# ─────────────────────────────────────────────────────────────────────────────

class TestAuthSignature:
    def setup_method(self):
        self.agent = HostAgent.__new__(HostAgent)

    def test_none_input(self):
        assert self.agent._auth_signature(None) is None

    def test_empty_dict(self):
        assert self.agent._auth_signature({}) is None

    def test_valid_auth(self):
        assert self.agent._auth_signature({"token": "tok", "session_id": "sid"}) == ("tok", "sid")

    def test_only_token(self):
        sig = self.agent._auth_signature({"token": "tok"})
        assert sig == ("tok", None)

    def test_only_session(self):
        sig = self.agent._auth_signature({"session_id": "sid"})
        assert sig == (None, "sid")


# ─────────────────────────────────────────────────────────────────────────────
# 3. _ensure_mcp_tools raises on bad auth
# ─────────────────────────────────────────────────────────────────────────────

class TestEnsureMcpTools:
    def setup_method(self):
        self.agent = HostAgent.__new__(HostAgent)
        self.agent._mcp_tools_loaded = False
        self.agent._last_auth_signature = None
        self.agent._current_auth = None

    @pytest.mark.asyncio
    async def test_raises_on_none_auth(self):
        with pytest.raises(ValueError):
            await self.agent._ensure_mcp_tools(None)

    @pytest.mark.asyncio
    async def test_raises_on_empty_dict(self):
        with pytest.raises(ValueError):
            await self.agent._ensure_mcp_tools({})

    @pytest.mark.asyncio
    async def test_raises_when_session_missing(self):
        with pytest.raises(ValueError):
            await self.agent._ensure_mcp_tools({"token": "tok"})

    @pytest.mark.asyncio
    async def test_raises_when_token_missing(self):
        with pytest.raises(ValueError):
            await self.agent._ensure_mcp_tools({"session_id": "sid"})


# ─────────────────────────────────────────────────────────────────────────────
# 4 & 5. execute() integration tests — auth guard + anti-stale-fallback
# ─────────────────────────────────────────────────────────────────────────────

def _make_executor_with_patches():
    """Return (executor, fake_task, patches_context) ready for use."""
    executor = HostAgentExecutor.__new__(HostAgentExecutor)
    executor.agent = MagicMock()
    executor.agent.invoke = AsyncMock()
    return executor


class TestExecuteAuthEnforcement:

    @pytest.mark.asyncio
    async def test_rejects_when_no_auth(self):
        """No metadata at all → immediate TaskState.failed, invoke never called."""
        executor = _make_executor_with_patches()
        ctx = _make_context(metadata=None)
        queue = _make_event_queue()
        fake_task = _make_fake_task()

        with patch("agents.seatbooking_host_agent.agent_executor.new_task",
                   return_value=fake_task) as mock_new_task, \
             patch("agents.seatbooking_host_agent.agent_executor.TaskUpdater") as MockUpdater:

            updater_inst = AsyncMock()
            MockUpdater.return_value = updater_inst

            await executor.execute(ctx, queue)

            # Auth guard must have fired
            updater_inst.update_status.assert_called_once()
            status_arg = updater_inst.update_status.call_args[0][0]
            assert status_arg == TaskState.failed, f"Expected failed, got {status_arg}"

            # invoke() must NOT have been called
            executor.agent.invoke.assert_not_called()

    @pytest.mark.asyncio
    async def test_rejects_when_token_missing(self):
        """session_id present but token absent → reject."""
        executor = _make_executor_with_patches()
        ctx = _make_context(metadata={"auth": {"session_id": "sid-123"}})
        queue = _make_event_queue()
        fake_task = _make_fake_task()

        with patch("agents.seatbooking_host_agent.agent_executor.new_task",
                   return_value=fake_task), \
             patch("agents.seatbooking_host_agent.agent_executor.TaskUpdater") as MockUpdater:

            updater_inst = AsyncMock()
            MockUpdater.return_value = updater_inst

            await executor.execute(ctx, queue)

            status_arg = updater_inst.update_status.call_args[0][0]
            assert status_arg == TaskState.failed

            # Failure message should mention 'token'
            msg_arg = str(updater_inst.update_status.call_args)
            assert "token" in msg_arg.lower()

            executor.agent.invoke.assert_not_called()

    @pytest.mark.asyncio
    async def test_rejects_when_session_id_missing(self):
        """token present but session_id absent → reject."""
        executor = _make_executor_with_patches()
        ctx = _make_context(metadata={"auth": {"token": "my-token"}})
        queue = _make_event_queue()
        fake_task = _make_fake_task()

        with patch("agents.seatbooking_host_agent.agent_executor.new_task",
                   return_value=fake_task), \
             patch("agents.seatbooking_host_agent.agent_executor.TaskUpdater") as MockUpdater:

            updater_inst = AsyncMock()
            MockUpdater.return_value = updater_inst

            await executor.execute(ctx, queue)

            status_arg = updater_inst.update_status.call_args[0][0]
            assert status_arg == TaskState.failed

            msg_arg = str(updater_inst.update_status.call_args)
            assert "session_id" in msg_arg.lower()

            executor.agent.invoke.assert_not_called()

    @pytest.mark.asyncio
    async def test_stale_auth_not_reused(self):
        """
        KEY REGRESSION: stale _current_auth from a previous call must NOT
        be used for a new request that arrives without any auth metadata.
        """
        executor = _make_executor_with_patches()

        # Pre-load stale state as if a previous authenticated request ran
        executor._current_auth = {"token": "old-tok", "session_id": "old-sid"}

        ctx = _make_context(metadata=None)   # New request — NO auth
        queue = _make_event_queue()
        fake_task = _make_fake_task()

        with patch("agents.seatbooking_host_agent.agent_executor.new_task",
                   return_value=fake_task), \
             patch("agents.seatbooking_host_agent.agent_executor.TaskUpdater") as MockUpdater:

            updater_inst = AsyncMock()
            MockUpdater.return_value = updater_inst

            await executor.execute(ctx, queue)

            # Must still be rejected — stale auth must not be consulted
            status_arg = updater_inst.update_status.call_args[0][0]
            assert status_arg == TaskState.failed, \
                "Stale _current_auth must not allow an unauthenticated request through"
            executor.agent.invoke.assert_not_called()


# ─────────────────────────────────────────────────────────────────────────────
# 6. Streamlit UI auth guard logic (no Streamlit runtime needed)
# ─────────────────────────────────────────────────────────────────────────────

class TestUIAuthGuard:
    """Directly tests the guard logic extracted from chat_ai.py."""

    @staticmethod
    def _missing_for(token: str, session: str) -> list[str]:
        """Mirror the guard logic from chat_ai.py."""
        missing = []
        if not token:
            missing.append("Auth Token")
        if not session:
            missing.append("Session ID")
        return missing

    def test_both_blank(self):
        assert self._missing_for("", "") == ["Auth Token", "Session ID"]

    def test_only_token_blank(self):
        assert self._missing_for("", "sess-123") == ["Auth Token"]

    def test_only_session_blank(self):
        assert self._missing_for("mytoken", "") == ["Session ID"]

    def test_both_provided(self):
        assert self._missing_for("mytoken", "sess-123") == []

    def test_whitespace_only_counts_as_blank(self):
        token = "   ".strip()
        session = "\t".strip()
        assert self._missing_for(token, session) == ["Auth Token", "Session ID"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
