import os
from dotenv import load_dotenv

# Load environment variables from .env into os.environ
load_dotenv()

class Config:
    GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
    HOST_AGENT_PORT: int = os.getenv("HOST_AGENT_PORT", 8080)
    # POST_DESIGN_AGENT_PORT: int = os.getenv("POST_DESIGN_AGENT_PORT", 10000)
    SEATBOOKING_MCP_SERVER_PORT: int = os.getenv("SEATBOOKING_MCP_SERVER_PORT", 10001)
    TEST_MCP_SERVER_PORT: int = os.getenv("TEST_MCP_SERVER_PORT", 8000)
# You can create a global instance if you like
config = Config()
