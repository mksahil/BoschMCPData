"""
Agent Connector - Fixed with correct A2A types
"""

from a2a.client import A2AClient
from a2a.types import (
    AgentCard, 
    MessageSendParams,
    SendMessageRequest,
    SendStreamingMessageRequest,
    Message, 
    TextPart
)
from uuid import uuid4
import httpx


class AgentConnector:
    """
    Connects to an A2A agent and sends tasks with optional auth metadata.
    """
    
    def __init__(self, agent_card: AgentCard):
        self.agent_card = agent_card
        self.url = agent_card.url
    
    async def send_task(
        self, 
        message: str, 
        session_id: str, 
        auth: dict = None
    ) -> str:
        """
        Send a task to the agent with optional auth credentials.
        """
        async with httpx.AsyncClient(timeout=300) as httpx_client:
            client = A2AClient(
                httpx_client=httpx_client,
                agent_card=self.agent_card
            )
            
            message_id = uuid4().hex
            request_id = uuid4().hex
            text_part = TextPart(text=message)
            
            # Build metadata with auth if provided
            metadata = {"auth": auth} if auth else None
            
            # Create the message
            msg = Message(
                role="user",
                parts=[text_part],
                messageId=message_id,
                contextId=session_id,
                metadata=metadata
            )
            
            # Create params
            params = MessageSendParams(message=msg)
            
            # Create streaming request (correct type for streaming)
            streaming_request = SendStreamingMessageRequest(
                id=request_id,
                params=params
            )
            
            try:
                print(f"📤 Sending streaming message to agent...")
                
                content = ""
                async for event in client.send_message_streaming(streaming_request):
                    
                    # Get the result dict directly via model_dump
                    try:
                        event_data = event.model_dump()
                    except:
                        continue
                    
                    result_data = event_data.get('result')
                    if not result_data:
                        continue
                    
                    # Check for status-update with message
                    status = result_data.get('status')
                    if status:
                        message = status.get('message')
                        if message:
                            parts = message.get('parts', [])
                            for part in parts:
                                if part.get('kind') == 'text' and part.get('text'):
                                    content += part['text']
                    
                    # Check for artifacts
                    artifacts = result_data.get('artifacts')
                    if artifacts:
                        for artifact in artifacts:
                            parts = artifact.get('parts', [])
                            for part in parts:
                                if part.get('kind') == 'text' and part.get('text'):
                                    content += part['text']
                    
                    # Check if final
                    is_final = result_data.get('final', False)
                    if is_final and content:
                        print(f"✅ Got response: {content[:50]}...")
                        return content.strip()
                
                if content:
                    return content.strip()
                
                return "No response received from agent"
                
            except Exception as e:
                import traceback
                print(f"❌ Exception: {e}")
                traceback.print_exc()
                return f"Error: {str(e)}"
    
    def _extract_text(self, part) -> str:
        """Extract text from a message part."""
        if hasattr(part, 'text') and part.text:
            return str(part.text)
        if isinstance(part, dict) and 'text' in part:
            return str(part['text'])
        if isinstance(part, str):
            return part
        return ""
    
    async def send_task_sync(
        self, 
        message: str, 
        session_id: str, 
        auth: dict = None
    ) -> str:
        """
        Send a task using non-streaming endpoint (if streaming doesn't work).
        """
        async with httpx.AsyncClient(timeout=300) as httpx_client:
            client = A2AClient(
                httpx_client=httpx_client,
                agent_card=self.agent_card
            )
            
            message_id = uuid4().hex
            request_id = uuid4().hex
            text_part = TextPart(text=message)
            
            metadata = {"auth": auth} if auth else None
            
            msg = Message(
                role="user",
                parts=[text_part],
                messageId=message_id,
                contextId=session_id,
                metadata=metadata
            )
            
            params = MessageSendParams(message=msg)
            
            # Non-streaming request
            request = SendMessageRequest(
                id=request_id,
                params=params
            )
            
            try:
                print(f"📤 Sending sync message to agent...")
                response = await client.send_message(request)
                print(f"📨 Response: {type(response).__name__}")
                
                if hasattr(response, 'error') and response.error:
                    return f"Error: {response.error}"
                
                if hasattr(response, 'result') and response.result:
                    result = response.result
                    
                    # Extract from artifacts
                    if hasattr(result, 'artifacts') and result.artifacts:
                        texts = []
                        for artifact in result.artifacts:
                            for part in getattr(artifact, 'parts', []):
                                text = self._extract_text(part)
                                if text:
                                    texts.append(text)
                        if texts:
                            return "\n".join(texts)
                    
                    return str(result)
                
                return str(response)
                
            except Exception as e:
                import traceback
                traceback.print_exc()
                return f"Error: {str(e)}"