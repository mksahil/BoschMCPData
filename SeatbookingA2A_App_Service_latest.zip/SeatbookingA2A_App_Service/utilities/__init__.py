"""Utilities package for the mcp_a2a_agent_system project.

This file makes `utilities` a regular Python package so subpackages
like `utilities.a2a` and `utilities.mcp` can be imported reliably.
"""

__all__ = [
    # exported subpackages (imported lazily by users)
]
