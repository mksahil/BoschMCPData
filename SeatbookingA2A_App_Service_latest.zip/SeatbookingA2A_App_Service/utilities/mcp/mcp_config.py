{
    "mcpservers": {
        "Test_MCP": {
            "command": "streamable-http",
                "args": [
                "https://seatbookingmcp-hwehefc6ffhgf6fe.centralindia-01.azurewebsites.net/mcp"
            ]
        }
    }
}