"""
Seatbooking Agent MCP Server using FastMCP
Run with: fastmcp run seatbooking_agent_mcp_server.py --transport sse --port 8000
Or: python seatbooking_agent_mcp_server.py

Supports authentication via:
1. Tool arguments (session_id, auth_token)
2. Environment variables (SEATBOOKING_SESSION_ID, SEATBOOKING_AUTH_TOKEN)
3. HTTP headers when using SSE transport (X-Session-Id, Authorization)
"""

import httpx
import os
from fastmcp import FastMCP, Context
from fastmcp.server.dependencies import get_http_headers
from typing import Optional, Tuple

# Configuration
SEATBOOKING_API_URL = os.getenv("SEATBOOKING_API_URL", "https://bosch-chartbot.azurewebsites.net")

# Initialize FastMCP server
mcp = FastMCP(
    name="seatbooking-agent",
    instructions="""Seatbooking Agent assistant that helps with:
    1. Book a seat
    2. Cancel a booking
    3. Viewing Booking History
    """
)

# Default credentials (can be overridden per-request via tool arguments)
# DEFAULT_SESSION_ID = os.getenv("SEATBOOKING_SESSION_ID", "")
# DEFAULT_AUTH_TOKEN = os.getenv("SEATBOOKING_AUTH_TOKEN", "")


def _extract_auth_from_headers() -> Tuple[Optional[str], Optional[str]]:
    """
    Inspect the incoming HTTP headers for Authorization / Session identifiers.
    Returns: (token_without_bearer, session_id)
    """
    try:
        headers = get_http_headers()
    except RuntimeError:
        headers = {}
    
    auth_header = headers.get("authorization") or headers.get("Authorization")
    session_header = (
        headers.get("x-session-id")
        or headers.get("X-Session-Id")
        or headers.get("session-id")
        or headers.get("Session-Id")
        or headers.get("session_id")
        or headers.get("Session_id")
    )
    token = None
    if auth_header:
        token = auth_header.replace("Bearer", "", 1).strip()
    return token or None, session_header


async def call_seatbooking_api(
    message: str,
    files: list = [],
    session_id: str = None,
    auth_token: str = None
) -> dict:
    """Call the seatbooking AI API"""
    sid = session_id or ""
    token = auth_token or ""
    
    if not sid or not token:
        raise ValueError("Missing session_id or auth_token for Seatbooking API call.")
    
    async with httpx.AsyncClient(
        base_url=SEATBOOKING_API_URL,
        headers={
            "accept": "application/json",
            "Content-Type": "application/json",
            "Session_id": sid,
            "Authorization": f"Bearer {token}"
        },
        timeout=30.0
    ) as client:
        payload = {
            "EmployeeQueryMessage": message,
        }
        response = await client.post("/chat", json=payload)
        response.raise_for_status()
        return response.json()


@mcp.tool()
async def ask_seatbooking_agent(
    message: str,
    session_id: str = "",
    auth_token: str = "",
    files: list = [],
    ctx: Context | None = None
) -> str:
    """
    Ask the seatbooking agent a question or request about seatbooking.
    
    Can help with:
    1. Booking a seat
    2. Canceling a booking
    
    Args:
        message: Your question or request for the seatbooking agent
        session_id: Session ID for authentication (optional if set in env)
        auth_token: Bearer token for authentication (optional if set in env)
        files: Optional list of files to attach
    """
    try:
        header_token, header_session = _extract_auth_from_headers()
        final_session = session_id or header_session
        final_token = auth_token or header_token
        
        def _mask(value: str | None) -> str:
            if not value:
                return "missing"
            if len(value) <= 8:
                return value
            return f"{value[:4]}...{value[-4:]}"

        if ctx and ctx.request_context:
            ctx_session = getattr(ctx.request_context, "session_id", "n/a")
            print(f"🛰️ Incoming MCP ctx session={ctx_session!r}")

        print(
            "🔐 Seatbooking agent auth "
            f"(token={_mask(final_token)}, session={_mask(final_session)})"
        )
        
        if not final_session or not final_token:
            return "Authentication missing: provide session_id and auth_token (headers or arguments)."
        
        result = await call_seatbooking_api(
            message=message,
            files=files,
            session_id=final_session,
            auth_token=final_token
        )
        
        # print("MCP Seatbooking Agent Response: ", result)
        return f"Seatbooking Agent Response:\n{result.get('item', result)}"
    except httpx.HTTPStatusError as e:
        return f"API Error: {e.response.status_code} - {e.response.text}"
    except Exception as e:
        return f"Error: {str(e)}"



@mcp.tool()
async def get_seatbooking_help() -> str:
    """
    Get information about what the seatbooking agent can help with.
    No authentication required.
    """
    return """I can help you with:

1. **Booking a Seat**
2. **Canceling a Seat**
3. **Viewing Booking History**

"""

# Resource for server info
@mcp.resource("info://server")
def get_server_info() -> str:
    """Get server configuration info"""
    return f"""Seatbooking Agent MCP Server
API URL: {SEATBOOKING_API_URL}
"""


# if __name__ == "__main__":
#     import sys
    
#     # Get port from args or env
#     port = int(os.getenv("SEATBOOKING_AGENT_MCP_SERVER_PORT", "8080"))
#     if len(sys.argv) > 1:
#         try:
#             port = int(sys.argv[1])
#         except ValueError:
#             pass
    
#     print(f"🚀 Starting Seatbooking Agent MCP Server on port {port}")
#     print(f"   API URL: {SEATBOOKING_API_URL}")

    
#     # Run with SSE transport for HTTP access
#     mcp.run(transport="streamable-http", port=port)

if __name__ == "__main__":    
    mcp.run(transport="http", host="0.0.0.0", port=8000)