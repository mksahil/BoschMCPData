const axios = require('axios');
const https = require('https');
const { createOpenAIClient, getChatModelName } = require('./services/openai-client');
const configService = require('./services/config-service');
const boschAuthService = require('./services/bosch-auth-service');
const entryExitServiceV2 = require('./services/entry-exit-service-v2');

// Disable SSL verification for Azure APIs (Bosch self-signed cert)
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

/**
 * Build Authorization header object for MCP / chat endpoint calls.
 * @param {string|null} jwtToken - JWT from /Token/GenrateTokenDetails (no "Bearer" prefix)
 * @param {string|null} employeeNumber - X-Employee-Number header value
 */
function buildAuthHeaders(jwtToken, employeeNumber) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/event-stream'
  };
  if (employeeNumber) {
    headers['X-Employee-Number'] = employeeNumber;
  }
  if (jwtToken) {
    const raw = jwtToken.replace(/^Bearer\s+/i, '').trim();
    headers['Authorization'] = `Bearer ${raw}`;
    console.log('[EntryExit] Authorization header set (token prefix):', raw.substring(0, 20) + '...');
  } else {
    console.warn('[EntryExit] No JWT token — calling MCP endpoint without Authorization header');
  }
  return headers;
}

class EntryExitMCPV2Client {
  constructor() {
    // Use new deployed MCP server URLs
    this.mcpServerUrl = process.env.ENTRYEXIT_MCP_SERVER_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/mcp';
    this.chatEndpoint = process.env.ENTRYEXIT_CHAT_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/chat';
    this.defaultEmployeeNumber = process.env.DEFAULT_EMPLOYEE_NUMBER;
    this.sessionId = null;
    this.isInitialized = false;

    // Initialize OpenAI for local AI processing if chat endpoint fails
    this.openai = createOpenAIClient();

    // Available MCP tools as per the documentation
    this.availableTools = [
      'get_attendance_by_date',
      'get_attendance_range',
      'get_month_summary',
      'get_current_status',
      'get_raw_swipes',
      'get_employee_name'
    ];
  }

  /**
   * Parse SSE response from MCP server
   */
  parseSSEResponse(sseData) {
    const lines = sseData.split('\n');
    let result = null;

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          result = JSON.parse(line.substring(6));
        } catch (e) {
          console.log('Failed to parse SSE data line:', line);
        }
      }
    }

    return result;
  }

  /**
   * Initialize MCP session with the server.
   * @param {string|null} employeeNumber
   * @param {string|null} jwtToken - JWT from /Token/GenrateTokenDetails
   */
  async initializeSession(employeeNumber, jwtToken = null) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    try {
      console.log('Initializing MCP session...');

      const initPayload = {
        jsonrpc: "2.0",
        method: "initialize",
        params: {
          protocolVersion: "2024-11-05",
          capabilities: { tools: {} },
          clientInfo: { name: "mybgs-client", version: "1.0.0" }
        },
        id: 1
      };

      const response = await axios.post(
        this.mcpServerUrl,
        initPayload,
        {
          headers: buildAuthHeaders(jwtToken, empNumber),
          timeout: 45000, // 45s for Azure cold starts
          httpsAgent,
          transformResponse: [(data) => data] // Keep as raw string to parse SSE
        }
      );

      const result = this.parseSSEResponse(response.data);

      if (result && result.result) {
        // Extract session ID from response headers
        this.sessionId = response.headers['mcp-session-id'] || response.headers['x-mcp-session-id'];
        console.log('MCP Session initialized:', result.result.serverInfo);
        console.log('Session ID:', this.sessionId);
        this.isInitialized = true;
        return result;
      } else {
        throw new Error('Invalid initialization response');
      }
    } catch (error) {
      console.error('Error initializing MCP session:', error.message);
      throw error;
    }
  }

  /**
   * Call MCP tool using proper JSON-RPC protocol.
   * @param {string} toolName
   * @param {object} params
   * @param {string|null} employeeNumber
   * @param {string|null} jwtToken - JWT from /Token/GenrateTokenDetails for Authorization header
   */
  async callMCPToolWithProtocol(toolName, params, employeeNumber, jwtToken = null) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    // Initialize session if not done — pass JWT so the init request is also authenticated
    if (!this.isInitialized) {
      await this.initializeSession(empNumber, jwtToken);
    }

    const toolCallPayload = {
      jsonrpc: "2.0",
      method: "tools/call",
      params: {
        name: toolName,
        arguments: params || {}
      },
      id: Date.now()
    };

    const headers = buildAuthHeaders(jwtToken, empNumber);

    // Add MCP session ID if available
    if (this.sessionId) {
      headers['Mcp-Session-Id'] = this.sessionId;
    }

    try {
      console.log(`Calling MCP tool: ${toolName} with params:`, params);
      console.log(`[EntryExit] MCP call auth token present: ${!!jwtToken}`);

      const response = await axios.post(
        this.mcpServerUrl,
        toolCallPayload,
        {
          headers,
          timeout: 30000,   // 30 s — matches chat-endpoint timeout; allows for cold-start
          httpsAgent,
          transformResponse: [(data) => data]
        }
      );

      const result = this.parseSSEResponse(response.data);

      if (result && result.result) {
        console.log('MCP tool result:', result.result);
        return result.result;
      } else if (result && result.error) {
        const msg = result.error.message || 'MCP tool call failed';
        const err = new Error(msg);
        if (/unauthorized|authentication|invalid.?token|access.?denied|forbidden/i.test(msg)) {
          err.isAuthFailure = true;
        }
        throw err;
      }

      return result;
    } catch (error) {
      console.error(`Error calling MCP tool ${toolName}:`, error.message);

      // Mark HTTP 401 responses as auth failures so callers can refresh tokens
      if (error.response?.status === 401 || error.response?.status === 403) {
        error.isAuthFailure = true;
      }

      // Reset MCP session on error so the next call re-initializes cleanly
      this.isInitialized = false;
      this.sessionId = null;

      throw error;
    }
  }

  /**
   * Privacy check — delegates to the canonical classifyPrivacy() in EntryExitServiceV2.
   * Uses LLM few-shot classification (admin-configurable via the Few-Shot AI tab) as
   * the primary signal, then falls back to the deterministic regex implementation
   * (Patterns A–E) if the LLM call fails.
   *
   * Returns true  → query is about another person (block)
   *         false → query is about the logged-in user (allow)
   */
  async isQueryAboutOtherPerson(query, loggedInUserName) {
    return entryExitServiceV2.classifyPrivacy(query, loggedInUserName);
  }

  /**
   * Returns true when the query should bypass the Azure chat endpoint and use
   * direct MCP tool calls instead.
   *
   * The chat endpoint has its own LLM that tends to summarise multi-month or
   * explicit "details" queries rather than showing every day.  Routing these
   * through our own tool-calling path lets us control the formatting prompt.
   *
   * Triggers:
   *   1. Two or more distinct calendar months are mentioned ("jan, feb and march")
   *   2. An explicit completeness keyword is present ("all", "full", "day-wise", …)
   */
  isDetailOrMultiMonthQuery(query) {
    const q = query.toLowerCase();

    // ── Multi-month detection ────────────────────────────────────────────────
    // Collapse short-form and long-form month names to their 3-letter key so
    // "january" and "jan" both count as one unique month mention.
    const monthAliases = [
      'january', 'jan', 'february', 'feb', 'march', 'mar',
      'april', 'apr', 'may', 'june', 'jun', 'july', 'jul',
      'august', 'aug', 'september', 'sep', 'sept',
      'october', 'oct', 'november', 'nov', 'december', 'dec'
    ];
    const monthTo3 = {
      january: 'jan', jan: 'jan', february: 'feb', feb: 'feb',
      march: 'mar', mar: 'mar', april: 'apr', apr: 'apr', may: 'may',
      june: 'jun', jun: 'jun', july: 'jul', jul: 'jul',
      august: 'aug', aug: 'aug', september: 'sep', sep: 'sep', sept: 'sep',
      october: 'oct', oct: 'oct', november: 'nov', nov: 'nov',
      december: 'dec', dec: 'dec'
    };
    const uniqueMonths = new Set(
      monthAliases.filter(m => q.includes(m)).map(m => monthTo3[m])
    );
    if (uniqueMonths.size >= 2) {
      console.log(`[EntryExit] Multi-month query detected (${[...uniqueMonths].join(', ')}) — routing to direct tools`);
      return true;
    }

    // ── Explicit completeness / detail request ───────────────────────────────
    if (/\b(all|complete|full|every|each|day[\s-]?wise|daily|details?|complete\s+details?|full\s+details?)\b/.test(q)) {
      console.log('[EntryExit] Detail-request keyword detected — routing to direct tools');
      return true;
    }

    return false;
  }

  /**
   * Process a natural-language entry/exit query using the chat endpoint, with
   * JWT auth passed through to every MCP / chat call.
   * @param {string} query
   * @param {string|null} employeeNumber
   * @param {string|null} userName
   * @param {string|null} jwtToken - JWT from /Token/GenrateTokenDetails
   * @param {string|null} authToken - OAuth Bearer token (used to refresh JWT on auth failure)
   */
  async processQueryWithAI(query, employeeNumber = null, userName = null, jwtToken = null, authToken = null) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;
    const lowerQuery = query.toLowerCase();
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/;

    // Privacy check: LLM few-shot classifier (falls back to regex if LLM fails)
    if (await this.isQueryAboutOtherPerson(query, userName)) {
      console.log('[EntryExit] Privacy check: Blocking query about colleague data');
      return {
        success: false,
        response: "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.",
        employeeNumber: empNumber,
        method: 'privacy-blocked'
      };
    }

    if (identityPattern.test(lowerQuery)) {
      console.log('Identity query detected, bypassing chat endpoint');
      return await this.processIdentityQuery(empNumber, jwtToken);
    }

    // Multi-month queries ("jan, feb and march") and explicit detail requests
    // ("day-wise", "all", "complete") are routed directly to MCP tools so we
    // can show every record.  The Azure chat endpoint has its own LLM that
    // summarises these queries instead of listing each day.
    if (this.isDetailOrMultiMonthQuery(query)) {
      return await this.processQueryWithTools(query, empNumber, jwtToken);
    }

    // Inner helper: run the actual chat-endpoint call with whichever JWT is current
    const runChatRequest = async (activeJwt) => {
      console.log(`Processing AI-powered entry/exit query for employee ${empNumber}: ${query}`);
      console.log(`[EntryExit] Chat endpoint auth token present: ${!!activeJwt}`);

      const response = await axios.post(
        this.chatEndpoint,
        { question: query },
        {
          headers: buildAuthHeaders(activeJwt, empNumber),
          timeout: 30000,
          httpsAgent
        }
      );

      if (response.data && response.data.answer) {
        return {
          success: true,
          response: response.data.answer,
          employeeNumber: empNumber,
          method: 'ai-chat'
        };
      }
      throw new Error('Invalid response from chat endpoint');
    };

    try {
      return await runChatRequest(jwtToken);
    } catch (error) {
      console.error('Error calling chat endpoint:', error.message);

      // Detect HTTP 401 / 403 or explicit auth error messages
      const isAuthError = error.response?.status === 401
        || error.response?.status === 403
        || /unauthorized|invalid.?token|access.?denied|forbidden|authentication/i.test(error.message);

      if (isAuthError && authToken) {
        console.warn('[EntryExit] ⚠️ Auth failure on chat endpoint — clearing session and retrying with fresh JWT');
        boschAuthService.clearUserSession(empNumber);
        // Reset MCP session so the next MCP call re-initializes with the fresh token
        this.isInitialized = false;
        this.sessionId = null;

        try {
          const freshTokens = await boschAuthService.storeUserTokens(empNumber, authToken);
          const freshJwt = freshTokens.jwtToken;
          console.log('[EntryExit] 🔄 Retrying chat endpoint with fresh JWT');
          return await runChatRequest(freshJwt);
        } catch (retryErr) {
          console.error('[EntryExit] Retry with fresh JWT also failed:', retryErr.message);
          // Fall through to tool-based fallback
        }
      }

      // Fallback to direct tool calling — pass JWT through
      console.log('Falling back to direct tool calling...');
      return await this.processQueryWithTools(query, empNumber, jwtToken);
    }
  }

  /**
   * Directly resolve identity queries to avoid chat endpoint refusals.
   * @param {string} employeeNumber
   * @param {string|null} jwtToken
   */
  async processIdentityQuery(employeeNumber, jwtToken = null) {
    try {
      const toolResult = await this.callMCPTool('get_employee_name', {}, employeeNumber, jwtToken);
      const formattedResponse = this.basicFormatResponse(toolResult, 'get_employee_name');
      return {
        success: true,
        response: formattedResponse,
        employeeNumber,
        method: 'direct-tools',
        tool: 'get_employee_name'
      };
    } catch (error) {
      console.error('Error resolving employee name:', error);
      return {
        success: false,
        response: "I'm having trouble accessing your profile information. Please try again later.",
        error: error.message,
        method: 'error'
      };
    }
  }

  /**
   * Process query by analyzing intent and calling appropriate MCP tools directly.
   * This is a fallback when the chat endpoint is unavailable.
   * @param {string} query
   * @param {string|null} employeeNumber
   * @param {string|null} jwtToken
   */
  async processQueryWithTools(query, employeeNumber, jwtToken = null) {
    const empNumber = employeeNumber || this.defaultEmployeeNumber;

    try {
      // Use OpenAI to determine which tool to call
      const toolDecision = await this.determineToolToCall(query);

      if (!toolDecision.tool) {
        return {
          success: false,
          response: "I couldn't understand your attendance query. Please try asking about specific dates, ranges, or monthly summaries.",
          method: 'tool-selection-failed'
        };
      }

      // Normalize params to fix any freeform month/date strings from GPT
      const normalizedParams = this.normalizeParams(toolDecision.tool, toolDecision.params, query);

      // Call the appropriate MCP tool — pass JWT through
      const toolResult = await this.callMCPTool(toolDecision.tool, normalizedParams, empNumber, jwtToken);

      // Format the response using AI
      const formattedResponse = await this.formatResponseWithAI(query, toolResult, toolDecision.tool);

      return {
        success: true,
        response: formattedResponse,
        employeeNumber: empNumber,
        method: 'direct-tools',
        tool: toolDecision.tool
      };

    } catch (error) {
      console.error('Error in tool-based processing:', error);
      return {
        success: false,
        response: "I'm having trouble accessing your attendance information. Please try again later.",
        error: error.message,
        method: 'error'
      };
    }
  }

  /**
   * Normalize tool params to ensure correct date/month formats before calling MCP.
   * Handles cases where GPT returns e.g. month: 'February 2026' instead of '2026-02'.
   */
  normalizeParams(toolName, params, originalQuery) {
    if (!params) return params;
    const normalized = { ...params };

    const monthMap = {
      january: '01', jan: '01', february: '02', feb: '02',
      march: '03', mar: '03', april: '04', apr: '04', may: '05',
      june: '06', jun: '06', july: '07', jul: '07', august: '08', aug: '08',
      september: '09', sep: '09', sept: '09', october: '10', oct: '10',
      november: '11', nov: '11', december: '12', dec: '12'
    };

    const toYYYYMM = (val) => {
      if (!val) return null;
      const s = String(val).trim();
      // Already correct: 2026-02
      if (/^\d{4}-\d{2}$/.test(s)) return s;
      // February 2026 or Feb 2026
      const m1 = s.match(/^([a-z]+)\s+(\d{4})$/i);
      if (m1 && monthMap[m1[1].toLowerCase()]) {
        return `${m1[2]}-${monthMap[m1[1].toLowerCase()]}`;
      }
      // 2026 February
      const m2 = s.match(/^(\d{4})\s+([a-z]+)$/i);
      if (m2 && monthMap[m2[2].toLowerCase()]) {
        return `${m2[1]}-${monthMap[m2[2].toLowerCase()]}`;
      }
      // Just month name: "February" → use current year
      if (monthMap[s.toLowerCase()]) {
        const yr = new Date().getFullYear();
        return `${yr}-${monthMap[s.toLowerCase()]}`;
      }
      // 02-2026 or 02/2026
      const m3 = s.match(/^(\d{2})[\-\/](\d{4})$/);
      if (m3) return `${m3[2]}-${m3[1]}`;
      return null;
    };

    const toYYYYMMDD = (val) => {
      if (!val) return null;
      const s = String(val).trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        // Validate: ensure components didn't overflow (e.g. Feb 29 in non-leap year)
        const [y, mo, d] = s.split('-').map(Number);
        const dateObj = new Date(y, mo - 1, d); // local constructor — no UTC overflow tricks
        if (dateObj.getFullYear() === y && dateObj.getMonth() === mo - 1 && dateObj.getDate() === d) {
          return s; // genuinely valid date
        }
        // Overflowed: clamp to real last day of that month
        const lastDay = new Date(y, mo, 0).getDate();
        const clamped = `${y}-${String(mo).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
        console.log(`[NormalizeParams] Clamped invalid date '${s}' → '${clamped}' (month only has ${lastDay} days)`);
        return clamped;
      }
      // Try JS Date parse for other formats
      const d = new Date(s);
      if (!isNaN(d.getTime())) {
        return d.toISOString().split('T')[0];
      }
      return null;
    };

    if (toolName === 'get_month_summary' && normalized.month) {
      const fixed = toYYYYMM(normalized.month);
      if (fixed) {
        console.log(`[NormalizeParams] month: '${normalized.month}' → '${fixed}'`);
        normalized.month = fixed;
      } else {
        // Fallback: extract from original query
        const fallback = this.extractMonth(originalQuery);
        if (fallback) normalized.month = fallback;
      }
    }

    if ((toolName === 'get_attendance_by_date' || toolName === 'get_raw_swipes') && normalized.date_str) {
      const fixed = toYYYYMMDD(normalized.date_str);
      if (fixed) {
        console.log(`[NormalizeParams] date_str: '${normalized.date_str}' → '${fixed}'`);
        normalized.date_str = fixed;
      }
    }

    if (toolName === 'get_attendance_range') {
      if (normalized.start_date) {
        const fixed = toYYYYMMDD(normalized.start_date);
        if (fixed) { console.log(`[NormalizeParams] start_date: '${normalized.start_date}' → '${fixed}'`); normalized.start_date = fixed; }
      }
      if (normalized.end_date) {
        const fixed = toYYYYMMDD(normalized.end_date);
        if (fixed) { console.log(`[NormalizeParams] end_date: '${normalized.end_date}' → '${fixed}'`); normalized.end_date = fixed; }
      }
    }

    return normalized;
  }

  /**
   * Use OpenAI to determine which MCP tool to call based on the query
   */
  async determineToolToCall(query) {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().toISOString().slice(0, 7);

    const systemPrompt = `You are an assistant that determines which attendance tool to call based on user queries.
Today's date is ${today}.

Available tools and their EXACT parameter schemas:
1. get_attendance_by_date - Get attendance for a specific date
   Parameters: { "date_str": "YYYY-MM-DD" } (required)
   
2. get_attendance_range - Get attendance for a date range
   Parameters: { "start_date": "YYYY-MM-DD", "end_date": "YYYY-MM-DD" } (both required)
   
3. get_month_summary - Get monthly attendance summary  
   Parameters: { "month": "YYYY-MM" } (required, e.g., "2025-01" for January 2025)
   
4. get_current_status - Get current check-in/out status
   Parameters: {} (no parameters needed)
   
5. get_raw_swipes - Get raw swipe events for a date
   Parameters: { "date_str": "YYYY-MM-DD" } (required)
   
6. get_employee_name - Get employee's name
   Parameters: {} (no parameters needed)

Routing Rules:
- For queries spanning MULTIPLE months (e.g., "jan, feb and march", "attendance for Q1", "January to March"), ALWAYS use get_attendance_range covering the full period (start_date = first day of earliest month, end_date = last day of latest month).
- For queries asking for day-wise details, "all", "complete", or "full" details of a single month, use get_attendance_range for that month's full date range.
- For queries asking for a summary of a single month (e.g., "monthly report for January", "how many days in February"), use get_month_summary.
- get_raw_swipes should only be used when the user explicitly asks for "raw swipes", "all swipes", or "swipe data" for a *specific date*. It should not be used for general monthly or range queries.

IMPORTANT: Use the EXACT parameter names shown above (date_str, start_date, end_date, month).
For "today", use date: ${today}
For "this month", use month: ${currentMonth}

Respond with a JSON object containing:
- tool: the tool name to call
- params: the parameters object with correct keys and values
- explanation: brief explanation of why this tool was chosen`;

    try {
      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        // temperature: 0.1, // GPT-5 only supports default temperature of 1.0
        response_format: { type: "json_object" }
      });

      const decision = JSON.parse(response.choices[0].message.content);
      console.log('Tool decision:', decision);
      return decision;

    } catch (error) {
      console.error('Error determining tool:', error);

      // Fallback to basic keyword matching
      return this.fallbackToolSelection(query);
    }
  }

  /**
   * Fallback tool selection using keyword matching
   * Uses correct parameter names as per MCP tool definitions
   */
  fallbackToolSelection(query) {
    const lowerQuery = query.toLowerCase();
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format

    if (lowerQuery.includes('current') || lowerQuery.includes('now') || lowerQuery.includes('checked in') || lowerQuery.includes('status')) {
      return { tool: 'get_current_status', params: {} };
    } else if (lowerQuery.includes('today') && !lowerQuery.match(/\b(all|every|each)\b/)) {
      return { tool: 'get_attendance_by_date', params: { date_str: today } };
    } else if (lowerQuery.includes('yesterday')) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_by_date', params: { date_str: yesterday } };
    } else if (lowerQuery.includes('month') || lowerQuery.includes('january') || lowerQuery.includes('february') ||
      lowerQuery.includes('march') || lowerQuery.includes('april') || lowerQuery.includes('may') ||
      lowerQuery.includes('june') || lowerQuery.includes('july') || lowerQuery.includes('august') ||
      lowerQuery.includes('september') || lowerQuery.includes('october') || lowerQuery.includes('november') ||
      lowerQuery.includes('december') ||
      lowerQuery.includes('jan') || lowerQuery.includes('feb') || lowerQuery.includes('mar') ||
      lowerQuery.includes('apr') || lowerQuery.includes('jun') || lowerQuery.includes('jul') ||
      lowerQuery.includes('aug') || lowerQuery.includes('sep') || lowerQuery.includes('oct') ||
      lowerQuery.includes('nov') || lowerQuery.includes('dec')) {
      const monthMatch = this.extractMonth(query);
      const targetMonth = monthMatch || currentMonth;

      // If user wants detail per day (entry/exit/swipe details), use range; otherwise use summary
      const wantsDetail = /\b(all|every|each|exact|detail|entry|exit|swipe|swiped|days|times)\b/i.test(lowerQuery);
      if (wantsDetail) {
        // Build full-month date range
        const [yr, mo] = targetMonth.split('-');
        const lastDay = new Date(parseInt(yr), parseInt(mo), 0).getDate();
        const startDate = `${yr}-${mo}-01`;
        const endDate = `${yr}-${mo}-${String(lastDay).padStart(2, '0')}`;
        return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: endDate } };
      }
      return { tool: 'get_month_summary', params: { month: targetMonth } };
    } else if (lowerQuery.includes('week')) {
      // Last 7 days
      const startDate = new Date(Date.now() - 6 * 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: today } };
    } else if (lowerQuery.match(/last\s+(\d+)\s+days/)) {
      const daysMatch = lowerQuery.match(/last\s+(\d+)\s+days/);
      const days = parseInt(daysMatch[1]) - 1;
      const startDate = new Date(Date.now() - days * 86400000).toISOString().split('T')[0];
      return { tool: 'get_attendance_range', params: { start_date: startDate, end_date: today } };
    } else if (lowerQuery.includes('raw swipe') || (lowerQuery.includes('swipe') && !lowerQuery.match(/\b(all|every|each|month|days)\b/))) {
      // Only use raw_swipes for explicit single-day swipe requests
      return { tool: 'get_raw_swipes', params: { date_str: today } };
    } else if (lowerQuery.includes('name') || lowerQuery.includes('who am i')) {
      return { tool: 'get_employee_name', params: {} };
    }

    // Default: today's attendance
    return { tool: 'get_attendance_by_date', params: { date_str: today } };
  }

  /**
   * Extract month from query (e.g., "january 2025" -> "2025-01")
   */
  extractMonth(query) {
    const months = {
      'january': '01', 'jan': '01',
      'february': '02', 'feb': '02',
      'march': '03', 'mar': '03',
      'april': '04', 'apr': '04',
      'may': '05',
      'june': '06', 'jun': '06',
      'july': '07', 'jul': '07',
      'august': '08', 'aug': '08',
      'september': '09', 'sep': '09', 'sept': '09',
      'october': '10', 'oct': '10',
      'november': '11', 'nov': '11',
      'december': '12', 'dec': '12'
    };

    const lowerQuery = query.toLowerCase();
    for (const [name, num] of Object.entries(months)) {
      if (lowerQuery.includes(name)) {
        const yearMatch = lowerQuery.match(/\d{4}/);
        const year = yearMatch ? yearMatch[0] : new Date().getFullYear().toString();
        return `${year}-${num}`;
      }
    }

    return null;
  }

  /**
   * Format month string (e.g., "2025-11" -> "November 2025")
   */
  formatMonthName(monthStr) {
    if (!monthStr) return 'the month';

    const months = ['January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'];

    const [year, month] = monthStr.split('-');
    const monthIndex = parseInt(month) - 1;

    if (monthIndex >= 0 && monthIndex < 12) {
      return `${months[monthIndex]} ${year}`;
    }
    return monthStr;
  }

  /**
   * Call an MCP tool directly - delegates to protocol-based method.
   * @param {string} toolName
   * @param {object} params
   * @param {string|null} employeeNumber
   * @param {string|null} jwtToken
   */
  async callMCPTool(toolName, params, employeeNumber, jwtToken = null) {
    return await this.callMCPToolWithProtocol(toolName, params, employeeNumber, jwtToken);
  }

  /**
   * Format the tool response into natural language using AI
   */
  async formatResponseWithAI(originalQuery, toolResult, toolName) {
    try {
      const systemPrompt = `You are a helpful HR assistant formatting employee attendance data.
Convert the raw attendance data into a clear, complete response.
IMPORTANT:
- Show EVERY record from the data — do NOT summarise, pick highlights, or omit any day.
- For range or multi-month queries, list EACH day that has an attendance record, with entry time, exit time, and duration.
- Group records by month when multiple months are present (e.g. "January", "February" section headers).
- Use a consistent bullet-list format: "• <Date>: In <time> → Out <time> (<duration>)"
- After listing all days, add a brief summary line (total days present, total hours).
- NEVER ask the user to rephrase their query or provide data in a specific format.
- NEVER mention internal tool names, API formats, or date formats (YYYY-MM-DD etc.) to the user.
- If the data is empty or missing, say the record was not found for that period — do not ask them to try a different format.
- Always respond as if you fully understood what the user asked.`;

      const userPrompt = `User asked: "${originalQuery}"
Tool called: ${toolName}
Raw data received: ${JSON.stringify(toolResult, null, 2)}

Please format this into a helpful response.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ]
      });

      const aiResponse = response.choices[0]?.message?.content;

      // If AI returned empty/null, use basic formatting
      if (!aiResponse || aiResponse.trim() === '') {
        console.log('AI returned empty response, using basic formatting');
        return this.basicFormatResponse(toolResult, toolName);
      }

      return aiResponse;

    } catch (error) {
      console.error('Error formatting response with AI:', error.message);

      // Fallback to basic formatting
      return this.basicFormatResponse(toolResult, toolName);
    }
  }

  /**
   * Basic response formatting without AI
   */
  basicFormatResponse(toolResult, toolName) {
    // Handle MCP response structure with content array
    let data = toolResult;
    if (toolResult && toolResult.structuredContent) {
      data = toolResult.structuredContent;
    } else if (toolResult && toolResult.content && toolResult.content[0]) {
      try {
        data = JSON.parse(toolResult.content[0].text);
      } catch (e) {
        data = toolResult.content[0].text;
      }
    }

    if (!data || typeof data === 'string') {
      return data || "No data available.";
    }

    switch (toolName) {
      case 'get_current_status':
        const status = data.status || (data.checked_in ? 'IN' : 'OUT');
        const lastSwipe = data.last_swipe || {};
        const swipeTime = lastSwipe.time || data.last_swipe_time || '';
        const location = lastSwipe.location || '';

        if (status === 'IN' || data.checked_in) {
          return `✅ You are currently **checked IN**${swipeTime ? `. Last swipe: ${swipeTime}` : ''}${location ? ` at ${location}` : ''}`;
        } else {
          return `⬜ You are currently **checked OUT**${swipeTime ? `. Last swipe: ${swipeTime}` : ''}${location ? ` at ${location}` : ''}`;
        }

      case 'get_attendance_by_date':
        const firstIn = data.first_in;
        const lastOut = data.last_out;
        const totalHours = data.total_hours || '00:00:00';
        const date = data.date;

        if (firstIn && lastOut) {
          return `📅 **${date}**\n• First entry: ${firstIn}\n• Last exit: ${lastOut}\n• Total hours: ${totalHours}`;
        } else if (firstIn) {
          return `📅 **${date}**\n• First entry: ${firstIn}\n• Last exit: Not recorded yet\n• Total hours: ${totalHours}`;
        } else {
          return `📅 **${date}**\nNo attendance record found for this date.`;
        }

      case 'get_month_summary':
        const monthData = data;
        const monthName = this.formatMonthName(monthData.month);
        const totalDays = monthData.total_days || 0;
        const sumHours = monthData.total_hours || 0;
        const avgIn = monthData.average_in || 'N/A';
        const avgOut = monthData.average_out || 'N/A';
        return `📊 **Monthly Summary for ${monthName}**\n• Days present: ${totalDays}\n• Total hours: ${sumHours}\n• Average entry: ${avgIn}\n• Average exit: ${avgOut}`;

      case 'get_attendance_range':
        const rangeSummary = data.summary || {};
        const days = data.days || data.records || [];

        if (Array.isArray(days) && days.length > 0) {
          let response = `📅 **Attendance Summary**\n`;
          response += `📈 Total: ${rangeSummary.total_days || days.length} days, ${rangeSummary.total_hours || 'N/A'} hours\n\n`;

          days.forEach(rec => {
            const dateStr = rec.date || 'N/A';
            const firstIn = rec.first_in ? rec.first_in.split('T')[1] : 'N/A';
            const lastOut = rec.last_out ? rec.last_out.split('T')[1] : 'N/A';
            response += `• **${dateStr}**: ${firstIn} - ${lastOut} (${rec.total_hours || 'N/A'})\n`;
          });
          return response;
        } else {
          return `📅 **Attendance Summary**\nNo attendance records found for this date range.`;
        }

      case 'get_raw_swipes':
        const swipes = data.result || data.swipes || data;
        if (Array.isArray(swipes) && swipes.length > 0) {
          let response = `🔄 **Raw Swipes:**\n`;
          swipes.forEach(s => {
            response += `• ${s.timestamp || s.time}: ${s.type || s.direction} at ${s.location || 'N/A'}\n`;
          });
          return response;
        }
        return `No swipe data found.`;

      case 'get_employee_name':
        return `You are ${data.name || data.employee_name || 'Unknown'}.`;

      default:
        return `Here's your attendance data:\n\`\`\`json\n${JSON.stringify(data, null, 2)}\n\`\`\``;
    }
  }
}

// Export singleton instance
let mcpV2Client = null;

module.exports = {
  getEntryExitV2Client: () => {
    if (!mcpV2Client) {
      mcpV2Client = new EntryExitMCPV2Client();
    }
    return mcpV2Client;
  }
};