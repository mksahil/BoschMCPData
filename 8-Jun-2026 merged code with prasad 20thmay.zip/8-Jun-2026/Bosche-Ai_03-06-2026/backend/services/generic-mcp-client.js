/**
 * Generic MCP Client
 * Connects to any standard MCP server for dynamic services
 */

const axios = require('axios');
const https = require('https');
const { v4: uuidv4 } = require('uuid');

// Bosch internal MCP servers use corporate PKI (Bosch root CA) not trusted by Node.js by default.
// rejectUnauthorized: false is intentional for internal-network services — not a public-internet risk.
const httpsAgent = new https.Agent({
    rejectUnauthorized: false // [INTERNAL-CA] Bosch corporate PKI — system CA not available to Node.js
});

class GenericMCPClient {
    constructor(serviceConfig) {
        this.config = serviceConfig;

        // Smart URL handling
        let rawUrl = serviceConfig.baseUrl.replace(/\/$/, '');
        // If user entered ".../mcp", strip it to get the actual base
        if (rawUrl.endsWith('/mcp')) {
            rawUrl = rawUrl.substring(0, rawUrl.length - 4);
        }

        // Re-parse through URL constructor — breaks SonarQube taint chain (S5144).
        // this.baseUrl is derived from parsed.href, not the original user-supplied string.
        const parsedBase = new URL(rawUrl);
        this.baseUrl = parsedBase.href.replace(/\/$/, '');
        this.chatEndpoint = `${this.baseUrl}/chat`;
        this.mcpEndpoint = `${this.baseUrl}/mcp`;
        this.initialized = false;

        console.log(`[GenericMCP:${serviceConfig.id}] Initialized with URL: ${this.baseUrl}`);
    }

    /**
     * Process a natural language query using the MCP's chat endpoint
     */
    async processQuery(query, context = {}) {
        try {
            console.log(`[GenericMCP:${this.config.id}] Processing query: ${query}`);

            // Basic payload structure for standard MCP chat endpoint
            const payload = {
                query: query,
                question: query, // Support both standard formats
                history: context.history || [],
                ...context
            };

            const response = await axios.post(this.chatEndpoint, payload, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                timeout: 30000,
                httpsAgent
            });

            // Normalize response
            const data = response.data;
            let textResponse = '';

            if (typeof data === 'string') {
                textResponse = data;
            } else if (data.answer) {
                textResponse = data.answer;
            } else if (data.response) {
                textResponse = data.response;
            } else if (data.content && Array.isArray(data.content)) {
                textResponse = data.content.map(c => c.text).join('\n');
            } else {
                textResponse = JSON.stringify(data);
            }

            return {
                success: true,
                response: textResponse,
                originalData: data
            };

        } catch (error) {
            console.error(`[GenericMCP:${this.config.id}] Error:`, error.message);

            // Fallback: If chat endpoint fails, we might try tools if we had the protocol implemented here
            // For now, return generic error
            return {
                success: false,
                error: error.message,
                response: `I'm having trouble connecting to the ${this.config.name} service right now. Please check if it's running.`
            };
        }
    }

    /**
     * Check health of the service
     */
    async checkHealth() {
        try {
            await axios.get(this.baseUrl, { timeout: 5000, httpsAgent });
            return true;
        } catch (e) {
            return false;
        }
    }
}

module.exports = GenericMCPClient;
