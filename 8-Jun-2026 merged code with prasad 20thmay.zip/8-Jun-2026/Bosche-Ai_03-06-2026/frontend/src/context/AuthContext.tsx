import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { logoutAzureAD, getAccessTokenSilently } from '@/services/azureAuthService';

// ── Service-token types (target-unique — used by chat requests) ───────────────

/** One token bundle for a single Bosch service (travel / seatbooking / default). */
export interface ServiceTokenBundle {
  jwt:       string;
  sessionId: string;
}

/**
 * Per-service JWT tokens + SessionIds generated at login time.
 * Stored in sessionStorage so they survive page refreshes but are
 * destroyed when the browser tab/window is closed.
 * Sent with every chat request so the backend uses them directly
 * instead of performing server-side cache lookups.
 */
export interface ServiceTokens {
  travel?:      ServiceTokenBundle | null;
  seatbooking?: ServiceTokenBundle | null;
  entryexit?:   ServiceTokenBundle | null;
  canteen?:     ServiceTokenBundle | null;
  community?:   ServiceTokenBundle | null;
}

// ─────────────────────────────────────────────────────────────────────────────

interface User {
  employeeNumber: string;
  name: string;
  accessToken: string;
  tokenType: string;
  entityId: string;
  entityName: string;
  isTemporaryPassword: boolean;
  loginTimestamp: string;
  ntid: string;
  expiresIn: number;
  issuedAt: string;
  expiresAt: string;
  sessionId?: string;
  loginMethod?: 'credential' | 'sso';
  /** Per-service JWT + SessionId bundles generated at login. Stored in sessionStorage. */
  serviceTokens?: ServiceTokens;
}

interface ArenaTokenResponse {
  userName: string;
  Name?: string;
  access_token: string;
  token_type: string;
  EntityId: string;
  EntityName: string;
  IsTemporaryPassword: string;
  LoginTimeStamp: string;
  NTID: string;
  expires_in: number;
  '.issued': string;
  '.expires': string;
  sessionId?: string;
  /** Per-service tokens returned by the backend /api/auth/login route. */
  serviceTokens?: ServiceTokens;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  /**
   * null  = consent status not yet known (still loading after login)
   * false = user has NOT consented yet — show ConsentModal
   * true  = user has consented — allow app access
   */
  hasConsented: boolean | null;
  login: (employeeNumber: string, password: string, isPreEncrypted?: boolean) => Promise<{ success: boolean; error?: string }>;
  ssoLogin: (arenaTokenData: ArenaTokenResponse) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  /**
   * refreshSession — called by useSessionTimeout when the user clicks "Stay Logged In".
   * For SSO users: silently acquires a new Azure AD access token.
   * For credential users: no-op (returns true — timer reset is sufficient).
   * Returns false and calls logout() if the underlying refresh token has expired.
   */
  refreshSession: () => Promise<boolean>;
  /** Save consent to the backend and flip hasConsented to true locally. */
  recordConsent: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// ── Consent helpers ──────────────────────────────────────────────────────────

const API_BASE = import.meta.env.PROD
  ? 'https://my-bgsw-ai-api-dev.azurewebsites.net'
  : 'http://localhost:3001';

/**
 * Derive the stable NT-ID used for consent lookup.
 * Falls back to employeeNumber so credential-only users without an NTID still work.
 */
function resolveNtId(user: User): string {
  return (user.ntid || user.employeeNumber || '').trim();
}

async function fetchConsentStatus(ntId: string): Promise<boolean> {
  try {
    const resp = await fetch(`${API_BASE}/api/auth/consent?nt_id=${encodeURIComponent(ntId)}`);
    if (!resp.ok) return false;
    const data = await resp.json() as { hasConsented: boolean };
    return data.hasConsented === true;
  } catch {
    return false;
  }
}

async function postConsent(userId: string, userName: string, ntId: string): Promise<boolean> {
  try {
    const resp = await fetch(`${API_BASE}/api/auth/consent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, user_name: userName, nt_id: ntId }),
    });
    if (!resp.ok) return false;
    const data = await resp.json() as { success: boolean };
    return data.success === true;
  } catch {
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  /** null = not yet checked, false = no consent, true = consented */
  const [hasConsented, setHasConsented] = useState<boolean | null>(null);

  useEffect(() => {
    const init = async () => {
      const storedUser = sessionStorage.getItem('mybgsw_user');
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser) as User;
          const expiresAt = new Date(parsedUser.expiresAt);
          if (expiresAt > new Date()) {
            setUser(parsedUser);
            // Consent is fetched by the user-watching useEffect below
          } else {
            sessionStorage.removeItem('mybgsw_user');
          }
        } catch {
          sessionStorage.removeItem('mybgsw_user');
        }
      }
      setIsLoading(false);
    };
    init();
  }, []);

  // Fetch consent whenever the logged-in user changes.
  // Using a useEffect prevents a race where isLoading=false and isAuthenticated=true
  // are committed in separate React flushes, causing ProtectedRoute to see a
  // half-ready state and the page staying on /login despite a successful login.
  useEffect(() => {
    if (!user) { setHasConsented(null); return; }
    let cancelled = false;
    const ntId = resolveNtId(user);
    if (!ntId) { setHasConsented(false); return; }
    fetchConsentStatus(ntId).then(consented => {
      if (!cancelled) setHasConsented(consented);
    });
    return () => { cancelled = true; };
  }, [user]);

  const login = async (
    employeeNumber: string,
    password: string,
    isPreEncrypted: boolean = false,
  ): Promise<{ success: boolean; error?: string; retryAfter?: number }> => {
    try {
      setIsLoading(true);

      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: employeeNumber, password, isPreEncrypted }),
      });

      const data = (await response.json()) as ArenaTokenResponse;

      if (response.status === 429) {
        const retryAfter = parseInt(response.headers.get('Retry-After') || '60', 10);
        return {
          success: false,
          error: (data as { error?: string }).error || 'Too many login attempts. Please wait before trying again.',
          retryAfter,
        };
      }

      if (!response.ok) {
        return { success: false, error: (data as { error?: string }).error || 'Login failed' };
      }

      const userData: User = {
        employeeNumber: data.userName,
        name: data.Name?.trim() || data.userName,
        accessToken: data.access_token,
        tokenType: data.token_type,
        entityId: data.EntityId,
        entityName: data.EntityName,
        isTemporaryPassword: data.IsTemporaryPassword === 'True',
        loginTimestamp: data.LoginTimeStamp,
        ntid: data.NTID,
        expiresIn: data.expires_in,
        issuedAt: data['.issued'],
        expiresAt: data['.expires'],
        sessionId: data.sessionId,
        loginMethod: 'credential',
        // Per-service JWT + SessionId bundles — generated by the backend at login
        // and stored here so every chat request can include them without a server
        // round-trip. sessionStorage destroys them automatically on tab close.
        serviceTokens: data.serviceTokens,
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));
      // Consent is fetched by the user-watching useEffect — no await needed here.

      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  const ssoLogin = async (arenaTokenData: ArenaTokenResponse): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      if (!arenaTokenData) {
        return { success: false, error: 'No token data provided' };
      }

      // SSO redirects bypass /api/auth/login, so we call a dedicated endpoint to
      // generate JWT tokens for all services using the OAuth token received from
      // the Arena SSO redirect. Result is stored in sessionStorage and auto-destroyed
      // when the tab closes.
      let serviceTokens: ServiceTokens | undefined;
      try {
        const tokenRes = await fetch(`${API_BASE}/api/auth/service-tokens`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            employeeNumber: arenaTokenData.userName,
            oauthToken:     arenaTokenData.access_token,
          }),
        });

        if (tokenRes.ok) {
          const tokenData = await tokenRes.json() as { serviceTokens: ServiceTokens };
          serviceTokens = tokenData.serviceTokens;
          console.log('[SSO] Service tokens generated successfully');
        } else {
          console.warn('[SSO] /api/auth/service-tokens returned', tokenRes.status, '— A2A services may degrade');
        }
      } catch (tokenErr) {
        console.warn('[SSO] Could not fetch service tokens:', tokenErr);
      }

      const userData: User = {
        employeeNumber: arenaTokenData.userName,
        name: arenaTokenData.Name?.trim() || arenaTokenData.userName,
        accessToken: arenaTokenData.access_token,
        tokenType: arenaTokenData.token_type,
        entityId: arenaTokenData.EntityId,
        entityName: arenaTokenData.EntityName,
        isTemporaryPassword: arenaTokenData.IsTemporaryPassword === 'True',
        loginTimestamp: arenaTokenData.LoginTimeStamp,
        ntid: arenaTokenData.NTID,
        expiresIn: arenaTokenData.expires_in,
        issuedAt: arenaTokenData['.issued'],
        expiresAt: arenaTokenData['.expires'],
        sessionId: arenaTokenData.sessionId ?? serviceTokens?.entryexit?.sessionId,
        loginMethod: 'sso',
        serviceTokens,
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));
      // Consent is fetched by the user-watching useEffect — no await needed here.

      return { success: true };
    } catch (error) {
      console.error('SSO login error:', error);
      return { success: false, error: 'SSO login failed. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Save consent to the backend then update local state.
   * Called by ConsentModal after the user ticks both checkboxes and clicks Continue.
   */
  const recordConsent = async (): Promise<void> => {
    if (!user) return;
    const ntId = resolveNtId(user);
    if (!ntId) return;
    await postConsent(user.employeeNumber, user.name, ntId);
    setHasConsented(true);
  };

  const refreshSession = async (): Promise<boolean> => {
    try {
      if (user?.loginMethod === 'sso') {
        const token = await getAccessTokenSilently();
        if (!token) {
          // Refresh token has expired — force re-authentication
          await logout();
          return false;
        }
      }
      // Credential users: timer reset alone is sufficient
      return true;
    } catch (error) {
      console.error('[AuthContext] Session refresh failed:', error);
      await logout();
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      if (user?.loginMethod === 'sso') {
        await logoutAzureAD();
      }
      setUser(null);
      setHasConsented(null);
      sessionStorage.removeItem('mybgsw_user');
    } catch (error) {
      console.error('Logout error:', error);
      setUser(null);
      setHasConsented(null);
      sessionStorage.removeItem('mybgsw_user');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        hasConsented,
        login,
        ssoLogin,
        logout,
        refreshSession,
        recordConsent,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
