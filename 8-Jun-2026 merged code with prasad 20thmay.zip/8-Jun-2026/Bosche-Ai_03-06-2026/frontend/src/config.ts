// API Configuration
// For production deployment on Vercel, use the Render backend URL
// For ngrok demo, use empty string so it uses relative paths (proxied by Vite)
export const API_BASE_URL = import.meta.env.PROD
  ? import.meta.env.VITE_API_BASE_URL
  : 'http://localhost:3001'; // Empty for local dev - Vite proxy handles /api/* routes

// Admin API base URL — used by the Admin panel to call backend config endpoints.
// In local dev this points directly to the backend server (not proxied by Vite).
// Override via VITE_ADMIN_API_URL in your .env file.

export const ADMIN_BASE_URL = import.meta.env.PROD
  ? import.meta.env.VITE_ADMIN_BASE_URL
  : 'http://localhost:3001';

// API Endpoints
export const API_ENDPOINTS = {
  logs: `${API_BASE_URL}/api/logs`,
  sessions: `${API_BASE_URL}/api/sessions`,
  logsDownload: `${API_BASE_URL}/api/logs/download`,
  // Unified smart chat endpoint - uses AI to route to correct service
  chat: `${API_BASE_URL}/api/chat`,
  // History endpoint
  chatHistory: `${API_BASE_URL}/api/chat/history`,
  // Individual service endpoints (legacy, prefer using /api/chat)
  canteenQuery: `${API_BASE_URL}/api/canteen/query`,
  entryExitQuery: `${API_BASE_URL}/api/entryexit/query`,
  // Chat feedback endpoint
  chatFeedback: `${API_BASE_URL}/api/chat/feedback`,
  // Get list of available services
  services: `${API_BASE_URL}/api/services`,
  // Backend service health check (returns status for all services)
  health: `${API_BASE_URL}/api/health`,
};
