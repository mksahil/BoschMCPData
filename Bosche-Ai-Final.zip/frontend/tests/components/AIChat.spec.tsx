import { render, screen, fireEvent, act, waitFor } from '@testing-library/react';
import { AIChat } from '@/components/AIChat';
import { AuthProvider } from '@/context/AuthContext';
import logger from '@/lib/logger';

// ─── Mocks ───────────────────────────────────────────────────────────────────
// Mock scrollIntoView which is missing in JSDOM
window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

function mockFetchResponse(body: object, ok = true) {
  return Promise.resolve({
    ok,
    json: () => Promise.resolve(body),
    status: ok ? 200 : 400
  });
}

describe('AIChat', () => {
  const mockUser = {
    employeeNumber: 'EMP001',
    name: 'John Doe',
    accessToken: 'test-token',
  };

  beforeEach(() => {
    sessionStorage.clear();
    spyOn(window, 'fetch').and.returnValue(mockFetchResponse({ success: true, history: [] }));
    spyOn(logger, 'logChatMessage');
    spyOn(logger, 'logButtonClick');
    spyOn(logger, 'log');
  });

  const renderChat = () => {
    return render(
      <AuthProvider>
        <AIChat />
      </AuthProvider>
    );
  };

  it('renders the floating chat button', () => {
    renderChat();
    expect(screen.getByRole('button')).toBeTruthy();
  });

  it('opens clicking the chat button', async () => {
    renderChat();
    const button = screen.getByRole('button');
    
    await act(async () => {
      fireEvent.click(button);
    });

    expect(screen.getByText(/Ask MyBGSW.AI/i)).toBeTruthy();
    expect(screen.getByPlaceholderText(/Type your message/i)).toBeTruthy();
  });

  it('loads chat history when opened', async () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    const mockHistory = [
      { role: 'user', content: 'Hello AI', timestamp: new Date().toISOString() },
      { role: 'assistant', content: 'Hi there!', timestamp: new Date().toISOString() }
    ];

    (window.fetch as jasmine.Spy).and.callFake((url: string) => {
      if (url.includes('chat/history')) {
        return mockFetchResponse({ success: true, history: mockHistory });
      }
      return mockFetchResponse({ success: true });
    });

    renderChat();
    const button = screen.getByRole('button');
    
    await act(async () => {
      fireEvent.click(button);
    });

    await waitFor(() => {
      expect(screen.getByText('Hello AI')).toBeTruthy();
      expect(screen.getByText('Hi there!')).toBeTruthy();
    });
  });

  it('sends a message and displays AI response', async () => {
    sessionStorage.setItem('mybgsw_user', JSON.stringify({
      ...mockUser,
      expiresAt: new Date(Date.now() + 3600000).toISOString()
    }));

    (window.fetch as jasmine.Spy).and.callFake((url: string) => {
      if (url.includes('chat')) {
        return mockFetchResponse({ success: true, response: 'I am your AI assistant.' });
      }
      return mockFetchResponse({ success: true });
    });

    renderChat();
    await act(async () => {
      // The toggle button is the only one rendered initially
      fireEvent.click(screen.getByRole('button'));
    });

    const input = screen.getByPlaceholderText(/Type your message/i);
    // Find the send button specifically (it's the one with the lucide-send icon)
    const buttons = screen.getAllByRole('button');
    const sendButton = buttons.find(b => b.querySelector('.lucide-send')) || buttons[buttons.length - 1];

    await act(async () => {
      fireEvent.change(input, { target: { value: 'What is your name?' } });
      fireEvent.click(sendButton!);
    });

    expect(logger.logChatMessage).toHaveBeenCalledWith('What is your name?', true, jasmine.any(Object));
    
    await waitFor(() => {
      expect(screen.getByText('I am your AI assistant.')).toBeTruthy();
    });
  });

  it('displays error message when API fails', async () => {
    spyOn(console, 'error'); // Suppress expected error log
    (window.fetch as jasmine.Spy).and.returnValue(Promise.reject(new Error('API Down')));

    renderChat();
    await act(async () => {
      fireEvent.click(screen.getByRole('button'));
    });

    const input = screen.getByPlaceholderText(/Type your message/i);
    await act(async () => {
      fireEvent.change(input, { target: { value: 'fail' } });
      fireEvent.keyPress(input, { key: 'Enter', code: 'Enter', charCode: 13 });
    });

    await waitFor(() => {
      expect(screen.getByText(/trouble processing your request/i)).toBeTruthy();
    });
  });
});
