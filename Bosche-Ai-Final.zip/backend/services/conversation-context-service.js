/**
 * Conversation Context Service
 * Maintains conversation context for AI orchestration
 * Enables follow-up queries like "what about yesterday?" to work correctly
 */

const { createOpenAIClient, getChatModelName } = require('./openai-client');
const fs = require('fs-extra');
const path = require('path');
const configService = require('./config-service');

class ConversationContextService {
  constructor() {
    // Store conversation contexts by sessionId
    // In production, use Redis or similar for persistence
    this.contexts = new Map();

    // Maximum number of messages to keep per session
    this.maxHistoryLength = 10;

    // Context expiry time (30 minutes)
    this.contextExpiryMs = 30 * 60 * 1000;

    // Initialize OpenAI for context analysis
    this._openai = null;

    // Directory for storing conversation history
    // In Azure/Cloud, use an absolute path to a mounted persistent volume via env var
    this.dataDir = process.env.CHAT_HISTORY_DIR || path.join(__dirname, '../data/conversations');
    fs.ensureDirSync(this.dataDir);
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Get or create a conversation context for a session
   */
  getContext(sessionId) {
    if (!this.contexts.has(sessionId)) {
      this.contexts.set(sessionId, {
        sessionId,
        messages: [],
        lastService: null,
        lastTopic: null,
        lastDate: null,
        lastMonth: null,
        locationId: null,
        employeeNumber: null,
        travelState: {
          from: null,
          to: null,
          startDate: null,
          endDate: null,
          passengers: 1,
          travelClass: null,
          preferences: null,
          isComplete: false,
          approved: false
        },
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    return this.contexts.get(sessionId);
  }

  /**
   * Initialize context for a user (load history)
   */
  async initializeContext(sessionId, employeeNumber) {
    // [FIX #21 | Rule S2083 - Path Injection]: Sanitize sessionId and employeeNumber at the
    // entry point of initializeContext — the earliest place both user-controlled values appear
    // after arriving from req.body in server.js.
    //
    // SonarQube's taint analysis traced the unvalidated values from the HTTP source through
    // this function into getContext() (Map key usage) and onward into loadContext() (file I/O).
    // Even though _buildSafeFilePath() in saveContext/loadContext blocks path operations on bad
    // inputs, SonarQube flags any use of tainted data before that sanitization point.
    //
    // Fix: apply the same allowlist regexes here so the variables are clean for all downstream
    // use — Map lookups, disk reads, disk writes — and SonarQube's taint chain is broken at
    // the source rather than only at the sink.
    const SESSION_RE  = /^[a-zA-Z0-9_-]{1,128}$/;
    const EMPLOYEE_RE = /^\d{6,12}$/;

    if (!sessionId || !SESSION_RE.test(String(sessionId))) {
      console.warn('[ConversationContext] initializeContext: rejected invalid sessionId');
      // Return a fresh anonymous context rather than exposing Map state or disk data
      return {
        sessionId: null, messages: [], lastService: null, lastTopic: null,
        lastDate: null, lastMonth: null, locationId: null, employeeNumber: null,
        travelState: { from: null, to: null, startDate: null, endDate: null,
          passengers: 1, travelClass: null, preferences: null, isComplete: false, approved: false },
        createdAt: Date.now(), updatedAt: Date.now()
      };
    }

    // employeeNumber is optional — if present it must pass the allowlist; if not, proceed without disk load
    if (employeeNumber && !EMPLOYEE_RE.test(String(employeeNumber))) {
      console.warn('[ConversationContext] initializeContext: invalid employeeNumber — continuing without disk context');
      employeeNumber = null;
    }

    if (!employeeNumber) return this.getContext(sessionId);

    // If context doesn't exist or is empty, try to load from disk
    let context = this.getContext(sessionId);

    if (context.messages.length === 0) {
      const history = await this.loadContext(employeeNumber, sessionId);
      if (history && history.length > 0) {
        console.log(`[ConversationContext] Loaded ${history.length} messages for session ${sessionId}`);
        // Add loaded messages to current session context
        context.messages = history;
        context.employeeNumber = employeeNumber;

        // Restore context state (last service, topic, etc.) from the most recent relevant message
        for (let i = history.length - 1; i >= 0; i--) {
          const msg = history[i];
          if (msg.service || msg.topic || msg.locationId) {
            context.lastService = msg.service || context.lastService;
            context.lastTopic = msg.topic || context.lastTopic;
            context.lastDate = msg.date || context.lastDate;
            context.locationId = msg.locationId || context.locationId;
            
            // Restore travel state if present in metadata
            if (msg.travelState) {
              context.travelState = { ...context.travelState, ...msg.travelState };
            }
            
            if (msg.role === 'assistant' && msg.service) break;
          }
        }

        this.contexts.set(sessionId, context);
      }
    }

    return context;
  }

  /**
   * [FIX #20 | Rule S2083 - Path Injection]: Build a validated, contained file path from
   * employeeNumber and sessionId.
   *
   * Both values originate from user-controlled HTTP request bodies (see server.js /api/chat).
   * Using them directly in path.join() creates a path traversal vulnerability — an attacker
   * can supply values like "../../etc/passwd" or "..\\..\\.env" to read or overwrite
   * arbitrary files on the server.
   *
   * Two defences are applied:
   *   1. Allowlist regex — employeeNumber must be 6-12 digits; sessionId must be 1-128
   *      alphanumeric/dash/underscore characters. Any other shape is rejected immediately.
   *   2. path.resolve() containment — even after passing the regex, the fully resolved path
   *      is checked to ensure it starts with this.dataDir. This catches any edge-case
   *      traversal that a regex alone might miss.
   *
   * Returns the safe absolute path string, or null if validation fails.
   */
  _buildSafeFilePath(employeeNumber, sessionId) {
    const EMPLOYEE_RE = /^\d{6,12}$/;
    const SESSION_RE  = /^[a-zA-Z0-9_-]{1,128}$/;

    if (!EMPLOYEE_RE.test(String(employeeNumber)) || !SESSION_RE.test(String(sessionId))) {
      return null;
    }

    const base     = path.resolve(this.dataDir);
    const resolved = path.resolve(base, `${employeeNumber}_${sessionId}.json`);

    // Ensure resolved path is strictly inside the data directory
    if (!resolved.startsWith(base + path.sep)) {
      return null;
    }

    return resolved;
  }

  /**
   * Save context to disk
   */
  async saveContext(employeeNumber, sessionId, messages) {
    if (!employeeNumber || !sessionId) return;

    // [FIX #20 | Rule S2083 - Path Injection]: validate inputs before path construction
    const filePath = this._buildSafeFilePath(employeeNumber, sessionId);
    if (!filePath) {
      console.warn('[ConversationContext] saveContext: rejected unsafe employeeNumber or sessionId — path injection attempt blocked');
      return;
    }

    try {
      await fs.writeJson(filePath, messages, { spaces: 2 });
    } catch (error) {
      console.error(`[ConversationContext] Failed to save context for session ${sessionId}:`, 'An internal server error occurred');
    }
  }

  /**
   * Load context from disk
   */
  async loadContext(employeeNumber, sessionId) {
    if (!employeeNumber || !sessionId) return [];

    // [FIX #20 | Rule S2083 - Path Injection]: validate inputs before path construction
    // This also resolves issue-2 (line 82) where initializeContext passes unvalidated
    // sessionId/employeeNumber into this function — validation now happens at the sink.
    const filePath = this._buildSafeFilePath(employeeNumber, sessionId);
    if (!filePath) {
      console.warn('[ConversationContext] loadContext: rejected unsafe employeeNumber or sessionId — path injection attempt blocked');
      return [];
    }

    try {
      // Inline containment guard: ensure resolved filePath stays within dataDir
      if (!filePath.startsWith(path.resolve(this.dataDir) + path.sep)) {
        console.warn('[ConversationContext] loadContext: path containment check failed');
        return [];
      }
      if (await fs.pathExists(filePath)) {
        const messages = await fs.readJson(filePath);

        // Filter out messages older than 7 days
        const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
        let activeMessages = messages.filter(msg => {
          const timestamp = new Date(msg.timestamp).getTime();
          return timestamp > sevenDaysAgo;
        });

        // Optimization: Keep only the last 100 messages
        if (activeMessages.length > 100) {
          activeMessages = activeMessages.slice(-100);
        }

        // If we filtered out messages, save the cleaned up version.
        // [FIX #21 | Rule S2083 - Path Injection]: employeeNumber and sessionId were validated
        // by _buildSafeFilePath() above before we reached this point. saveContext() also runs
        // _buildSafeFilePath() internally, providing a second layer of defence.
        if (activeMessages.length !== messages.length) {
          await this.saveContext(employeeNumber, sessionId, activeMessages);
        }

        return activeMessages;
      }
    } catch (error) {
      console.error(`[ConversationContext] Failed to load context for session ${sessionId}:`, 'An internal server error occurred');
    }
    return [];
  }

  /**
   * Add a message to the conversation context
   */
  addMessage(sessionId, role, content, metadata = {}) {
    const context = this.getContext(sessionId);

    context.messages.push({
      role,
      content,
      timestamp: Date.now(),
      ...metadata
    });

    // Keep only the last N messages in memory for immediate context
    // But we'll persist more to disk

    context.updatedAt = Date.now();

    // Update context metadata if provided
    if (metadata.service) {
      context.lastService = metadata.service;
    }
    if (metadata.topic) {
      context.lastTopic = metadata.topic;
    }
    if (metadata.date) {
      context.lastDate = metadata.date;
    }
    if (metadata.month) {
      context.lastMonth = metadata.month;
    }
    if (metadata.locationId) {
      context.locationId = metadata.locationId;
    }
    if (metadata.employeeNumber) {
      context.employeeNumber = metadata.employeeNumber;
    }

    // Persist to disk if we have an employee number and session ID
    if (context.employeeNumber && context.sessionId) {
      // We want to save all messages (not just the limited in-memory window)
      // So we'll reload, append, and save, or just append to what we have if we know it's complete
      // For simplicity and correctness with the 7-day window, let's load-merge-save async
      this.saveContextWithHistory(context.employeeNumber, context.sessionId, {
        role,
        content,
        timestamp: Date.now(),
        ...metadata
      });
    }

    return context;
  }

  /**
   * Helper to append message to persistent storage
   */
  async saveContextWithHistory(employeeNumber, sessionId, newMessage) {
    try {
      // Load existing full history
      let history = await this.loadContext(employeeNumber, sessionId);

      // Add new message
      history.push(newMessage);

      // Save back (filter for 7 days happens in loadContext, but we can also enforce here)
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      history = history.filter(msg => new Date(msg.timestamp).getTime() > sevenDaysAgo);

      // Optimization: Enforce 100 message limit
      if (history.length > 100) {
        history = history.slice(-100);
      }

      await this.saveContext(employeeNumber, sessionId, history);
    } catch (error) {
      console.error('[ConversationContext] Error in saveContextWithHistory:', error);
    }
  }

  /**
   * Update context with service-specific metadata after processing
   */
  updateServiceContext(sessionId, serviceData) {
    const context = this.getContext(sessionId);

    if (serviceData.service) {
      context.lastService = serviceData.service;
    }
    if (serviceData.topic) {
      context.lastTopic = serviceData.topic;
    }
    if (serviceData.date) {
      context.lastDate = serviceData.date;
    }
    if (serviceData.month) {
      context.lastMonth = serviceData.month;
    }
    if (serviceData.locationId) {
      context.locationId = serviceData.locationId;
    }

    context.updatedAt = Date.now();
    return context;
  }

  /**
   * Check if a query is a follow-up question
   * Follow-up queries are short, context-dependent questions
   */
  isFollowUpQuery(query) {
    const lowerQuery = query.toLowerCase().trim();

    // Common follow-up patterns from config
    const routingConfig = configService.getRoutingConfigSync();
    const patterns = routingConfig.followUpPatterns || {};
    // Escape special regex characters to prevent RegExp injection from config values
    const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const followUpPatterns = Object.values(patterns).map(p => new RegExp(escapeRegExp(String(p)), 'i'));

    // Short queries (less than 6 words without clear subject) are often follow-ups
    const wordCount = query.split(/\s+/).length;
    const subjectKeywords = routingConfig.subjectKeywords || [];
    const hasSubject = new RegExp(subjectKeywords.map(escapeRegExp).join('|'), 'i').test(query);

    // Check against patterns
    for (const pattern of followUpPatterns) {
      if (pattern.test(lowerQuery)) {
        console.log('[ConversationContext] Matched follow-up pattern:', pattern);
        return true;
      }
    }

    // Short queries without clear subject are likely follow-ups
    if (wordCount <= 4 && !hasSubject) {
      console.log('[ConversationContext] Short query without subject, treating as follow-up');
      return true;
    }

    return false;
  }

  /**
   * Rewrite a follow-up query to include context from previous conversation
   * This is the key method for context-aware responses
   */
  async rewriteQueryWithContext(sessionId, query, conversationHistory = []) {
    const context = this.getContext(sessionId);
    const lowerQuery = query.toLowerCase();
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/;

    console.log('[ConversationContext] Processing query:', query);
    console.log('[ConversationContext] Session:', sessionId);
    console.log('[ConversationContext] Stored context:', {
      lastService: context.lastService,
      lastTopic: context.lastTopic,
      lastDate: context.lastDate,
      messageCount: context.messages?.length || 0
    });
    console.log('[ConversationContext] Conversation history length:', conversationHistory?.length || 0);

    // If no previous context AND no conversation history, return query as-is
    if (!context.lastService && (!conversationHistory || conversationHistory.length === 0)) {
      console.log('[ConversationContext] No context available, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    // Identity queries should not be rewritten as follow-ups
    if (identityPattern.test(lowerQuery)) {
      console.log('[ConversationContext] Identity query detected, skipping rewrite');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: 'entryexit'
      };
    }

    // Check if this might be a follow-up
    const isFollowUp = this.isFollowUpQuery(query);
    console.log('[ConversationContext] Is follow-up query:', isFollowUp);

    if (!isFollowUp) {
      console.log('[ConversationContext] Not a follow-up, returning original query');
      return {
        rewrittenQuery: query,
        originalQuery: query,
        wasRewritten: false,
        inferredService: null
      };
    }

    console.log('[ConversationContext] === FOLLOW-UP DETECTED ===');
    console.log('[ConversationContext] Original query:', query);
    console.log('[ConversationContext] Last service:', context.lastService);
    console.log('[ConversationContext] Last topic:', context.lastTopic);

    // Use AI to rewrite the query with context
    try {
      // Use full context messages which includes loaded history
      // We look back 10 messages to catch context
      const recentMessages = context.messages.length > 0 ? context.messages : conversationHistory;
      const historyToUse = recentMessages.slice(-10);

      const recentHistory = historyToUse.map(msg =>
        `${msg.role === 'user' ? 'User' : 'Assistant'}: ${(msg.content || '').substring(0, 500)}`
      ).join('\n');

      const systemPrompt = `You are a context-aware query rewriter. Given a follow-up question and conversation history, rewrite the query to be self-contained and explicit.

CONVERSATION HISTORY:
${recentHistory}

CONTEXT:
- Last service used: ${context.lastService || 'unknown'}
- Last topic discussed: ${context.lastTopic || 'unknown'}
- Last date mentioned: ${context.lastDate || 'not specified'}
- Last month referenced: ${context.lastMonth || 'not specified'}

RULES:
1. If the user asks "what about yesterday?" after asking about today's menu, rewrite to "What is the canteen menu for yesterday?"
2. If the user asks "and tomorrow?" after asking about entry time, rewrite to "What was my entry time tomorrow?" (or correct grammar)
3. If the user asks "same for last week?", understand the previous query topic and rewrite accordingly
4. If the user says "that month", "that month's details", "in that month", or "for that month", replace it with the actual month name from context (e.g., "February 2026")
5. Preserve any specific details the user mentions in the follow-up
6. Make the rewritten query complete and understandable without context
7. Also identify which service should handle this query

Respond in JSON format:
{
  "rewrittenQuery": "the complete, self-contained query",
  "inferredService": "canteen|entryexit|travel|seatbooking|community|banner|general",
  "explanation": "brief explanation of what context was used"
}`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Follow-up question: "${query}"` }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content);

      console.log('[ConversationContext] Rewritten query:', result.rewrittenQuery);
      console.log('[ConversationContext] Inferred service:', result.inferredService);

      return {
        rewrittenQuery: result.rewrittenQuery,
        originalQuery: query,
        wasRewritten: true,
        inferredService: result.inferredService,
        explanation: result.explanation
      };

    } catch (error) {
      console.error('[ConversationContext] Error rewriting query:', error.message);

      // Fallback: simple context injection
      return this.fallbackRewrite(query, context);
    }
  }

  /**
   * Fallback query rewriting when AI is unavailable
   */
  fallbackRewrite(query, context) {
    const lowerQuery = query.toLowerCase().trim();
    let rewrittenQuery = query;
    let inferredService = context.lastService;

    // Handle date-based follow-ups
    const datePatterns = {
      'yesterday': 'yesterday',
      'tomorrow': 'tomorrow',
      'today': 'today',
      'last week': 'last week',
      'this week': 'this week',
      'last month': 'last month',
      'this month': 'this month'
    };

    for (const [pattern, dateStr] of Object.entries(datePatterns)) {
      if (lowerQuery.includes(pattern) || lowerQuery === pattern || lowerQuery === `what about ${pattern}?`) {
        // Add topic context
        if (context.lastService === 'canteen') {
          rewrittenQuery = `What is the canteen menu for ${dateStr}?`;
        } else if (context.lastService === 'entryexit') {
          rewrittenQuery = `What was my entry/exit time ${dateStr}?`;
        } else if (context.lastTopic) {
          rewrittenQuery = `${context.lastTopic} for ${dateStr}`;
        }
        break;
      }
    }

    // Handle "what about X" patterns
    if (lowerQuery.startsWith('what about') || lowerQuery.startsWith('and what about')) {
      const subject = query.replace(/^(and\s+)?what about\s*/i, '').replace(/\?$/, '').trim();
      if (context.lastService === 'canteen') {
        rewrittenQuery = `What is the canteen menu for ${subject}?`;
      } else if (context.lastService === 'entryexit') {
        rewrittenQuery = `What was my entry/exit time for ${subject}?`;
      }
    }

    return {
      rewrittenQuery,
      originalQuery: query,
      wasRewritten: rewrittenQuery !== query,
      inferredService
    };
  }

  /**
   * Extract topic from an AI response for context tracking
   */
  extractTopicFromResponse(response, service) {
    const routingConfig = configService.getRoutingConfigSync();
    const topics = routingConfig.topicKeywords || {};

    const serviceTopics = topics[service] || [];
    const lowerResponse = response.toLowerCase();

    for (const topic of serviceTopics) {
      if (lowerResponse.includes(topic)) {
        return topic;
      }
    }

    return service; // Default to service name as topic
  }

  /**
   * Extract date from query or response
   */
  extractDate(text) {
    const lowerText = text.toLowerCase();

    if (lowerText.includes('today')) return 'today';
    if (lowerText.includes('yesterday')) return 'yesterday';
    if (lowerText.includes('tomorrow')) return 'tomorrow';

    // Try to find date patterns
    const dateMatch = text.match(/(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})|(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*\d{0,4})/i);
    if (dateMatch) {
      return dateMatch[0];
    }

    return null;
  }

  /**
   * Get conversation history for API responses
   */
  getMessageHistory(sessionId) {
    const context = this.getContext(sessionId);
    return context.messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }

  /**
   * Clean up expired contexts
   */
  cleanupExpiredContexts() {
    const now = Date.now();
    for (const [sessionId, context] of this.contexts.entries()) {
      if (now - context.updatedAt > this.contextExpiryMs) {
        this.contexts.delete(sessionId);
        console.log('[ConversationContext] Cleaned up expired context:', sessionId);
      }
    }
  }

  /**
   * Clear context for a session
   */
  clearContext(sessionId) {
    this.contexts.delete(sessionId);
  }
}

module.exports = new ConversationContextService();
