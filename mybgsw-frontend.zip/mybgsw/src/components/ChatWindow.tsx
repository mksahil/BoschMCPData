import { useState, useRef, useEffect, KeyboardEvent, useCallback } from "react";
import { Send, X, Bot, User, MapPin, Sparkles, Mic, MicOff, ThumbsUp, ThumbsDown } from "lucide-react";
import { cn, generateUUID, renderMarkdown } from "@/lib/utils";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Label } from "./ui/label";
import { toast } from "sonner";
import { API_ENDPOINTS } from "@/config";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";

// Web Speech API type declaration
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

interface Banner {
  id: string;
  title: string;
  description: string;
  tag: string;
  hasImage: boolean;
  imageBase64?: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  banners?: Banner[];
  conversationId?: number | null;
  feedback?: number; // -1 = thumbs down, 0 = no feedback, 1 = thumbs up
}

interface ChatWindowProps {
  isOpen: boolean;
  onClose: () => void; // This toggles the open state
}

export const ChatWindow = ({ isOpen, onClose: onToggle }: ChatWindowProps) => {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI companion. I can help you with:\n• Checking your schedule and tasks\n• Booking commute and cafeteria\n• Finding mentors and learning paths\n• Managing leave and travel\n• Tracking your progress\n\nHow can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [waitingForLocation, setWaitingForLocation] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null);
  const [activeService, setActiveService] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeechRecognitionSupported, setIsSpeechRecognitionSupported] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Check if browser supports Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setIsSpeechRecognitionSupported(false);
    }
  }, []);

  // Auto-scroll to the latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Speech recognition handler
  const toggleVoice = useCallback(() => {
    if (isListening) {
      // Stop listening
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const isBrowser = typeof window !== 'undefined';
      const isFirefox = isBrowser && /Firefox/.test(navigator.userAgent);
      const message = isFirefox 
        ? 'Voice input is not supported in Firefox. Please use Chrome, Edge, or Safari.'
        : 'Speech recognition is not supported in your browser. Try Chrome, Edge, or Safari.';
      toast.error(message);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setMessage(prev => prev ? prev + ' ' + transcript : transcript);
      toast.success('Voice captured!');
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please allow microphone permissions.');
      } else {
        toast.error('Voice input failed. Please try again.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, [isListening]);


  // Generate unique session ID for conversation context
  const [sessionId] = useState(() => generateUUID());

  const getServicePrefix = (query: string): string => {
    const q = query.toLowerCase();

    // Seat booking keywords
    if (q.includes('seat') || q.includes('desk') || (q.includes('book') && (q.includes('office') || q.includes('workstation') || q.includes('floor')))) {
      return 'seat booking: ';
    }

    // Travel keywords (broader set)
    if (['travel', 'flight', 'trip', 'hotel', 'visa', 'business trip', 'train', 'bus', 'ticket', 'booking', 'delhi', 'bangalore', 'mumbai', 'to', 'from'].some(k => q.includes(k))) {
      return 'travel: ';
    }

    // Canteen keywords
    if (['canteen', 'cafeteria', 'lunch', 'breakfast', 'menu', 'food', 'eat', 'hungry'].some(k => q.includes(k))) {
      return 'canteen: ';
    }

    // Fallback to active service context
    if (activeService) {
      const s = activeService.toLowerCase();
      if (s.includes('travel')) return 'travel: ';
      if (s.includes('canteen') || s.includes('cafeteria')) return 'canteen: ';
      if (s.includes('seat')) return 'seat booking: ';
    }

    return '';
  };

  const handleLocationSelect = async (locationId: number) => {
    const locationName = locationId === 1 ? 'Bangalore' : 'Coimbatore';
    const userMessage: Message = {
      role: 'user',
      content: locationName,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setSelectedLocation(locationId);
    setWaitingForLocation(false);
    setIsTyping(true);

    // Re-send the last query with location context
    const lastUserMessage = [...messages].reverse().find(msg => msg.role === "user");
    if (lastUserMessage) {
      try {
        const response = await fetch(API_ENDPOINTS.canteenQuery, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
            'X-Employee-Number': user?.employeeNumber || '',
          },
          body: JSON.stringify({
            query: lastUserMessage.content,
            sessionId,
            locationId,
            employeeNumber: user?.employeeNumber || ''
          })
        });

        const data = await response.json();

        if (response.ok) {
          const aiMessage: Message = {
            role: "assistant",
            content: data.response,
            timestamp: new Date()
          };
          setMessages(prev => [...prev, aiMessage]);
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }
    setIsTyping(false);
  };

  const handleSend = async (incomingMessage?: string) => {
    const messageToSend = incomingMessage || message;
    if (!messageToSend.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: messageToSend,
      timestamp: new Date()
    };

    logger.logChatMessage(messageToSend, true, {
      messageLength: messageToSend.length,
      sessionTime: new Date().getTime() - new Date(sessionStorage.getItem('sessionStartTime') || '').getTime()
    });

    const qPrefix = getServicePrefix(messageToSend);
    let finalQuery = `${qPrefix}${messageToSend}`;

    // REINFORCED: Natural Language Context Wrapping
    // If we are in a service mode, always use the explicit "my own" wrapper to bypass backend guardrails.
    if (activeService) {
      const s = activeService.toLowerCase();
      if (s.includes('travel')) {
        finalQuery = `travel: I am providing details for my own travel booking: ${messageToSend}`;
      } else if (s.includes('seat')) {
        finalQuery = `seat booking: I am providing details for my own seat booking: ${messageToSend}`;
      } else if (s.includes('canteen') || s.includes('cafeteria')) {
        finalQuery = `canteen: I am providing details for my canteen order: ${messageToSend}`;
      }
    }

    // Get last 5 messages for context (skip initial greeting, focus on actual conversation)
    // CRITICAL: Include prefixes for BOTH user and assistant messages in history 
    // This gives the backend a much stronger signal of a locked service mode
    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => {
      const msgPrefix = getServicePrefix(msg.content);
      let content = msg.content;
      
      // Wrap user messages in history too if they were follow-ups
      if (msg.role === 'user' && !msgPrefix && activeService) {
        const s = activeService.toLowerCase();
        if (s.includes('travel')) content = `I am providing details for my own travel booking: ${msg.content}`;
        else if (s.includes('seat')) content = `I am providing details for my own seat booking: ${msg.content}`;
        else if (s.includes('canteen')) content = `I am providing details for my canteen order: ${msg.content}`;
      }

      const finalService = msgPrefix.replace(': ', '') || activeService || '';
      const finalPrefix = finalService ? `${finalService.toLowerCase()}: ` : '';
      
      return {
        role: msg.role,
        content: `${finalPrefix}${content}`
      };
    });

    // message routing logs removed for security

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsTyping(true);

    try {
      // Use unified smart chat endpoint - AI will route to correct service
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: finalQuery,
          service: qPrefix.replace(': ', '') || activeService, // Explicit service hint
          sessionId,
          locationId: selectedLocation,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory  // Send last 5 messages for context
        })
      });

      const data = await response.json();

      if (response.ok) {
        // Handle location selection for canteen queries
        if (data.needs_location) {
          setWaitingForLocation(true);
        }

        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date(),
          banners: data.banners, // Include banner data if available
          conversationId: data.conversationId || null,
          feedback: 0 // No feedback yet
        };

        // Log AI response with service info
        logger.logChatMessage(aiMessage.content, false, {
          responseTime: new Date().getTime() - userMessage.timestamp.getTime(),
          userQuery: messageToSend,
          service: data.service,
          serviceName: data.serviceName
        });

        // Update active service for next turns
        if (data.service) {
          setActiveService(data.service);
        }

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Chat query error:', error);
      const errorMessage: Message = {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }

    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Handle feedback (thumbs up/down)
  const handleFeedback = async (messageIndex: number, feedback: number) => {
    const msg = messages[messageIndex];
    if (!msg.conversationId) return;

    // Optimistically update UI
    setMessages(prev => prev.map((m, i) =>
      i === messageIndex ? { ...m, feedback } : m
    ));

    try {
      const response = await fetch(API_ENDPOINTS.chatFeedback, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: msg.conversationId,
          feedback
        })
      });

      if (!response.ok) {
        throw new Error('Failed to save feedback');
      }

      toast.success(feedback === 1 ? 'Thanks for the positive feedback!' : 'Thanks for your feedback!');
    } catch (error) {
      console.error('Feedback error:', error);
      // Revert on error
      setMessages(prev => prev.map((m, i) =>
        i === messageIndex ? { ...m, feedback: 0 } : m
      ));
      toast.error('Failed to save feedback');
    }
  };

  // Autofocus input when not typing or waiting for action
  useEffect(() => {
    if (isOpen && !isTyping && !waitingForLocation) {
      // Small timeout to allow transitions to complete
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen, isTyping, waitingForLocation]);

  return (
    <div
      className="fixed left-0 right-0 z-40 transition-all duration-300 ease-out pointer-events-none"
      style={{ bottom: '70px' }}
    >
      <div className="container mx-auto px-4 max-w-4xl pointer-events-auto">
        {/* Main chat container - expands from bottom */}
        <div
          className={cn(
            "relative bg-card rounded-t-2xl shadow-sm transition-all duration-300 ease-out overflow-hidden",
            isOpen ? "h-[70vh] max-h-[600px]" : "h-0"
          )}
        >

          {/* Chat content - only visible when open */}
          <div className={cn(
            "relative flex flex-col h-full transition-opacity duration-200",
            isOpen ? "opacity-100" : "opacity-0"
          )}>
            {/* Header */}
            <div className="bg-gradient-primary px-4 py-3 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                  <Sparkles className="w-3 h-3 text-primary-foreground" />
                </div>
                <h3 className="text-primary-foreground font-medium text-sm">Ask MyBGSW.AI</h3>
              </div>
              <button
                onClick={onToggle}
                className="w-7 h-7 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20 flex items-center justify-center transition-colors"
              >
                <X className="w-3.5 h-3.5 text-primary-foreground" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "flex gap-2",
                    msg.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  {msg.role === "assistant" && (
                    <div className="w-7 h-7 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
                    </div>
                  )}
                  <div
                    className={cn(
                      "rounded-2xl p-3 max-w-[80%] shadow-sm",
                      msg.role === "user"
                        ? "bg-gradient-primary text-primary-foreground"
                        : "bg-secondary/60 text-foreground"
                    )}
                  >
                    <p className="text-sm whitespace-pre-line" dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />

                    {/* Render banner images if available */}
                    {msg.banners && msg.banners.length > 0 && (
                      <div className="mt-3 space-y-3">
                        {msg.banners.map((banner, bannerIdx) => (
                          banner.hasImage && banner.imageBase64 && (
                            <div key={bannerIdx} className="rounded-lg overflow-hidden border border-border">
                              <img
                                src={`data:image/png;base64,${banner.imageBase64}`}
                                alt={banner.title}
                                className="w-full h-auto max-h-48 object-cover"
                                onError={(e) => {
                                  // Try jpeg if png fails
                                  const img = e.target as HTMLImageElement;
                                  if (img.src.includes('image/png')) {
                                    img.src = `data:image/jpeg;base64,${banner.imageBase64}`;
                                  }
                                }}
                              />
                              <div className="p-2 bg-card">
                                <p className="text-xs font-medium">{banner.title}</p>
                              </div>
                            </div>
                          )
                        ))}
                      </div>
                    )}

                    <p className={cn(
                      "text-xs mt-1",
                      msg.role === "user" ? "text-primary-foreground/60" : "text-muted-foreground"
                    )}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>

                    {/* Feedback buttons for assistant messages (skip initial greeting) */}
                    {msg.role === "assistant" && idx > 0 && (
                      <div className="flex items-center gap-1 mt-1.5 -mb-1">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleFeedback(idx, 1); }}
                          className={cn(
                            "p-1 rounded-md transition-all duration-200",
                            msg.feedback === 1
                              ? "text-green-500 bg-green-500/10"
                              : "text-muted-foreground/40 hover:text-green-500 hover:bg-green-500/10"
                          )}
                          title="Helpful"
                          disabled={msg.feedback === 1}
                        >
                          <ThumbsUp className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleFeedback(idx, -1); }}
                          className={cn(
                            "p-1 rounded-md transition-all duration-200",
                            msg.feedback === -1
                              ? "text-red-500 bg-red-500/10"
                              : "text-muted-foreground/40 hover:text-red-500 hover:bg-red-500/10"
                          )}
                          title="Not helpful"
                          disabled={msg.feedback === -1}
                        >
                          <ThumbsDown className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                  {msg.role === "user" && (
                    <div className="w-7 h-7 bg-gradient-accent rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-accent-foreground font-medium text-[10px]">
                        {user?.name
                          ? user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
                          : 'ME'}
                      </span>
                    </div>
                  )}
                </div>
              ))}
              {isTyping && (
                <div className="flex gap-2">
                  <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <div className="bg-secondary rounded-lg p-3">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                    </div>
                  </div>
                </div>
              )}

              {/* Location Selection */}
              {waitingForLocation && !isTyping && (
                <div className="flex flex-col gap-2 items-center p-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <MapPin className="w-4 h-4" />
                    <span>Please select your location:</span>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleLocationSelect(1)}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                    >
                      Bangalore
                    </button>
                    <button
                      onClick={() => handleLocationSelect(2)}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                    >
                      Coimbatore
                    </button>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          </div>
        </div>

        {/* Bottom Input Bar - Always visible, serves as both collapsed and expanded input */}
        <div className="relative">
          <div className={cn(
            "relative bg-card shadow-sm border border-border/80 transition-all duration-300",
            isOpen ? "rounded-b-2xl rounded-t-none" : "rounded-2xl"
          )}>
            <div className="flex items-center gap-3 p-3">
              {/* AI Indicator */}
              <button
                onClick={onToggle}
                className="flex-shrink-0 w-9 h-9 bg-gradient-primary rounded-full flex items-center justify-center hover:opacity-90 transition-opacity cursor-pointer pointer-events-auto"
              >
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              </button>

              {/* Input */}
              <div className="flex-1">
                <Input
                  ref={inputRef}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  onFocus={() => !isOpen && onToggle()} // Opens the chat when focused
                  placeholder="Ask me anything..."
                  className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-sm"
                  disabled={isTyping}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={toggleVoice}
                  disabled={!isSpeechRecognitionSupported}
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300",
                    !isSpeechRecognitionSupported
                      ? "bg-secondary/30 text-muted-foreground/50 cursor-not-allowed opacity-50"
                      : isListening
                      ? "bg-destructive text-destructive-foreground shadow-glow animate-pulse"
                      : "bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary"
                  )}
                  title={
                    !isSpeechRecognitionSupported
                      ? "Voice input not supported in this browser"
                      : isListening
                      ? "Stop listening"
                      : "Voice input"
                  }
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                </button>

                <button
                  onClick={() => handleSend()}
                  disabled={!message.trim() || isTyping}
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center transition-colors",
                    message.trim() && !isTyping
                      ? "bg-gradient-primary text-primary-foreground hover:opacity-90"
                      : "bg-secondary/50 text-muted-foreground cursor-not-allowed"
                  )}
                  title="Send message"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>


      </div>
    </div>
  );
};
