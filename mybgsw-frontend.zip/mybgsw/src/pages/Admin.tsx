
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, Plus, Trash2, Save, Server, ExternalLink, Sparkles, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

// ... existing code ...

// ... existing code ...

interface Service {
    id: string;
    name: string;
    baseUrl: string;
    description: string;
    keywords: string[];
}

const Admin = () => {
    console.log("Admin: Component Rendered");
    const [services, setServices] = useState<Service[]>([]);
    const [loading, setLoading] = useState(true);
    const [isAdding, setIsAdding] = useState(false);
    const [analyzing, setAnalyzing] = useState(false); // New state
    const [newService, setNewService] = useState<Service>({
        // ... existing code ...
    });
    const [keywordsInput, setKeywordsInput] = useState('');
    const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);

    const { toast } = useToast();
    const navigate = useNavigate();

    // Planets available for mapping
    const availablePlanets = [
        { id: 'gym', name: 'Gym' },
        { id: 'parking', name: 'Parking' },
        { id: 'effort', name: 'Effort' },
        { id: 'projects', name: 'Projects' },
        { id: 'meetings', name: 'Meetings' },
        { id: 'courses', name: 'Courses' },
        { id: 'certifications', name: 'Badges' },
        { id: 'blogs', name: 'Blogs' },
        { id: 'watchlist', name: 'Watchlist' },
        { id: 'music', name: 'Music' },
        { id: 'wayfinder', name: 'WayFinder' },
        { id: 'holidays', name: 'Holidays' },
    ];

    useEffect(() => {
        console.log("Admin: useEffect fired");
        fetchServices();
    }, []);

    // New Auto-Detect Handler
    const handleAutoDetect = async () => {
        if (!newService.baseUrl) {
            toast({
                title: "URL Required",
                description: "Please enter an MCP URL first.",
                variant: "destructive",
            });
            return;
        }

        setAnalyzing(true);
        try {
            // this fixed: Issue #17 - Insecure Transmission
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services/discover`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: newService.baseUrl }),
            });

            const data = await response.json();

            if (data.success && data.analysis) {
                setNewService(prev => ({
                    ...prev,
                    name: data.analysis.name || prev.name,
                    description: data.analysis.description || prev.description,
                    // Auto-select planet if recommended
                    id: data.analysis.recommendedPlanetId || prev.id,
                    baseUrl: data.analysis.derivedFromUrl || prev.baseUrl
                }));

                // Set keywords
                if (data.analysis.keywords && Array.isArray(data.analysis.keywords)) {
                    setKeywordsInput(data.analysis.keywords.join(', '));
                }

                toast({
                    title: "Discovery Successful",
                    description: "Smart analysis complete! Fields have been auto-filled.",
                });
            } else {
                throw new Error(data.error || 'Discovery failed');
            }
        } catch (error) {
            console.error(error);
            toast({
                title: "Discovery Failed",
                description: "Could not analyze the MCP. Please fill details manually.",
                variant: "destructive",
            });
        } finally {
            setAnalyzing(false);
        }
    };

    const fetchServices = async () => {
        console.log("Admin: fetchServices started");
        try {
            // this fixed: Issue #17 - Insecure Transmission
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services`);
            console.log("Admin: Response received", response.status);

            const data = await response.json();
            console.log("Admin: Data received", data);

            // [SQ-FIX] Issue #10 (Rule S3923): Removed redundant else-if condition
            if (data.services) {
                console.log("Admin: Setting services (direct)", data.services);
                setServices(data.services);
            } else {
                console.error("Admin: Invalid data format", data);
                toast({
                    title: "Error fetching services",
                    description: data.error || "Unknown error",
                    variant: "destructive"
                });
            }
        } catch (error) {
            console.error('Admin: Failed to fetch services:', error);
            toast({
                title: "Connection Error",
                description: "Could not connect to backend",
                variant: "destructive"
            });
        } finally {
            console.log("Admin: Finally block - setting loading false");
            setLoading(false);
        }
    };

    const handleSaveService = async () => {
        try {
            if (!newService.id || !newService.name || !newService.baseUrl) {
                toast({
                    title: "Validation Error",
                    description: "Please fill in all required fields",
                    variant: "destructive"
                });
                return;
            }

            // Format keywords
            const keywords = keywordsInput.split(',').map(k => k.trim()).filter(k => k);
            const serviceToSave = { ...newService, keywords };

            // this fixed: Issue #17 - Insecure Transmission
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(serviceToSave)
            });

            const data = await response.json();
            if (data.success) {
                toast({
                    title: "Success",
                    description: "Service saved successfully"
                });
                setIsAdding(false);
                setNewService({ id: '', name: '', baseUrl: '', description: '', keywords: [] });
                setKeywordsInput('');
                fetchServices();
            } else {
                toast({
                    title: "Error saving service",
                    description: data.error,
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to save service",
                variant: "destructive"
            });
        }
    };

    const handleDeleteService = (id: string) => {
        setServiceToDelete(id);
    };

    const confirmDeleteService = async () => {
        if (!serviceToDelete) return;

        try {
            // this fixed: Issue #17 - Insecure Transmission
            const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
            const response = await fetch(`${apiUrl}/api/admin/services/${serviceToDelete}`, {
                method: 'DELETE'
            });
            const data = await response.json();

            if (data.success) {
                toast({ title: "Service deleted" });
                fetchServices();
            } else {
                toast({
                    title: "Error",
                    description: data.error,
                    variant: "destructive"
                });
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to delete service",
                variant: "destructive"
            });
        } finally {
            setServiceToDelete(null);
        }
    };

    return (
        <div className="min-h-screen bg-background p-8">
            <div className="max-w-4xl mx-auto space-y-8">

                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" onClick={() => navigate('/')}>
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold tracking-tight">MCP Service Admin</h1>
                            <p className="text-muted-foreground">Manage dynamic MCP server connections and planet mappings</p>
                        </div>
                    </div>
                    <Button onClick={() => setIsAdding(true)}>
                        <Plus className="h-4 w-4 mr-2" /> Add Service
                    </Button>
                </div>

                {isAdding && (
                    <Card className="border-primary/50 shadow-lg animate-in fade-in slide-in-from-top-4">
                        <CardHeader>
                            <CardTitle>Add New Service</CardTitle>
                            <CardDescription>Configure a new MCP server connection</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="service-id">Planet ID / Service ID</Label>
                                    <select
                                        id="service-id"
                                        className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                                        value={newService.id}
                                        onChange={(e) => {
                                            const planet = availablePlanets.find(p => p.id === e.target.value);
                                            setNewService({ ...newService, id: e.target.value, name: planet ? `${planet.name} Assistant` : '' })
                                        }}
                                    >
                                        <option value="">Select a Planet...</option>
                                        {availablePlanets.map(planet => (
                                            <option key={planet.id} value={planet.id}>{planet.name} ({planet.id})</option>
                                        ))}
                                        <option value="custom">Custom ID...</option>
                                    </select>
                                    {newService.id === 'custom' && (
                                        <Input
                                            placeholder="Enter custom ID"
                                            onChange={(e) => setNewService({ ...newService, id: e.target.value })}
                                        />
                                    )}
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="service-name">Service Name</Label>
                                    <Input
                                        id="service-name"
                                        placeholder="e.g. Gym Assistant"
                                        value={newService.name}
                                        onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="base-url">MCP Server URL</Label>
                                <div className="space-y-2">
                                    <div className="relative">
                                        <Server className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                        <Input
                                            id="base-url"
                                            className="pl-9"
                                            placeholder="https://mcp-server.azurewebsites.net"
                                            value={newService.baseUrl}
                                            onChange={(e) => setNewService({ ...newService, baseUrl: e.target.value })}
                                        />
                                    </div>
                                    <Button
                                        type="button"
                                        variant="secondary"
                                        size="sm"
                                        className="w-full"
                                        onClick={handleAutoDetect}
                                        disabled={analyzing}
                                    >
                                        {analyzing ? (
                                            <>
                                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                                Analyzing Capabilities...
                                            </>
                                        ) : (
                                            <>
                                                <Sparkles className="mr-2 h-4 w-4 text-purple-500" />
                                                Auto-Detect Details
                                            </>
                                        )}
                                    </Button>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description">Description (for AI Router)</Label>
                                <Input
                                    id="description"
                                    placeholder="What does this service do?"
                                    value={newService.description}
                                    onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="keywords">Keywords (comma separated)</Label>
                                <Input
                                    id="keywords"
                                    placeholder="gym, workout, exercise"
                                    value={keywordsInput}
                                    onChange={(e) => setKeywordsInput(e.target.value)}
                                />
                            </div>

                        </CardContent>
                        <CardFooter className="flex justify-end gap-2">
                            <Button variant="ghost" onClick={() => setIsAdding(false)}>Cancel</Button>
                            <Button onClick={handleSaveService}>
                                <Save className="h-4 w-4 mr-2" /> Save Service
                            </Button>
                        </CardFooter>
                    </Card>
                )}

                <div className="grid gap-4">
                    <h2 className="text-xl font-semibold">Active Services</h2>
                    {loading ? (
                        <div className="text-center py-10 text-muted-foreground">Loading services...</div>
                    ) : services.length === 0 ? (
                        <div className="text-center py-10 border rounded-lg bg-muted/20 text-muted-foreground">
                            No dynamic services configured. Add one to get started.
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {services.map(service => (
                                <Card key={service.id} className="hover:border-primary/50 transition-colors">
                                    <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                                        <CardTitle className="text-lg font-medium">
                                            {service.name}
                                            <Badge variant="secondary" className="ml-2 text-xs font-normal">{service.id}</Badge>
                                        </CardTitle>
                                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDeleteService(service.id)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-sm text-muted-foreground mb-4">{service.description}</div>
                                        <div className="space-y-2 text-xs">
                                            <div className="flex items-center gap-2">
                                                <Server className="h-3 w-3" />
                                                <span className="truncate text-blue-500 font-mono">{service.baseUrl}</span>
                                            </div>
                                            <div className="flex flex-wrap gap-1 mt-2">
                                                {service.keywords && service.keywords.map(k => (
                                                    <Badge key={k} variant="outline" className="text-[10px]">{k}</Badge>
                                                ))}
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </div>

                <AlertDialog open={!!serviceToDelete} onOpenChange={(open) => !open && setServiceToDelete(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the MCP service configuration from the system.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setServiceToDelete(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDeleteService} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete Service</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>

            </div>
        </div>
    );
};

export default Admin;
