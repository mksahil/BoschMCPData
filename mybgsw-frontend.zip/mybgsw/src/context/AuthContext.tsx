import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { logoutAzureAD } from '@/services/azureAuthService';

interface User {
  employeeNumber: string;
  name: string;
  accessToken: string;
  tokenType: string;
  entityId: string;
  entityName: string;
  isTemporaryPassword: boolean;
  loginTimestamp: string;
  ntid: string;
  expiresIn: number;
  issuedAt: string;
  expiresAt: string;
  sessionId?: string;
  loginMethod?: 'credential' | 'sso';
}

interface ArenaTokenResponse {
  userName: string;
  Name?: string;
  access_token: string;
  token_type: string;
  EntityId: string;
  EntityName: string;
  IsTemporaryPassword: string;
  LoginTimeStamp: string;
  NTID: string;
  expires_in: number;
  '.issued': string;
  '.expires': string;
  sessionId?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (employeeNumber: string, password: string, isPreEncrypted?: boolean) => Promise<{ success: boolean; error?: string }>;
  ssoLogin: (arenaTokenData: ArenaTokenResponse) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = sessionStorage.getItem('mybgsw_user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser) as User;
        const expiresAt = new Date(parsedUser.expiresAt);
        if (expiresAt > new Date()) {
          setUser(parsedUser);
        } else {
          sessionStorage.removeItem('mybgsw_user');
        }
      } catch {
        sessionStorage.removeItem('mybgsw_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (
    employeeNumber: string,
    password: string,
    isPreEncrypted: boolean = false,
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      const API_BASE = import.meta.env.PROD
        ? 'https://my-bgsw-ai-api-dev.azurewebsites.net'
        : 'http://localhost:3001';

      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: employeeNumber,
          password,
          isPreEncrypted,
        }),
      });

      const data = (await response.json()) as ArenaTokenResponse;

      if (!response.ok) {
        return { success: false, error: (data as { error?: string }).error || 'Login failed' };
      }

      const userData: User = {
        employeeNumber: data.userName,
        name: data.Name?.trim() || data.userName,
        accessToken: data.access_token,
        tokenType: data.token_type,
        entityId: data.EntityId,
        entityName: data.EntityName,
        isTemporaryPassword: data.IsTemporaryPassword === 'True',
        loginTimestamp: data.LoginTimeStamp,
        ntid: data.NTID,
        expiresIn: data.expires_in,
        issuedAt: data['.issued'],
        expiresAt: data['.expires'],
        sessionId: data.sessionId,
        loginMethod: 'credential',
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));
      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  const ssoLogin = async (arenaTokenData: ArenaTokenResponse): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      if (!arenaTokenData) {
        return { success: false, error: 'No token data provided' };
      }

      const userData: User = {
        employeeNumber: arenaTokenData.userName,
        name: arenaTokenData.Name?.trim() || arenaTokenData.userName,
        accessToken: arenaTokenData.access_token,
        tokenType: arenaTokenData.token_type,
        entityId: arenaTokenData.EntityId,
        entityName: arenaTokenData.EntityName,
        isTemporaryPassword: arenaTokenData.IsTemporaryPassword === 'True',
        loginTimestamp: arenaTokenData.LoginTimeStamp,
        ntid: arenaTokenData.NTID,
        expiresIn: arenaTokenData.expires_in,
        issuedAt: arenaTokenData['.issued'],
        expiresAt: arenaTokenData['.expires'],
        sessionId: arenaTokenData.sessionId,
        loginMethod: 'sso',
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));
      return { success: true };
    } catch (error) {
      console.error('SSO login error:', error);
      return { success: false, error: 'SSO login failed. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      if (user?.loginMethod === 'sso') {
        await logoutAzureAD();
      }
      setUser(null);
      sessionStorage.removeItem('mybgsw_user');
    } catch (error) {
      console.error('Logout error:', error);
      setUser(null);
      sessionStorage.removeItem('mybgsw_user');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        ssoLogin,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
