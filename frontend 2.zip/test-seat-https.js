const https = require('https');

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-123',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-123',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      employee_id: '34835634',
      user_id: '34835634',
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      user_data: {
        id: '34835634',
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      }
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

console.log('Calling A2A Seat Booking Agent (Direct HTTPS)...');
const req = https.request(options, (res) => {
  console.log('Status:', res.statusCode);
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Response:');
    try {
      console.log(JSON.stringify(JSON.parse(body), null, 2));
    } catch (e) {
      console.log(body);
    }
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
