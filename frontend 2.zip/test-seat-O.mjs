import https from 'https';
import fs from 'fs';

const employeeId = '34835634';
const name = 'Manjunath';
const email = 'manjunath@bosch.com';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-O',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-O',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-O'
      },
      // Candidate O: user_data with 'id' instead of 'employee_id'
      booking_mode: 'seat',
      travel_mode: 'seat',
      employee_id: employeeId,
      user_id: employeeId,
      user_name: name,
      user_email: email,
      user_data: {
        id: employeeId,
        name: name,
        email: email
      }
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

console.log('Calling A2A Seat Booking Agent (Candidate O user_data.id)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-O.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-O.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
