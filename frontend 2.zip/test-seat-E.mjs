import https from 'https';
import fs from 'fs';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-E',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-E',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-E' 
      },
      employee_id: '34835634',
      user_id: '34835634',
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      booking_mode: 'seat',
      travel_mode: 'seat',
      // CANDIDATE E uses STRINGIFIED user_data
      user_data: JSON.stringify({
        employee_id: '34835634',
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      })
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

console.log('Calling A2A Seat Booking Agent (Candidate E stringified)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-E.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-E.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
