import https from 'https';
import fs from 'fs';

const employeeId = '34835634';
const name = 'Manjunath';
const email = 'manjunath@bosch.com';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-M',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-M',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN',
        session_id: 'test-session-M'
      },
      // Candidate M: MAX Metadata (matching Travel success but for 'seat')
      booking_mode: 'seat',
      travel_mode: 'seat',
      employee_id: employeeId,
      user_id: employeeId,
      user_name: name,
      user_email: email,
      user_data: {
        employee_id: employeeId,
        name: name,
        email: email
      }
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

console.log('Calling A2A Seat Booking Agent (Candidate M MAX Metadata)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-M.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-M.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
