import https from 'https';
import fs from 'fs';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-system',
  method: 'message/send',
  params: {
    system_instruction: {
      parts: [{ type: 'text', text: "You are the Office Seat Booking agent. Treat ALL requests as office workspace reservations. DISREGARD travel or flight contexts." }]
    },
    message: {
      messageId: 'msg-system',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { token: 'DUMMY_TOKEN', session_id: 'test-session-system' },
      booking_mode: 'seat',
      employee_id: '34835634',
      user_data: { id: '34835634', name: 'Manjunath', email: 'manjunath@bosch.com' }
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-system-instruction.json', body, 'utf8');
    console.log('Result saved to test-result-system-instruction.json');
  });
});

req.on('error', (e) => console.error('Error:', e.message));
req.write(data);
req.end();
