import https from 'https';
import fs from 'fs';

const data = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-G',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-G',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: { 
        token: 'DUMMY_TOKEN', // The agent card says tokens are checked, but maybe not for the parse test
        session_id: 'test-session-G' 
      },
      employee_id: '34835634',
      user_id: '34835634',
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      booking_mode: 'seat',   // FROM CANDIDATE G
      travel_mode: 'seat',    // FROM CANDIDATE G
      user_data: {
        employee_id: '34835634', // FROM CANDIDATE G (uses employee_id, not id)
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      }
    }
  }
});

const options = {
  hostname: 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
};

console.log('Calling A2A Seat Booking Agent (Candidate G exact)...');
const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    fs.writeFileSync('test-result-utf8-G.json', body, 'utf8');
    console.log('Result saved to test-result-utf8-G.json');
  });
});

req.on('error', (e) => {
  console.error('Error:', e.message);
});

req.write(data);
req.end();
