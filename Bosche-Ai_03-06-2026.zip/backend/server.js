const path = require('path');
// Load .env from the backend directory
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const fs = require('fs-extra');
const https = require('https');
const { rateLimit } = require('express-rate-limit');
const axios = require('axios');
const { format } = require('date-fns');
const boschAuthService = require('./services/bosch-auth-service');
const communityService = require('./services/community-service');
const conversationContextService = require('./services/conversation-context-service');
const conversationDbService = require('./services/conversation-db-service');
const consentDbService = require('./services/consent-db-service');
const mcpServiceManager = require('./services/mcp-service-manager');
const mcpDiscoveryService = require('./services/mcp-discovery-service');
const configService = require('./services/config-service');
const GenericMCPClient = require('./services/generic-mcp-client');
const privacyGuardService = require('./services/privacy-guard-service');

// Bosch internal MCP servers use corporate PKI (Bosch root CA) not trusted by Node.js by default.
// rejectUnauthorized: false is intentional for internal-network services — not a public-internet risk.
const httpsAgent = new https.Agent({
  rejectUnauthorized: false // [INTERNAL-CA] Bosch corporate PKI — system CA not available to Node.js
});

// [FIX #1 | Rule S5144 - SSRF]: Extract Bearer token at the source using strict regex.
// Only a correctly-formed Bearer token (RFC 6750 chars) is forwarded.
// Malformed / injected values return null, breaking the taint chain before it can propagate.
function extractBearerToken(authHeader) {
  if (typeof authHeader !== 'string') return null;
  const match = authHeader.match(/^Bearer\s+([A-Za-z0-9\-_.~+/=]+)$/);
  if (!match) return null;
  return match[1]; // Only the clean token — no 'Bearer ' prefix, no special chars
}

const app = express();
const PORT = process.env.PORT || 3001;

// Normalise req.ip so rate-limit keys are stable across IPv4/IPv6 loopback variants.
// '1' trusts one hop (the immediate connection), which is correct for both local dev
// and Azure App Service (single reverse proxy). Without this, ::1 and ::ffff:127.0.0.1
// produce different keys and effectively bypass per-IP rate limiting.
app.set('trust proxy', 1);

// Middleware
const defaultCorsOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:8080',
  'http://103.230.85.80:3000',
  'https://my-bgsw-ai-dev.azurewebsites.net',
  'https://bgsw-as-mybgsw-ai-dev-001.azurewebsites.net',
  'https://bgsw-as-mybgsw-ai-qa-001.azurewebsites.net'
];
const configuredCorsOrigins = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(origin => origin.trim()).filter(Boolean)
  : defaultCorsOrigins;

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) {
      return callback(null, true);
    }

    if (configuredCorsOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error(`CORS not allowed for origin: ${origin}`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Employee-Number', 'X-User-Name']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ── Rate Limiting ────────────────────────────────────────────────────────────
//
// Layer 1 — Global (IP-keyed, 100/min)
//   Catches bots/scrapers on all routes except /api/logs (activity logging
//   must never be blocked — it is a fire-and-forget observability call).
//
// Layer 2 — Chat (employee-keyed, 10/min)
//   Applied only to /api/chat — the conversational AI endpoint.
//
// Layer 3 — Service APIs (employee-keyed, 10/min)
//   Applied to domain-specific AI routes: /api/canteen/query,
//   /api/entryexit/query, /api/time-tracking/query.
//   Separate from chatRateLimiter so each bucket is independent.
//
// Layer 4 — Login (IP-keyed, 10/min)
//   Brute-force protection on /api/auth/login.
// ─────────────────────────────────────────────────────────────────────────────

// Shared helper — normalises IPv6 loopback variants to a single stable string
const normalizeIp = (req) => {
  const raw = req.ip || req.socket?.remoteAddress || 'unknown';
  return raw.replace(/^::ffff:/, '').replace(/^::1$/, '127.0.0.1');
};

// Shared handler factory — logs every 429 with user + IP context then sends the response
const makeLimitHandler = (limiterName, message) => (req, res) => {
  const ip = normalizeIp(req);
  const employee = req.headers['x-employee-number'] || '(no employee header)';
  const retryAfter = res.getHeader('Retry-After') || 60;
  console.warn(
    `[RateLimit] ${limiterName} triggered | employee=${employee} | ip=${ip} | ` +
    `path=${req.method} ${req.path} | retry-after=${retryAfter}s | ` +
    `ts=${new Date().toISOString()}`
  );
  res.status(429).json({ error: message, retryAfter: Number(retryAfter) });
};

const globalRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  skip: (req) => req.path.startsWith('/api/logs'),
  standardHeaders: true,
  legacyHeaders: false,
  handler: makeLimitHandler('GLOBAL', 'Too many requests from this IP. Please slow down.'),
});

app.use(globalRateLimiter);

// Chat AI — /api/chat only
const chatRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  keyGenerator: (req) => req.headers['x-employee-number'] || normalizeIp(req),
  standardHeaders: true,
  legacyHeaders: false,
  handler: makeLimitHandler('CHAT', 'Too many chat messages. You can send up to 10 messages per minute. Please wait before trying again.'),
});

// Service APIs — canteen / entry-exit / community / time-tracking
const serviceRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  keyGenerator: (req) => req.headers['x-employee-number'] || normalizeIp(req),
  standardHeaders: true,
  legacyHeaders: false,
  handler: makeLimitHandler('SERVICE', 'Too many service requests. You can make up to 10 requests per minute. Please wait before trying again.'),
});

const loginRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: makeLimitHandler('LOGIN', 'Too many login attempts. Please wait a minute before trying again.'),
});

// Ensure logs directory exists
const logsDir = path.join(__dirname, 'logs');
const sessionsDir = path.join(logsDir, 'sessions');
fs.ensureDirSync(logsDir);
fs.ensureDirSync(sessionsDir);

// Root endpoint for health checks
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    service: 'MyBGSW Backend API',
    timestamp: new Date().toISOString(),
    endpoints: ['/api/health', '/api/canteen/query', '/api/entryexit/query', '/api/logs']
  });
});

// Helper function to get log file path for today
const getDailyLogFile = () => {
  const today = format(new Date(), 'yyyy-MM-dd');
  return path.join(logsDir, `${today}_activity.json`);
};

// Helper function to get session log file
const getSessionLogFile = (sessionId) => {
  return path.join(sessionsDir, `${sessionId}.json`);
};

// API endpoint to log user activities
app.post('/api/logs', async (req, res) => {
  try {
    const logEntry = {
      ...req.body,
      serverTimestamp: new Date().toISOString(),
      ip: req.ip || req.connection.remoteAddress
    };

    // Filter out unwanted events at the server level too
    const blockedActions = ['mouse_activity', 'scroll_behavior', 'hover_event', 'scroll_depth', 'idle_detection'];
    if (blockedActions.includes(logEntry.action)) {
      console.log(`Blocked unwanted log: ${logEntry.action}`);
      return res.json({ success: true, blocked: true }); // Return success but don't save
    }

    // Write to daily log file
    const dailyLogFile = getDailyLogFile();
    await fs.appendFile(dailyLogFile, JSON.stringify(logEntry) + '\n');

    // Also write to session-specific log
    if (logEntry.sessionId) {
      if (!/^[a-zA-Z0-9_-]+$/.test(logEntry.sessionId)) {
        return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
      }
      // [FIX #2 | Rule S2083 - Path Traversal]: Path containment check for session log file
      const sessionLogFile = path.resolve(getSessionLogFile(logEntry.sessionId));
      if (!sessionLogFile.startsWith(path.resolve(sessionsDir))) {
        return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
      }
      await fs.appendFile(sessionLogFile, JSON.stringify(logEntry) + '\n');
    }

    console.log(`Logged: ${logEntry.action}`);
    res.json({ success: true });
  } catch (error) {
    console.error('Error logging activity:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get logs (for viewer)
app.get('/api/logs', async (req, res) => {
  try {
    const { date, sessionId, limit = 100 } = req.query;

    // Strict validation to prevent Path Traversal
    if (sessionId && !/^[a-zA-Z0-9_-]+$/.test(sessionId)) {
      return res.status(400).json({ success: false, error: 'Invalid sessionId format' });
    }
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    let logFile;
    if (sessionId) {
      logFile = getSessionLogFile(sessionId);
    } else if (date) {
      logFile = path.join(logsDir, `${date}_activity.json`);
    } else {
      logFile = getDailyLogFile();
    }

    // [FIX #2 | Rule S2083 - Path Traversal]: Path injection containment check — resolvedLogFile must stay within logsDir
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.json({ logs: [] });
    }

    // Read file and parse logs
    const content = await fs.readFile(resolvedLogFile, 'utf-8');
    const logs = content
      .trim()
      .split('\n')
      .filter(line => line)
      .map(line => {
        try {
          return JSON.parse(line);
        } catch (e) {
          return null;
        }
      })
      .filter(log => log !== null);

    // Return last 'limit' logs
    const limitedLogs = logs.slice(-limit);
    res.json({ logs: limitedLogs, total: logs.length });
  } catch (error) {
    console.error('Error retrieving logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to get all sessions
app.get('/api/sessions', async (req, res) => {
  try {
    const sessionFiles = await fs.readdir(sessionsDir);
    const sessions = sessionFiles
      .filter(file => file.endsWith('.json'))
      .map(file => file.replace('.json', ''));

    res.json({ sessions });
  } catch (error) {
    console.error('Error retrieving sessions:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// API endpoint to download logs
app.get('/api/logs/download', async (req, res) => {
  try {
    const { date, format: exportFormat = 'json' } = req.query;

    // Strict validation to prevent Path Traversal and HTTP Header CRLF Injection
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date format' });
    }

    const logFile = date
      ? path.join(logsDir, `${date}_activity.json`)
      : getDailyLogFile();

    // [FIX #2 | Rule S2083 - Path Traversal]: Path injection containment check for download endpoint
    const resolvedLogFile = path.resolve(logFile);
    if (!resolvedLogFile.startsWith(path.resolve(logsDir))) {
      return res.status(403).json({ success: false, error: 'Access denied: Invalid path' });
    }

    if (!await fs.pathExists(resolvedLogFile)) {
      return res.status(404).json({ error: 'Log file not found' });
    }

    if (exportFormat === 'json') {
      res.download(resolvedLogFile);
    } else if (exportFormat === 'csv') {
      // Convert to CSV format
      const content = await fs.readFile(resolvedLogFile, 'utf-8');
      const logs = content
        .trim()
        .split('\n')
        .filter(line => line)
        .map(line => JSON.parse(line));

      // Create CSV
      const csv = [
        'Timestamp,SessionID,Action,Page,Details',
        ...logs.map(log =>
          `"${log.timestamp}","${log.sessionId}","${log.action}","${log.page}","${JSON.stringify(log.details || {}).replace(/"/g, '""')}"`
        )
      ].join('\n');

      // [FIX #2 | CWE-113 - HTTP Header Injection]: Strip CR/LF characters from the filename
      // as defense-in-depth, even though date is already validated by the regex above.
      const safeFilename = (date || 'today').replace(/[\r\n]/g, '');
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}_logs.csv"`);
      res.send(csv);
    }
  } catch (error) {
    console.error('Error downloading logs:', error);
    res.status(500).json({ success: false, error: 'An internal server error occurred' });
  }
});

// Import MCP client - use HTTP client for deployed Canteen MCP, stdio for local
const { getClient: getHttpClient } = require('./mcp-client-http');
const { getClient: getStdioClient } = require('./mcp-client-stdio');

// Determine which canteen client to use based on environment
const isDeployedCanteen = process.env.CANTEEN_MCP_URL &&
  !process.env.CANTEEN_MCP_URL.includes('localhost');

const getClient = isDeployedCanteen ? getHttpClient : getStdioClient;
console.log(`Using ${isDeployedCanteen ? 'HTTP' : 'stdio'} client for Canteen MCP`);

// Import intelligent canteen handler
const { processIntelligentQuery } = require('./intelligent-canteen');

// Import Entry/Exit MCP client
const { getEntryExitV2Client } = require('./entryexit-mcp-v2-client');

// Store conversation contexts (in production, use Redis or similar)
const conversationContexts = new Map();

// Canteen query endpoint
app.post('/api/canteen/query', serviceRateLimiter, async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber } = req.body;

    // Extract auth headers
    let authToken = req.headers['authorization'] || req.body.authToken;
    if (authToken && typeof authToken === 'string') {
      authToken = authToken.trim().replace(/[\r\n]/g, '').replace(/^Bearer\s+/i, '');
    }
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('Processing canteen query:', query);
    console.log('Auth token present:', !!authToken);
    console.log('Employee number:', empNumber);

    // ── Token Auth: get Bosch JWT for canteen MCP calls ──
    let canteenJwtToken = null;
    if (authToken && empNumber) {
      try {
        const userTokens = await boschAuthService.getTokenForUser(empNumber, authToken);
        canteenJwtToken = userTokens.jwtToken;
        console.log('[CanteenQuery] JWT token obtained for MCP calls:', !!canteenJwtToken);
      } catch (tokenErr) {
        console.warn('[CanteenQuery] Failed to get JWT token (will call MCP without auth):', tokenErr.message);
      }
    }

    // Get or create conversation context
    let context = conversationContexts.get(sessionId) || {};

    // If locationId is provided (user selected location), update context
    if (locationId) {
      context.location_id = locationId;
      context.location = locationId === 1 ? 'bangalore' : 'coimbatore';
      conversationContexts.set(sessionId, context);
    }

    // Inject JWT so intelligent-canteen → mcp-client-http can pass it as Authorization header
    context.authToken = canteenJwtToken;

    // Get MCP client instance
    const mcpClient = await getClient();

    // Process query with intelligence
    const result = await processIntelligentQuery(query, mcpClient, context);

    // Update context if location was determined
    if (result.location_id) {
      context.location_id = result.location_id;
      context.location = result.location;
      conversationContexts.set(sessionId, context);
    }

    res.json({
      response: result.response,
      needs_location: result.needs_location,
      location_id: result.location_id,
      menuData: result.menuData, // Include structured menu data for CafeteriaCard
      success: true
    });

  } catch (error) {
    console.error('Canteen query error:', error);
    res.status(500).json({
      error: 'Failed to process canteen query',
      details: error.message
    });
  }
});

// Import Entry/Exit services
const entryExitService = require('./services/entry-exit-service-v2');

// ============= ENTRY/EXIT TIME TRACKING ENDPOINTS =============

// Main endpoint for time tracking queries
app.post('/api/time-tracking/query', serviceRateLimiter, async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Query is required'
      });
    }

    // Use default employee number if not provided
    const empNum = employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const userName = req.body.userName || null;

    console.log(`Time tracking query for employee ${empNum}: ${query}`);

    const result = await entryExitService.getEmployeeTimeData(empNum, query, userName);

    // If it's a privacy block, handle it gracefully
    if (result && result.success === false && result.answer) {
      return res.json({
        success: false,
        employeeNumber: empNum,
        response: result.answer,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      response: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Time tracking query error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process time tracking query',
      details: error.message
    });
  }
});

// Quick endpoint for today's entry time
app.get('/api/time-tracking/today-entry/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayEntry(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today entry:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Quick endpoint for today's exit time
app.get('/api/time-tracking/today-exit/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayExit(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today exit:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get today's working hours
app.get('/api/time-tracking/today-hours/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getTodayHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get today hours:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get weekly attendance summary
app.get('/api/time-tracking/weekly-summary/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.getWeeklyHours(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get weekly summary:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get monthly report
app.get('/api/time-tracking/monthly-report/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const currentDate = new Date();
    const month = req.query.month || (currentDate.getMonth() + 1);
    const year = req.query.year || currentDate.getFullYear();

    const result = await entryExitService.getMonthlyReport(empNum, month, year);
    res.json({
      success: true,
      employeeNumber: empNum,
      month,
      year,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get monthly report:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Check if late today
app.get('/api/time-tracking/late-check/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const result = await entryExitService.checkLateToday(empNum);
    res.json({
      success: true,
      employeeNumber: empNum,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to check late status:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get attendance statistics
app.get('/api/time-tracking/stats/:employeeNumber?', serviceRateLimiter, async (req, res) => {
  try {
    const empNum = req.params.employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER || '30945143';
    const period = req.query.period || 'this month';

    const result = await entryExitService.getAttendanceStats(empNum, period);
    res.json({
      success: true,
      employeeNumber: empNum,
      period,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get attendance stats:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Admin endpoint to clear cache
app.post('/api/time-tracking/cache/clear', (req, res) => {
  const { employeeNumber } = req.body;
  entryExitService.clearCache(employeeNumber);
  res.json({
    success: true,
    message: employeeNumber ?
      `Cache cleared for employee ${employeeNumber}` :
      'All cache cleared'
  });
});

// Admin endpoint to get cache stats
app.get('/api/time-tracking/cache/stats', (req, res) => {
  const stats = entryExitService.getCacheStats();
  res.json({ success: true, stats });
});

// ============= ADMIN API ENDPOINTS =============

// Auth guard for all /api/admin routes — requires a valid Bosch SSO Bearer token.
// Consistent with every other authenticated route in this server.
function adminAuth(req, res, next) {
  const token = extractBearerToken(req.headers['authorization']);
  if (!token) {
    return res.status(401).json({ success: false, error: 'Authorization required' });
  }
  next();
}
app.use('/api/admin', adminAuth);

// [FIX | Rule S5144 - SSRF]: Allowlist-based URL validator for admin discovery endpoint.
// Blocks private/loopback/link-local ranges and non-http(s) schemes so an attacker
// cannot force the server to probe internal services or cloud metadata endpoints.
// Returns { safeUrl } on success, or { error } on failure.
// Passing back parsed.href (not the raw input) breaks the SonarQube taint chain (S5144).
function validateDiscoverUrl(raw) {
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    return { error: 'Invalid URL format' };
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return { error: 'Only http and https URLs are allowed' };
  }

  const hostname = parsed.hostname.toLowerCase();

  if (hostname === 'localhost' || hostname === '0.0.0.0') {
    return { error: 'Requests to localhost are not allowed' };
  }

  if (hostname === '[::1]' || hostname === '::1') {
    return { error: 'Requests to loopback addresses are not allowed' };
  }

  const ipv4Match = hostname.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4Match) {
    const [, a, b] = ipv4Match.map(Number);
    if (
      a === 127 ||
      a === 10 ||
      (a === 172 && b >= 16 && b <= 31) ||
      a === 192 && b === 168 ||
      a === 169 && b === 254
    ) {
      return { error: 'Requests to private or reserved IP ranges are not allowed' };
    }
  }

  return { safeUrl: parsed.href }; // reconstructed — not the raw user string
}

// Smart Discovery Endpoint
app.post('/api/admin/services/discover', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    const { safeUrl, error: urlError } = validateDiscoverUrl(url);
    if (urlError) {
      return res.status(400).json({ success: false, error: urlError });
    }

    console.log(`[AdminAPI] Discovering service at: ${safeUrl}`);
    const analysis = await mcpDiscoveryService.discover(safeUrl);
    res.json({ success: true, analysis });
  } catch (error) {
    console.error('Discovery error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get all configured services

// Get all configured services
app.get('/api/admin/services', (req, res) => {
  try {
    const services = mcpServiceManager.getAllServices();
    res.json({ success: true, services });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Add or update a service
app.post('/api/admin/services', async (req, res) => {
  try {
    const serviceConfig = req.body;
    // Basic validation
    if (!serviceConfig.id || !serviceConfig.name || !serviceConfig.baseUrl) {
      return res.status(400).json({ error: 'Missing required fields: id, name, baseUrl' });
    }

    const savedService = await mcpServiceManager.addService(serviceConfig);
    res.json({ success: true, service: savedService });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete a service
app.delete('/api/admin/services/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const removed = await mcpServiceManager.removeService(id);
    if (removed) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, error: 'Service not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- Unified App Config Endpoints ---

// Get full application configuration
app.get('/api/admin/config', async (req, res) => {
  try {
    const config = await configService.getFullConfig();
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update a core service config
app.post('/api/admin/config/core/:serviceId', async (req, res) => {
  try {
    const { serviceId } = req.params;
    const serviceConfig = req.body;
    const updated = await configService.updateCoreService(serviceId, serviceConfig);
    res.json({ success: true, service: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update privacy whitelist
app.post('/api/admin/config/privacy', async (req, res) => {
  try {
    const { nonNames } = req.body;
    if (!nonNames || !Array.isArray(nonNames)) {
      return res.status(400).json({ success: false, error: 'nonNames array is required' });
    }
    const updated = await configService.updatePrivacyWhitelist(nonNames);
    res.json({ success: true, nonNames: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update routing configuration
app.post('/api/admin/config/routing', async (req, res) => {
  try {
    const routingConfig = req.body;
    const updated = await configService.updateRoutingConfig(routingConfig);
    res.json({ success: true, routingConfig: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ── Keyword Config endpoints (centralised keyword management) ──

app.post('/api/admin/config/keywords/privacy', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Privacy detection config object is required' });
    }
    const updated = await configService.updateKeywordConfig('privacyDetection', data);
    res.json({ success: true, privacyDetection: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/travel', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Travel service config object is required' });
    }
    const updated = await configService.updateKeywordConfig('travelService', data);
    res.json({ success: true, travelService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/seatbooking', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Seat booking config object is required' });
    }
    const updated = await configService.updateKeywordConfig('seatBookingService', data);
    res.json({ success: true, seatBookingService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/community', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Community config object is required' });
    }
    const updated = await configService.updateKeywordConfig('communityService', data);
    res.json({ success: true, communityService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/admin/config/keywords/entryexit', async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Entry/Exit config object is required' });
    }
    const updated = await configService.updateKeywordConfig('entryExitService', data);
    res.json({ success: true, entryExitService: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ── Few-Shot Config endpoint ──
app.post('/api/admin/config/fewshots/:service', async (req, res) => {
  try {
    const { service } = req.params;
    const { examples } = req.body;
    if (!Array.isArray(examples)) {
      return res.status(400).json({ success: false, error: 'examples array is required' });
    }
    for (const ex of examples) {
      if (typeof ex.query !== 'string' || typeof ex.intent !== 'string') {
        return res.status(400).json({ success: false, error: 'Each example must have query (string) and intent (string)' });
      }
    }
    const updated = await configService.updateFewShotConfig(service, examples);
    res.json({ success: true, service, examples: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ── Booking Validation Config endpoint ──
app.post('/api/admin/config/booking/:service', async (req, res) => {
  try {
    const { service } = req.params;
    const data = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ success: false, error: 'Booking config object is required' });
    }
    if (typeof data.allowPreviousDateBooking !== 'boolean') {
      return res.status(400).json({ success: false, error: 'allowPreviousDateBooking must be a boolean' });
    }
    const updated = await configService.updateBookingConfig(service, data);
    res.json({ success: true, service, config: updated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get employee name from Entry/Exit MCP
app.get('/api/time-tracking/employee-name', serviceRateLimiter, async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const authToken = req.headers['authorization'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting employee name for:', empNum);

    // Fetch Bosch JWT for MCP authorization
    let jwtToken = null;
    if (authToken && empNum) {
      try {
        const userTokens = await boschAuthService.getTokenForUser(empNum, authToken);
        jwtToken = userTokens?.jwtToken || null;
      } catch (tokenErr) {
        console.warn('[TimeTracking] employee-name: Failed to get JWT token:', tokenErr.message);
      }
    }

    const entryExitV2Client = getEntryExitV2Client();
    // callMCPToolWithProtocol(toolName, params, employeeNumber, jwtToken)
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_employee_name', {}, empNum, jwtToken);

    // result is MCP JSON-RPC result: {content: [{type: 'text', text: '...'}]}
    let name = 'Unknown';
    if (result && result.content && result.content[0] && result.content[0].text) {
      try {
        const parsed = JSON.parse(result.content[0].text);
        name = parsed.name || parsed.employee_name || 'Unknown';
      } catch (e) {
        name = result.content[0].text || 'Unknown';
      }
    } else if (result && (result.name || result.employee_name)) {
      // Fallback: direct fields if MCP returns flat object
      name = result.name || result.employee_name || 'Unknown';
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      name: name,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get employee name:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get current check-in/out status from Entry/Exit MCP
app.get('/api/time-tracking/current-status', serviceRateLimiter, async (req, res) => {
  try {
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const authToken = req.headers['authorization'];
    const empNum = headerEmployeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Getting current status for:', empNum);

    // Fetch Bosch JWT for MCP authorization
    let jwtToken = null;
    if (authToken && empNum) {
      try {
        const userTokens = await boschAuthService.getTokenForUser(empNum, authToken);
        jwtToken = userTokens?.jwtToken || null;
      } catch (tokenErr) {
        console.warn('[TimeTracking] current-status: Failed to get JWT token:', tokenErr.message);
      }
    }

    const entryExitV2Client = getEntryExitV2Client();
    // callMCPToolWithProtocol(toolName, params, employeeNumber, jwtToken)
    const result = await entryExitV2Client.callMCPToolWithProtocol('get_current_status', {}, empNum, jwtToken);

    // result is MCP JSON-RPC result: {content: [{type: 'text', text: '...'}]}
    let status = 'unknown';
    let lastSwipe = null;
    let location = null;

    if (result && result.content && result.content[0] && result.content[0].text) {
      try {
        const parsed = JSON.parse(result.content[0].text);
        status = parsed.status || parsed.current_status || 'unknown';
        if (parsed.last_swipe) {
          lastSwipe = parsed.last_swipe.time || null;
          location = parsed.last_swipe.location || null;
        }
      } catch (e) {
        const text = result.content[0].text.toLowerCase();
        if (text.includes('checked in') || text === 'in') status = 'IN';
        else if (text.includes('checked out') || text === 'out') status = 'OUT';
      }
    } else if (result) {
      // Fallback: direct fields if MCP returns flat object
      const data = result.structuredContent || result;
      status = data.status || data.current_status || 'unknown';
      if (data.last_swipe) {
        lastSwipe = data.last_swipe.time || null;
        location = data.last_swipe.location || null;
      }
    }

    res.json({
      success: true,
      employeeNumber: empNum,
      status: status,
      lastSwipe: lastSwipe,
      location: location,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to get current status:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// ============= COMMUNITY API ENDPOINTS =============

/**
 * GET /api/community/list - Get list of communities from MCP
 */
app.get('/api/community/list', serviceRateLimiter, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;

    console.log(`[Community API] Fetching communities: page=${page}, pageSize=${pageSize}`);

    const data = await communityService.getCommunityList(page, pageSize);

    // Use flattenCommunities for consistent parsing across MCP/legacy responses
    const flat = communityService.flattenCommunities(data);
    const communities = flat.map(c => ({
      id: c.communityId,
      name: c.name,
      description: c.description || '',
      members: c.members || 0,
      color: c.color || '#007bc0',
      icon: c.imageUrl || null,
      category: 'General',
      locations: (c.locations || []).map(l => ({
        id: l.id,
        name: l.name,
        code: l.code
      }))
    }));

    res.json({
      success: true,
      communities: communities,
      totalCount: communities.length,
      page: page,
      pageSize: pageSize
    });
  } catch (error) {
    console.error('[Community API] Error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      communities: []
    });
  }
});

/**
 * GET /api/community/registered - Get communities the logged-in user is registered to.
 * Used by CommunityCard on mount to seed the joined-IDs set authoritatively.
 */
app.get('/api/community/registered', serviceRateLimiter, async (req, res) => {
  try {
    const authToken = req.headers['authorization'];
    if (!authToken) {
      return res.status(401).json({ success: false, error: 'Authorization header is required' });
    }

    // Pass employeeNumber + userName so getRegisteredCommunityList sends the
    // correct X-Employee-Number / X-User-Name headers to the Bosch API —
    // matching what the chat flow sends via routingContext.
    const employeeNumber = req.headers['x-employee-number'] || '';
    const userName = req.headers['x-user-name'] || '';

    const data = await communityService.getRegisteredCommunityList({ authToken, employeeNumber, userName });

    const flat = communityService.flattenCommunities(data);

    // IDs: coerce to numbers for Set<number> comparison in the frontend
    const communityIds = flat
      .map(c => Number(c.communityId))
      .filter(id => !isNaN(id) && id > 0);

    // Names: normalised lowercase — used as a fallback match when IDs differ
    // between the main community list and the registered community list APIs.
    const communityNames = flat
      .map(c => (c.name || '').trim().toLowerCase())
      .filter(n => n.length > 0);

    console.log(`[Community API] Registered IDs: [${communityIds.join(', ') || 'none'}]`);
    console.log(`[Community API] Registered names: [${communityNames.join(' | ') || 'none'}]`);
    res.json({ success: true, communityIds, communityNames, count: flat.length });
  } catch (error) {
    console.error('[Community API] /registered error:', error.message);
    res.status(500).json({ success: false, error: error.message, communityIds: [] });
  }
});

/**
 * POST /api/community/register - Register user to a community
 */
app.post('/api/community/register', serviceRateLimiter, async (req, res) => {
  try {
    const { communityId, locationId } = req.body;
    const authToken = req.headers['authorization'];

    if (!communityId || !locationId) {
      return res.status(400).json({ success: false, error: 'communityId and locationId are required' });
    }
    if (!authToken) {
      return res.status(401).json({ success: false, error: 'Authorization header is required' });
    }

    console.log(`[Community API] Registering: communityId=${communityId}, locationId=${locationId}`);

    const result = await communityService.registerUserToCommunity(
      Number(communityId),
      Number(locationId),
      { authToken }
    );

    const parsed = typeof result === 'string' ? JSON.parse(result) : result;

    if (parsed && parsed.IsSuccess) {
      // Apply optimistic update to cache so the UI sees the member count increase immediately
      await communityService.applyOptimisticUpdate(Number(communityId));
    }

    res.json({
      success: parsed?.IsSuccess || false,
      message: parsed?.Message || '',
      data: parsed
    });
  } catch (error) {
    console.error('[Community API] Register error:', error.message);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Entry/Exit query endpoint for AI Chat
app.post('/api/entryexit/query', serviceRateLimiter, async (req, res) => {
  try {
    const { query, employeeNumber } = req.body;

    // Extract auth headers
    const authToken = req.headers['authorization'];
    const headerEmployeeNumber = req.headers['x-employee-number'];

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    // Use employee number from header if available, else from body, else default
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    console.log('Processing entry/exit query:', query);
    console.log('Employee number:', empNumber);
    console.log('Auth token present:', !!authToken);

    // Fetch Bosch JWT for Entry/Exit MCP authorization
    let entryExitJwtToken = null;
    if (authToken && empNumber) {
      try {
        const userTokens = await boschAuthService.getTokenForUser(empNumber, authToken);
        entryExitJwtToken = userTokens?.jwtToken || null;
        console.log(`[EntryExit] JWT token obtained for /api/entryexit/query: ${!!entryExitJwtToken}`);
      } catch (tokenErr) {
        console.warn('[EntryExit] /api/entryexit/query: Failed to get JWT token:', tokenErr.message);
      }
    }

    // Use the new V2 AI-powered client that properly uses MCP tools
    const entryExitV2Client = getEntryExitV2Client();

    // Process the query using AI (chat endpoint) or intelligent tool selection
    // Pass the employee number from headers/body; also pass OAuth authToken so
    // the client can refresh the JWT if the MCP server rejects it (auth retry).
    const result = await entryExitV2Client.processQueryWithAI(query, empNumber, req.body.userName, entryExitJwtToken, authToken);

    res.json({
      response: result.response,
      employeeNumber: result.employeeNumber,
      method: result.method,
      tool_used: result.tool,
      success: result.success
    });

  } catch (error) {
    console.error('Entry/Exit query error:', error);
    res.status(500).json({
      error: 'Failed to process entry/exit query',
      details: error.message,
      response: "I'm having trouble accessing the attendance system. Please try again later or check the HR portal directly."
    });
  }
});

// Health check - parallel lightweight ping of every backend service
app.get('/api/health', async (req, res) => {
  const startTime = Date.now();

  /**
   * Ping a URL with a short timeout.
   * Any HTTP response (even 4xx/5xx) = service is reachable → "up".
   * Network error / timeout → "down".
   */
  const ping = async (url, timeoutMs = 5000) => {
    try {
      await axios.get(url, {
        timeout: timeoutMs,
        httpsAgent,
        validateStatus: () => true  // treat any HTTP status as "reachable"
      });
      return true;
    } catch {
      return false;
    }
  };

  // Base URLs for each service (strip trailing MCP-specific paths for a lighter ping)
  const canteenBase = (process.env.CANTEEN_MCP_URL || 'https://mcp-canteen-dev.azurewebsites.net').replace(/\/$/, '');
  const entryExitBase = (process.env.ENTRYEXIT_MCP_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/mcp').replace(/\/mcp$/, '').replace(/\/$/, '');
  const travelBase = (process.env.TRAVEL_API_URL || 'https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io').replace(/\/$/, '');
  const seatBase = (process.env.SEATBOOKING_API_URL || 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io').replace(/\/$/, '');
  const boschApiBase = 'https://dev.boschassociatearena.com';
  const communityBase = process.env.COMMUNITY_MCP_URL ? process.env.COMMUNITY_MCP_URL.replace(/\/$/, '') : null;

  // Run all checks concurrently — health check must be fast
  const [canteenOk, entryExitOk, travelOk, seatOk, boschOk, communityOk] = await Promise.all([
    ping(canteenBase),
    ping(entryExitBase),
    ping(travelBase),
    ping(seatBase),
    ping(boschApiBase),
    communityBase ? ping(communityBase) : Promise.resolve(null)
  ]);

  const services = {
    server: { status: 'up', label: 'Server' },
    boschApi: { status: boschOk ? 'up' : 'down', label: 'Bosch API' },
    canteen: { status: canteenOk ? 'up' : 'down', label: 'Canteen' },
    entryExit: { status: entryExitOk ? 'up' : 'down', label: 'Entry/Exit' },
    travel: { status: travelOk ? 'up' : 'down', label: 'Travel' },
    seatBooking: { status: seatOk ? 'up' : 'down', label: 'Seat Booking' },
    community: { status: communityOk === null ? 'unconfigured' : communityOk ? 'up' : 'down', label: 'Community' }
  };

  const downCount = Object.values(services).filter(s => s.status === 'down').length;
  const overallStatus = downCount === 0 ? 'OK' : downCount <= 2 ? 'DEGRADED' : 'OUTAGE';

  res.json({
    status: overallStatus,
    timestamp: new Date().toISOString(),
    responseTimeMs: Date.now() - startTime,
    services
  });
});

// Authentication endpoint - Proxy to Bosch Arena API
// Authentication endpoint - Proxy to Bosch Arena API
app.post('/api/auth/login', loginRateLimiter, async (req, res) => {
  let username = '';
  try {
    const { username: reqUsername, password, isPreEncrypted } = req.body;
    username = reqUsername; // Store for error handling scope

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    console.log('Login attempt for user:', username);
    console.log('Using boschAuthService for secure login...');
    console.log('Password is pre-encrypted:', isPreEncrypted ? 'Yes' : 'No (will encrypt)');

    // Use the service - pass isPreEncrypted flag to skip double-encryption
    const loginResponse = await boschAuthService.login(username, password, null, isPreEncrypted === true);

    console.log('Login successful for user:', username);

    // Generate JWT tokens for ALL services at login time and return them to the
    // frontend so they can be stored in sessionStorage.  The frontend sends them
    // back with every chat request, eliminating the need for server-side token
    // cache lookups on the hot path.  The server-side Maps are kept as fallback.
    try {
      console.log('--- STARTING JWT GENERATION FOR ALL SERVICES DURING LOGIN ---');
      const oauthToken = loginResponse.access_token;
      const expiresIn = loginResponse.expires_in;

      const serviceTokens = await boschAuthService.generateAllServiceTokens(username, oauthToken, expiresIn);
      console.log('[auth/login] serviceTokens generated:', JSON.stringify({
        travel: serviceTokens.travel ? { sessionId: serviceTokens.travel.sessionId } : null,
        seatbooking: serviceTokens.seatbooking ? { sessionId: serviceTokens.seatbooking.sessionId } : null,
        entryexit: serviceTokens.entryexit ? { sessionId: serviceTokens.entryexit.sessionId } : null,
        canteen: serviceTokens.canteen ? { sessionId: serviceTokens.canteen.sessionId } : null,
        community: serviceTokens.community ? { sessionId: serviceTokens.community.sessionId } : null,
      }));

      // Surface a top-level sessionId for backward compat with frontend code that
      // reads loginResponse.sessionId into mybgsw_user.sessionId.
      // Use the entryexit token as the canonical "default" — it uses the same
      // MyBGSWAI clientID but now has its own dedicated SessionId.
      loginResponse.sessionId = serviceTokens.entryexit?.sessionId ?? null;
      // Attach the full per-service token map so the frontend can store it in
      // sessionStorage and include it in every subsequent chat request.
      loginResponse.serviceTokens = serviceTokens;

      console.log(`[auth/login] All 5 service tokens generated. Canonical SessionId: ${loginResponse.sessionId}`);
    } catch (tokenError) {
      console.error('--- FAILED to generate service tokens during login! ---');
      console.error('Error:', tokenError.message);
      // Continue — login itself succeeded; A2A services will fall back to server-side cache.
    }

    res.json(loginResponse);

  } catch (error) {
    console.error('Login proxy error:', error.message);

    // Handle axios error responses
    if (error.response) {
      const errorData = error.response.data;
      console.log('Login failed for user:', username, 'Status:', error.response.status);
      return res.status(error.response.status).json({
        error: errorData.error_description || errorData.error || 'Login failed'
      });
    }

    res.status(500).json({
      error: 'Authentication service unavailable. Please try again later.'
    });
  }
});

/**
 * POST 
 * Generates JWT tokens for all three services (default, travel, seatbooking) from
 * a valid OAuth token.  Used by the SSO login flow — SSO redirects bypass our
 * /api/auth/login route so the frontend needs to call this separately after receiving
 * the OAuth token from the Arena SSO redirect.
 *
 * Body: { employeeNumber: string, oauthToken: string }
 * Returns: { serviceTokens: { travel, seatbooking, entryexit, canteen, community } }
 */
app.post('/api/auth/service-tokens', async (req, res) => {
  try {
    const { employeeNumber, oauthToken } = req.body;

    if (!employeeNumber || !oauthToken) {
      return res.status(400).json({ error: 'employeeNumber and oauthToken are required' });
    }

    console.log(`[service-tokens] Generating all service tokens for employee: ${employeeNumber}`);
    const serviceTokens = await boschAuthService.generateAllServiceTokens(employeeNumber, oauthToken);

    console.log('[service-tokens] Done:', JSON.stringify({
      travel: serviceTokens.travel ? { sessionId: serviceTokens.travel.sessionId } : null,
      seatbooking: serviceTokens.seatbooking ? { sessionId: serviceTokens.seatbooking.sessionId } : null,
      entryexit: serviceTokens.entryexit ? { sessionId: serviceTokens.entryexit.sessionId } : null,
      canteen: serviceTokens.canteen ? { sessionId: serviceTokens.canteen.sessionId } : null,
      community: serviceTokens.community ? { sessionId: serviceTokens.community.sessionId } : null,
    }));

    res.json({ serviceTokens });
  } catch (error) {
    console.error('[service-tokens] Error:', error.message);
    res.status(500).json({ error: 'Failed to generate service tokens' });
  }
});

// ── Consent Endpoints ─────────────────────────────────────────────────────────
/**
 * GET /api/auth/consent
 * Check whether the authenticated user has already given consent.
 * Query param: nt_id  (required)
 *
 * Returns: { hasConsented: boolean }
 */
app.get('/api/auth/consent', async (req, res) => {
  try {
    const { nt_id } = req.query;

    if (!nt_id || typeof nt_id !== 'string' || nt_id.trim() === '') {
      return res.status(400).json({ error: 'nt_id query parameter is required' });
    }

    // Reject suspiciously long or non-printable values
    const sanitizedNtId = nt_id.trim().slice(0, 255);

    const { hasConsented, record } = await consentDbService.checkConsent(sanitizedNtId);
    return res.json({ hasConsented, record: record || null });

  } catch (error) {
    console.error('[ConsentAPI] GET /api/auth/consent error:', error.message);
    return res.status(500).json({ error: 'Failed to check consent status' });
  }
});

/**
 * POST /api/auth/consent
 * Record that the user has given consent.
 * Body: { user_id, user_name, nt_id }
 *
 * Returns: { success: boolean }
 */
app.post('/api/auth/consent', async (req, res) => {
  try {
    const { user_id, user_name, nt_id } = req.body;

    if (!nt_id || typeof nt_id !== 'string' || nt_id.trim() === '') {
      return res.status(400).json({ error: 'nt_id is required' });
    }

    const sanitizedNtId = nt_id.trim().slice(0, 255);
    const sanitizedUserId = (user_id || '').toString().trim().slice(0, 255) || null;
    const sanitizedName = (user_name || '').toString().trim().slice(0, 255) || null;

    const success = await consentDbService.saveConsent(sanitizedUserId, sanitizedName, sanitizedNtId);

    if (!success) {
      return res.status(500).json({ error: 'Failed to save consent' });
    }

    return res.json({ success: true });

  } catch (error) {
    console.error('[ConsentAPI] POST /api/auth/consent error:', error.message);
    return res.status(500).json({ error: 'Failed to save consent' });
  }
});

// ── End Consent Endpoints ─────────────────────────────────────────────────────


// ============= UNIFIED SMART CHAT ENDPOINT =============
// Import all services for smart routing
const intelligentRouter = require('./services/intelligent-router');
// communityService already imported at top of file
const travelService = require('./services/travel-service');
const seatbookingService = require('./services/seatbooking-service');
const bannerService = require('./services/banner-service');

/**
 * GET /api/chat/history - Get chat history for a user (7 days context)
 */
app.get('/api/chat/history', async (req, res) => {
  try {
    const { employeeNumber } = req.query;
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber) {
      return res.status(400).json({ error: 'Employee number is required' });
    }

    console.log(`[Chat History] Fetching history for ${empNumber}`);
    const history = await conversationContextService.loadContext(empNumber);

    res.json({
      success: true,
      history: history || []
    });
  } catch (error) {
    console.error('Error fetching chat history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch chat history'
    });
  }
});

/**
 * LLM-first general privacy classifier.
 *
 * Uses few-shot examples from fewShotConfig.generalPrivacy (configurable via
 * Admin UI → Few-Shot tab) to decide whether the query is asking about the
 * logged-in user's OWN data ("self" → ALLOW) or another person's data
 * ("other" → BLOCK).
 *
 * Falls back to the deterministic detectColleagueQuery() if the LLM call
 * fails for any reason (network, quota, parse error).
 *
 * @param {string}  query
 * @param {string}  loggedInEmployeeNumber
 * @param {string}  loggedInUserName
 * @returns {Promise<{isColleagueQuery: boolean, reason: string}>}
 */
async function classifyGeneralPrivacy(query, loggedInEmployeeNumber, loggedInUserName) {
  try {
    const { createOpenAIClient, getChatModelName } = require('./services/openai-client');
    const openai = createOpenAIClient();

    const examples = configService.getFewShotConfigSync().generalPrivacy || [];
    const exampleLines = examples
      .map(e => `Q: "${e.query}" → {"intent":"${e.intent}"}`)
      .join('\n');

    const userName = loggedInUserName || 'the logged-in user';

    const systemPrompt = `You are a privacy classifier for a workplace assistant at Bosch.
The logged-in user is: "${userName}".

Your task: decide if the user's query is asking about their OWN data/actions ("self") or about ANOTHER person's data ("other").

Rules:
- "self"  → the query is about the logged-in user's own travel, attendance, seat, canteen, or any personal action. ALLOW.
- "other" → the query mentions another person's name, uses relationship words (friend, colleague, manager), or uses third-person pronouns (his, her, their) to access someone else's data. BLOCK.
- When the query is ambiguous with no explicit reference to another person, classify as "self".
- Bulk/collective requests ("all employees", "team attendance", "everyone") → "other".

Few-shot examples:
${exampleLines}

Respond with ONLY valid JSON, no explanation: {"intent":"self"} or {"intent":"other"}`;

    const response = await openai.chat.completions.create({
      model: getChatModelName('gpt-4o-mini'),
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: query }
      ],
      max_tokens: 20,
      temperature: 0
    });

    const raw = response.choices[0].message.content.trim();
    const parsed = JSON.parse(raw);

    if (parsed.intent === 'other') {
      console.log(`[Privacy/LLM] Blocked — intent="other" for query: "${query}"`);
      return { isColleagueQuery: true, reason: 'LLM classified as asking about another person' };
    }
    if (parsed.intent === 'self') {
      console.log(`[Privacy/LLM] Allowed — intent="self" for query: "${query}"`);
      return { isColleagueQuery: false, reason: '' };
    }

    // Unexpected value — fall through to regex
    throw new Error(`Unexpected LLM intent: ${parsed.intent}`);
  } catch (err) {
    console.warn(`[Privacy/LLM] Classification failed (${err.message}), falling back to regex`);
    return detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName);
  }
}

/**
 * Regex-based privacy guard (fallback).
 * Detect if a query is asking about another colleague's personal data.
 * Returns { isColleagueQuery: boolean, reason: string }
 *
 * DESIGN PRINCIPLES:
 * 1. Queries about the LOGGED-IN USER's own data -> ALLOW
 * 2. Queries that EXPLICITLY reference another person (name, pronoun, relationship) -> BLOCK
 * 3. Queries that try to access BULK / ALL employee data -> BLOCK
 * 4. Ambiguous queries with NO explicit other-person reference -> ALLOW (assume self)
 *
 * ALLOW: "give me entry exit times", "my attendance", "show me today's hours", "when did I come"
 * BLOCK: "Rahul's attendance", "my friend's entry time", "his hours", "show all employee attendance",
 *        "who came late today", "list everyone's attendance", "team attendance"
 */
function detectColleagueQuery(query, loggedInEmployeeNumber, loggedInUserName) {
  const q = query.toLowerCase().trim();
  const original = query.trim();

  // --- helpers ---
  const loggedInNames = [];
  if (loggedInUserName) {
    const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
    loggedInNames.push(...parts, loggedInUserName.toLowerCase());
  }
  const isOwnName = (name) => loggedInNames.includes(name.toLowerCase());

  // ── Load keyword config from centralised config (editable via Admin UI) ──
  const kwConfig = configService.getKeywordConfigSync().privacyDetection;

  // Word-boundary-aware plain-string match — no dynamic RegExp construction.
  // Simulates \b by checking that the character before/after the match is not a word char.
  const wordMatch = (haystack, needle) => {
    let pos = 0;
    while (pos <= haystack.length - needle.length) {
      const idx = haystack.indexOf(needle, pos);
      if (idx === -1) return false;
      const pre  = idx === 0 || !/\w/.test(haystack[idx - 1]);
      const post = idx + needle.length >= haystack.length || !/\w/.test(haystack[idx + needle.length]);
      if (pre && post) return true;
      pos = idx + 1;
    }
    return false;
  };

  // Personal data keywords — strip regex metacharacters and match as plain terms.
  // check-in / check-out variants (originally 'check.?in', 'check.?out' in config)
  // are covered by the static hardcoded pattern below.
  const plainDataKeywords = kwConfig.personalDataKeywords
    .map(k => k.replace(/[.*+?^${}()|[\]\\]/g, ' ').replace(/\s+/g, ' ').toLowerCase().trim())
    .filter(Boolean);
  const hasPersonalData = plainDataKeywords.some(k => wordMatch(q, k))
    || /\bcheck[\s-]?(?:in|out)\b/i.test(q); // static — not from config

  // Self-reference tokens
  const selfPattern = /\b(my|mine|me|myself|i|i'm|i've|i'll|i'd|i am)\b/i;
  const hasSelfRef = selfPattern.test(q);

  // Colleague / relationship words — all plain strings, word-boundary matched
  const colleagueWords = kwConfig.colleaguePatternWords
    .map(w => w.toLowerCase().replace(/\s+/g, ' ').trim());
  const hasColleagueWord = colleagueWords.some(w => wordMatch(q, w));

  // Global privacy whitelist (cities, common words, service keywords, etc.)
  // Declared early so it can be reused by ALL checks below, avoiding stale hardcoded subsets.
  const nonNames = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));

  // --- FAST PATH: self-reference with NO colleague word AND no other-person name -> ALLOW ---
  // We must NOT fast-path if the query also contains another person's name.
  // e.g. "show me entry exit of vaishnav" has 'me' but also 'vaishnav'
  if (hasSelfRef && !hasColleagueWord) {
    // Check for "of/for <name>" pattern (case-insensitive)
    const hasOfForName = q.match(/\b(?:of|for)\s+([a-z]{3,})\b/i);
    let otherNameDetected = false;
    if (hasOfForName) {
      const candidate = hasOfForName[1].toLowerCase();
      const safeWords = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
        'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
        'week', 'month', 'year', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
        'bangalore', 'coimbatore', 'bosch', 'india',
        'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'noida',
        'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
        'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
        'yes', 'no', 'ok', 'confirm', 'confirmation', 'approve', 'approved', 'proceed', 'proceeding',
        'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat',
        'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
        'data', 'record', 'records', 'report', 'log', 'hours', 'working',
        'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
        'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
        'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
        'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
        'book', 'booked', 'booking', 'planning', 'planned', 'location', 'locations', 'building', 'floor',
        'desk', 'station', 'meeting', 'room', 'office', 'details', 'information', 'info',
        'accommodation', 'air', 'required', 'needed']);
      if (!safeWords.has(candidate) && !nonNames.has(candidate) && !isOwnName(candidate)) {
        otherNameDetected = true;
      }
    }
    // Check for possessive name: "vaishnav's entry"
    const hasPossessiveName = q.match(/(\w{3,})(?:'s|s')\s+/i);
    if (hasPossessiveName && !isOwnName(hasPossessiveName[1])) {
      const pName = hasPossessiveName[1].toLowerCase();
      const skipPossessive = new Set(['today', 'yesterday', 'tomorrow', 'it', 'that', 'this', 'there', 'here',
        'what', 'let', 'don', 'doesn', 'didn', 'won', 'today', 'week', 'month', 'year', 'last', 'next',
        'swipe', 'entry', 'exit', 'time', 'check', 'clock', 'shift', 'who', 'where', 'when', 'how']);
      if (!skipPossessive.has(pName) && !nonNames.has(pName)) otherNameDetected = true;
    }
    if (!otherNameDetected) {
      return { isColleagueQuery: false, reason: '' };
    }
    // Otherwise fall through to full checks
  }

  // --- CHECK 1: Bulk / collective data requests -> BLOCK ---
  // (phrases from config — build regex dynamically)
  const bulkPhrases = kwConfig.bulkPatternPhrases.map(p => p.toLowerCase().replace(/\s+/g, ' ').trim());
  if (bulkPhrases.some(p => q.includes(p))) {
    return { isColleagueQuery: true, reason: 'Bulk / collective data request' };
  }

  // --- CHECK 2: Impersonation detection -> BLOCK ---
  // "I am Rahul, show entry time", "my name is Priya, give attendance"
  const impersonation = q.match(/\b(?:i\s+am|i'm|my\s+name\s+is|this\s+is)\s+([a-z]+)/i);
  if (impersonation) {
    const claimedName = impersonation[1].toLowerCase();
    const skipWords = new Set(kwConfig.impersonationSkipWords);
    if (!isOwnName(claimedName) && !skipWords.has(claimedName)) {
      return { isColleagueQuery: true, reason: `Possible impersonation: ${impersonation[1]}` };
    }
  }

  // --- CHECK 3: Employee number for someone else -> BLOCK ---
  const empNumMatches = q.match(/\b(\d{7,8})\b/g);
  if (empNumMatches) {
    for (const num of empNumMatches) {
      if (num !== loggedInEmployeeNumber) {
        return { isColleagueQuery: true, reason: `Contains different employee number: ${num}` };
      }
    }
  }

  // --- CHECK 4: Explicit colleague / relationship words -> BLOCK ---
  if (hasColleagueWord) {
    return { isColleagueQuery: true, reason: 'Explicit colleague / relationship reference' };
  }

  // --- CHECK 5: Third-person pronouns with personal data -> BLOCK ---
  const thirdPerson = /\b(his|her|their|he|she|they)\b/i;
  if (thirdPerson.test(q) && hasPersonalData) {
    return { isColleagueQuery: true, reason: 'Third-person pronoun with personal data' };
  }

  // --- CHECK 6: "details/information about <someone>" -> BLOCK ---
  // Split multi-word captures and check EACH word against nonNames / safeSelf.
  // e.g. "info about Mind Buddies" → both "mind" and "buddies" should be safe.
  const aboutMatch = q.match(/\b(?:details?|information|info)\s+(?:about|on|of)\s+([a-z'']+(?:\s+[a-z'']+)?)/i);
  if (aboutMatch) {
    const safeSelf = new Set(['me', 'myself', 'my', 'mine']);
    const targetWords = aboutMatch[1].toLowerCase().split(/\s+/).filter(Boolean);
    const anyUnsafe = targetWords.some(w => !safeSelf.has(w) && !nonNames.has(w) && !isOwnName(w));
    if (anyUnsafe) {
      return { isColleagueQuery: true, reason: `Asking about someone: ${aboutMatch[1]}` };
    }
  }

  // --- CHECK 7: Possessive name pattern: "Rahul's attendance" -> BLOCK ---
  // (nonNames already declared above, before the fast path)

  const possessiveRe = /(\w+)(?:'s|s')\s+/gi;
  for (const m of q.matchAll(possessiveRe)) {
    const name = m[1].toLowerCase();
    if (name.length > 2 && !nonNames.has(name) && !isOwnName(name) && hasPersonalData) {
      return { isColleagueQuery: true, reason: `Possessive name: ${m[1]}` };
    }
  }

  // --- CHECK 8: "of/for <Name>" pattern -> BLOCK ---
  const ofForRe = /\b(?:of|for)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b/g;
  for (const m of original.matchAll(ofForRe)) {
    const nameStr = m[1].toLowerCase();
    const words = nameStr.split(/\s+/);
    const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));
    if (anyOtherPerson && hasPersonalData) {
      return { isColleagueQuery: true, reason: `of/for <Name>: ${m[1]}` };
    }
  }

  // --- CHECK 9: Capitalized name near personal data (no self-ref) -> BLOCK ---
  if (!hasSelfRef) {
    const capNameRe = /\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(capNameRe)) {
      const nameStr = m[1].toLowerCase();
      const words = nameStr.split(/\s+/);
      const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));

      if (anyOtherPerson && hasPersonalData) {
        // proximity check: name within 40 chars of a personal data keyword
        const idx = m.index;
        const window = original.substring(Math.max(0, idx - 40), idx + m[1].length + 40);
        if (personalDataPattern.test(window)) {
          return { isColleagueQuery: true, reason: `Capitalized name near personal data: ${m[1]}` };
        }
      }
    }
  }

  // --- CHECK 10: "for <Name>" without personal data keywords (follow-up evasion) -> BLOCK ---
  // Catches: "can you do it for vaishnavi", "do it for Rahul", "same for Priya"
  //
  // IMPORTANT: when the captured phrase is multi-word (e.g. "full day",
  // "the whole day") we must check EACH WORD individually against the
  // safe-list, not the joined phrase. Otherwise a legitimate query like
  // "need the booking for 9th of April and for full day" was being
  // blocked because the single-string key "full day" isn't in the set,
  // even though both "full" and "day" are.
  const forNameEvasion = q.match(/\bfor\s+([a-z]{3,}(?:\s+[a-z]{3,})?)\s*\??$/i);
  if (forNameEvasion) {
    const phrase = forNameEvasion[1].toLowerCase();
    const safeForTargets = new Set(['me', 'myself', 'my', 'own', 'today', 'yesterday', 'tomorrow', 'now', 'free',
      'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
      'week', 'weeks', 'month', 'months', 'year', 'years', 'this', 'that', 'next', 'last', 'coming', 'previous', 'past', 'current',
      'bangalore', 'bengaluru', 'coimbatore', 'bosch', 'india',
      'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune', 'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'gurugram', 'noida',
      'mysore', 'mysuru',
      'lunch', 'dinner', 'breakfast',
      'business', 'personal', 'leisure', 'official', 'work', 'home', 'office', 'reference', 'later',
      'approval', 'review', 'confirmation', 'details', 'information', 'nothing', 'everything', 'anyone', 'everyone',
      'entry', 'exit', 'time', 'times', 'attendance', 'check', 'checking', 'leave', 'travel', 'booking', 'seat', 'seats', 'desk', 'desks',
      'swipe', 'swiped', 'swiping', 'punch', 'punched', 'clock', 'clocked', 'clocking', 'shift', 'overtime',
      'data', 'record', 'records', 'report', 'log', 'hours', 'working',
      'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any', 'every', 'each', 'all', 'days', 'day',
      'morning', 'afternoon', 'evening', 'night', 'noon', 'midnight', 'midday',
      'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec',
      'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
      'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
      'book', 'booked', 'booking', 'planning', 'planned', 'location', 'locations', 'building', 'floor',
      'desk', 'station', 'meeting', 'room', 'office', 'details', 'information', 'info',
      'yes', 'no', 'ok', 'confirm', 'confirmation', 'approve', 'approved', 'proceed', 'proceeding',
      'accommodation', 'air', 'required', 'needed',
      'first', 'second', 'third', 'fourth', 'fifth', 'half', 'quarter']);

    const phraseWords = phrase.split(/\s+/).filter(Boolean);
    // Allow the phrase if EVERY word is either safe, in the global privacy
    // whitelist (nonNames), the logged-in user's name, or a pure number/ordinal.
    const allSafe = phraseWords.every(w =>
      safeForTargets.has(w) ||
      nonNames.has(w) ||
      isOwnName(w) ||
      /^\d+(?:st|nd|rd|th)?$/i.test(w)
    );
    if (!allSafe) {
      return { isColleagueQuery: true, reason: `"for <Name>" evasion: ${forNameEvasion[1]}` };
    }
  }

  // --- CHECK 11: Indirect phrasing ("tell about", "show details of") with a name -> BLOCK ---
  const indirectMatch = original.match(/\b(?:tell|show|give|get|fetch|find|display|check)\s+(?:me\s+)?(?:about|details?\s+(?:of|about|for))\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/);
  if (indirectMatch) {
    const nameStr = indirectMatch[1].toLowerCase();
    const words = nameStr.split(/\s+/);
    const anyOtherPerson = words.some(w => !nonNames.has(w) && !isOwnName(w));
    if (anyOtherPerson) {
      return { isColleagueQuery: true, reason: `Indirect phrasing about: ${indirectMatch[1]}` };
    }
  }

  // DEFAULT: No explicit other-person reference -> treat as self-query -> ALLOW
  return { isColleagueQuery: false, reason: '' };
}

/**
 * Seat availability queries ask about general facility resources (which floors
 * have free desks) — not about any individual's personal booking data.
 * They must be exempt from the colleague-privacy guard, which would otherwise
 * block them because "seat" is a personalDataKeyword and there is no self-
 * reference ("my") in phrases like "show availability across all floors".
 */
/**
 * Unified privacy + intent classifier using LLM and conversation history.
 *
 * Replaces the two-step flow:
 *   classifyGeneralPrivacy() → detectAmbiguousBannerOrPerson()
 *
 * with a single LLM call that reads recent conversation history to resolve
 * ambiguous terms like "ROB" (banner name vs colleague name) without asking
 * the user for clarification when context is sufficient.
 *
 * Returns one of:
 *   { intent: 'self',      term: null   } → query is about the logged-in user, allow
 *   { intent: 'banner',    term: string } → query is about a banner/announcement, route to banner
 *   { intent: 'colleague', term: null   } → query is about another person's private data, block
 *   { intent: 'ambiguous', term: string } → cannot decide from context, show disambiguation prompt
 *
 * Falls back to the old two-step approach if the LLM call fails.
 */
async function classifyPrivacyWithContext(query, loggedInUserName, recentMessages, activeService = null) {
  try {
    const { createOpenAIClient, getChatModelName } = require('./services/openai-client');
    const openai = createOpenAIClient();

    const userName = loggedInUserName || 'the logged-in user';

    const historyText = (recentMessages || [])
      .slice(-6)
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${(m.content || '').substring(0, 200)}`)
      .join('\n');

    const historySection = historyText
      ? `\nRecent conversation:\n${historyText}\n`
      : '\n(No prior conversation.)\n';

    const activeServiceSection = activeService
      ? `\nCurrently active service (from the previous turn): "${activeService}". If the new message is a short follow-up (a location, number, confirmation, or one-word reply), keep this service — do not reclassify.\n`
      : '';

    // ── Inject admin-configured few-shot examples ────────────────────────────
    // Service routing examples: use query text from per-service few-shots as
    // grounding signals for Step 1 (service classification).
    // Privacy intent examples: use generalPrivacy few-shots for Step 2
    // (self vs colleague), mapping 'other' → 'colleague' for the LLM.
    let serviceExamplesSection = '';
    let privacyExamplesSection = '';
    try {
      const fewShots = configService.getFewShotConfigSync() || {};

      // Step 1 examples — take up to 4 representative queries per service
      const svcMap = {
        travel: fewShots.travel,
        seatbooking: fewShots.seatbooking,
        community: fewShots.community,
        entryexit: fewShots.entryexit,
      };
      const svcLines = [];
      for (const [svc, examples] of Object.entries(svcMap)) {
        if (Array.isArray(examples) && examples.length > 0) {
          examples.slice(0, 4).forEach(ex => {
            svcLines.push(`Q: "${ex.query}" → service: "${svc}"`);
          });
        }
      }
      if (svcLines.length > 0) {
        serviceExamplesSection = `\nService routing examples (admin-validated — use these to guide Step 1):\n${svcLines.join('\n')}\n`;
      }

      // Step 2 examples — generalPrivacy few-shots: 'self' → "self", 'other' → "colleague"
      const gp = fewShots.generalPrivacy;
      if (Array.isArray(gp) && gp.length > 0) {
        const selfEx = gp.filter(e => e.intent === 'self').slice(0, 6);
        const otherEx = gp.filter(e => e.intent === 'other').slice(0, 5);
        const privLines = [
          ...selfEx.map(e => `Q: "${e.query}" → intent: "self"`),
          ...otherEx.map(e => `Q: "${e.query}" → intent: "colleague"`),
        ];
        if (privLines.length > 0) {
          privacyExamplesSection = `\nPrivacy intent examples (admin-validated — use these to guide Step 2):\n${privLines.join('\n')}\n`;
        }
      }
    } catch (fewShotErr) {
      console.warn('[Privacy/Context] Could not load few-shot config:', fewShotErr.message);
    }
    // ─────────────────────────────────────────────────────────────────────────

    const systemPrompt = `You are a privacy and intent classifier for a workplace assistant at Bosch.
The logged-in user is: "${userName}".
${historySection}${activeServiceSection}
Step 1 — Identify the SERVICE this query is for (use exactly one of these keys):
- "banner"      → company events, announcements, banners, promotions, highlights, what's new
- "travel"      → book/raise/arrange travel, trips, flights, tickets
- "seatbooking" → book/reserve/cancel a seat, desk, workspace, or check seat availability
- "entryexit"   → attendance, swipe details/records, punch in/out, check-in/out, working hours, entry/exit/in/out time
- "community"   → join/list communities, clubs, groups, membership queries
- "canteen"     → cafeteria menu, food menu, today's lunch/dinner/breakfast
- "general"     → none of the above
${serviceExamplesSection}
Step 2 — Classify the privacy INTENT into EXACTLY ONE of these four:
- "self"      → asking about the logged-in user's OWN data. ALLOW.
- "banner"    → asking about a company banner, announcement, event, or promotion. Even if the term looks like a person's name (e.g. "ROB", "SPARK"), classify as "banner" when context points to banners/events.
- "colleague" → clearly asking about ANOTHER person's private data (their attendance, salary, entry time, leave). BLOCK.
- "ambiguous" → the term could be a banner/announcement OR a colleague name, and context does not decide.
${privacyExamplesSection}
Step 3 — Rate your CONFIDENCE in the service classification:
- "high"   → query clearly maps to exactly one service
- "low"    → query is vague, generic, or could reasonably belong to 2+ services

When confidence is "low", also list up to 3 alternative service keys in "alternatives" (the other plausible services besides the primary one).

Key rules:
- SHORT FOLLOW-UP RULE: If the message is 1-3 words AND activeService is set AND the message contains NO keyword that signals a DIFFERENT service → keep activeService as the service, intent="self", confidence="high". Genuine follow-ups: "Coimbatore", "Bangalore", "yes", "no", "confirm", "ok", "2", "tomorrow", "cancel", "go ahead". Do NOT apply this rule when the message contains a clear service-switching keyword — classify those by the keyword instead:
  • "community", "club", "group", "membership" → service="community"
  • "travel", "flight", "trip", "ticket", "train", "bus" → service="travel"
  • "seat", "desk", "workspace", "workstation" → service="seatbooking"
  • "canteen", "menu", "food", "lunch", "dinner", "breakfast" → service="canteen"
  • "attendance", "entry", "exit", "swipe", "punch", "check-in", "check-out", "working hours" → service="entryexit"
  • "banner", "announcement", "event", "promotion" → service="banner"
- Use conversation history to resolve ambiguity: if prior turns were about a service, continue that service unless the new message clearly signals a switch.
- If query has personal-data keywords (attendance, salary, payslip, entry time, leave, hours, swipe) AND refers to another person → "colleague".
- Classify as "banner" or "ambiguous" ONLY when the looked-up term is a short internal code, acronym, or recognisable event/programme name that could plausibly be a Bosch banner or announcement (e.g. "ROB", "SPARK", "ASPIRE"). Do NOT classify as "banner" just because the query uses a generic verb like "show me" or "tell me about" — data, documents, reports, and technical queries go to "general".
- If query says "colleague", "friend", "coworker", "manager", "his", "her", "their" → "colleague".
- When in doubt between "banner" and "ambiguous", prefer "ambiguous" so the user gets to choose.
- Extract the ambiguous term (the name/code being looked up) for "banner" and "ambiguous" intents.
- Queries about data, reports, entity data, records, or technical information with no service-specific keywords → service="general", intent="self".
- If the service cannot be determined with confidence="high" and there is no activeService → set confidence="low" and list up to 3 alternatives.
- Greetings, thank-you messages, or completely off-topic queries → service="general", confidence="high".

Reply with ONLY valid JSON, no explanation:
{"intent":"self","term":null,"service":"entryexit","confidence":"high","alternatives":[]}
{"intent":"self","term":null,"service":"travel","confidence":"low","alternatives":["seatbooking","entryexit"]}`;

    const response = await openai.chat.completions.create({
      model: getChatModelName('gpt-4o-mini'),
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: query }
      ],
      max_tokens: 80,
      temperature: 0
    });

    const raw = response.choices[0].message.content.trim();
    const parsed = JSON.parse(raw);
    const validIntents = ['self', 'banner', 'colleague', 'ambiguous'];
    const validServices = ['banner', 'travel', 'seatbooking', 'entryexit', 'community', 'canteen', 'general'];
    if (validIntents.includes(parsed.intent)) {
      const service = validServices.includes(parsed.service) ? parsed.service : 'general';
      const confidence = parsed.confidence === 'low' ? 'low' : 'high';
      const alternatives = Array.isArray(parsed.alternatives)
        ? parsed.alternatives.filter(s => validServices.includes(s) && s !== service)
        : [];
      console.log(`[Privacy/Context] intent="${parsed.intent}", term="${parsed.term}", service="${service}", confidence="${confidence}" for query: "${query}"`);
      return { intent: parsed.intent, term: parsed.term || null, service, confidence, alternatives };
    }
    throw new Error(`Unexpected intent: ${parsed.intent}`);
  } catch (err) {
    console.warn(`[Privacy/Context] LLM failed (${err.message}), falling back to legacy two-step check`);
    return null; // caller falls back to old flow
  }
}

/**
 * Resolves relative temporal references in a query to absolute IST dates.
 * Examples: "yesterday" → "May 1st 2026", "next Monday" → "May 4th 2026".
 * Multi-word patterns (e.g. "day before yesterday") are processed before single-word
 * patterns to prevent partial replacement.
 */
/**
 * @deprecated — No longer called. Superseded by
 * conversationContextService.resolveAndRewriteQuery() which is invoked at Step 2b
 * and handles follow-up detection, query rewriting, and service-switch detection in
 * a single LLM call. Kept here temporarily for reference; safe to delete.
 */
async function resolveQueryContext(query, serviceHistory, lastService) {
  if (!serviceHistory || serviceHistory.length === 0 || !lastService) {
    return { isFollowUp: false, targetService: null };
  }
  try {
    const { createOpenAIClient, getChatModelName } = require('./services/openai-client');
    const openai = createOpenAIClient();

    const serviceLabels = {
      seatbooking: 'Seat / Desk Booking',
      travel: 'Travel Booking',
      entryexit: 'Entry & Exit Attendance',
      community: 'Community',
      canteen: 'Cafeteria / Canteen',
      banner: 'Banners & Announcements'
    };

    const serviceDescriptions = `Available services and what they handle:
- banner: company events, announcements, banners, promotions, highlights, what's new
- travel: book/raise/arrange travel, trips, flights, tickets
- seatbooking: book/reserve/cancel a seat, desk, or workspace
- entryexit: attendance, swipe details/records, punch in/out, check-in/out, working hours, entry/exit/in/out time
- community: join communities or clubs, show/list communities, community membership
- canteen: cafeteria menu, food menu, today's lunch/dinner/breakfast`;

    const historyText = serviceHistory
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${(m.content || '').substring(0, 300)}`)
      .join('\n');

    const systemPrompt = `You are a routing assistant for a workplace chatbot at Bosch.

${serviceDescriptions}

The user's last active service was: ${serviceLabels[lastService] || lastService} (key: "${lastService}").

Recent ${serviceLabels[lastService] || lastService} conversation:
${historyText}

New user message: "${query}"

Decide if the new message is:
1. A follow-up/continuation of the above conversation (same service)
2. A new request clearly belonging to a DIFFERENT service from the list above
3. A new request for the same service or ambiguous

Follow-up means it:
- Corrects a detail from prior exchange ("I meant April 30th", "actually make it Bangalore")
- Confirms or denies something asked ("yes", "no", "go ahead", "cancel that")
- Refers back with pronouns ("that", "it", "the same", "instead", "actually")
- Is a short clarification only meaningful in context of prior messages

Reply with ONLY valid JSON using one of these forms:
- Follow-up to same service: {"isFollowUp": true, "targetService": "${lastService}"}
- New request for a different service: {"isFollowUp": false, "targetService": "<service-key>"}
- New request for same service or unclear: {"isFollowUp": false, "targetService": null}`;

    const response = await openai.chat.completions.create({
      model: getChatModelName('gpt-4o-mini'),
      messages: [{ role: 'user', content: systemPrompt }],
      max_tokens: 60,
      temperature: 0
    });

    const raw = response.choices[0].message.content.trim();
    const parsed = JSON.parse(raw);
    console.log(`[ContextResolve] "${query}" → isFollowUp=${parsed.isFollowUp}, targetService=${parsed.targetService} (lastService=${lastService})`);
    return {
      isFollowUp: parsed.isFollowUp === true,
      targetService: parsed.targetService || null
    };
  } catch (e) {
    console.warn('[ContextResolve] LLM context resolution failed, defaulting to no follow-up:', e.message);
    return { isFollowUp: false, targetService: null };
  }
}

function resolveRelativeDates(queryText) {
  const q = String(queryText || '');

  const istNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));

  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];

  const ordinalSuffix = (d) => {
    const v = d % 100;
    if (v >= 11 && v <= 13) return 'th';
    switch (d % 10) {
      case 1: return 'st';
      case 2: return 'nd';
      case 3: return 'rd';
      default: return 'th';
    }
  };

  const fmtDate = (date) => {
    const d = date.getDate();
    return `${MONTHS[date.getMonth()]} ${d}${ordinalSuffix(d)} ${date.getFullYear()}`;
  };

  const shiftDays = (n) => {
    const d = new Date(istNow);
    d.setDate(d.getDate() + n);
    return d;
  };

  const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

  let result = q;

  // Multi-word patterns first (must precede single-word replacements)
  result = result.replace(/\bday\s+before\s+yesterday\b/gi, fmtDate(shiftDays(-2)));
  result = result.replace(/\bday\s+after\s+tomorrow\b/gi, fmtDate(shiftDays(2)));

  // Single-word relative references
  result = result.replace(/\byesterday\b/gi, fmtDate(shiftDays(-1)));
  result = result.replace(/\btomorrow\b/gi, fmtDate(shiftDays(1)));
  result = result.replace(/\btoday\b/gi, fmtDate(istNow));

  // "last/previous <weekday>"
  result = result.replace(
    /\b(?:last|previous)\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/gi,
    (_, day) => {
      const target = DAYS.indexOf(day.toLowerCase());
      const cur = istNow.getDay();
      let diff = cur - target;
      if (diff <= 0) diff += 7;
      return fmtDate(shiftDays(-diff));
    }
  );

  // "next/coming <weekday>"
  result = result.replace(
    /\b(?:next|coming)\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/gi,
    (_, day) => {
      const target = DAYS.indexOf(day.toLowerCase());
      const cur = istNow.getDay();
      let diff = target - cur;
      if (diff <= 0) diff += 7;
      return fmtDate(shiftDays(diff));
    }
  );

  // "this <weekday>" — nearest upcoming occurrence (same day = today)
  result = result.replace(
    /\bthis\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/gi,
    (_, day) => {
      const target = DAYS.indexOf(day.toLowerCase());
      const cur = istNow.getDay();
      let diff = target - cur;
      if (diff < 0) diff += 7;
      return fmtDate(shiftDays(diff));
    }
  );

  return result;
}



/**
 * Unified chat endpoint with intelligent routing
 * Routes queries to appropriate MCP service using OpenAI classification
 */
app.post('/api/chat', chatRateLimiter, async (req, res) => {
  try {
    const { query, sessionId, locationId, employeeNumber, conversationHistory, activeService } = req.body;

    // Extract auth headers (check both header and body) and strictly sanitize
    let authToken = req.headers['authorization'] || req.body.authToken || req.body.authorization;
    if (authToken && typeof authToken === 'string') {
      authToken = authToken.trim().replace(/[\r\n]/g, '');
    }
    const headerEmployeeNumber = req.headers['x-employee-number'];
    const empNumber = headerEmployeeNumber || employeeNumber || process.env.DEFAULT_EMPLOYEE_NUMBER;

    if (!empNumber || empNumber.trim() === '') {
      console.log('[UnifiedChat] REJECTED: No user identity (employeeNumber) provided');
      return res.status(401).json({
        error: 'Authentication required',
        response: "Please log in to your Bosch account to access the AI Travel Assistant and other personal services."
      });
    }

    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    console.log('\n========== UNIFIED CHAT REQUEST ==========');
    console.log('Query:', query);
    console.log('Session:', sessionId);
    console.log('Employee:', empNumber);
    console.log('Auth present:', !!authToken);
    console.log('Auth token (first 60 chars):', authToken ? authToken.substring(0, 60) + '...' : 'NONE');
    console.log('Conversation history:', conversationHistory?.length || 0, 'messages');

    //Start Icube code Data protection

    // ===== DATA PROTECTION: LAYER 1 (REGEX) =====
    const regexCheck = privacyGuardService.containsSensitivePattern(query);
    if (regexCheck.isSensitive) {
      console.log(`[PrivacyGuard] Blocked query (Layer 1): ${regexCheck.reason}`);
      const blockMessage = "I cannot process this request as it contains sensitive information. Please remove any personal, financial, or business-critical data and try again.";
      return res.json({ success: true, response: blockMessage, service: 'privacy_guard', serviceName: 'Data Protection' });
    }

    // ===== DATA PROTECTION: LAYER 2 (LLM PROMISE) =====
    const semanticCheckPromise = privacyGuardService.checkSemanticSensitivity(query);

    //End Icube code Data protection


    // ===== CONVERSATION CONTEXT ORCHESTRATION =====

    // Step 0: Initialize context (load history if needed)
    await conversationContextService.initializeContext(sessionId, empNumber);

    // Step 0.5: Add user message to conversation context
    conversationContextService.addMessage(sessionId, 'user', query, {
      employeeNumber: empNumber,
      locationId
    });

    // Step 1: PRIVACY + SERVICE CLASSIFICATION (on original query before rewriting)
    // Single LLM call that identifies both privacy intent and which service the query belongs to.
    // This catches colleague data requests and also drives routing for all services.
    console.log(`[UnifiedChat] Processing query for Employee: ${empNumber}, User: ${req.body.userName || 'Unknown'}`);

    // ── UNIFIED PRIVACY + INTENT CLASSIFICATION ─────────────────────────────
    // Single LLM call returns: { intent, term, service }
    //   intent 'self'      → allow (user asking about own data)
    //   intent 'banner'    → route directly to banner (no disambiguation needed)
    //   intent 'ambiguous' → show disambiguation prompt (user picks banner or colleague)
    //   intent 'colleague' → block with privacy message
    //   service            → which service this query belongs to (used for routing & privacy skip)
    //
    // Services with no personal employee data (banner, community, seatbooking, canteen)
    // always get intent='self' from the LLM since no privacy risk exists.
    // Falls back to the legacy two-step flow if the LLM call fails.
    const _privCtx = conversationContextService.getContext(sessionId);
    const _recentMsgs = (_privCtx?.messages || []).slice(-6);
    let privacyResult = await classifyPrivacyWithContext(query, req.body.userName, _recentMsgs, activeService);

    // Public-data services: privacy check is irrelevant regardless of LLM result
    const _PUBLIC_SERVICES = ['banner', 'community', 'seatbooking', 'canteen'];
    const privacySkipped = privacyResult && _PUBLIC_SERVICES.includes(privacyResult.service);
    if (privacySkipped) privacyResult = { ...privacyResult, intent: 'self' };

    // LLM failed — fall back to the legacy two-step approach
    if (!privacyResult) {
      const legacyCheck = await classifyGeneralPrivacy(query, empNumber, req.body.userName);
      if (legacyCheck.isColleagueQuery) {
        const legacyAmbiguous = detectAmbiguousBannerOrPerson(query, sessionId);
        privacyResult = legacyAmbiguous
          ? { intent: 'ambiguous', term: legacyAmbiguous.term, service: 'general' }
          : { intent: 'colleague', term: null, service: 'general' };
      } else {
        privacyResult = { intent: 'self', term: null, service: 'general' };
      }
    }

    // ── Low-confidence clarification — ask rather than guess ─────────────────
    if (privacyResult.confidence === 'low' && !activeService) {
      const serviceLabels = {
        travel: 'Travel booking', seatbooking: 'Seat/desk booking',
        canteen: 'Cafeteria menu', entryexit: 'Attendance / entry-exit',
        community: 'Communities', banner: 'Announcements & banners', general: 'General query'
      };
      const primary = serviceLabels[privacyResult.service] || privacyResult.service;
      const alts = (privacyResult.alternatives || [])
        .map(s => serviceLabels[s] || s)
        .filter(Boolean);
      const optionsList = [primary, ...alts].map(l => `• ${l}`).join('\n');
      const clarifyResponse = `I'm not quite sure what you're looking for. Did you mean one of these?\n\n${optionsList}\n\nCould you give me a bit more detail?`;

      conversationContextService.addMessage(sessionId, 'assistant', clarifyResponse, { clarification: true });
      let conversationId = null;
      try {
        conversationId = await conversationDbService.saveConversation(empNumber, query, clarifyResponse, 'general');
      } catch (dbErr) {
        console.error('[Clarify] DB save error:', dbErr.message);
      }
      return res.json({ response: clarifyResponse, service: null, conversationId, isAmbiguous: true });
    }

    // ── Route based on privacy intent ────────────────────────────────────────
    if (privacyResult.intent === 'banner') {
      // LLM is confident the term refers to a banner — route directly, no disambiguation
      console.log(`[Privacy] Routing directly to banner for term: "${privacyResult.term}"`);
      // Let the query fall through to the router with banner context; don't block or disambig
      // (no return here — continues to Step 2 → router → banner service)

    } else if (privacyResult.intent === 'ambiguous') {
      const term = privacyResult.term || 'that';
      const _privCtx2 = conversationContextService.getContext(sessionId);
      const preferBanner = _privCtx2?.lastService === 'banner';
      const disambigResponse = preferBanner
        ? `It looks like **${term}** could refer to a banner/announcement or a colleague. Since you were recently viewing banners, did you mean:\n\n- **"Show Banner ${term}"** — to view banner details\n- **"Show colleague ${term}"** — *(note: I can only share your own personal data, not a colleague's)*`
        : `**${term}** could refer to a banner/announcement or a colleague. Could you clarify?\n\n- **"Show Banner ${term}"** — to view banner details\n- **"Show colleague ${term}"** — *(note: I can only share your own personal data, not a colleague's)*`;

      conversationContextService.addMessage(sessionId, 'assistant', disambigResponse, { disambiguation: true, term });

      let conversationId = null;
      try {
        conversationId = await conversationDbService.saveConversation(empNumber, query, disambigResponse, 'banner');
      } catch (dbErr) {
        console.error('[Privacy] Disambiguation DB save error:', dbErr.message);
      }

      return res.json({
        response: disambigResponse,
        service: 'banner',
        serviceName: 'Banner Assistant',
        success: true,
        conversationId
      });

    } else if (privacyResult.intent === 'colleague') {
      console.log('[Privacy] Blocked colleague data query by unified classifier');

      // Save the privacy response to conversation context
      const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

      conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
        blocked: true,
        reason: 'colleague_privacy'
      });

      // Save to DB
      let conversationId = null;
      try {
        conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
      } catch (dbErr) {
        console.error('[Privacy] DB save error:', dbErr.message);
      }

      return res.json({
        response: privacyResponse,
        service: 'privacy_guard',
        serviceName: 'Privacy Protection',
        success: true,
        conversationId
      });
    }

    // ── CONFIDENCE CHECK & CLARIFICATION ────────────────────────────────────────
    // If the LLM is not confident about which service the query belongs to,
    // ask the user to clarify instead of guessing and potentially giving a wrong answer.
    // Skip clarification when: the query is a follow-up (has lastService context),
    // the privacy intent itself is ambiguous/colleague (handled above), or service=general.
    const _hasActiveContext = Boolean(_privCtx?.lastService);
    if (
      privacyResult?.confidence === 'low' &&
      privacyResult.intent === 'self' &&
      !_hasActiveContext
    ) {
      const _serviceLabelsForClarif = {
        banner: { label: 'Events & Announcements', hint: 'company events, banners, promotions' },
        travel: { label: 'Travel Booking', hint: 'raise or track a travel request' },
        seatbooking: { label: 'Seat / Desk Booking', hint: 'reserve or cancel a seat or desk' },
        entryexit: { label: 'Attendance & Entry/Exit', hint: 'swipe records, working hours, punch times' },
        community: { label: 'Communities & Clubs', hint: 'join or explore Bosch communities' },
        canteen: { label: 'Cafeteria Menu', hint: 'today\'s food menu or meal options' }
      };

      const candidates = [privacyResult.service, ...(privacyResult.alternatives || [])]
        .filter(s => s && s !== 'general' && _serviceLabelsForClarif[s]);

      if (candidates.length > 0) {
        const options = candidates
          .map(s => `- **${_serviceLabelsForClarif[s].label}** — ${_serviceLabelsForClarif[s].hint}`)
          .join('\n');
        const clarifyResponse = `I'm not sure exactly what you're looking for. Could you be more specific? You might be asking about:\n\n${options}\n\nFeel free to rephrase and I'll help you right away!`;

        conversationContextService.addMessage(sessionId, 'assistant', clarifyResponse, { clarification: true });
        let conversationId = null;
        try {
          conversationId = await conversationDbService.saveConversation(empNumber, query, clarifyResponse, 'clarification');
        } catch (dbErr) {
          console.error('[Clarification] DB save error:', dbErr.message);
        }
        return res.json({ response: clarifyResponse, service: 'clarification', serviceName: 'Clarification', success: true, conversationId });
      }
    }

    // Step 2a: Quick check for simple greetings - route them directly to general
    const greetingKeywords = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings'];
    const lowerQuery = query.toLowerCase().trim();
    const isSimpleGreeting = lowerQuery.length < 20 && greetingKeywords.some(greeting => lowerQuery.includes(greeting));

    if (isSimpleGreeting) {
      console.log('[Routing] Simple greeting detected, routing to general: "' + query + '"');
      const generalResponse = await intelligentRouter.generateGeneralResponse(query, conversationHistory);
      return res.json({
        success: true,
        response: generalResponse,
        service: 'general',
        serviceName: 'General Assistant'
      });
    }

    // Step 2b: Unified context resolver — single LLM call that detects follow-ups,
    // rewrites incomplete queries with explicit context values, and identifies service
    // switches — all without word-count heuristics or keyword blocklists.
    // This replaces both the old word-count-gated rewriteQueryWithContext call AND
    // the separate resolveQueryContext call that previously ran in Step 3.
    console.log('[Context] Resolving context with sessionId:', sessionId);
    const unifiedContext = await conversationContextService.resolveAndRewriteQuery(sessionId, query);

    const effectiveQuery = unifiedContext.rewrittenQuery;
    const wasRewritten   = unifiedContext.wasRewritten;

    console.log('[Context] Was rewritten:', wasRewritten);
    console.log('[Context] Effective query:', effectiveQuery);

    if (wasRewritten) {
      console.log('[Context] Original query:', query);
      console.log('[Context] Rewritten query:', effectiveQuery);
      console.log('[Context] Resolved service:', unifiedContext.targetService);
    }

    // Step 2c: NARROW PRIVACY CHECK on the rewritten query
    // ONLY check for explicit name injection (possessive "Rahul's" or
    // We do NOT run the full detectColleagueQuery here because AI-rewritten queries
    // might introduce words like "Provide" (capitalized) which trip the privacy guard falsely.
    // We only check for explicit name injection patterns.
    const strictEvasionRe = /\b([A-Z][a-z]{2,})(?:'s|s')\s+(?:entry|exit|attendance|time|swipe|leave|record|data|details|info|information)/g;
    const strictForEvasionRe = /\b(?:of|for)\s+([A-Z][a-z]{2,})\b/g;

    if (wasRewritten && effectiveQuery !== query && !_PUBLIC_SERVICES.includes(privacyResult?.service)) {
      const loggedInNames = [];
      if (req.body.userName) {
        req.body.userName.toLowerCase().split(/\s+/).filter(Boolean).forEach(p => loggedInNames.push(p));
        loggedInNames.push(req.body.userName.toLowerCase());
      }
      const isOwnNameRewrite = (n) => loggedInNames.includes(n.toLowerCase());

      // Known safe words: derive from global nonNames whitelist + AI rewrite verbs from config
      // This eliminates the stale duplicate "rewriteSafe" list — single source of truth.
      const _nonNamesArr = configService.getPrivacyWhitelistSync().map(w => w.toLowerCase());
      const _aiVerbs = configService.getKeywordConfigSync().privacyDetection.aiRewriteVerbs;
      const rewriteSafe = new Set([..._nonNamesArr, ..._aiVerbs, 'me', 'myself']);

      let nameInjected = false;
      let nameInjectedReason = '';

      // Only block: possessive "Name's data" injected into rewrite
      const possMatch = effectiveQuery.match(/\b([A-Z][a-z]{2,})(?:'s|s')\s+/g);
      if (possMatch) {
        for (const m of possMatch) {
          const name = m.replace(/('s|s')\s*$/i, '').trim().toLowerCase();
          if (!rewriteSafe.has(name) && !isOwnNameRewrite(name)) {
            nameInjected = true;
            nameInjectedReason = `Possessive name injected in rewrite: ${m.trim()}`;
            break;
          }
        }
      }

      // Only block: explicit "for <ProperName>" at end of sentence (evasion pattern)
      if (!nameInjected) {
        const forNameMatch = effectiveQuery.match(/\bfor\s+([A-Z][a-z]{3,}(?:\s+[A-Z][a-z]{3,})?)\s*[?.!]?$/);
        if (forNameMatch) {
          const matchedPhrase = forNameMatch[1];
          const words = matchedPhrase.toLowerCase().split(/\s+/).filter(Boolean);

          // It's a violation if ANY word in the phrase is NOT safe AND NOT the user's name
          const hasInsecureWord = words.some(word => !rewriteSafe.has(word) && !isOwnNameRewrite(word));

          if (hasInsecureWord) {
            nameInjected = true;
            nameInjectedReason = `Name injected via "for <Name>" evasion: ${matchedPhrase}`;
          }
        }
      }

      if (nameInjected) {
        console.log('[Privacy] Blocked REWRITTEN query (name injection):', nameInjectedReason);
        console.log('[Privacy] Original was:', query);
        console.log('[Privacy] Rewritten was:', effectiveQuery);

        const privacyResponse = "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR.";

        conversationContextService.addMessage(sessionId, 'assistant', privacyResponse, {
          blocked: true,
          reason: 'colleague_privacy_rewritten'
        });

        let conversationId = null;
        try {
          conversationId = await conversationDbService.saveConversation(empNumber, query, privacyResponse, 'privacy_guard');
        } catch (dbErr) {
          console.error('[Privacy] DB save error:', dbErr.message);
        }

        return res.json({
          response: privacyResponse,
          service: 'privacy_guard',
          serviceName: 'Privacy Protection',
          success: true,
          conversationId
        });
      }
    }

    // Step 3: Classify the query using AI (use rewritten query for better classification)
    // If context already inferred a service, use that as a hint
    const identityPattern = /\b(who am i|my name|what is my name|employee name|identify me)\b/i;
    const isIdentityQuery = identityPattern.test(effectiveQuery);

    // ── Context resolution result (from Step 2b unified call) ───────────────────
    // isFollowUp and targetService are already resolved by resolveAndRewriteQuery above.
    // We just derive historyForRouter from the result here.
    const _ctx = conversationContextService.getContext(sessionId);
    let isFollowUp = unifiedContext.isFollowUp;
    // Pass service-filtered history to the router only on follow-ups so the router
    // classifies with the right context. Fresh queries get no prior history to avoid bias.
    const historyForRouter = isFollowUp && _ctx?.lastService
      ? conversationContextService.getServiceHistory(sessionId, _ctx.lastService, 6)
      : [];
    console.log(`[Routing] isFollowUp=${isFollowUp}, targetService=${unifiedContext.targetService}, passing ${historyForRouter.length} history messages to router`);
    // ────────────────────────────────────────────────────────────────────────────

    let classification = { service: 'general', serviceName: 'General Assistant' };
    if (!isIdentityQuery) {
      classification = await intelligentRouter.routeQuery(
        effectiveQuery,
        historyForRouter
      );
    } else {
      console.log('[Routing] Identity query detected, forcing entryexit service');
      classification = { service: 'entryexit', serviceName: 'Entry/Exit Time Tracking' };
    }

    // Override classification using LLM signals — priority order (highest first):
    //   1. Privacy LLM identified the service on the original query
    //   2. Unified context resolver: follow-up OR detected service switch
    //      (replaces the old separate "rewriter inferred service" + "resolveQueryContext" priorities)
    //   3. Router's own classification (lowest priority, used as fallback)
    let finalService = classification.service;

    // Priority 1: Privacy LLM service identification
    if (!isIdentityQuery && privacyResult?.service && privacyResult.service !== 'general') {
      console.log(`[Routing] Privacy LLM identified service: '${privacyResult.service}'`);
      finalService = privacyResult.service;
    }

    // Priority 2: Unified context resolver (follow-up same-service OR detected service switch).
    // Only applied when the resolver returned a specific targetService (Cases 1 & 2).
    // Case 3 (new self-contained query) returns targetService=null and does not override.
    if (!isIdentityQuery && unifiedContext.targetService && unifiedContext.targetService !== 'general'
        && unifiedContext.targetService !== finalService) {
      console.log(`[Routing] Unified context resolver: '${finalService}' → '${unifiedContext.targetService}' (isFollowUp=${unifiedContext.isFollowUp})`);
      finalService = unifiedContext.targetService;
    }

    // CONTEXT-SWITCH FIX: If the resolved service differs from the previous service on a
    // fresh (non-follow-up) query, reset stale topic/date context so future follow-ups
    // inherit the new service rather than the old one.
    if (!isFollowUp) {
      const prevContext = conversationContextService.getContext(sessionId);
      if (prevContext.lastService && prevContext.lastService !== finalService) {
        console.log(`[Context] Service switch detected: ${prevContext.lastService} → ${finalService}. Resetting stale context.`);
        conversationContextService.updateServiceContext(sessionId, {
          service: finalService,
          topic: null,
          date: null,
          month: null
        });

        // If the user was mid-travel-booking and switches to another service,
        // clear the incomplete travelState so it doesn't silently resume if
        // the user is ever routed back to travel without explicitly restarting.
        // A complete booking (isComplete=true, approved=true) that already
        // reached the agent is also cleared — the agent confirms separately
        // and we don't want a duplicate submission on an unrelated re-visit.
        if (prevContext.lastService === 'travel') {
          const ctx = conversationContextService.getContext(sessionId);
          if (ctx.travelState && (ctx.travelState.from || ctx.travelState.to || ctx.travelState.isComplete)) {
            ctx.travelState = {
              from: null, to: null, startDate: null, endDate: null,
              passengers: 1, modeOfTravel: null, travelClass: null, preferences: null,
              isComplete: false, approved: false, missingFields: []
            };
            console.log('[Context] Cleared travelState due to mid-booking service switch away from travel.');
          }
        }
      }
    }

    //Start Icube code

    // ===== DATA PROTECTION: AWAIT LAYER 2 (LLM) =====
    const semanticCheck = await semanticCheckPromise;
    if (semanticCheck.isSensitive) {
      console.log(`[PrivacyGuard] Blocked query (Layer 2 Semantic): ${semanticCheck.category} - ${semanticCheck.reason}`);
      const blockMessage = "I cannot process this request as it contains sensitive business or personal information. Please remove any confidential data and try again.";
      return res.json({ success: true, response: blockMessage, service: 'privacy_guard', serviceName: 'Data Protection' });
    }

    // ===== SCOPE GUARD: Detect out-of-scope queries (Universal) =====
    // Only check if it's NOT a simple greeting or identity query
    if (!isIdentityQuery) {
      const scopeCheck = await privacyGuardService.checkIfOutOfScope(effectiveQuery);
      if (scopeCheck.isOutOfScope) {
        console.log(`[ScopeGuard] Out-of-scope query detected: ${scopeCheck.reason}`);
        const outOfScopeResponse = `I'm sorry, but I can only assist with topics related to Bosch workplace services. Your question appears to be outside my scope.\n\nHere's what I can help you with:\n\n🍽️ **Canteen** – Today's cafeteria menu, food items, meal timings\n⏰ **Entry/Exit Tracking** – Attendance, working hours, swipe records\n✈️ **Travel** – Business trip booking, travel settlements, expense claims\n💺 **Seat Booking** – Desk/workspace reservation\n👥 **Community** – Bosch/BGSW communities, clubs, groups\n📢 **Company News** – Announcements, upcoming BGSW events, promotions\n\nHow can I assist you with one of these services?`;

        // Save the flagged response to conversation context
        conversationContextService.addMessage(sessionId, 'assistant', outOfScopeResponse, {
          service: 'out_of_scope',
          flagged: true
        });

        return res.json({
          success: true,
          response: outOfScopeResponse,
          service: 'out_of_scope',
          serviceName: 'Scope Guard',
          isOutOfScope: true,
          scopeReason: scopeCheck.reason,
          conversationId: null
        });
      }
    }

    // Now safe to log and save to context
    console.log('Query (Passed Privacy Checks):', query);
    conversationContextService.addMessage(sessionId, 'user', query, {
      employeeNumber: empNumber,
      locationId
    });

    //End Icube code

    // Tag the user message that was stored at the top of this request with the
    // resolved service so future getServiceHistory() calls return a labelled thread.
    conversationContextService.tagLastUserMessage(sessionId, { service: finalService });

    console.log('Classification:', finalService, '-', classification.serviceName);

    /**
     * Helper to sanitize browser-sent parameters that might be literal strings "null" or "undefined"
     * @param {any} val - Value to sanitize
     * @returns {any} - Sanitized value
     */
    const sanitizeParam = (val) => {
      if (typeof val === 'string') {
        const trimmed = val.trim();
        const lowerVal = trimmed.toLowerCase();
        if (lowerVal === 'null' || lowerVal === 'undefined' || lowerVal === 'nan' || lowerVal === '') {
          return null;
        }
        return trimmed; // Return the trimmed version
      }
      return val;
    };

    // Step 3: Route to appropriate service
    let result;
    const routingContext = {
      sessionId: sanitizeParam(sessionId),
      authToken: sanitizeParam(authToken) ? sanitizeParam(authToken).replace(/^Bearer\s+/i, '') : null,
      employeeNumber: sanitizeParam(empNumber),
      locationId: sanitizeParam(locationId)
    };

    // Global Diagnostic Logging
    console.log(`[UnifiedChat] Processing ${finalService} for ${empNumber}.`);
    console.log(`[UnifiedChat] AuthToken Source: ${req.headers['authorization'] ? 'Header' : (req.body.authToken || req.body.authorization ? 'Body' : 'None')}`);
    if (routingContext.authToken) {
      console.log(`[UnifiedChat] AuthToken Length: ${routingContext.authToken.length}`);
      console.log(`[UnifiedChat] AuthToken Sample: ${routingContext.authToken.substring(0, 5)}...${routingContext.authToken.substring(routingContext.authToken.length - 5)}`);
    } else {
      console.warn('[UnifiedChat] WARNING: No authToken found for routingContext');
    }

    // Resolve relative date references ("yesterday", "next Monday", etc.) to absolute
    // IST dates for services that forward the query to downstream agents.
    // Using a separate variable so the original query/effectiveQuery stay intact for
    // logging and context-rewrite tracking.
    let effectiveQueryForService = effectiveQuery;
    if (['travel', 'seatbooking', 'entryexit'].includes(finalService)) {
      const _resolved = resolveRelativeDates(effectiveQuery);
      if (_resolved !== effectiveQuery) {
        console.log(`[DateResolver] Resolved relative date: "${effectiveQuery}" → "${_resolved}"`);
        effectiveQueryForService = _resolved;
      }
    }

    // Use finalService for routing (accounts for context-inferred service)
    switch (finalService) {
      case 'canteen': {
        // ── Token Auth: use dedicated canteen serviceToken from browser sessionStorage ──
        // Priority 1: serviceTokens.canteen — own SessionId, no server round-trip.
        // Priority 2: server-side cache fallback (older clients / SSO edge cases).
        let canteenJwtToken = null;
        const canteenClientTokens = req.body.serviceTokens?.canteen;
        if (canteenClientTokens?.jwt) {
          canteenJwtToken = canteenClientTokens.jwt;
          console.log('[UnifiedChat] Canteen: using dedicated serviceToken from browser sessionStorage');
        } else if (routingContext.authToken && routingContext.employeeNumber) {
          try {
            const userTokens = await boschAuthService.getTokenForUser(
              routingContext.employeeNumber,
              routingContext.authToken,
              'canteen'
            );
            canteenJwtToken = userTokens?.jwtToken || null;
            console.log('[UnifiedChat] Canteen: JWT token obtained from server cache fallback:', !!canteenJwtToken);
          } catch (tokenErr) {
            console.warn('[UnifiedChat] Canteen: Failed to get JWT token (will call MCP without auth):', tokenErr.message);
          }
        } else {
          console.warn('[UnifiedChat] Canteen: No authToken/employeeNumber — skipping JWT fetch');
        }

        // Use existing canteen logic with context-aware query
        const mcpClient = await getClient();
        let canteenContext = conversationContexts.get(sessionId) || {};
        if (locationId) {
          canteenContext.location_id = locationId;
          canteenContext.location = locationId === 1 ? 'bangalore' : 'coimbatore';
          conversationContexts.set(sessionId, canteenContext);
        }
        // Inject JWT so intelligent-canteen → mcp-client-http can pass it as Authorization header
        canteenContext.authToken = canteenJwtToken;

        // Use effectiveQuery (rewritten with context) instead of original query
        const canteenResult = await processIntelligentQuery(effectiveQuery, mcpClient, canteenContext);
        if (canteenResult.location_id) {
          canteenContext.location_id = canteenResult.location_id;
          canteenContext.location = canteenResult.location;
          conversationContexts.set(sessionId, canteenContext);
        }
        result = {
          success: true,
          response: canteenResult.response,
          service: 'canteen',
          serviceName: 'Canteen Menu',
          needs_location: canteenResult.needs_location,
          location_id: canteenResult.location_id,
          menuData: canteenResult.menuData
        };
        break;
      }

      case 'entryexit': {
        // ── Token Auth: use dedicated entryexit serviceToken from browser sessionStorage ──
        // Priority 1: serviceTokens.entryexit — own SessionId, no server round-trip.
        // Priority 2: server-side cache fallback (older clients / SSO edge cases).
        let entryExitJwtToken = null;
        const entryExitClientTokens = req.body.serviceTokens?.entryexit;
        if (entryExitClientTokens?.jwt) {
          entryExitJwtToken = entryExitClientTokens.jwt;
          console.log('[UnifiedChat] Entry/Exit: using dedicated serviceToken from browser sessionStorage');
        } else if (routingContext.authToken && routingContext.employeeNumber) {
          try {
            const userTokens = await boschAuthService.getTokenForUser(
              routingContext.employeeNumber, routingContext.authToken, 'entryexit'
            );
            entryExitJwtToken = userTokens?.jwtToken || null;
            console.log(`[UnifiedChat] Entry/Exit JWT token obtained from server cache fallback: ${!!entryExitJwtToken}`);
          } catch (tokenErr) {
            console.warn('[UnifiedChat] Entry/Exit: Failed to get JWT token:', tokenErr.message);
          }
        }

        // Use existing entry/exit logic with context-aware query
        const entryExitV2Client = getEntryExitV2Client();
        // effectiveQueryForService has relative dates resolved (e.g. "yesterday" → "May 1st 2026")
        const entryExitResult = await entryExitV2Client.processQueryWithAI(
          effectiveQueryForService, empNumber, req.body.userName, entryExitJwtToken, routingContext.authToken
        );
        result = {
          success: entryExitResult.success,
          response: entryExitResult.response,
          service: 'entryexit',
          serviceName: 'Entry/Exit Time Tracking',
          employeeNumber: entryExitResult.employeeNumber,
          tool_used: entryExitResult.tool
        };
        break;
      }

      case 'travel':
        // Ensure userName and identity metadata are correctly propagated
        if (req.body.userName) {
          routingContext.userName = req.body.userName;
        }

        // Resolve tokens for Travel.
        // Priority 1: serviceTokens sent by the frontend (stored in browser sessionStorage
        //             at login — no server round-trip, survives server restarts).
        // Priority 2: server-side cache lookup (fallback for older clients / SSO edge cases).
        // IMPORTANT: routingContext.sessionId (the frontend UUID) is intentionally NOT
        // overwritten.  The travel service uses it to look up travelState from
        // conversationContextService.  Overwriting it with the Bosch-issued agentSessionId
        // would break multi-turn booking conversations (travelState never found → Phase 2
        // never reached).
        try {
          const clientTokens = req.body.serviceTokens?.travel;
          if (clientTokens?.jwt) {
            // Fast path: use the token the frontend already has in sessionStorage.
            routingContext.jwtToken = clientTokens.jwt;
            routingContext.agentSessionId = clientTokens.sessionId;
            console.log('[UnifiedChat] Travel: using serviceTokens from browser sessionStorage');
            console.log('[UnifiedChat] Agent-generated sessionId for A2A contextId:', clientTokens.sessionId);
          } else if (routingContext.authToken) {
            // Fallback: resolve from server-side cache (or mint fresh if needed).
            console.log(`[UnifiedChat] Travel: serviceTokens missing — falling back to server cache (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken, 'travel');
            if (userTokens && userTokens.jwtToken) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.agentSessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token successfully attached to routingContext (Travel, cache fallback)');
            }
          } else {
            console.warn('[UnifiedChat] No authToken and no serviceTokens provided for travel — user may not be logged in');
          }
        } catch (tokenError) {
          console.error('[UnifiedChat] Token resolution failed for Travel:', tokenError.message);
        }

        // When there is an active A2A travel session the A2A agent manages its own
        // multi-turn state and expects the user's raw reply (e.g. "yes", "confirm").
        // Re-writing the query in that case can corrupt structured values (cost-centre
        // codes, WBS elements, etc.) that the LLM rewriter extracts from the
        // truncated conversation history.  Use the original user message directly.
        {
          const _travelCtx = conversationContextService.getContext(routingContext.sessionId);
          const _hasActiveA2ASession = !!_travelCtx?.travelAgentContextId;
          // Active A2A: skip context rewrite but still resolve relative dates in the raw query.
          // Normal path: use effectiveQueryForService (context-rewritten + dates resolved).
          const queryForTravel = _hasActiveA2ASession ? resolveRelativeDates(query) : effectiveQueryForService;
          if (_hasActiveA2ASession) {
            console.log('[UnifiedChat] Travel: active A2A session detected — using original query (skipping rewrite) to avoid code truncation');
          }

          // Use effectiveQuery for context-aware processing
          const travelResult = await travelService.processQuery(queryForTravel, {
            authToken: routingContext.authToken,
            employeeNumber: empNumber,
            jwtToken: routingContext.jwtToken,
            sessionId: routingContext.sessionId,       // frontend UUID → travelState lookup
            agentSessionId: routingContext.agentSessionId, // agent-generated → A2A contextId
            userName: req.body.userName || routingContext.user?.name || 'Bosch User'
          });
          result = {
            success: travelResult.success,
            response: travelResult.response,
            service: 'travel',
            serviceName: 'Travel Assistant',
            data: travelResult.data,
            travelState: travelResult.travelState // Include structured state for frontend
          };
        }
        break;

      case 'seatbooking':
        // Ensure userName and identity metadata are correctly propagated
        // (mirror the travel case — the A2A seat-booking agent may use this
        // to identify the requester in the booking record and the privacy
        // check uses it to whitelist the user's own name).
        if (req.body.userName) {
          routingContext.userName = req.body.userName;
        }

        // 2. Resolve tokens for Seat Booking.
        //    Priority 1: serviceTokens from browser sessionStorage (fast, no round-trip).
        //    Priority 2: server-side cache fallback.
        //    routingContext.sessionId (frontend UUID) intentionally NOT overwritten.
        try {
          const clientTokens = req.body.serviceTokens?.seatbooking;
          if (clientTokens?.jwt) {
            routingContext.jwtToken = clientTokens.jwt;
            routingContext.agentSessionId = clientTokens.sessionId;
            console.log('[UnifiedChat] SeatBooking: using serviceTokens from browser sessionStorage');
            console.log('[UnifiedChat] Agent-generated sessionId for A2A contextId:', clientTokens.sessionId);
          } else if (routingContext.authToken) {
            console.log(`[UnifiedChat] SeatBooking: serviceTokens missing — falling back to server cache (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken, 'seatbooking');
            if (userTokens && userTokens.jwtToken) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.agentSessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token successfully attached to routingContext (SeatBooking, cache fallback)');
            } else {
              console.warn('[UnifiedChat] getTokenForUser returned no jwtToken for SeatBooking — service will fallback.');
            }
          } else {
            console.log('[UnifiedChat] No authToken and no serviceTokens for seat-booking — service will fallback to Service Account');
          }
        } catch (tokenError) {
          console.error('[UnifiedChat] ERROR resolving tokens for seat booking:', tokenError.message);
          console.log('[UnifiedChat] Proceeding without user tokens - Seat Booking service will handle fallback.');
        }

        // effectiveQueryForService has relative dates resolved (e.g. "tomorrow" → "May 3rd 2026")
        const seatResult = await seatbookingService.processQuery(effectiveQueryForService, {
          authToken: routingContext.authToken,
          employeeNumber: routingContext.employeeNumber,
          jwtToken: routingContext.jwtToken,
          sessionId: routingContext.sessionId,         // frontend UUID → conversation context
          agentSessionId: routingContext.agentSessionId, // agent-generated → A2A contextId
          userName: req.body.userName || routingContext.user?.name || 'Bosch User',
          originalQuery: query  // raw user query before context rewriting — used as date-check fallback
        });

        // Seat Booking: No longer force a location selection popup.
        // Let the A2A agent's natural response handle the conversation.
        result = {
          success: seatResult.success,
          response: seatResult.response,
          service: 'seatbooking',
          serviceName: 'Seat Booking',
          data: seatResult.data,
          needs_location: false
        };
        break;

      case 'community':
        // Resolve tokens for Community.
        // Priority 1: serviceTokens.community — dedicated SessionId, no server round-trip.
        //             Uses MyBGSWAI clientID but its own independent SessionId so it never
        //             conflicts with entryexit or canteen when user switches context.
        // Priority 2: server-side cache fallback (older clients / SSO edge cases).
        try {
          const clientTokens = req.body.serviceTokens?.community;
          if (clientTokens?.jwt) {
            routingContext.jwtToken = clientTokens.jwt;
            routingContext.agentSessionId = clientTokens.sessionId;
            console.log('[UnifiedChat] Community: using dedicated serviceToken from browser sessionStorage');
          } else if (routingContext.authToken) {
            console.log(`[UnifiedChat] Community: serviceTokens missing — falling back to server cache (Employee: ${routingContext.employeeNumber})`);
            const userTokens = await boschAuthService.getTokenForUser(routingContext.employeeNumber, routingContext.authToken, 'community');
            if (userTokens && userTokens.jwtToken) {
              routingContext.jwtToken = userTokens.jwtToken;
              routingContext.agentSessionId = userTokens.sessionId;
              console.log('[UnifiedChat] JWT Token successfully attached to routingContext (Community, cache fallback)');
            } else {
              console.warn('[UnifiedChat] Token resolution returned no JWT for Community');
            }
          } else {
            console.warn('[UnifiedChat] No authToken and no serviceTokens found for Community resolution');
          }
        } catch (tokenError) {
          console.warn('[UnifiedChat] Token resolution warning for Community:', tokenError.message);
        }

        // Use effectiveQuery for context-aware processing
        const communityResult = await communityService.processQuery(effectiveQuery, {
          ...routingContext,
          jwtToken: routingContext.jwtToken,
          sessionId: routingContext.sessionId,         // frontend UUID → conversation context
          agentSessionId: routingContext.agentSessionId, // agent-generated → available for MCP/A2A
          userName: req.body.userName || routingContext.user?.name || 'Bosch User'
        });
        result = {
          success: communityResult.success,
          response: communityResult.response,
          service: 'community',
          serviceName: 'Bosch Community',
          data: communityResult.data
        };
        break;

      case 'banner':
        // Use effectiveQuery for context-aware processing
        const bannerResult = await bannerService.processBannerQuery(effectiveQuery);
        result = {
          success: !bannerResult.error,
          response: bannerResult.response,
          service: 'banner',
          serviceName: 'Company News/Snippets',
          banners: bannerResult.banners,
          hasBannerImages: bannerResult.hasBannerImages
        };
        break;

      case 'general':
        // Use effectiveQuery for context-aware processing
        // Get full context including persisted history
        const generalContext = conversationContextService.getContext(sessionId);
        const fullHistory = generalContext && generalContext.messages.length > 0 ? generalContext.messages : conversationHistory;

        const generalResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fullHistory);
        result = {
          success: true,
          response: generalResponse,
          service: 'general',
          serviceName: 'General Assistant'
        };
        break;

      default:
        // Check if it's a dynamic service
        const serviceConfig = mcpServiceManager.getService(finalService);
        if (serviceConfig) {
          try {
            const genericClient = new GenericMCPClient(serviceConfig);
            // Pass context
            const dynamicContext = {
              sessionId,
              employeeNumber: empNumber,
              locationId,
              history: conversationHistory
            };

            const dynamicResult = await genericClient.processQuery(effectiveQuery, dynamicContext);

            result = {
              success: dynamicResult.success,
              response: dynamicResult.response,
              service: finalService,
              serviceName: serviceConfig.name,
              data: dynamicResult.originalData
            };
          } catch (err) {
            console.error(`Error invoking dynamic service ${finalService}:`, err);
            // Fallback to general if dynamic service fails
            const fallbackContext = conversationContextService.getContext(sessionId);
            const fallbackHistory = fallbackContext && fallbackContext.messages.length > 0 ? fallbackContext.messages : conversationHistory;
            const fallbackResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, fallbackHistory);
            result = {
              success: true,
              response: fallbackResponse,
              service: 'general',
              serviceName: 'General Assistant (Fallback)'
            };
          }
        } else {
          // Unknown service, default to general
          const unknownContext = conversationContextService.getContext(sessionId);
          const unknownHistory = unknownContext && unknownContext.messages.length > 0 ? unknownContext.messages : conversationHistory;
          const unknownResponse = await intelligentRouter.generateGeneralResponse(effectiveQuery, unknownHistory);
          result = {
            success: true,
            response: unknownResponse,
            service: 'general',
            serviceName: 'General Assistant'
          };
        }
        break;
    }

    // ===== UPDATE CONVERSATION CONTEXT =====
    // Step 4: Store the AI response and update context metadata
    const topic = conversationContextService.extractTopicFromResponse(result.response, result.service);
    const dateInQuery = conversationContextService.extractDate(effectiveQuery);

    // Extract month reference from the query (e.g. "February 2026" → "2026-02")
    const monthNames = {
      january: '01', jan: '01', february: '02', feb: '02', march: '03', mar: '03',
      april: '04', apr: '04', may: '05', june: '06', jun: '06', july: '07', jul: '07',
      august: '08', aug: '08', september: '09', sep: '09', october: '10', oct: '10',
      november: '11', nov: '11', december: '12', dec: '12'
    };
    let monthInQuery = null;
    const monthRegex = /\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\b(?:\s+(\d{4}))?/i;
    const monthMatch = effectiveQuery.match(monthRegex);
    if (monthMatch) {
      const mNum = monthNames[monthMatch[1].toLowerCase()];
      const mYear = monthMatch[2] || new Date().getFullYear().toString();
      monthInQuery = `${mYear}-${mNum}`;
    }

    // Only add the assistant message to conversation context when it is a real
    // response. Hard errors (result.success === false) are noise for LLM context:
    // a message like "I'm temporarily unable to process travel bookings" in the
    // history would confuse the router on the next query and could cause the
    // context-rewriter to treat "try again" as a follow-up to a broken session.
    // The DB save (below) still records every turn for audit purposes.
    if (result.success !== false) {
      conversationContextService.addMessage(sessionId, 'assistant', result.response, {
        service: result.service,
        topic: topic,
        date: dateInQuery,
        month: monthInQuery,
        locationId: result.location_id || locationId
      });
    } else {
      console.log('[Context] Skipping addMessage for failed response (success=false) to keep history clean.');
    }

    // Always update the service context so routing stays accurate even after
    // an error (the user is still in the travel/seatbooking/etc. context).
    conversationContextService.updateServiceContext(sessionId, {
      service: result.service,
      topic: topic,
      date: dateInQuery,
      month: monthInQuery,
      locationId: result.location_id || locationId
    });

    console.log('[Context] Updated context - Service:', result.service, 'Topic:', topic, 'Date:', dateInQuery);
    console.log('Response service:', result.service);
    console.log('==========================================\n');

    // Include context info in response for debugging (optional)
    result.contextInfo = {
      wasRewritten: wasRewritten,
      originalQuery: wasRewritten ? query : undefined,
      effectiveQuery: wasRewritten ? effectiveQuery : undefined
    };

    // ===== PERSIST TO MS SQL AZURE DB =====
    // Save conversation to database (non-blocking, don't fail the response)
    let conversationId = null;
    try {
      // Generate a proper UUID for the session if the frontend sessionId isn't UUID format
      const { v4: uuidv4, validate: uuidValidate } = require('uuid');
      const dbSessionId = uuidValidate(sessionId) ? sessionId : uuidv4();

      conversationId = await conversationDbService.saveConversation(
        dbSessionId,
        result.service || 'web',
        query,
        result.response || ''
      );
    } catch (dbError) {
      console.error('[ConversationDB] Failed to persist (non-fatal):', dbError.message);
    }

    // Include conversationId in response for feedback reference
    result.conversationId = conversationId;

    res.json(result);

  } catch (error) {
    console.error('Unified chat error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process query',
      details: error.message,
      response: "I'm having trouble processing your request right now. Please try again."
    });
  }
});

/**
 * POST /api/chat/feedback - Submit feedback for a conversation
 * Body: { conversationId: number, feedback: number }
 * feedback: -1 = thumbs down, 0 = no feedback, 1 = thumbs up
 */
app.post('/api/chat/feedback', async (req, res) => {
  try {
    const { conversationId, feedback } = req.body;

    if (!conversationId) {
      return res.status(400).json({ error: 'conversationId is required' });
    }

    if (![-1, 0, 1].includes(feedback)) {
      return res.status(400).json({ error: 'feedback must be -1, 0, or 1' });
    }

    console.log(`[Feedback] Updating conversation ${conversationId} with feedback: ${feedback}`);
    const success = await conversationDbService.updateFeedback(conversationId, feedback);

    if (success) {
      res.json({ success: true, message: 'Feedback saved' });
    } else {
      res.status(404).json({ success: false, error: 'Conversation not found or DB unavailable' });
    }
  } catch (error) {
    console.error('Feedback error:', error);
    res.status(500).json({ success: false, error: 'Failed to save feedback' });
  }
});

// Get available services
app.get('/api/services', (req, res) => {
  const servicesMap = intelligentRouter.getAllServices();
  const servicesList = Object.entries(servicesMap).map(([id, s]) => ({
    id: id,
    name: s.name,
    icon: s.icon || 'ðŸ¤–', // Default icon if none provided
    description: s.description,
    isDynamic: !!s.isDynamic
  }));

  res.json({
    services: servicesList
  });
});

// Start server
app.listen(PORT, '0.0.0.0', async () => {
  // Initialize configuration
  try {
    const configService = require('./services/config-service');
    await configService.initialize();
  } catch (err) {
    console.error('Failed to initialize ConfigService:', err);
  }
  console.log(`Server running on port ${PORT}`);
  console.log(`Logs will be stored in: ${logsDir}`);
  console.log(`Entry/Exit MCP URL: ${process.env.ENTRYEXIT_MCP_URL || 'Using default URL'}`);
  console.log(`Smart routing enabled with services: canteen, entryexit, travel, seatbooking, community, banner`);
});