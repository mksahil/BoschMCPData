import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ConsentModal } from '@/components/ConsentModal';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { isAuthenticated, isLoading, user, hasConsented, recordConsent } = useAuth();
  const location = useLocation();

  // 1. Auth still initialising — show spinner
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading…</p>
        </div>
      </div>
    );
  }

  // 2. Not logged in — redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 3. Logged in but consent status still loading (null = API call in flight)
  if (hasConsented === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Checking access…</p>
        </div>
      </div>
    );
  }

  // 4. Logged in but not yet consented — show consent gate over a blank screen
  if (!hasConsented) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
        <ConsentModal
          userName={user?.name}
          onConsent={recordConsent}
        />
      </div>
    );
  }

  // 5. Authenticated + consented — render the page
  return <>{children}</>;
};

export default ProtectedRoute;
