import { useState, useCallback, useRef } from "react";

interface RateLimitState {
  isRateLimited: boolean;
  message: string;
  retryAfter: number; // seconds remaining
}

interface UseRateLimitReturn {
  isRateLimited: boolean;
  rateLimitMessage: string;
  retryAfter: number;
  handleRateLimitResponse: (response: Response, data: { error?: string }) => void;
}

export function useRateLimit(): UseRateLimitReturn {
  const [state, setState] = useState<RateLimitState>({
    isRateLimited: false,
    message: "",
    retryAfter: 0,
  });

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const handleRateLimitResponse = useCallback(
    (response: Response, data: { error?: string }) => {
      const retryAfter = parseInt(
        response.headers.get("Retry-After") || "60",
        10
      );
      const message =
        data?.error ||
        "Too many requests. Please wait before trying again.";

      // Clear any existing timers
      if (timerRef.current) clearTimeout(timerRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);

      setState({ isRateLimited: true, message, retryAfter });

      // Count down every second so UI can optionally show "retry in Xs"
      let remaining = retryAfter;
      countdownRef.current = setInterval(() => {
        remaining -= 1;
        setState((prev) => ({ ...prev, retryAfter: remaining }));
        if (remaining <= 0 && countdownRef.current) {
          clearInterval(countdownRef.current);
        }
      }, 1000);

      // Re-enable after the window expires
      timerRef.current = setTimeout(() => {
        if (countdownRef.current) clearInterval(countdownRef.current);
        setState({ isRateLimited: false, message: "", retryAfter: 0 });
      }, retryAfter * 1000);
    },
    []
  );

  return {
    isRateLimited: state.isRateLimited,
    rateLimitMessage: state.message,
    retryAfter: state.retryAfter,
    handleRateLimitResponse,
  };
}
