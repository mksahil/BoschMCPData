/**
 * Travel Service
 * Calls the Travel MCP Server (A2A Agent) for travel planning and settlements
 * Uses stable A2A Protocol (Mirroring SeatBooking implementation)
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');
const configService = require('./config-service');
const { createOpenAIClient, getChatModelName } = require('./openai-client');
const conversationContextService = require('./conversation-context-service');

// Bosch internal MCP servers use corporate PKI (Bosch root CA) not trusted by Node.js by default.
// rejectUnauthorized: false is intentional for internal-network services — not a public-internet risk.
const httpsAgent = new https.Agent({
  rejectUnauthorized: false // [INTERNAL-CA] Bosch corporate PKI — system CA not available to Node.js
});

class TravelService {
  constructor() {
    // A2A Host Agent URL (Travel Agent) - Using TRAVEL_API_URL as primary (confirmed Hub endpoint)
    let rawUrl = process.env.TRAVEL_API_URL || 'https://bgsw-travel-host-dev-001.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    // Ensure URL is trimmed and ends with exactly one slash for consistency
    this.apiUrl = rawUrl.trim().replace(/\/+$/, '') + '/';
    this.agentCardPath = '/.well-known/agent.json';

    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000;
    this.agentCard = null;
    this._openai = null;
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Fetch the agent card from the Travel A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) return this.agentCard;
    try {
      console.log(`[Travel] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(`${this.apiUrl}${this.agentCardPath}`, { httpsAgent, timeout: 10000 });
      this.agentCard = response.data;
      return this.agentCard;
    } catch (error) {
      console.error('[Travel] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Call the Travel A2A Agent using proper A2A protocol
   * Mirroring the working SeatBooking implementation for maximum stability
   */
  async callTravelAPI(message, employeeNumber, userOAuthToken, files = [], explicitJwtToken = null, explicitSessionId = null, userName = null, agentSessionId = null) {
    try {
      console.log(`[Travel] Calling A2A Travel Agent at: ${this.apiUrl}`);
      console.log('[Travel] Input context:', {
        employeeNumber,
        userName: userName || '(missing)',
        hasExplicitJwt: !!explicitJwtToken,
        explicitJwtPrefix: explicitJwtToken ? String(explicitJwtToken).substring(0, 30) + '...' : null,
        hasExplicitSession: !!explicitSessionId,
        hasOAuth: !!userOAuthToken
      });

      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;
      let authStrategy = null;

      // Strategy 1: Use explicit tokens if provided (passed from login context)
      if (jwtToken) {
        authStrategy = 'STRATEGY_1_EXPLICIT_USER_JWT';
        console.log('[Travel] ✅ Strategy 1: Using EXPLICIT user JWT token');
      }

      // Strategy 2: Try cached user tokens (travel-scoped cache)
      if (!jwtToken && userOAuthToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userOAuthToken, 'travel');
        if (cachedTokens) {
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
          authStrategy = 'STRATEGY_2_CACHED_USER_TOKENS';
          console.log('[Travel] ✅ Strategy 2: Using CACHED user tokens (travel clientId)');
        }
      }

      // Strategy 3: Convert OAuth to JWT using the travel clientId
      if (!jwtToken && userOAuthToken) {
        try {
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userOAuthToken, undefined, 'travel');
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
          authStrategy = 'STRATEGY_3_OAUTH_CONVERTED';
          console.log('[Travel] ✅ Strategy 3: User JWT generated with travel clientId');
        } catch (conversionError) {
          console.log('[Travel] ❌ Strategy 3 failed:', conversionError.message);
        }
      }

      // Sanitize tokens (prevent literal "null" strings from browsers)
      const isNullStr = (val) => typeof val === 'string' && (val.toLowerCase() === 'null' || val.toLowerCase() === 'undefined' || val === '');
      if (isNullStr(jwtToken)) jwtToken = null;
      if (isNullStr(sessionId)) sessionId = null;

      console.log(`[Travel] Final auth strategy used: ${authStrategy || 'NONE (will throw AUTH_REQUIRED)'}`);

      // No service-account fallback: if the user's own JWT could not be
      // resolved, fail loudly rather than silently impersonating a shared
      // service account. A shared service account JWT caused all users to
      // share the same A2A agent session, leaking travel data across users.
      if (!jwtToken) throw new Error('AUTH_REQUIRED');
      if (!sessionId) sessionId = boschAuthService.getOrCreateSessionId(employeeNumber, 'travel');

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Determine the contextId to use for this A2A call.
      //
      // Priority order:
      //   1. agentSessionId — from ResponseData.SessionId in /Token/GenrateTokenDetails.
      //      The agentic layer validates this against the JWT token, so it MUST be used
      //      when available. This is the proper session the agent expects.
      //   2. crypto.randomUUID() fallback — only when agentSessionId is unavailable
      //      (e.g. token refresh failed). A fresh UUID avoids inheriting broken state
      //      from a previous failed A2A call for the same frontend session.
      //
      // NOTE: the frontend sessionId (explicitSessionId) is intentionally NOT used here.
      // It is the conversation UUID used to look up travelState in conversationContextService,
      // not a session that the A2A agent layer recognises.
      const crypto = require('crypto');
      const isolatedSessionId = agentSessionId ||
        ((typeof crypto.randomUUID === 'function')
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`);

      console.log('[Travel] A2A contextId (sessionId):', isolatedSessionId);

      // Extract email/empNo from JWT claims (name is usually encrypted, so we
      // DO NOT pull it from there — see below).
      //
      // CRITICAL BUG HISTORY: Previously this block overwrote `userName` with
      // `claims.name` from the JWT. But the Bosch JWT stores `name` as an
      // encrypted AES blob (e.g. "mR1DfNIos4AKDqjZdIEl4AFu...=="), which the
      // downstream A2A agent can't parse. When that encrypted gibberish was
      // sent in `metadata.user_name`, the Travel agent fell back to its
      // hardcoded default test user "Votan" — causing retrieval responses to
      // start with "Votan, I checked your travel plans...". We now prefer the
      // explicit `userName` from the login context (which is the REAL plain
      // name) and only use a JWT claim if it clearly isn't an encrypted blob.
      let jwtName = null;
      let jwtEmail = null;
      let jwtEmpNo = null;

      const looksEncrypted = (val) => {
        if (typeof val !== 'string') return false;
        const v = val.trim();
        if (!v) return false;
        // Heuristic: encrypted blobs are base64-ish, no spaces, length > 24,
        // and usually end with "==" padding. Real names have spaces or short.
        if (v.includes(' ')) return false;
        if (v.length < 24) return false;
        if (/[^A-Za-z0-9+/=_-]/.test(v)) return false;
        return v.endsWith('==') || v.length > 40;
      };

      try {
        if (typeof jwtToken === 'string' && jwtToken.split('.').length === 3) {
          const payloadB64 = jwtToken.split('.')[1]
            .replace(/-/g, '+').replace(/_/g, '/');
          const padded = payloadB64 + '==='.slice((payloadB64.length + 3) % 4);
          const claims = JSON.parse(Buffer.from(padded, 'base64').toString('utf8'));

          // DIAGNOSTIC: dump the claim keys and the raw name claim so we can
          // tell from the logs whether the JWT is a service-account token
          // (whose name claim decrypts server-side to "Votan") or the real
          // user JWT.
          const claimKeys = Object.keys(claims).filter(k => !['exp', 'iat', 'nbf', 'iss', 'aud', 'jti'].includes(k));
          console.log('[Travel] 🔑 JWT claim keys:', claimKeys);
          console.log('[Travel] 🔑 JWT raw user claims:', {
            name: claims.name || claims.Name || null,
            username: claims.username || claims.userName || null,
            given_name: claims.given_name || null,
            email: claims.email || claims.Email || null,
            sub: claims.sub || null,
            employeeNumber: claims.employeeNumber || claims.emp_number || null,
            nameLooksEncrypted: looksEncrypted(claims.name || claims.Name || '')
          });
          if (claims.exp) {
            const expiresAt = new Date(claims.exp * 1000).toISOString();
            const isExpired = Date.now() > claims.exp * 1000;
            console.log(`[Travel] 🔑 JWT exp: ${expiresAt} (expired=${isExpired})`);
          }

          const rawName = claims.name || claims.Name || claims.username || claims.userName || claims.given_name || null;
          // Only trust the claim if it isn't an encrypted blob
          if (rawName && !looksEncrypted(rawName)) {
            jwtName = rawName;
          }
          jwtEmail = claims.email || claims.Email || claims.EmailId || null;
          if (looksEncrypted(jwtEmail)) jwtEmail = null;
          jwtEmpNo = claims.emp_number || claims.employeeNumber || claims.id || claims.sub || null;
        }
      } catch (e) {
        console.log('[Travel] Auth enrichment failed:', e.message);
      }

      // Final Sanitization: Ensure all identity fields are strings and non-empty.
      // Order of preference: explicit userName from login context > JWT plain claim > fallback.
      // This was previously inverted and caused the "Votan" default bug.
      const safeId = String(employeeNumber || jwtEmpNo || '').replace(/[^0-9]/g, '');
      const safeName = (userName && !looksEncrypted(userName)) ? userName : (jwtName || 'Bosch User');
      const safeEmail = jwtEmail || (safeId.includes('@') ? safeId : `${safeId}@bosch.com`);

      console.log(`[Travel] A2A Sync: Using Identity: Name="${safeName}", ID=${safeId}, Email=${safeEmail}`);

      // Build A2A request mirroring the working Python SDK test exactly:
      //
      //   Message(
      //     role=Role.user,
      //     messageId=str(uuid.uuid4()),
      //     contextId=session_id,          ← inside message
      //     metadata={"auth": {...}},       ← inside message
      //     parts=[Part(root=TextPart(text="..."))],
      //   )
      //
      // Previously metadata was placed at the params level and contextId was
      // missing entirely. The A2A agent reads auth from message.metadata.auth,
      // not params.metadata.auth, so the JWT was never being received.
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          message: {
            role: 'user',
            messageId: messageId,
            contextId: isolatedSessionId,
            metadata: {
              auth: {
                session_id: isolatedSessionId,
                token: jwtToken
              }
            },
            parts: [
              {
                kind: 'text',   // A2A SDK uses "kind" not "type" as the discriminator
                text: message
              }
            ]
          }
        }
      };

      // Validate that session_id and token are present in the outgoing A2A request
      const outAuth = a2aRequest.params.message.metadata.auth;
      console.log('[Travel] 📤 A2A Request payload validation:');
      console.log('[Travel]   method          :', a2aRequest.method);
      console.log('[Travel]   contextId       :', a2aRequest.params.message.contextId);
      console.log('[Travel]   messageId       :', a2aRequest.params.message.messageId);
      console.log('[Travel]   auth.session_id :', outAuth.session_id);
      console.log('[Travel]   auth.token set  :', !!outAuth.token, '| prefix:', outAuth.token ? String(outAuth.token).substring(0, 40) + '...' : 'MISSING');
      console.log('[Travel]   message text    :', a2aRequest.params.message.parts[0]?.text?.substring(0, 200));

      const response = await axios.post(this.apiUrl, a2aRequest, {
        headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
        httpsAgent,
        timeout: 300000 // 5 minutes
      });

      const a2aResult = response.data;

      // ── Level 1: JSON-RPC protocol error ──────────────────────────────────
      if (a2aResult.error) {
        const msg = a2aResult.error.message || 'A2A request failed';
        const err = new Error(msg);
        // Mark token validation failures with a stable flag so callers can
        // clear stale credentials and retry with a freshly-issued pair.
        if (/token validation failed/i.test(msg) || /request rejected/i.test(msg)) {
          err.isTokenValidationFailure = true;
        }
        throw err;
      }

      // ── Level 2: Task-level failure (state: "failed") ─────────────────────
      // Some A2A agents return auth errors as a completed task whose
      // status.state is "failed" with the error text inside status.message.parts
      // rather than as a top-level JSON-RPC error.
      const taskResult = a2aResult.result;
      if (taskResult?.status?.state === 'failed') {
        const parts = taskResult.status?.message?.parts || [];
        const errorText = parts
          .filter(p => p.kind === 'text' || p.type === 'text')
          .map(p => p.text)
          .join(' ')
          .trim() || 'A2A task failed with state=failed';
        console.error('[Travel] Task-level failure:', errorText);
        const err = new Error(errorText);
        if (/invalid.?token|token.?rejected|authentication.?failed|unauthorized|token.?validation/i.test(errorText)) {
          err.isTokenValidationFailure = true;
        }
        throw err;
      }

      return taskResult;
    } catch (error) {
      console.error('[Travel] API error:', error.message);
      throw error;
    }
  }

  /**
   * Wrapper around callTravelAPI that detects token-validation failures and
   * retries using a two-stage strategy identical to the seat booking service.
   *
   * Stage 1 — Fresh user JWT:
   *   Clears stale credentials, calls /Token/GenrateTokenDetails for a new
   *   JWT + SessionId pair, and retries.  Fixes transient A2A session expiry.
   *
   * Stage 2 — Pre-authenticated env token (TRAVEL_JWT_TOKEN):
   *   The travel A2A agent calls Bosch's ValidateToken API which is configured
   *   for a specific clientID different from BOSCH_CLIENT_ID.  The user JWT
   *   (aud: kdGM5oc…) is always rejected by it.  TRAVEL_JWT_TOKEN holds a JWT
   *   minted for the correct clientID and is accepted by ValidateToken.
   *   The real user identity (employeeNumber, userName) is still forwarded in
   *   the A2A message metadata so the agent acts on behalf of the correct user.
   */
  async callTravelAPIWithRetry(message, employeeNumber, authToken, files, jwtToken, sessionId, userName, agentSessionId) {
    try {
      return await this.callTravelAPI(message, employeeNumber, authToken, files, jwtToken, sessionId, userName, agentSessionId);
    } catch (err) {
      if (!err.isTokenValidationFailure) throw err;

      // ── Stage 1: Refresh user JWT (using travel clientId) ───────────────────
      console.warn('[Travel] ⚠️ Token validation failed — clearing session cache and retrying with fresh credentials');
      boschAuthService.clearUserSession(employeeNumber, 'travel');

      if (authToken) {
        try {
          const freshTokens = await boschAuthService.storeUserTokens(employeeNumber, authToken, undefined, 'travel');
          console.log('[Travel] 🔄 Stage 1: Retrying A2A call with fresh JWT and SessionId:', freshTokens.sessionId);
          return await this.callTravelAPI(
            message, employeeNumber, authToken, files,
            freshTokens.jwtToken, sessionId, userName, freshTokens.sessionId
          );
        } catch (stage1Err) {
          if (!stage1Err.isTokenValidationFailure) throw stage1Err;
          console.warn('[Travel] Stage 1 retry also rejected — user JWT audience not accepted by travel ValidateToken API');
        }
      }

      // ── Stage 2: Pre-authenticated env token fallback ────────────────────
      // The travel A2A agent's ValidateToken API is configured for a Bosch
      // clientID different from BOSCH_CLIENT_ID.  TRAVEL_JWT_TOKEN holds a
      // JWT minted for the correct clientID and is always accepted.
      // If TRAVEL_JWT_TOKEN is not set, try SEATBOOKING_JWT_TOKEN as a
      // secondary option — both agents may share the same clientID audience.
      const preAuthJwt = process.env.TRAVEL_JWT_TOKEN || process.env.SEATBOOKING_JWT_TOKEN;
      if (preAuthJwt) {
        const crypto = require('crypto');

        // Reuse a stable A2A contextId per frontend session so the travel
        // agent retains any in-flight session state across retries within
        // the same conversation.  A new UUID is minted on the first Stage-2
        // call and stored on the conversationContextService context object;
        // subsequent calls in the same session reuse it.
        let preAuthSession;
        if (sessionId) {
          const convContext = conversationContextService.getContext(sessionId);
          if (convContext.travelContextId) {
            preAuthSession = convContext.travelContextId;
            console.log('[Travel] Stage 2: Reusing stable A2A contextId for session', sessionId, '→', preAuthSession);
          } else {
            preAuthSession = crypto.randomUUID();
            convContext.travelContextId = preAuthSession;
            console.log('[Travel] Stage 2: Minted new stable A2A contextId for session', sessionId, '→', preAuthSession);
          }
        } else {
          preAuthSession = crypto.randomUUID();
          console.log('[Travel] Stage 2: No sessionId — using ephemeral A2A contextId:', preAuthSession);
        }

        console.warn('[Travel] 🔄 Stage 2: Falling back to TRAVEL_JWT_TOKEN (pre-auth). User identity still forwarded via metadata.');
        return await this.callTravelAPI(
          message, employeeNumber, authToken, files,
          preAuthJwt, sessionId, userName, preAuthSession
        );
      }

      // No fallback available — surface the original token validation error
      throw err;
    }
  }

  /**
   * Check if query is asking about another person's travel data.
   *
   * Strategy: Instead of flagging every unknown capitalised word as a person
   * name (which false-positives on cities, airlines, hotels, etc.), we detect
   * **syntactic patterns** that strongly indicate a person reference:
   *   A) Possessive:  "Rajesh's travel expenses"
   *   B) Genitive:    "travel details of Kumar"
   *   C) Action-for:  "book a flight for Priya"
   *   D) Name-before-travel-noun: "Check Ramesh travel booking"
   *
   * Capitalised words appearing after travel prepositions (to/from/in/at/via …)
   * are treated as locations and excluded from name checks.
   */
  isQueryAboutOtherPerson(query, loggedInUserName) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // ── Helper: does `name` match the logged-in user? ──
    const isOwnName = (name) => {
      if (!loggedInUserName) return false;
      const parts = loggedInUserName.toLowerCase().split(/\s+/).filter(Boolean);
      const n = name.toLowerCase();
      return parts.some(p => p === n || n.includes(p) || p.includes(n));
    };

    // ── Step 1 – Gate: must contain a travel-data keyword (from config) ──
    const travelKwConfig = configService.getKeywordConfigSync().travelService;
    const travelDataKeywords = travelKwConfig.travelDataKeywords;
    if (!travelDataKeywords.some(kw => q.includes(kw))) return false;

    // ── Step 2 – Self-reference → safe (unless colleague word) ──
    const hasSelfRef = /\b(my|mine|me|myself|i)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|team\s?mate|boss|manager|reportee|someone\s+else)\b/i.test(q);
    if (hasSelfRef && !hasColleagueWord) return false;

    // ── Step 3 – Colleague / role word → blocked ──
    if (hasColleagueWord) return true;

    // ── Step 4 – Third-person possessive pronoun + travel noun → blocked ──
    //   Matching "his trip", "her booking", "their expenses" etc.
    //   Avoids false-positives from standalone "he/she/they" (e.g. "they cancelled the flight").
    const travelNounRe = '(?:travel|trip|flight|booking|expense|settlement|reimbursement|itinerary|ticket|details?|data|records?|history|status|info|information)';
    if (new RegExp(`\\b(his|her|their)\\s+${travelNounRe}`, 'i').test(q)) return true;
    if (/\bfor\s+(him|her|them)\b/i.test(q)) return true;

    // ── Step 5 – Pattern-based person-name detection ──

    // 5.0  Build a set of words that appear after travel prepositions → these are locations
    const locationPositions = new Set();
    const prepRe = /\b(?:to|from|in|at|via|through|near|around|between|towards?|into)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)/g;
    for (const m of original.matchAll(prepRe)) {
      m[1].toLowerCase().split(/\s+/).forEach(w => locationPositions.add(w));
    }

    // 5.1  Combined safe-word check: global whitelist + travel entities + preposition locations
    const whitelist = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));

    //      Travel-specific proper nouns from config (airlines, hotels, cities, etc.)
    const TRAVEL_ENTITIES = new Set(travelKwConfig.travelEntities.map(e => e.toLowerCase()));

    const isKnownSafe = (name) => {
      const n = name.toLowerCase();
      if (whitelist.has(n) || TRAVEL_ENTITIES.has(n) || locationPositions.has(n)) return true;
      // Multi-word: safe if any constituent word is recognised
      return n.split(/\s+/).some(w => whitelist.has(w) || TRAVEL_ENTITIES.has(w) || locationPositions.has(w));
    };

    // ── Pattern A: Possessive — "<Name>'s …" (strongest person signal) ──
    for (const m of original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)'s\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: possessive "${m[1]}'s"`);
        return true;
      }
    }

    // ── Pattern B: "<travel noun> of/for <Name>" ──
    const genitiveRe = new RegExp(
      `\\b${travelNounRe}\\s+(?:of|for)\\s+([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\b`, 'g'
    );
    for (const m of original.matchAll(genitiveRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: "of/for ${m[1]}" after travel noun`);
        return true;
      }
    }

    // ── Pattern C: "book/show/get … for <Name>" (not a known location) ──
    for (const m of original.matchAll(/\b(?:book|show|get|find|fetch|check|retrieve|pull|display)\b[^.]*?\bfor\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[Travel Privacy] Blocked: action "for ${m[1]}"`);
        return true;
      }
    }

    // ── Pattern D: "<Name> <travel-data-noun>" where Name is NOT after a preposition ──
    const nameBeforeNounRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${travelNounRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeNounRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        // Make sure it's not immediately preceded by a travel preposition
        const before = original.substring(Math.max(0, m.index - 15), m.index).trim().toLowerCase();
        if (!/\b(?:to|from|in|at|via|through|near|around|between)\s*$/.test(before)) {
          console.log(`[Travel Privacy] Blocked: "${m[1]}" before travel noun`);
          return true;
        }
      }
    }

    // No person-name pattern detected → safe
    return false;
  }

  /**
   * Extract travel slots using LLM
   */
  async extractTravelSlots(query, history = [], currentState = {}) {
    try {
      const today = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: 'full' });
      const systemPrompt = `You are a travel parameter extractor. Extract travel details from the user's latest query into JSON.
Current Date (IST): ${today}
Current State: ${JSON.stringify(currentState)}

FIELDS TO EXTRACT:
- from: Origin city (CRITICAL: Do not swap with destination)
- to: Destination city (CRITICAL: Do not swap with origin)
- startDate: Departure date (YYYY-MM-DD. If relative like 'next Friday', calculate from ${today})
- endDate: Return date (YYYY-MM-DD. Must be after startDate)
- passengers: Number of people (integer, default 1)
- modeOfTravel: Mode of transport the user prefers. Capture any of: "Air", "Bus", "Train", "Cab", "Taxi", "Own vehicle", "Own arrangements" — or any transport mode the user mentions. Leave null if not specified.
- travelClass: Seat/cabin class only (Economy, Business, First). Leave null if not specified.
- preferences: Any other notes (specific airlines, hotels, accommodation requirements, activities, etc.)
- approved: Boolean (Set true if user says: yes, yep, sure, go ahead, confirm, book it, let's do it, or anything affirmative.)
- isNewBooking: Boolean (Set true if the user wants to start a FRESH travel request. This should be true if: (A) They use keywords like 'new', 'another', 'start over', 'start fresh'; (B) They use generic initiation phrases like 'book a ticket', 'I want to travel', 'plan a trip' without providing more specific details yet; OR (C) The user provides a NEW origin (from) or destination (to) that clearly contradicts the current incomplete state.)

CONSTRAINTS:
- If the user says "Mysore to Bangalore", from="Mysore" and to="Bangalore". DO NOT SWAP THEM.
- Ensure dates strictly follow the user's request. If the user mentions specific dates in May 2026, use those exact dates.
- When the user says just "Air", "Bus", "Train", "Cab", "Taxi" etc., set modeOfTravel to that value. Do NOT set isNewBooking=true for single-word mode-of-travel answers.
- Return a JSON object with all fields above. Identify if any mandatory fields are missing based on the aggregated context (current state + new query) and list them in "missingFields" (array).
- Set "isComplete": true if and only if all 4 mandatory fields (from, to, startDate, endDate) are present in the final aggregate state.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (e) {
      console.error('[Travel] Extraction error:', e.message);
      return { isComplete: false };
    }
  }

  /**
   * Classify the user's travel query intent using few-shot LLM prompting.
   * Returns one of: 'retrieve' | 'book'
   * Falls back to keyword matching if the LLM call fails.
   */
  async classifyQueryIntent(query) {
    const examples = configService.getFewShotConfigSync().travel || [];
    const exampleLines = examples.map(e => `Q: "${e.query}" → {"intent":"${e.intent}"}`).join('\n');
    const systemPrompt = `You are an intent classifier for a workplace travel assistant at Bosch.
Classify the user query into exactly one of these intents:
- "retrieve" : user wants to view, check, or list their existing travel plans, trips, or bookings
- "book"     : user wants to make a new travel booking, continue an existing booking conversation, provide travel details, confirm, or modify a booking

Few-shot examples:
${exampleLines}

Respond with ONLY valid JSON, no explanation: {"intent":"retrieve"|"book"}`;

    try {
      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        max_tokens: 20,
        temperature: 0
      });

      const raw = response.choices[0].message.content.trim();
      const parsed = JSON.parse(raw);
      const valid = ['retrieve', 'book'];
      if (valid.includes(parsed.intent)) {
        console.log(`[Travel] LLM intent: "${parsed.intent}" for query: "${query}"`);
        return parsed.intent;
      }
    } catch (e) {
      console.warn('[Travel] LLM intent classification failed, using keyword fallback:', e.message);
    }

    return this.classifyQueryIntentFallback(query);
  }

  /**
   * Keyword-based intent fallback used when the LLM call fails.
   */
  classifyQueryIntentFallback(query) {
    const retrievalPhrases = [
      /\b(?:show|list|view|display|get|retrieve|see)\b.*\b(?:my|mine)\b.*\b(?:plan|plans|trip|trips|booking|bookings|itinerary|itineraries)\b/i,
      /\b(?:my|mine)\b.*\b(?:plan|plans|trip|trips|booking|bookings|itinerary|itineraries)\b.*\b(?:details|info|information|status)\b/i,
      /^\s*(?:my\s+)?(?:plans|bookings|trips)\s*$/i
    ];
    if (retrievalPhrases.some(re => re.test(query))) return 'retrieve';
    return 'book';
  }

  /**
   * Main query entry point
   */
  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId, agentSessionId, userName } = context;

      // DIAGNOSTIC: confirm identity fields actually arrived from server.js.
      // If userName here is '(missing)' or 'Bosch User', then the A2A agent
      // will fall back to its default test user "Votan" regardless of what
      // we try to pass in metadata.
      console.log('[Travel] processQuery context received:', {
        employeeNumber: employeeNumber || '(missing)',
        userName: userName || '(missing)',
        hasAuthToken: !!authToken,
        hasJwtToken: !!jwtToken,
        jwtPrefix: jwtToken ? String(jwtToken).substring(0, 30) + '...' : null,
        hasSessionId: !!sessionId,
        agentSessionId: agentSessionId || '(missing — will fallback to random UUID)'
      });

      if (this.isQueryAboutOtherPerson(query, userName)) {
        return { success: false, response: "I'm sorry, but I can only provide your own personal information for privacy reasons." };
      }

      const sessionContext = conversationContextService.getContext(sessionId);

      // 1. LLM-based intent classification with few-shot examples.
      // Falls back to keyword matching if the LLM call fails.
      const intent = await this.classifyQueryIntent(query);
      const isRetrievalQuery = intent === 'retrieve';

      if (isRetrievalQuery) {
        console.log(`[Travel] Retrieval intent detected: "${query}". Delegating directly to A2A Agent.`);
        let result = await this.callTravelAPIWithRetry(query, employeeNumber, authToken, [], jwtToken, sessionId, userName, agentSessionId);
        let response = this.formatTravelResponse(result, userName);

        console.log('[Travel] 📋 Agent response (retrieval, first attempt):', response.substring(0, 500));

        // Same Python-error detection as the booking path: if the agent
        // returned an internal error, retry once with a fresh session id
        // before giving up.
        const looksLikeAgentInternalError = (text) => {
          if (!text || typeof text !== 'string') return false;
          return /'str'\s+object\s+has\s+no\s+attribute\s+'get'/i.test(text)
            || /traceback\s*\(most recent call last\)/i.test(text)
            || /AttributeError|TypeError|KeyError/.test(text)
            || /travel agent tool.*error/i.test(text)
            || /unable to process travel booking requests due to an issue with the travel agent/i.test(text)
            || /unable to find or delegate the task to a travel agent/i.test(text)
            || /unable to fulfill your request at this time/i.test(text)
            || /there was an error when trying to book your travel/i.test(text);
        };

        if (looksLikeAgentInternalError(response)) {
          console.warn('[Travel] ⚠️ Retrieval path: agent internal error detected. Retrying with same agentSessionId.');
          try {
            result = await this.callTravelAPI(query, employeeNumber, authToken, [], jwtToken, null, userName, agentSessionId);
            response = this.formatTravelResponse(result, userName);
          } catch (retryErr) {
            console.error('[Travel] Retrieval retry failed:', retryErr.message);
          }

          if (looksLikeAgentInternalError(response)) {
            return {
              success: false,
              response: "✈️ **Travel Assistant**\n\nI'm temporarily unable to retrieve travel plans — the travel agent service is returning an internal error. This is usually transient. Please try again in a minute.",
              travelState: sessionContext.travelState
            };
          }
        }

        return {
          success: true,
          response,
          data: result,
          travelState: sessionContext.travelState
        };
      }

      // 2. Extract slots and intent from current query.
      // extractTravelSlots uses its own LLM call and sets isNewBooking=true
      // for fresh-start phrases ("book a travel", "start over", etc.) —
      // no separate forceResetPhrases regex needed.
      const extraction = await this.extractTravelSlots(query, [], sessionContext.travelState);

      // 3. Handle New Booking Intent: Reset state if user clearly wants a fresh start.
      //
      // Important: extractTravelSlots may also return isNewBooking=true when
      // the user says "yes" and the conversation service has rewritten it into
      // a full "Yes, I approve my travel from X to Y…" message — because all
      // the booking slots are present in that rewrite.  We must NOT clear the
      // stored travelAgentContextId in that case, since we need it to forward
      // the approval to the right A2A session.
      //
      // Guard: only clear the A2A context when this is a genuine new booking
      // (isNewBooking=true AND the user has NOT expressed approval in this turn).
      if (extraction.isNewBooking) {
        console.log(`[Travel] New booking intent detected by extractTravelSlots, resetting travelState.`);
        sessionContext.travelState = {
          from: null, to: null, startDate: null, endDate: null,
          passengers: 1, modeOfTravel: null, travelClass: null, preferences: null,
          isComplete: false, approved: false, missingFields: []
        };
        if (!extraction.approved) {
          // Genuine new booking — discard any pending approval context so the
          // next A2A call starts a completely fresh session.
          sessionContext.travelAgentContextId = null;
          console.log('[Travel] Cleared stored A2A contextId (genuine new booking start).');
        }
      }

      // Smart Merge: Preserve previous non-null values and truthy flags
      const newState = { ...sessionContext.travelState };

      // Update fields if new extraction has value
      ['from', 'to', 'startDate', 'endDate', 'passengers', 'modeOfTravel', 'travelClass', 'preferences'].forEach(field => {
        if (extraction[field]) newState[field] = extraction[field];
      });

      // Update flags (once true, they stay true unless user specifically cancels which isn't handled here)
      newState.isComplete = sessionContext.travelState.isComplete || extraction.isComplete || false;
      newState.approved = sessionContext.travelState.approved || extraction.approved || false;
      newState.missingFields = extraction.missingFields || [];

      // Programmatic Sanity Check for completion
      if (!newState.isComplete && newState.from && newState.to && newState.startDate && newState.endDate) {
        console.log('[Travel] Programmatic check: context IS complete.');
        newState.isComplete = true;
        newState.missingFields = [];
      }

      sessionContext.travelState = newState;

      // ── Early Previous Date Validation ───────────────────────────────────────
      // Fire as soon as startDate is extracted — before asking for missing slots.
      // This prevents the service from collecting from/to/endDate details for a
      // booking that will ultimately be rejected because the departure date is in
      // the past.  Mirrors the identical block in Phase 2 exactly.
      const earlyBookingCfg = configService.getBookingConfigSync();
      if (earlyBookingCfg?.travel?.allowPreviousDateBooking === false) {
        const earlyStartDate = newState.startDate;
        if (earlyStartDate) {
          const istNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
          const todayIST = `${istNow.getFullYear()}-${String(istNow.getMonth() + 1).padStart(2, '0')}-${String(istNow.getDate()).padStart(2, '0')}`;
          if (earlyStartDate < todayIST) {
            console.log(`[Travel] ❌ Early previous date check blocked: startDate=${earlyStartDate}, today(IST)=${todayIST}`);
            sessionContext.travelState = {
              from: null, to: null, startDate: null, endDate: null,
              passengers: 1, modeOfTravel: null, travelClass: null, preferences: null,
              isComplete: false, approved: false, missingFields: []
            };
            sessionContext.travelAgentContextId = null;
            return {
              success: false,
              response: `✈️ **Travel Assistant**\n\nSorry, bookings for past dates are not allowed. Your requested departure date **${earlyStartDate}** has already passed.\n\nPlease provide a future travel date and I will be happy to proceed with your booking.`,
              travelState: sessionContext.travelState
            };
          }
        }
      }
      // ─────────────────────────────────────────────────────────────────────────

      // Phase 1: Check for mandatory completion
      if (!sessionContext.travelState.isComplete) {
        console.log(`[Travel] Context incomplete. Missing: ${sessionContext.travelState.missingFields?.join(', ')}`);

        // Generate a friendly local response asking for missing fields
        const missingResponse = await this.generateLocalGatheringResponse(
          query,
          sessionContext.travelState,
          sessionContext.travelState.missingFields
        );

        return {
          success: true,
          response: missingResponse,
          travelState: sessionContext.travelState
        };
      }

      // Phase 2: Context is complete, hand off to A2A Agent
      console.log('[Travel] Context complete, delegating to A2A Agent.');

      // ── Previous Date Booking Validation ─────────────────────────────────
      // Block past-date bookings unless the admin has explicitly allowed them.
      const bookingCfg = configService.getBookingConfigSync();
      if (bookingCfg?.travel?.allowPreviousDateBooking === false) {
        const startDate = sessionContext.travelState.startDate; // YYYY-MM-DD
        if (startDate) {
          // Use IST for "today" so users in India get the correct cut-off
          const istNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
          const todayIST = `${istNow.getFullYear()}-${String(istNow.getMonth() + 1).padStart(2, '0')}-${String(istNow.getDate()).padStart(2, '0')}`;
          if (startDate < todayIST) {
            console.log(`[Travel] ❌ Previous date booking blocked: startDate=${startDate}, today(IST)=${todayIST}`);
            // Reset state so the user can immediately provide a new date
            sessionContext.travelState = {
              from: null, to: null, startDate: null, endDate: null,
              passengers: 1, modeOfTravel: null, travelClass: null, preferences: null,
              isComplete: false, approved: false, missingFields: []
            };
            sessionContext.travelAgentContextId = null;
            return {
              success: false,
              response: `✈️ **Travel Assistant**\n\nSorry, bookings for past dates are not allowed. Your requested departure date **${startDate}** has already passed.\n\nPlease provide a future travel date and I will be happy to proceed with your booking.`,
              travelState: sessionContext.travelState
            };
          }
        }
      }
      // ─────────────────────────────────────────────────────────────────────

      // ── Active A2A context detection ──────────────────────────────────────
      //
      // Problem being solved:
      //   Once the A2A travel agent is contacted, it drives a multi-turn
      //   conversation inside its own session (keyed by contextId). If we
      //   rebuild the consolidated message on every user reply, the agent
      //   receives the same incomplete request again and again — creating an
      //   infinite loop (e.g. it keeps asking for "mode of travel" even after
      //   the user already answered "Air").
      //
      // Fix:
      //   After the FIRST successful A2A call we store the contextId the agent
      //   returned in sessionContext.travelAgentContextId. On every subsequent
      //   turn we detect this stored contextId and forward the user's raw
      //   message directly to the same A2A context — letting the agent handle
      //   its own multi-turn conversation naturally. Only when the user
      //   explicitly wants to start over do we clear the context and rebuild.
      const hasActiveA2AContext = !!sessionContext.travelAgentContextId;

      // Helper: detect the Python-style internal errors the A2A agent
      // sometimes returns as plain text (e.g. "'str' object has no attribute
      // 'get'"). When we see one, we retry once with a fresh isolated
      // session id to blow away any poisoned agent-side state.
      const looksLikeAgentInternalError = (text) => {
        if (!text || typeof text !== 'string') return false;
        return /'str'\s+object\s+has\s+no\s+attribute\s+'get'/i.test(text)
          || /traceback\s*\(most recent call last\)/i.test(text)
          || /AttributeError|TypeError|KeyError/.test(text)
          || /travel agent tool.*error/i.test(text)
          || /unable to book your travel/i.test(text)
          || /unable to process travel booking requests due to an issue with the travel agent/i.test(text)
          || /unable to find or delegate the task to a travel agent/i.test(text)
          || /unable to fulfill your request at this time/i.test(text)
          || /there was an error when trying to book your travel/i.test(text);
      };

      let a2aMessage;
      let a2aContextId;

      if (hasActiveA2AContext) {
        // A2A agent is already in a conversation with this user.
        // Forward the user's raw reply directly to the same A2A context so the
        // agent can continue naturally (answer follow-up questions, collect mode
        // of travel, process approval, etc.).
        a2aMessage = query;
        a2aContextId = sessionContext.travelAgentContextId;
        console.log('[Travel] 🟢 Active A2A context: forwarding user reply to contextId:', a2aContextId, '| message:', a2aMessage);
      } else {
        // First call for this booking: build the consolidated natural-language
        // prompt the A2A host agent expects and start a new A2A context.

        // Sanitize travelState fields into plain primitives/strings. The LLM
        // extractor can occasionally return `preferences` as an object or array,
        // which would get stringified as "[object Object]" and confuse the
        // downstream agent. Forcing everything to a plain string here keeps the
        // consolidated prompt clean.
        const toPlainString = (val) => {
          if (val === null || val === undefined) return '';
          if (typeof val === 'string') return val;
          if (typeof val === 'number' || typeof val === 'boolean') return String(val);
          try { return JSON.stringify(val); } catch { return String(val); }
        };

        const safeState = {
          from: toPlainString(sessionContext.travelState.from),
          to: toPlainString(sessionContext.travelState.to),
          startDate: toPlainString(sessionContext.travelState.startDate),
          endDate: toPlainString(sessionContext.travelState.endDate),
          passengers: toPlainString(sessionContext.travelState.passengers) || '1',
          modeOfTravel: toPlainString(sessionContext.travelState.modeOfTravel) || '',
          travelClass: toPlainString(sessionContext.travelState.travelClass) || '',
          preferences: toPlainString(sessionContext.travelState.preferences) || '',
        };

        // Build a natural-language booking request that matches the format the
        // A2A host agent expects.
        const nlParts = [`book a travel from ${safeState.from} to ${safeState.to}`];
        nlParts.push(`departing on ${safeState.startDate}`);
        if (safeState.endDate) nlParts.push(`returning on ${safeState.endDate}`);
        nlParts.push(`for ${safeState.passengers} passenger(s)`);
        if (safeState.modeOfTravel) {
          nlParts.push(`by ${safeState.modeOfTravel}`);
        }
        if (safeState.travelClass) {
          nlParts.push(`${safeState.travelClass} class`);
        }
        if (safeState.preferences) {
          nlParts.push(safeState.preferences);
        }

        a2aMessage = nlParts.join(', ');
        a2aContextId = agentSessionId;
        console.log('[Travel] 📝 Booking flow: sending consolidated prompt with contextId:', a2aContextId);
      }

      let result = await this.callTravelAPIWithRetry(a2aMessage, employeeNumber, authToken, [], jwtToken, sessionId, userName, a2aContextId);
      let response = this.formatTravelResponse(result, userName);

      console.log('[Travel] 📋 Agent response (first attempt):', response.substring(0, 500));

      if (looksLikeAgentInternalError(response)) {
        console.warn('[Travel] ⚠️ Detected internal A2A agent error in response. Retrying once with same contextId.');
        try {
          result = await this.callTravelAPI(a2aMessage, employeeNumber, authToken, [], jwtToken, null, userName, a2aContextId);
          response = this.formatTravelResponse(result, userName);
          console.log('[Travel] 📋 Agent response (retry):', response.substring(0, 500));
        } catch (retryErr) {
          console.error('[Travel] Retry with fresh session failed:', retryErr.message);
        }

        if (looksLikeAgentInternalError(response)) {
          console.error('[Travel] Retry still returned an internal agent error. Surfacing friendly message.');
          return {
            success: false,
            response: "✈️ **Travel Assistant**\n\nI'm temporarily unable to process travel bookings — the travel agent service is returning an internal error. This is usually transient. Please try again in a minute, or visit the Bosch travel portal directly if the issue persists.",
            travelState: sessionContext.travelState
          };
        }
      }

      // ── Post-call: persist contextId for the active A2A context ──────────
      // The A2A result always includes the contextId it used.  Store/refresh it
      // so that every subsequent user reply in this booking session gets
      // forwarded to the same A2A context (see hasActiveA2AContext above).
      if (result && result.contextId) {
        sessionContext.travelAgentContextId = result.contextId;
        console.log('[Travel] 💾 Stored/refreshed A2A contextId:', result.contextId);
      }

      // ── Booking confirmed: clear all accumulated state ────────────────────
      const lowerResponse = response.toLowerCase();
      if (lowerResponse.includes('creation id') || lowerResponse.includes('recorded') || lowerResponse.includes('finalized') || lowerResponse.includes('confirmed')) {
        console.log('[Travel] ✅ Success response detected, clearing travelState and stored contextId.');
        sessionContext.travelAgentContextId = null;
        sessionContext.travelState = {
          from: null, to: null, startDate: null, endDate: null,
          passengers: 1, modeOfTravel: null, travelClass: null, preferences: null,
          isComplete: false, approved: false, missingFields: []
        };
      }

      return {
        success: true,
        response,
        data: result,
        travelState: sessionContext.travelState
      };
    } catch (error) {
      console.error('[Travel] Process error:', error.message);
      if (error.message === 'AUTH_REQUIRED') {
        return { success: false, response: "✈️ **Travel Assistant**\n\nYour session credentials could not be verified with the travel system. This usually happens when your login session has expired. Please **refresh the page and log in again** to continue." };
      }
      return { success: false, response: "✈️ **Travel Assistant**\n\nI'm having trouble connecting to the travel system. Please try again or visit the portal directly." };
    }
  }

  /**
   * Generate a friendly local response when fields are missing
   */
  async generateLocalGatheringResponse(query, state, missingFields = []) {
    try {
      // Build a human-readable summary of what is already known so the LLM
      // can acknowledge it and only ask for what is still missing.
      const known = [];
      if (state.from) known.push(`departure city: **${state.from}**`);
      if (state.to) known.push(`destination: **${state.to}**`);
      if (state.startDate) known.push(`departure date: **${state.startDate}**`);
      if (state.endDate) known.push(`return date: **${state.endDate}**`);
      const knownSummary = known.length > 0 ? `Already provided — ${known.join(', ')}.` : 'No details provided yet.';

      const allMissing = missingFields.length === 4 ||
        (!state.from && !state.to && !state.startDate && !state.endDate);

      const systemPrompt = `You are a helpful travel booking assistant at Bosch.
The user wants to book or raise a travel request. The exact wording does not matter — "book a travel", "raise a travel", "I want to travel", "arrange a trip" all mean the same thing.

${knownSummary}
Missing mandatory fields: ${missingFields.length > 0 ? missingFields.join(', ') : 'none'}.

Rules:
${allMissing
          ? `- All 4 mandatory fields are missing. Open with a short, friendly acknowledgement (1 sentence), then ask for ALL 4 fields in a bullet list:
  • Departure city (Where are you travelling from?)
  • Destination city (Where would you like to go?)
  • Start date (When do you want to leave?)
  • End date (When do you plan to return?)
- Do NOT ask about purpose, class, preferences, or visa — ask only these 4 fields.`
          : `- Some fields are already known (listed above). Acknowledge them warmly, then ask ONLY for the missing fields listed above.
- Be concise — do not repeat fields that are already provided.`}
- Always be friendly and professional.
- Respond in Markdown.`;

      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        temperature: 0.3
      });

      const text = response.choices[0].message.content;
      return `✈️ **Travel Assistant**\n\n${text}`;
    } catch (e) {
      return "✈️ **Travel Assistant**\n\nI've noted those details. Could you please provide your departure and return dates so I can help you with the booking?";
    }
  }

  /**
   * Format the final display text — aggregates text/data from ALL parts,
   * artifacts, history entries, and top-level data payloads returned by the
   * A2A Travel Agent.
   *
   * The old implementation picked only the FIRST text part from
   * result.status.message.parts, which meant that when the agent returned
   * a short acknowledgement text first and then pushed flight options / fare
   * / fund details into an artifact (or a later `data` part, or
   * `result.artifacts[].parts[]`), none of those details ever reached the
   * user. This is why "fund details" were missing after the booking was
   * delegated to the agent.
   *
   * This version mirrors `formatSeatBookingResponse`: it collects every
   * text and data chunk it can find, de-duplicates them, and joins them
   * into a single response. It also safely handles the "Processing..."
   * placeholder so it can be skipped without discarding other real content.
   */
  formatTravelResponse(result, userName) {
    if (!result) return "✈️ **Travel Assistant**\n\nNo response from travel system.";

    console.log('[Travel] Raw A2A Result keys:', Object.keys(result));
    if (result.status) console.log('[Travel] Result status keys:', Object.keys(result.status));
    if (result.artifacts) console.log('[Travel] Result artifacts count:', result.artifacts.length);
    // Log the raw status message parts so we can see exactly what the agent sent
    if (result.status?.message?.parts) {
      console.log('[Travel] 🔍 Raw status.message.parts:', JSON.stringify(result.status.message.parts).substring(0, 800));
    }

    // DEBUG: Look for "fund" or "cost" in the stringified result
    const rawString = JSON.stringify(result);
    if (rawString.toLowerCase().includes('fund') || rawString.toLowerCase().includes('detail')) {
      console.log('[Travel] 🔍 FOUND mentions of "fund" or "detail" in raw response!');
      // Log the full result for deep inspection
      console.log('[Travel] FULL RESULT:', JSON.stringify(result, null, 2));
    }

    const textChunks = [];

    const pushChunk = (val) => {
      if (val === undefined || val === null) return;
      let s;
      if (typeof val === 'string') s = val;
      else {
        try { s = JSON.stringify(val, null, 2); } catch { s = String(val); }
      }
      s = s.trim();
      if (!s) return;
      // Skip the noisy "Processing..." placeholder — the agent often sends
      // it as a first text frame before the real answer, and surfacing it
      // would hide the actual content that comes after.
      if (s === 'Processing...') return;
      textChunks.push(s);
    };

    const collectFromParts = (parts) => {
      if (!Array.isArray(parts)) return;
      for (const p of parts) {
        if (!p) continue;

        // Capture text from any field name the agent might use
        if (typeof p.text === 'string') pushChunk(p.text);
        if (typeof p.content === 'string') pushChunk(p.content);

        // Capture data objects from any field name
        if (p.data !== undefined) pushChunk(p.data);
        if (p.content !== undefined && typeof p.content === 'object') pushChunk(p.content);

        // Fallback: if the part has none of the above but has a 'result' or 'payload'
        if (p.result !== undefined) pushChunk(p.result);
        if (p.payload !== undefined) pushChunk(p.payload);
      }
    };

    // 1) Primary message parts
    if (result.status?.message?.parts) collectFromParts(result.status.message.parts);
    if (result.message?.parts) collectFromParts(result.message.parts);

    // 2) Artifacts — the A2A Travel Agent places flight options, fare /
    //    fund breakdowns and structured booking data here.
    if (Array.isArray(result.artifacts)) {
      for (const art of result.artifacts) {
        if (!art) continue;
        if (art.parts) collectFromParts(art.parts);
        if (art.content !== undefined) pushChunk(art.content);
        if (art.data !== undefined) pushChunk(art.data);
      }
    }

    // 3) Top-level data fields
    if (result.status?.data !== undefined) pushChunk(result.status.data);
    if (result.data !== undefined) pushChunk(result.data);

    // 4) History: Always check the latest agent turn for details that might 
    //    not be in the primary message (like fund breakdowns). We collect 
    //    everything and de-duplicate at the end to be safe.
    if (Array.isArray(result.history)) {
      const agentMsgs = result.history.filter(h => h?.role === 'agent');
      if (agentMsgs.length > 0) {
        // Collect from the last 2 agent messages just in case details 
        // were split across turns or echoed.
        const startIdx = Math.max(0, agentMsgs.length - 2);
        for (let i = agentMsgs.length - 1; i >= startIdx; i--) {
          collectFromParts(agentMsgs[i]?.parts);
        }
      }
    }

    // De-duplicate identical chunks (agents sometimes echo the same text
    // in both `status.message.parts` and `history`)
    const seen = new Set();
    const unique = textChunks.filter(t => { if (seen.has(t)) return false; seen.add(t); return true; });

    if (unique.length === 0) {
      return "✈️ **Travel Assistant**\n\nReceived a response from the travel agent but couldn't extract any readable content. Please try again or check the server logs.";
    }

    let joined = unique.join('\n\n');

    // Replace the fallback dev test identity ("Votan") with the real user's
    // first name so the response doesn't confuse the user when the service
    // account JWT is in use.
    if (userName) {
      const firstName = String(userName).split(' ')[0];
      if (firstName) {
        joined = joined.replace(/Votan/gi, firstName);
      }
    }

    return `✈️ **Travel Assistant**\n\n${joined}`;
  }
}

module.exports = new TravelService();
