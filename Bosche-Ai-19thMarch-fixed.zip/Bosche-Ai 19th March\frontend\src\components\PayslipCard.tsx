import { FileText, Download, Eye } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const PayslipCard = () => {
  return (
    <DashboardCard title="Payslip & Tax" icon={FileText}>
      <div className="space-y-4">
        <div className="p-4 bg-secondary/40 rounded-lg">
          <p className="text-xs text-muted-foreground mb-1">Current Month</p>
          <p className="text-2xl font-bold text-foreground">₹1,21,000</p>
          <p className="text-xs text-muted-foreground mt-1">Gross Salary</p>
        </div>
        <div className="space-y-2">
          <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 text-sm flex items-center justify-center gap-2">
            <Eye className="w-4 h-4" />
            View Latest Payslip
          </button>
          <button className="w-full py-2 px-4 bg-secondary/40 hover:bg-gradient-accent hover:text-accent-foreground rounded-lg transition-all duration-300 text-sm text-foreground flex items-center justify-center gap-2">
            <Download className="w-4 h-4" />
            Download Form 16
          </button>
        </div>
        <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <p className="text-xs font-semibold text-foreground mb-1">💡 Tax Savings Tip</p>
          <p className="text-xs text-muted-foreground">You can save ₹46,800 more under 80C this FY</p>
        </div>
      </div>
    </DashboardCard>
  );
};
