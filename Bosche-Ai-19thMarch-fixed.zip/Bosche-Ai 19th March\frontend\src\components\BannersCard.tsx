import { useState, useEffect, useRef } from 'react';
import { DashboardCard } from './DashboardCard';
import { Button } from '@/components/ui/button';
import { Loader2, Megaphone, Image as ImageIcon, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { API_ENDPOINTS } from '@/config';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useRateLimit } from '@/hooks/useRateLimit';
import { formatCountdown } from './RateLimitBanner';

interface Banner {
    id: string | number;
    title: string;
    description: string;
    tag: string;
    hasImage: boolean;
    imagePreview?: string | null;
    imageBase64?: string | null;
}

export const BannersCard = () => {
    const { user } = useAuth();
    const [banners, setBanners] = useState<Banner[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const autoPlayRef = useRef<NodeJS.Timeout | null>(null);
    const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

    const fetchBanners = async () => {
        try {
            setLoading(true);
            setError(null);

            // The backend /api/chat endpoint requires an authenticated user
            // (Authorization bearer token + employee number) to call the
            // upstream banner service. Without these, the server returns 401.
            if (!user?.accessToken || !user?.employeeNumber) {
                console.warn('[BannersCard] Skipping fetch — user not authenticated yet');
                setBanners([]);
                return;
            }

            const response = await fetch(API_ENDPOINTS.chat, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user.accessToken}`,
                    'X-Employee-Number': user.employeeNumber,
                },
                body: JSON.stringify({
                    query: "get all banners",
                    service: "banner",
                    employeeNumber: user.employeeNumber,
                })
            });

            const data = await response.json();

            if (response.status === 429) {
                handleRateLimitResponse(response, data);
                setError('Too many requests. Please wait before retrying.');
                return;
            }

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            if (data.success && data.banners) {
                setBanners(data.banners);
            } else {
                // no banners or unsuccessful response
            }
        } catch (error) {
            console.error('Error fetching banners:', error);
            if (error instanceof Error) {
                setError(`Failed to load banners: ${error.message}`);
                toast.error(`Failed to load banners: ${error.message}`);
            } else {
                setError("Failed to load banners. Please check server connection.");
                toast.error("Failed to load banners. Please check server connection.");
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        // Wait until the authenticated user is available before requesting
        // banners, otherwise the /api/chat endpoint returns 401.
        if (user?.accessToken && user?.employeeNumber) {
            fetchBanners();
        }
    }, [user?.accessToken, user?.employeeNumber]);

    // Auto-play logic
    useEffect(() => {
        if (loading || banners.length <= 1 || isPaused) return;

        const startAutoPlay = () => {
            autoPlayRef.current = setInterval(() => {
                setCurrentIndex((prev) => (prev + 1) % banners.length);
            }, 10000); // 10 seconds per slide
        };

        startAutoPlay();

        return () => {
            if (autoPlayRef.current) {
                clearInterval(autoPlayRef.current);
            }
        };
    }, [banners.length, loading, isPaused]);

    const handleNext = () => {
        setCurrentIndex((prev) => (prev + 1) % banners.length);
    };

    const handlePrev = () => {
        setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
    };

    const goToSlide = (index: number) => {
        setCurrentIndex(index);
    };

    return (
        <DashboardCard title="Company News/Snippets" icon={Megaphone} className="min-w-[600px] max-w-[800px]">
            <div
                className="h-[450px] relative flex flex-col group"
                onMouseEnter={() => setIsPaused(true)}
                onMouseLeave={() => setIsPaused(false)}
            >
                {loading ? (
                    <div className="flex flex-col items-center justify-center flex-1 gap-3 text-muted-foreground">
                        <Loader2 className="w-8 h-8 animate-spin text-primary" />
                        <p className="text-sm">Loading announcements...</p>
                    </div>
                ) : error ? (
                    <div className="flex flex-col items-center justify-center flex-1 h-full gap-3 p-6 text-center">
                        <div className="w-12 h-12 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-2">
                            <AlertCircle className="w-6 h-6 text-amber-500" />
                        </div>
                        <p className="text-sm text-foreground font-medium max-w-[280px]">{error}</p>
                        {isRateLimited && (
                            <p className="text-xs text-amber-500 font-medium tracking-wide">
                                Available again in {formatCountdown(retryAfter)}...
                            </p>
                        )}
                        <button
                            onClick={fetchBanners}
                            disabled={isRateLimited}
                            className="px-6 py-2 mt-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isRateLimited ? "Paused" : "Try Again"}
                        </button>
                    </div>
                ) : banners.length === 0 ? (
                    <div className="flex flex-col items-center justify-center flex-1 text-muted-foreground">
                        <Megaphone className="w-12 h-12 mb-4 opacity-20" />
                        <p>No banners available.</p>
                    </div>
                ) : (
                    <>
                        {/* Main Slide Content */}
                        <div className="relative flex-1 overflow-hidden rounded-xl border border-border/50 bg-secondary/20">
                            <div className="absolute inset-0 transition-all duration-500 ease-in-out">
                                {banners.map((banner, index) => (
                                    <div
                                        key={banner.id || index}
                                        className={cn(
                                            "absolute inset-0 flex flex-col transition-opacity duration-500",
                                            index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
                                        )}
                                    >
                                        {/* Image Area */}
                                        <div className="relative flex-1 bg-muted overflow-hidden">
                                            {banner.hasImage && banner.imageBase64 ? (
                                                <>
                                                    <div
                                                        className="absolute inset-0 bg-cover bg-center blur-xl opacity-50 scale-110"
                                                        style={{ backgroundImage: `url(data:image/jpeg;base64,${banner.imageBase64})` }}
                                                    />
                                                    <img
                                                        src={`data:image/jpeg;base64,${banner.imageBase64}`}
                                                        alt={banner.title}
                                                        className="relative h-full w-full object-contain z-10"
                                                    />
                                                    {/* Gradient Overlay for Text Readability */}
                                                    <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent z-20" />
                                                </>
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center bg-accent/5">
                                                    <ImageIcon className="w-16 h-16 text-muted-foreground/20" />
                                                    <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent z-20" />
                                                </div>
                                            )}

                                            {/* Tag (skip generic #Banners label) */}
                                            {banner.tag && banner.tag !== '#Banners' && (
                                                <div className="absolute top-4 right-4 z-30">
                                                    <span className="bg-primary/90 text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full shadow-lg backdrop-blur-sm">
                                                        {banner.tag}
                                                    </span>
                                                </div>
                                            )}
                                        </div>

                                        {/* Content Area - Overlay or Separate Section */}
                                        <div className="absolute bottom-0 left-0 right-0 p-6 z-30 pb-12">
                                            <h3 className="text-2xl font-bold text-foreground mb-2 line-clamp-1 drop-shadow-sm">
                                                {banner.title}
                                            </h3>
                                            <p className="text-sm text-muted-foreground line-clamp-3 max-w-2xl leading-relaxed">
                                                {banner.description}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {/* Navigation Arrows */}
                            {banners.length > 1 && (
                                <>
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        className="absolute left-2 top-1/2 -translate-y-1/2 z-40 h-10 w-10 rounded-full bg-background/20 backdrop-blur-md hover:bg-background/50 text-foreground shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handlePrev();
                                        }}
                                    >
                                        <ChevronLeft className="h-6 w-6" />
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        className="absolute right-2 top-1/2 -translate-y-1/2 z-40 h-10 w-10 rounded-full bg-background/20 backdrop-blur-md hover:bg-background/50 text-foreground shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handleNext();
                                        }}
                                    >
                                        <ChevronRight className="h-6 w-6" />
                                    </Button>
                                </>
                            )}
                        </div>

                        {/* Dot Indicators */}
                        {banners.length > 1 && (
                            <div className="flex justify-center gap-2 mt-4 absolute bottom-4 left-0 right-0 z-40">
                                {banners.map((_, index) => (
                                    <button
                                        key={index}
                                        onClick={() => goToSlide(index)}
                                        className={cn(
                                            "w-2 h-2 rounded-full transition-all duration-300 shadow-sm",
                                            index === currentIndex
                                                ? "bg-primary w-6"
                                                : "bg-muted-foreground/30 hover:bg-primary/50"
                                        )}
                                        aria-label={`Go to slide ${index + 1}`}
                                    />
                                ))}
                            </div>
                        )}
                    </>
                )}
            </div>
        </DashboardCard>
    );
};
