/**
 * Shared intent detection for the chat surfaces (AIChat, ChatWindow, cards).
 *
 * Goals:
 *  - Detect a clear new-intent from the latest user message using word-boundary matching.
 *  - Detect explicit "start a new booking / different topic" cues so the caller can RESET its
 *    locked-in service state instead of forcing the previous wrapper.
 *  - Be conservative: when the message has no obvious signal, return null and let the caller
 *    fall back to the existing active service (or let the backend decide).
 *
 * Do NOT use substring matches like q.includes("to") here — that's how we used to false-positive
 * on words like "tomorrow" / "from". All checks below use \b word boundaries.
 */

export type ServiceId = 'travel' | 'seatbooking' | 'canteen' | 'entryexit' | 'community' | 'banner' | 'general';

export interface IntentDetection {
  /** Best-guess service for this message, or null if nothing matched. */
  service: ServiceId | null;
  /** True if the message contains explicit cues to start over (new booking, cancel, instead, ...). */
  isRestart: boolean;
  /** True if the message contains a strong action verb (book/reserve/cancel/...). */
  hasStrongAction: boolean;
}

const RESTART_CUE = /\b(new\s+(booking|trip|flight|travel|reservation)|another\s+(trip|flight|booking|travel)|different\s+(trip|flight|destination|booking)|book\s+again|start\s+over|restart|cancel\s+(that|this|the\s+booking|booking)|instead\s+of)\b/i;

const STRONG_ACTION = /\b(book|reserve|reservation|schedule|plan|arrange|cancel|change|switch)\b/i;

// Travel signals — word-boundary, no city allow-list, no bare "to"/"from".
const TRAVEL_SIGNALS = [
  /\bflight(s)?\b/i,
  /\btravel\b/i,
  /\btrip(s)?\b/i,
  /\bhotel(s)?\b/i,
  /\bvisa\b/i,
  /\bbusiness\s+trip\b/i,
  /\bitinerary\b/i,
  /\bair(\s|-)?ticket(s)?\b/i,
  // "from <Place> to <Place>" — both anchored to a word so "tomorrow" is safe.
  /\bfrom\s+[a-z][a-z\s]{2,30}\s+to\s+[a-z][a-z\s]{2,30}\b/i,
];

const SEAT_SIGNALS = [
  /\bseat\b/i,
  /\bdesk\b/i,
  /\bworkstation\b/i,
  /\bcubicle\b/i,
  /\b(book|reserve)\s+(a\s+)?(office|workstation|floor|desk|seat)\b/i,
];

const CANTEEN_SIGNALS = [
  /\bcanteen\b/i,
  /\bcafeteria\b/i,
  /\b(lunch|breakfast|dinner)\b/i,
  /\bmenu\b/i,
  /\bfood\b/i,
];

const ENTRYEXIT_SIGNALS = [
  /\bentry\s+time\b/i,
  /\bexit\s+time\b/i,
  /\battendance\b/i,
  /\bswipe(s|d)?\b/i,
  /\bworking\s+hours?\b/i,
];

const BANNER_SIGNALS = [
  /\bbanner(s)?\b/i,
  /\bannouncement(s)?\b/i,
  /\bnews\b/i,
];

const COMMUNITY_SIGNALS = [
  /\bcommunity\b/i,
  /\bcommunities\b/i,
  /\bassociate\s*arena\b/i,
];

function any(regexList: RegExp[], text: string): boolean {
  for (const r of regexList) {
    if (r.test(text)) return true;
  }
  return false;
}

/**
 * Inspect a single message and return its detected intent.
 * Order of checks is deliberate — seat is tested before travel because "book a desk" must not
 * match a generic travel "book" verb.
 */
export function detectIntent(message: string): IntentDetection {
  const text = (message || '').trim();
  if (!text) {
    return { service: null, isRestart: false, hasStrongAction: false };
  }

  const isRestart = RESTART_CUE.test(text);
  const hasStrongAction = STRONG_ACTION.test(text);

  let service: ServiceId | null = null;
  if (any(SEAT_SIGNALS, text)) service = 'seatbooking';
  else if (any(TRAVEL_SIGNALS, text)) service = 'travel';
  else if (any(CANTEEN_SIGNALS, text)) service = 'canteen';
  else if (any(ENTRYEXIT_SIGNALS, text)) service = 'entryexit';
  else if (any(BANNER_SIGNALS, text)) service = 'banner';
  else if (any(COMMUNITY_SIGNALS, text)) service = 'community';

  return { service, isRestart, hasStrongAction };
}

/**
 * Decide whether the caller should clear its locked-in active service for this message.
 * The caller should reset when:
 *  - the message contains an explicit restart cue, OR
 *  - the message names a clearly different service than the currently active one.
 */
export function shouldResetActiveService(
  message: string,
  activeService: string | null
): boolean {
  const det = detectIntent(message);
  if (det.isRestart) return true;
  if (!activeService || !det.service) return false;
  const normalize = (s: string) => s.toLowerCase().replace(/\s+/g, '');
  return normalize(det.service) !== normalize(activeService);
}
