import { useState, useRef, useEffect, useCallback } from "react";
import { X, MapPin, ThumbsUp, ThumbsDown, MicOff, AlertTriangle } from "lucide-react";
import { useTheme } from "next-themes";
import { cn, generateUUID, renderMarkdown } from "@/lib/utils";
import { Input } from "./ui/input";
import { toast } from "sonner";
import { API_ENDPOINTS } from "@/config";
import { RateLimitBanner } from "./RateLimitBanner";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";
import { useRateLimit } from "@/hooks/useRateLimit";
import { detectIntent, shouldResetActiveService } from "@/lib/intentDetector";
import { checkSensitivity } from "@/lib/privacy-utils";
import { persistJoinedCommunityId } from "./CommunityCard";
import {
  getGlassContainerStyles,
  getGlassArcBorderStyles,
  getGlassSpecularStyles,
} from "@/lib/glassStyles";
import { useViewportWidth } from "@/hooks/useViewportWidth";

// Web Speech API type declaration
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

interface Banner {
  id: string;
  title: string;
  description: string;
  tag: string;
  hasImage: boolean;
  imageBase64?: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  banners?: Banner[];
  conversationId?: number | null;
  feedback?: number; // -1 = thumbs down, 0 = no feedback, 1 = thumbs up
  isOutOfScope?: boolean;
  isBlocked?: boolean;
}

interface ChatWindowProps {
  isOpen: boolean;
  onClose: () => void; // This toggles the open state
}

const getServicePrefix = (query: string, activeService: string | null): string => {
  const q = query.toLowerCase();

  if (q.includes('seat') || q.includes('desk') || (q.includes('book') && (q.includes('office') || q.includes('workstation') || q.includes('floor')))) {
    return 'seat booking: ';
  }
  // Note: 'to' and 'from' are intentionally excluded — they are substring-unsafe (e.g. "Coimbatore" contains "to").
  // Word-boundary city/route matching is handled by intentDetector.ts using regex.
  if (['travel', 'flight', 'trip', 'hotel', 'visa', 'business trip', 'train', 'bus', 'ticket', 'booking', 'delhi', 'bangalore', 'mumbai'].some(k => q.includes(k))) {
    return 'travel: ';
  }
  if (['canteen', 'cafeteria', 'lunch', 'breakfast', 'menu', 'food', 'eat', 'hungry'].some(k => q.includes(k))) {
    return 'canteen: ';
  }
  if (activeService) {
    const s = activeService.toLowerCase();
    if (s.includes('travel')) return 'travel: ';
    if (s.includes('canteen') || s.includes('cafeteria')) return 'canteen: ';
    if (s.includes('seat')) return 'seat booking: ';
  }
  return '';
};

export const ChatWindow = ({ isOpen, onClose: onToggle }: ChatWindowProps) => {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const viewportWidth = useViewportWidth();

  // True only when the agent-generated SessionId was successfully received from
  // /Token/GenrateTokenDetails during login. A null sessionId means the agentic
  // layer (Travel, Seat Booking) will reject requests — warn the user early.
  const hasSessionId = !!user?.sessionId;

  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI companion. I can help you with:\n🍽️ **Canteen** – Today's cafeteria menu, food items, meal timings\n⏰ **Entry/Exit Tracking** – Attendance, working hours, swipe records\n✈️ **Travel** – Business trip booking, travel settlements, expense claims\n💺 **Seat Booking** – Desk/workspace reservation\n👥 **Community** – Bosch/BGSW communities, clubs, groups\n📢 **Company News** – Announcements, upcoming BGSW events, promotions\n\nHow can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [waitingForLocation, setWaitingForLocation] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null);
  const [activeService, setActiveService] = useState<string | null>(null);
  const [sensitivityWarning, setSensitivityWarning] = useState<{ isSensitive: boolean, level: string, category: string | null }>({ isSensitive: false, level: 'none', category: null });
  const [isListening, setIsListening] = useState(false);
  const [isSpeechRecognitionSupported, setIsSpeechRecognitionSupported] = useState(true);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Check if browser supports Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) setIsSpeechRecognitionSupported(false);
  }, []);

  // Auto-scroll to the latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Live PII/sensitivity detection as user types
  useEffect(() => {
    if (message.trim().length > 0) {
      setSensitivityWarning(checkSensitivity(message));
    } else {
      setSensitivityWarning({ isSensitive: false, level: 'none', category: null });
    }
  }, [message]);

  // Speech recognition handler
  const toggleVoice = useCallback(() => {
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const isBrowser = typeof window !== 'undefined';
      const isFirefox = isBrowser && /Firefox/.test(navigator.userAgent);
      toast.error(isFirefox
        ? 'Voice input is not supported in Firefox. Please use Chrome, Edge, or Safari.'
        : 'Speech recognition is not supported in your browser. Try Chrome, Edge, or Safari.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => setIsListening(true);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setMessage(prev => prev ? prev + ' ' + transcript : transcript);
      toast.success('Voice captured!');
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please allow microphone permissions.');
      } else {
        toast.error('Voice input failed. Please try again.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, [isListening]);

  // Use the agent-generated SessionId from /Token/GenrateTokenDetails (stored on the
  // user object at login) so that the conversation-context key on the backend and the
  // A2A contextId used by Travel / Seat Booking all share the same ID.
  // Falls back to a local UUID only when the API returned null (warned in the UI above).
  const [sessionId] = useState(() => user?.sessionId || generateUUID());

  const handleLocationSelect = async (locationId: number) => {
    const locationName = locationId === 1 ? 'Bangalore' : 'Coimbatore';
    const userMessage: Message = {
      role: 'user',
      content: locationName,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setSelectedLocation(locationId);
    setWaitingForLocation(false);
    setIsTyping(true);

    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    try {
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: locationName,
          service: activeService,
          activeService: activeService,  // explicit follow-up context for LLM classifier
          sessionId,
          locationId,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory,
          serviceTokens: user?.serviceTokens,
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
      } else if (response.ok) {
        if (data.needs_location) setWaitingForLocation(true);

        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date(),
          banners: data.banners,
          conversationId: data.conversationId || null,
          feedback: 0,
          isOutOfScope: !!data.isOutOfScope,
          isBlocked: data.service === 'privacy_guard'
        };

        if (data.isOutOfScope) setActiveService(null);
        else if (data.service) setActiveService(data.service);

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      }]);
    }

    setIsTyping(false);
  };

  const handleSend = async (incomingMessage?: string) => {
    const messageToSend = incomingMessage || message;
    if (!messageToSend.trim() || sensitivityWarning.level === 'high') return;

    const userMessage: Message = {
      role: "user",
      content: messageToSend,
      timestamp: new Date()
    };

    logger.logChatMessage(messageToSend, true, {
      messageLength: messageToSend.length,
      sessionTime: new Date().getTime() - new Date(sessionStorage.getItem('sessionStartTime') || '').getTime()
    });

    const intent = detectIntent(messageToSend);
    const reset = shouldResetActiveService(messageToSend, activeService);
    if (reset && activeService) {
      console.log('[ChatWindow] Resetting active service:', activeService, '→', intent.service ?? '(none)');
      setActiveService(null);
    }
    const effectiveActiveService = reset ? null : activeService;
    const detectedService = intent.service ?? effectiveActiveService ?? null;

    // Send the raw message — no prefix injection. The backend LLM classifier
    // receives the unmodified text + activeService so it can resolve follow-up
    // messages ("Coimbatore", "yes", "2") correctly using conversation context.
    const finalQuery = messageToSend;

    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => ({
      role: msg.role,
      content: msg.content   // raw, no prefix rewriting
    }));

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsTyping(true);

    try {
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: finalQuery,
          service: detectedService,
          activeService: effectiveActiveService,  // currently locked-in service for follow-up context
          sessionId,
          locationId: selectedLocation,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory,
          serviceTokens: user?.serviceTokens,
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
      } else if (response.ok) {
        if (data.needs_location) setWaitingForLocation(true);

        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date(),
          banners: data.banners,
          conversationId: data.conversationId || null,
          feedback: 0,
          isOutOfScope: data.isOutOfScope || false,
          isBlocked: data.service === 'privacy_guard'
        };

        logger.logChatMessage(aiMessage.content, false, {
          responseTime: new Date().getTime() - userMessage.timestamp.getTime(),
          userQuery: messageToSend,
          service: data.service,
          serviceName: data.serviceName
        });

        if (data.isOutOfScope) setActiveService(null);
        else if (data.service) setActiveService(data.service);

        // ── Community join via chat → persist joined ID ──────────────────
        if (data.service === 'community') {
          const responseText = data.response || '';
          if (/successfully registered/i.test(responseText)) {
            const idMatch = responseText.match(/CommunityId[:\s]*(\d+)/i);
            if (idMatch) {
              try { persistJoinedCommunityId(parseInt(idMatch[1], 10)); } catch { /* ignore */ }
            }
          }
        }

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Chat query error:', error);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      }]);
    }

    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (message.trim() && !isTyping && !isRateLimited && sensitivityWarning.level !== 'high') handleSend();
    }
  };

  // Handle feedback (thumbs up/down)
  const handleFeedback = async (messageIndex: number, feedback: number) => {
    const msg = messages[messageIndex];
    if (!msg.conversationId) return;

    setMessages(prev => prev.map((m, i) => i === messageIndex ? { ...m, feedback } : m));

    try {
      const response = await fetch(API_ENDPOINTS.chatFeedback, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversationId: msg.conversationId, feedback })
      });

      if (!response.ok) throw new Error('Failed to save feedback');
      toast.success(feedback === 1 ? 'Thanks for the positive feedback!' : 'Thanks for your feedback!');
    } catch (error) {
      console.error('Feedback error:', error);
      setMessages(prev => prev.map((m, i) => i === messageIndex ? { ...m, feedback: 0 } : m));
      toast.error('Failed to save feedback');
    }
  };

  // Autofocus input when chat opens
  useEffect(() => {
    if (isOpen && !isTyping && !waitingForLocation) {
      const timer = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen, isTyping, waitingForLocation]);

  return (
    <div
      className="fixed left-0 right-0 z-40 pointer-events-none"
      style={{ bottom: '70px' }}
    >
      <div className="container mx-auto px-4 pointer-events-auto" style={{ maxWidth: "clamp(620px, 55vw, 1080px)" }}>

        {/* ── ONE glass container with gradient-border liquid glass ── */}
        <div
          className={cn("rounded-3xl transition-all duration-300 ease-out", isOpen ? "p-px" : "")}
          style={{ position: "relative" }}
        >
          {/* Arc border — conic masked to 1px corner ring only */}
          {isOpen && isDark && <div style={getGlassArcBorderStyles()} />}
          <div
            className={cn("flex flex-col rounded-3xl transition-all duration-300 ease-out", isOpen ? "overflow-hidden" : "overflow-visible")}
            style={{
              position: "relative",
              zIndex: 2,
              height: isOpen ? "clamp(420px, calc(100svh - 150px), 860px)" : "64px",
              ...(isOpen
                ? getGlassContainerStyles(isDark, viewportWidth)
                : { background: "transparent", backdropFilter: "none", WebkitBackdropFilter: "none", border: undefined, boxShadow: "none" }),
            }}
          >
            {/* Specular top-reflection — dark mode only */}
            {isOpen && isDark && <div style={getGlassSpecularStyles()} />}

            {/* ── Collapsible section — drag handle + header + messages ── */}
            <div
              className={cn(
                "flex flex-col min-h-0 transition-all duration-300 overflow-hidden",
                isOpen ? "flex-1 opacity-100" : "h-0 opacity-0 pointer-events-none"
              )}
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
                <div
                  className="w-10 h-1 rounded-full"
                  style={{ background: isDark ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.15)" }}
                />
              </div>

              {/* Header */}
              <div className="flex items-center justify-between px-5 py-3 flex-shrink-0">
                <div className="w-8" />
                <h3
                  className="font-semibold text-sm tracking-wide"
                  style={{ color: isDark ? "#fff" : "#111" }}
                >
                  Ask MyBGSW.Ai
                </h3>
                <button
                  onClick={onToggle}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
                  style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}
                  aria-label="Close chat"
                >
                  <X
                    className="w-3.5 h-3.5"
                    style={{ color: isDark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)" }}
                  />
                </button>
              </div>

              {/* ── Session ID missing warning (inside messages area) ── */}
              {!hasSessionId && (
                <div className="mx-4 mb-2 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3 py-2.5 flex items-start gap-2.5 flex-shrink-0">
                  <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 leading-snug">
                      Session Not Established
                    </p>
                    <p className="text-xs text-amber-600/80 dark:text-amber-400/80 mt-0.5 leading-snug">
                      Your AI session ID could not be retrieved during login. Services like Travel and Seat Booking may not work.
                      Please contact your <span className="font-semibold">administrator</span> to resolve this.
                    </p>
                  </div>
                </div>
              )}

              {/* Messages */}
              <div className="flex-1 px-4 py-5 overflow-y-auto space-y-6 custom-scrollbar min-h-0">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}
                  >
                    {msg.role === "assistant" && (
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ background: "#000000" }}
                      >
                        <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
                      </div>
                    )}
                    <div className="flex flex-col max-w-[80%]">
                      <div className="relative">
                        {/* Triangle tail */}
                        <div
                          style={msg.role === "assistant" ? {
                            position: "absolute",
                            left: "-7px",
                            top: "12px",
                            width: 0,
                            height: 0,
                            borderTop: "6px solid transparent",
                            borderBottom: "6px solid transparent",
                            borderRight: "8px solid rgba(0,0,0,1)",
                          } : {
                            position: "absolute",
                            right: "-7px",
                            top: "12px",
                            width: 0,
                            height: 0,
                            borderTop: "6px solid transparent",
                            borderBottom: "6px solid transparent",
                            borderLeft: "8px solid #0a84ff",
                          }}
                        />
                        <div
                          className="rounded-2xl px-5 py-3.5"
                          style={
                            msg.role === "user"
                              ? { background: "#0a84ff", color: "#fff" }
                              : {
                                background: msg.isOutOfScope ? "rgba(40,20,0,0.92)" : "rgba(0,0,0,1)",
                                color: "#fff",
                                border: msg.isOutOfScope ? "1px solid rgba(255,165,0,0.3)" : "none",
                              }
                          }
                        >
                          {msg.isOutOfScope && (
                            <div className="flex items-center gap-1.5 mb-2 px-2 py-1 rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-medium w-fit">
                              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                              Outside Supported Scope
                            </div>
                          )}
                          <p
                            className="text-sm leading-relaxed whitespace-pre-line"
                            dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                          />
                          {msg.banners && msg.banners.length > 0 && (
                            <div className="mt-3 space-y-3">
                              {msg.banners.map((banner, bi) =>
                                banner.hasImage && banner.imageBase64 ? (
                                  <div key={bi} className="rounded-xl overflow-hidden border border-white/10">
                                    <img
                                      src={`data:image/png;base64,${banner.imageBase64}`}
                                      alt={banner.title}
                                      className="w-full h-auto max-h-48 object-cover"
                                      onError={(e) => {
                                        const img = e.target as HTMLImageElement;
                                        if (img.src.includes("image/png"))
                                          img.src = `data:image/jpeg;base64,${banner.imageBase64}`;
                                      }}
                                    />
                                    <div className="p-2">
                                      <p className="text-xs font-medium text-white/80">{banner.title}</p>
                                    </div>
                                  </div>
                                ) : null
                              )}
                            </div>
                          )}
                          {/* Hint for out-of-scope / blocked messages */}
                          {(msg.isOutOfScope || msg.isBlocked) && (
                            <div className="mt-3 pt-3 border-t border-white/10 text-xs text-white/50">
                              <span className="font-medium text-white/70">Hint:</span>{' '}
                              Don't enter any sensitive personal or business-critical information.
                            </div>
                          )}
                          {/* Timestamp + feedback inside bubble */}
                          <div className={cn(
                            "flex items-center gap-2 mt-2",
                            msg.role === "user" ? "justify-end" : "justify-start"
                          )}>
                            <span className="text-[11px]" style={{ color: "rgba(255,255,255,0.4)" }}>
                              {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                            {msg.role === "assistant" && idx > 0 && (
                              <>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(idx, 1); }}
                                  disabled={msg.feedback === 1}
                                  title="Helpful"
                                  className={cn("p-0.5 rounded transition-all duration-200",
                                    msg.feedback === 1 ? "text-green-400" : "text-white/30 hover:text-green-400")}
                                >
                                  <ThumbsUp className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(idx, -1); }}
                                  disabled={msg.feedback === -1}
                                  title="Not helpful"
                                  className={cn("p-0.5 rounded transition-all duration-200",
                                    msg.feedback === -1 ? "text-red-400" : "text-white/30 hover:text-red-400")}
                                >
                                  <ThumbsDown className="w-3 h-3" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    {msg.role === "user" && (
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ background: "#0a84ff" }}
                      >
                        <img src="/user.svg" alt="You" className="w-5 h-5" />
                      </div>
                    )}
                  </div>
                ))}

                {isTyping && (
                  <div className="flex gap-3 items-start">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: "#000000" }}
                    >
                      <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
                    </div>
                    <div
                      className="rounded-2xl px-4 py-3"
                      style={{ background: isDark ? "rgba(0,0,0,0.90)" : "rgba(0,0,0,0.90)" }}
                    >
                      <div className="flex gap-1 items-center h-4">
                        {[0, 150, 300].map((delay) => (
                          <div
                            key={delay}
                            className="w-2 h-2 rounded-full animate-bounce"
                            style={{ background: "rgba(255,255,255,0.5)", animationDelay: `${delay}ms` }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {waitingForLocation && !isTyping && (
                  <div className="flex flex-col gap-3 items-center py-2">
                    <div
                      className="flex items-center gap-2 text-sm"
                      style={{ color: isDark ? "rgba(255,255,255,0.6)" : "rgba(0,0,0,0.5)" }}
                    >
                      <MapPin className="w-4 h-4" />
                      <span>Select your location:</span>
                    </div>
                    <div className="flex gap-3">
                      {["Bangalore", "Coimbatore"].map((loc, i) => (
                        <button
                          key={loc}
                          onClick={() => handleLocationSelect(i + 1)}
                          className="arc-btn arc-btn--rect"
                        >
                          <span className="arc-btn-inner">{loc}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {isRateLimited && <RateLimitBanner retryAfter={retryAfter} />}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* ══ INPUT PILL — always at container bottom ══ */}
            <div className="flex-shrink-0 px-3 py-3">
              {sensitivityWarning.isSensitive && sensitivityWarning.level === 'high' && (
                <div className="text-xs text-red-400 font-medium px-4 mb-2 animate-in slide-in-from-bottom-1">
                  ⚠️ Sensitive data detected ({sensitivityWarning.category}). Please remove before sending.
                </div>
              )}

              {/* Session ID warning strip inside pill area */}
              {!hasSessionId && (
                <div className="flex items-center gap-2 px-4 mb-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                  <p className="text-[11px] text-amber-600 dark:text-amber-400 leading-tight">
                    <span className="font-semibold">Session ID missing</span> — AI services unavailable. Contact your <span className="font-semibold">administrator</span>.
                  </p>
                </div>
              )}

              {/* Liquid glass input pill — gradient border simulates light on curved glass */}
              <div
                className="rounded-full relative"
                style={{
                  background: isDark ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.45)",
                  backdropFilter: isDark ? "blur(20px) saturate(160%)" : undefined,
                  WebkitBackdropFilter: "blur(20px) saturate(160%)",
                  boxShadow: isDark
                    ? "0 0 16px rgba(89,83,255,0.22), 0 0 32px rgba(208,38,217,0.12), inset 0 1px 0 rgba(255,255,255,0.10)"
                    : "0 0 12px rgba(89,83,255,0.10), 0 0 24px rgba(208,38,217,0.06), inset 0 1px 1px rgba(255,255,255,0.8)",
                }}
              >
                {/* Gradient border via mask — only paints the 1px border ring */}
                <div
                  style={{
                    position: "absolute",
                    inset: 0,
                    borderRadius: "9999px",
                    padding: "1px",
                    background: isDark
                      ? "linear-gradient(160deg, rgba(255,255,255,0.28) 0%, rgba(89,83,255,0.35) 40%, rgba(208,38,217,0.18) 70%, rgba(255,255,255,0.04) 100%)"
                      : "linear-gradient(160deg, rgba(255,255,255,0.70) 0%, rgba(89,83,255,0.25) 40%, rgba(208,38,217,0.20) 70%, rgba(200,200,215,0.15) 100%)",
                    WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                    WebkitMaskComposite: "xor",
                    mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                    maskComposite: "exclude",
                    pointerEvents: "none",
                  }}
                />
                <div
                  className="chat-input-pill flex items-center gap-2 px-4 rounded-full"
                >
                  {/* Toggle / star icon */}
                  <button
                    onClick={onToggle}
                    className="flex-shrink-0 flex items-center justify-center transition-all hover:scale-110"
                    aria-label="Toggle chat"
                  >
                    {!hasSessionId
                      ? <AlertTriangle className="w-5 h-5 text-amber-500 opacity-80" />
                      : <img src="/input-chat-star.svg" alt="" className="w-6 h-6 opacity-60" />
                    }
                  </button>

                  <div className="flex-1">
                    <Input
                      ref={inputRef}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyPress}
                      onFocus={() => !isOpen && onToggle()}
                      placeholder={
                        isRateLimited
                          ? "Too many requests. Please wait…"
                          : !hasSessionId
                            ? "Session unavailable — contact your administrator"
                            : "Enter your queries here"
                      }
                      className={cn(
                        "border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-sm",
                        !hasSessionId && "placeholder:text-amber-500/70"
                      )}
                      style={{ color: isDark ? "rgba(255,255,255,0.9)" : "rgba(0,0,0,0.85)" }}
                      disabled={isTyping || isRateLimited || !hasSessionId}
                    />
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {/* Mic button */}
                    <button
                      onClick={toggleVoice}
                      disabled={!isSpeechRecognitionSupported || !hasSessionId}
                      title={
                        !hasSessionId
                          ? "Session ID missing — contact administrator"
                          : !isSpeechRecognitionSupported
                            ? "Voice not supported in this browser"
                            : isListening ? "Stop listening" : "Voice input"
                      }
                      className={cn(
                        "flex items-center justify-center transition-all duration-200",
                        (!isSpeechRecognitionSupported || !hasSessionId) && "opacity-30 cursor-not-allowed",
                        isListening && "animate-pulse"
                      )}
                    >
                      {isListening
                        ? <MicOff className="w-5 h-5" style={{ color: "rgba(255,59,48,0.9)" }} />
                        : <img src="/microphone.svg" alt="mic" className="w-5 h-5 opacity-55" />
                      }
                    </button>

                    {/* Send button */}
                    <button
                      onClick={() => handleSend()}
                      disabled={!message.trim() || isTyping || isRateLimited || !hasSessionId || sensitivityWarning.level === 'high'}
                      title={
                        !hasSessionId ? "Session ID missing — contact administrator"
                          : isRateLimited ? "Rate limited — please wait"
                            : "Send message"
                      }
                      className="flex items-center justify-center transition-all duration-200 hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
                    >
                      <img
                        src="/send.svg"
                        alt="send"
                        className="w-5 h-5"
                        style={{
                          opacity: message.trim() && !isTyping && hasSessionId ? 1 : 0.45,
                          filter: message.trim() && !isTyping && hasSessionId
                            ? "drop-shadow(0 0 4px rgba(89,83,255,0.8))"
                            : "none",
                        }}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>{/* end gradient-border wrapper */}
      </div>
    </div>
  );
};
