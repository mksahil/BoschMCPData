import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Mic, Sparkles } from "lucide-react";
import { cn, renderMarkdown, generateUUID } from "@/lib/utils";
import logger from "@/lib/logger";
import { API_ENDPOINTS } from "@/config";
import { useAuth } from "@/context/AuthContext";
import { detectIntent, shouldResetActiveService } from "@/lib/intentDetector";
import { RateLimitBanner } from "./RateLimitBanner";
import { useRateLimit } from "@/hooks/useRateLimit";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export const AIChat = () => {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI companion. I can help you with:\n🍽️ **Canteen** – Today's cafeteria menu, food items, meal timings\n⏰ **Entry/Exit Tracking** – Attendance, working hours, swipe records\n✈️ **Travel** – Business trip booking, travel settlements, expense claims\n💺 **Seat Booking** – Desk/workspace reservation\n👥 **Community** – Bosch/BGSW communities, clubs, groups\n📢 **Company News** – Announcements, upcoming BGSW events, promotions\n\nHow can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [activeService, setActiveService] = useState<string | null>(null);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  // Use the agent-generated SessionId from /Token/GenrateTokenDetails (stored on the
  // user object at login) so that the conversation-context key on the backend and the
  // A2A contextId used by Travel / Seat Booking all share the same ID.
  // Falls back to a local UUID only when the API returned null (warned in the UI).
  const [sessionId] = useState(() => user?.sessionId || generateUUID());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      // Attempt immediate focus (for autoFocus fallback)
      inputRef.current?.focus();

      // Attempt focus after animation/render delays
      const timers = [
        setTimeout(() => inputRef.current?.focus(), 100),
        setTimeout(() => inputRef.current?.focus(), 300),
        setTimeout(() => inputRef.current?.focus(), 500)
      ];

      return () => timers.forEach(clearTimeout);
    }
  }, [isOpen]);

  // Focus input when AI finishes "typing"
  useEffect(() => {
    if (!isTyping && isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isTyping, isOpen]);

  // Load chat history on mount
  useEffect(() => {
    const fetchHistory = async () => {
      if (!user?.employeeNumber) return;

      try {
        const url = `${API_ENDPOINTS.chatHistory}?employeeNumber=${user.employeeNumber}`;

        const response = await fetch(url, {
          headers: {
            'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
            'X-Employee-Number': user?.employeeNumber || '',
          }
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.history && data.history.length > 0) {
            // Format history messages
            const historyMessages: Message[] = data.history.map((msg: any) => ({
              role: msg.role === 'user' ? 'user' : 'assistant',
              content: msg.content,
              timestamp: new Date(msg.timestamp)
            }));

            // Merge with initial greeting (keep greeting first, then history)
            setMessages(prev => {
              // Create set of existing message signatures to avoid duplicates
              // Using content+timestamp as unique key roughly
              const existingContent = new Set(prev.map(m => m.content + m.timestamp.getTime()));

              const newHistory = historyMessages.filter(m =>
                !existingContent.has(m.content + m.timestamp.getTime())
              );

              if (newHistory.length === 0) return prev;

              // Combined array, sorted by timestamp
              const combined = [...prev, ...newHistory].sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

              return combined;
            });
          }
        }
      } catch (error) {
        console.error('[AIChat] Failed to load history:', error);
      }
    };

    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen, user?.employeeNumber, user?.accessToken]);

  const handleSend = async () => {
    if (!message.trim()) return;

    const messageToSend = message.trim();

    // Detect intent using shared word-boundary matcher.
    // If the user is starting a new flow (restart cue OR a different service than the active one),
    // drop the locked-in active service so we DON'T pollute the request with the previous context.
    const intent = detectIntent(messageToSend);
    const reset = shouldResetActiveService(messageToSend, activeService);
    if (reset && activeService) {
      console.log('[AIChat] Resetting active service:', activeService, '→', intent.service ?? '(none)');
      setActiveService(null);
    }

    const effectiveActiveService = reset ? null : activeService;
    const detectedService = intent.service ?? effectiveActiveService ?? null;

    // Send the user's RAW message — no "travel: I am providing details..." wrappers.
    // The backend already has slot-extraction prompts that work better on natural text,
    // and the wrapper used to override fresh intent classification.
    const finalQuery = messageToSend;

    const userMessage: Message = {
      role: "user",
      content: messageToSend,
      timestamp: new Date()
    };

    // Log user message
    logger.logChatMessage(messageToSend, true, {
      messageLength: messageToSend.length,
      sessionTime: new Date().getTime() - new Date(sessionStorage.getItem('sessionStartTime') || '').getTime()
    });

    // Send unmodified history. Don't retroactively brand past messages as travel slot-fill —
    // that destroys the very signal the backend needs to detect a topic switch.
    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    // processing user message

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsTyping(true);

    try {
      // Use unified smart chat endpoint - AI will route to correct service
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: finalQuery,
          // Service hint: use the freshly detected intent if any, else the (possibly reset) active service.
          // Backend treats this as a tiebreaker, NOT a forced override.
          service: detectedService,
          sessionId,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory  // Send conversation history for context
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        return; // RateLimitBanner renders inline — no message push needed
      }

      if (response.ok) {
        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date()
        };

        // Log AI response with service info
        logger.logChatMessage(aiMessage.content, false, {
          responseTime: new Date().getTime() - userMessage.timestamp.getTime(),
          userQuery: messageToSend,
          service: data.service,
          serviceName: data.serviceName
        });

        // Update active service context for next turns
        if (data.service) {
          setActiveService(data.service);
        }

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to process request');
      }
    } catch (error) {
      console.error('[AIChat] Error:', error);
      const errorMessage: Message = {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !isRateLimited) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => {
          const newState = !isOpen;
          setIsOpen(newState);
          logger.logButtonClick('ai-chat-toggle', newState ? 'Open Chat' : 'Close Chat', {
            chatOpen: newState,
            messagesCount: messages.length
          });
        }}
        className={cn(
          "fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-primary shadow-elevated",
          "flex items-center justify-center z-50 hover:shadow-glow transition-all duration-300",
          "hover:scale-110 animate-pulse-glow"
        )}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-primary-foreground" />
        ) : (
          <MessageCircle className="w-6 h-6 text-primary-foreground" />
        )}
      </button>

      {/* Chat Panel */}
      {isOpen && (
        <div className="fixed top-20 bottom-24 right-6 w-96 bg-card rounded-2xl shadow-elevated border border-border z-[60] flex flex-col animate-slide-in">
          {/* Header */}
          <div className="bg-gradient-primary p-4 rounded-t-2xl">
            <h3 className="text-primary-foreground font-semibold text-lg">Ask MyBGSW.AI</h3>
            <p className="text-primary-foreground/80 text-xs mt-1">Your intelligent workplace companion</p>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={cn(
                  "flex gap-2",
                  msg.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {msg.role === "assistant" && (
                  <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
                <div
                  className={cn(
                    "rounded-lg p-3 max-w-[80%]",
                    msg.role === "user"
                      ? "bg-gradient-primary text-primary-foreground"
                      : "bg-secondary text-foreground"
                  )}
                >
                  <p className="text-sm whitespace-pre-line" dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />
                  <p className={cn(
                    "text-xs mt-1",
                    msg.role === "user" ? "text-primary-foreground/60" : "text-muted-foreground"
                  )}>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                {msg.role === "user" && (
                  <div className="w-8 h-8 bg-gradient-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-accent-foreground font-semibold text-xs">JD</span>
                  </div>
                )}
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-2">
                <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-primary-foreground" />
                </div>
                <div className="bg-secondary rounded-lg p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                  </div>
                </div>
              </div>
            )}
            {isRateLimited && <RateLimitBanner retryAfter={retryAfter} />}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-border">
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                autoFocus
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value);
                  // Log typing activity (throttled - only when user stops typing)
                  if (e.target.value.length > 0 && e.target.value.length % 10 === 0) {
                    logger.log('chat_typing', {
                      currentLength: e.target.value.length,
                      hasContent: true
                    });
                  }
                }}
                onFocus={() => logger.log('chat_input_focus', { timestamp: new Date().toISOString() })}
                onKeyPress={handleKeyPress}
                placeholder={isRateLimited ? "Too many requests. Please wait and try again." : "Type your message..."}
                disabled={isRateLimited || isTyping}
                className="flex-1 px-4 py-2 rounded-lg bg-secondary border border-border focus:outline-none focus:ring-2 focus:ring-primary text-sm text-foreground placeholder:text-muted-foreground"
              />
              <button
                onClick={() => logger.logButtonClick('chat-voice-input', 'Voice Input', { feature: 'voice', enabled: false })}
                className="w-10 h-10 bg-secondary hover:bg-gradient-primary rounded-lg flex items-center justify-center transition-all duration-300 group">
                <Mic className="w-5 h-5 text-muted-foreground group-hover:text-primary-foreground" />
              </button>
              <button
                onClick={() => {
                  logger.logButtonClick('chat-send-message', 'Send', {
                    messageLength: message.length,
                    hasContent: message.trim().length > 0
                  });
                  handleSend();
                }}
                disabled={!message.trim() || isRateLimited || isTyping}
                className="w-10 h-10 bg-gradient-primary hover:shadow-glow rounded-lg flex items-center justify-center transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5 text-primary-foreground" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
