import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ShieldAlert } from 'lucide-react';

interface SessionTimeoutModalProps {
  open: boolean;
  /** Remaining seconds in the 2-minute warning window */
  countdown: number;
  onStayLoggedIn: () => void;
  onLogout: () => void;
}

/**
 * SessionTimeoutModal
 *
 * Full-screen blocking dialog shown when the user has been inactive for 13
 * minutes. Displays a live countdown and two action buttons:
 *
 *   • Stay Logged In — resets the inactivity timer and refreshes the token
 *   • Log Out Now    — immediately ends the session
 *
 * The modal cannot be dismissed by clicking outside — the user must
 * explicitly choose an action.
 *
 * Accessibility:
 *   • role="timer" + aria-live="assertive" on countdown so screen readers
 *     announce updates without the user having to focus the element
 *   • DialogTitle / DialogDescription satisfy ARIA dialog labelling
 */
export function SessionTimeoutModal({
  open,
  countdown,
  onStayLoggedIn,
  onLogout,
}: SessionTimeoutModalProps) {
  const minutes = Math.floor(countdown / 60);
  const seconds = countdown % 60;
  const formatted = `${minutes}:${String(seconds).padStart(2, '0')}`;

  return (
    <Dialog open={open} onOpenChange={() => { /* intentionally blocked */ }}>
      <DialogContent
        className="sm:max-w-md z-[9999]"
        overlayClassName="z-[9999]"
        onInteractOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
        data-testid="session-timeout-modal"
      >
        <DialogHeader className="items-center text-center">
          <ShieldAlert className="h-10 w-10 text-destructive mb-2" aria-hidden="true" />
          <DialogTitle className="text-xl">Session About to Expire</DialogTitle>
          <DialogDescription className="text-center">
            You have been inactive. Your session will automatically end in:
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center gap-6 py-4">
          {/* Live countdown — announced to screen readers on every change */}
          <div
            role="timer"
            aria-live="assertive"
            aria-atomic="true"
            aria-label={`Session expires in ${formatted}`}
            data-testid="countdown-display"
            className="text-6xl font-bold tabular-nums text-destructive tracking-tight"
          >
            {formatted}
          </div>

          <p className="text-center text-sm text-muted-foreground px-4">
            Click <strong>Stay Logged In</strong> to continue, or your session
            will be closed when the timer reaches&nbsp;0:00.
          </p>

          <div className="flex gap-3 w-full pt-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={onLogout}
              data-testid="logout-button"
            >
              Log Out Now
            </Button>
            <Button
              className="flex-1"
              onClick={onStayLoggedIn}
              data-testid="stay-logged-in-button"
              autoFocus
            >
              Stay Logged In
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default SessionTimeoutModal;
