export const SENSITIVE_PATTERNS = [
  // Financial PII
  { pattern: /\b(?:\d[ -]*?){13,16}\b/, category: 'Financial PII', level: 'high' },
  // Identity PII
  { pattern: /\b[A-Z]{5}[0-9]{4}[A-Z]\b/i, category: 'Identity PII', level: 'high' },
  { pattern: /\b\d{4}\s\d{4}\s\d{4}\b/, category: 'Identity PII', level: 'high' },
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/, category: 'Identity PII', level: 'high' },
  // Authentication
  { pattern: /\b(?:password|pwd|secret|api[_\-\s]?key|token)\s*[:=]\s*\S+/i, category: 'Authentication credentials', level: 'high' },
  // Business (Low risk hint)
  { pattern: /\b(?:revenue|profit|merger|acquisition|nda|unreleased|restructuring)\b/i, category: 'Business-critical info', level: 'low' },
  // Health (Low risk hint)
  { pattern: /\b(?:diagnosis|prescription|disease|illness|medical condition)\b/i, category: 'Health info', level: 'low' }
];

export const checkSensitivity = (text: string) => {
  for (const item of SENSITIVE_PATTERNS) {
    if (item.pattern.test(text)) {
      return { isSensitive: true, level: item.level as 'high' | 'low', category: item.category };
    }
  }
  return { isSensitive: false, level: 'none' as 'none', category: null };
};
