const axios = require('axios');   // was missing — caused ReferenceError on MCP calls
const https = require('https');
const configService = require('./config-service');
const { createOpenAIClient, getChatModelName } = require('./openai-client');

// Bosch internal MCP servers use corporate PKI (Bosch root CA) not trusted by Node.js by default.
// rejectUnauthorized: false is intentional for internal-network services — not a public-internet risk.
const httpsAgent = new https.Agent({
  rejectUnauthorized: false // [INTERNAL-CA] Bosch corporate PKI — system CA not available to Node.js
});

/**
 * Build Authorization + content headers for MCP endpoint calls.
 * @param {string|null} jwtToken - JWT from /Token/GenrateTokenDetails (no "Bearer" prefix needed)
 * @param {string|null} employeeNumber
 */
function buildAuthHeaders(jwtToken, employeeNumber) {
  const headers = {
    'Accept': 'application/json, text/event-stream',
    'Content-Type': 'application/json'
  };
  if (employeeNumber) {
    headers['X-Employee-Number'] = employeeNumber;
  }
  if (jwtToken) {
    const raw = jwtToken.replace(/^Bearer\s+/i, '').trim();
    headers['Authorization'] = `Bearer ${raw}`;
    console.log('[EntryExitV2] Authorization header set (token prefix):', raw.substring(0, 20) + '...');
  } else {
    console.warn('[EntryExitV2] No JWT token — calling MCP without Authorization header');
  }
  return headers;
}

/**
 * Service V2 for integrating with Entry/Exit MCP Server
 * Uses the deployed MCP server on Azure
 */
class EntryExitServiceV2 {
  constructor() {
    // Use new deployed MCP server URL
    this.mcpEndpoint = process.env.ENTRYEXIT_MCP_URL || 'https://mcp-entry-exit-dev.azurewebsites.net/mcp';
    
    console.log('[EntryExit] MCP Endpoint:', this.mcpEndpoint);
    
    // Cache for frequently requested data
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    
    // MCP session ID
    this.mcpSessionId = null;

    // Lazy-initialised OpenAI client (same pattern as travel / seatbooking)
    this._openai = null;
  }

  /**
   * Lazy getter for the OpenAI client.
   */
  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }
  
  /**
   * Initialize MCP session
   */
  async initializeMCPSession(jwtToken = null) {
    try {
      console.log('[EntryExit] Initializing MCP session...');

      const initPayload = {
        jsonrpc: "2.0",
        method: "initialize",
        params: {
          protocolVersion: "2024-11-05",
          capabilities: {},
          clientInfo: { name: "mybgs-companion", version: "1.0.0" }
        },
        id: 1
      };

      const response = await axios.post(this.mcpEndpoint, initPayload, {
        headers: buildAuthHeaders(jwtToken, null),
        timeout: 30000,
        httpsAgent,
        transformResponse: [(data) => data]
      });

      // Extract session ID from response headers
      this.mcpSessionId = response.headers['mcp-session-id'];
      console.log('[EntryExit] MCP session initialized:', this.mcpSessionId);
      
      return this.mcpSessionId;
    } catch (error) {
      console.error('[EntryExit] Failed to initialize MCP session:', error.message);
      throw error;
    }
  }

  /**
   * Get cache key for a query
   */
  getCacheKey(employeeNumber, query) {
    return `${employeeNumber}:${query}`;
  }

  /**
   * Check if cached data is still valid
   */
  isCacheValid(cacheEntry) {
    if (!cacheEntry) return false;
    return Date.now() - cacheEntry.timestamp < this.cacheTimeout;
  }

  /**
   * Parse SSE response data
   */
  parseSSEResponse(sseData) {
    if (typeof sseData !== 'string') return sseData;
    
    console.log('[EntryExit] Parsing SSE response, length:', sseData?.length);
    
    // Handle different line endings
    const lines = sseData.split(/\r?\n/);
    let result = null;
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      // Check for data: prefix (with or without space after colon)
      if (trimmedLine.startsWith('data:')) {
        const jsonStr = trimmedLine.substring(5).trim();
        try {
          result = JSON.parse(jsonStr);
          console.log('[EntryExit] Successfully parsed SSE data');
        } catch (e) {
          // Not JSON, might be plain text
          result = { answer: jsonStr };
        }
      }
    }
    
    // If no SSE format found, try parsing the whole thing as JSON
    if (!result) {
      try {
        result = JSON.parse(sseData);
        console.log('[EntryExit] Parsed as direct JSON');
      } catch (e) {
        console.log('[EntryExit] Not valid JSON either');
      }
    }
    
    return result;
  }

  /**
   * Query the MCP endpoint using SSE format
   */
  async queryMCP(employeeNumber, toolName, args = {}, jwtToken = null) {
    try {
      console.log(`[EntryExit] Calling MCP tool: ${toolName}`, args);

      // Initialize session if needed
      if (!this.mcpSessionId) {
        await this.initializeMCPSession(jwtToken);
      }

      const toolCallPayload = {
        jsonrpc: "2.0",
        method: "tools/call",
        params: {
          name: toolName,
          arguments: args
        },
        id: Date.now()
      };

      const headers = buildAuthHeaders(jwtToken, employeeNumber);
      headers['mcp-session-id'] = this.mcpSessionId;

      const response = await axios.post(this.mcpEndpoint, toolCallPayload, {
        headers,
        timeout: 30000,
        httpsAgent,
        transformResponse: [(data) => data]
      });

      const result = this.parseSSEResponse(response.data);
      
      // Handle MCP tool response format
      if (result?.result?.content && Array.isArray(result.result.content)) {
        for (const item of result.result.content) {
          if (item.type === 'text' && item.text) {
            try {
              return JSON.parse(item.text);
            } catch (e) {
              return { answer: item.text };
            }
          }
        }
      }
      
      return result?.result || result;
    } catch (error) {
      console.error('[EntryExit] MCP call failed:', error.message);
      // Reset session on failure
      this.mcpSessionId = null;
      throw error;
    }
  }

  /**
   * Query the MCP endpoint for entry/exit data
   */
  async queryChat(employeeNumber, query, jwtToken = null) {
    const cacheKey = this.getCacheKey(employeeNumber, query);
    const cachedData = this.cache.get(cacheKey);

    // Check cache first
    if (this.isCacheValid(cachedData)) {
      console.log('[EntryExit] Returning cached data for:', query);
      return cachedData.data;
    }

    try {
      console.log(`[EntryExit] Querying MCP for employee ${employeeNumber}: ${query}`);

      // Use the MCP endpoint with proper session management
      const result = await this.queryMCP(employeeNumber, 'get_current_status', {
        employee_id: employeeNumber
      }, jwtToken);
      
      // Cache the response
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });

      return result;
    } catch (mcpError) {
      console.error('[EntryExit] MCP error:', mcpError.message);
      
      // Return cached data if available, even if expired
      if (cachedData) {
        console.log('[EntryExit] Returning expired cache due to error');
        return cachedData.data;
      }
      
      throw new Error(`Failed to query Entry/Exit server: ${mcpError.message}`);
    }
  }

  /**
   * Check if query is asking about another person's entry/exit data.
   *
   * Strategy (mirrors travel-service and seatbooking-service): detect
   * **syntactic patterns** that strongly indicate a person reference rather
   * than flagging every capitalised word as a name.  Day names, month names,
   * and temporal adjectives (daily, weekly…) are explicitly safe so that
   * queries like "day-wise details for April" or "attendance from Monday to
   * Friday" are never blocked.
   *
   * Patterns checked:
   *   A) Possessive  : "Rajesh's attendance"
   *   B) Genitive    : "entry details of Kumar"
   *   C) Action-for  : "show attendance for Priya"
   *   D) Name-before-noun: "Check Ramesh entry time"
   */
  isQueryAboutOtherPerson(query, loggedInUserName) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // ── Helper: does `name` match the logged-in user? ──────────────────────
    const ownNameParts = new Set();
    if (loggedInUserName) {
      const full = String(loggedInUserName).toLowerCase().trim();
      if (full) {
        ownNameParts.add(full);
        full.split(/\s+/).filter(Boolean).forEach(p => ownNameParts.add(p));
      }
    }
    const isOwnName = (name) => {
      if (!name) return false;
      const n = String(name).toLowerCase().trim();
      if (ownNameParts.has(n)) return true;
      for (const p of ownNameParts) {
        if (p.length >= 3 && (n.includes(p) || p.includes(n))) return true;
      }
      return false;
    };

    // ── Step 1 – Gate: must contain entry/exit data keywords ───────────────
    const timeTrackingKeywords = configService.getKeywordConfigSync().entryExitService.entryExitDataKeywords;
    const hasTimeData = timeTrackingKeywords.some(kw => q.includes(kw));
    if (!hasTimeData) return false;

    // ── Step 2 – Self-reference → safe (unless colleague word) ────────────
    const hasSelfRef = /\b(my|mine|me|myself|i|i\s+am|who\s+am\s+i|my\s+name|what\s+is\s+my\s+name)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|team\s?mate|boss|manager|reportee|other\s+employee|another\s+employee|someone\s+else|other\s+person|another\s+person|other\s+people)\b/i.test(q);
    if (hasSelfRef && !hasColleagueWord) return false;

    // ── Step 3 – Colleague / role word → blocked ───────────────────────────
    if (hasColleagueWord) return true;

    // ── Step 4 – Third-person pronoun + time/attendance noun → blocked ─────
    const timeNounRe = '(?:entry|exit|attendance|time|login|logout|check.?in|check.?out|details?|data|records?|history|status|info|information|report|summary|hours?|leaves?|day.?wise|in.?time|out.?time|swipe)';
    if (new RegExp(`\\b(his|her|their)\\s+${timeNounRe}`, 'i').test(q)) return true;
    if (/\bfor\s+(him|her|them)\b/i.test(q)) return true;

    // ── Step 5 – Pattern-based person-name detection ───────────────────────

    // 5.0  Words appearing after date/time prepositions are days/months, not names.
    const timeContextPositions = new Set();
    const timePrepRe = /\b(?:for|on|from|to|till|until|between|during|in|at|by|after|before|since)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)/g;
    for (const m of original.matchAll(timePrepRe)) {
      m[1].toLowerCase().split(/\s+/).forEach(w => timeContextPositions.add(w));
    }

    // 5.1  Static safe-word set: day names, month names, temporal terms.
    //      These are the most common false-positive sources for entry/exit queries
    //      ("day-wise for April", "attendance from Monday to Friday", etc.).
    const DAY_MONTH_TERMS = new Set([
      'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december',
      'today', 'yesterday', 'tomorrow',
      'daily', 'weekly', 'monthly', 'annual', 'yearly',
      'daywise', 'date', 'week', 'month', 'year',
      'morning', 'evening', 'afternoon', 'night',
      'current', 'recent', 'last', 'this', 'next', 'previous'
    ]);

    const whitelist = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));

    const isKnownSafe = (name) => {
      const n = name.toLowerCase();
      if (whitelist.has(n) || DAY_MONTH_TERMS.has(n) || timeContextPositions.has(n)) return true;
      // Multi-word phrase: safe if any constituent word is recognised
      return n.split(/\s+/).some(w => whitelist.has(w) || DAY_MONTH_TERMS.has(w) || timeContextPositions.has(w));
    };

    // ── Pattern A: Possessive — "<Name>'s …" ──────────────────────────────
    for (const m of original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)'s\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[EntryExit Privacy] Blocked: possessive "${m[1]}'s"`);
        return true;
      }
    }

    // ── Pattern B: "<time noun> of/for <Name>" ────────────────────────────
    const genitiveRe = new RegExp(
      `\\b${timeNounRe}\\s+(?:of|for)\\s+([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\b`, 'g'
    );
    for (const m of original.matchAll(genitiveRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[EntryExit Privacy] Blocked: "of/for ${m[1]}" after time noun`);
        return true;
      }
    }

    // ── Pattern C: "check/show/get … for <Name>" (not a known date/day) ───
    for (const m of original.matchAll(/\b(?:check|show|get|find|fetch|retrieve|display|view|list|give)\b[^.]*?\bfor\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[EntryExit Privacy] Blocked: action "for ${m[1]}"`);
        return true;
      }
    }

    // ── Pattern D: "<Name> <time-noun>" where Name is NOT a day/month ──────
    const nameBeforeNounRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${timeNounRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeNounRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        const before = original.substring(Math.max(0, m.index - 15), m.index).trim().toLowerCase();
        if (!/\b(?:for|on|in|at|from|to|till|until|during|since)\s*$/.test(before)) {
          console.log(`[EntryExit Privacy] Blocked: "${m[1]}" before time noun`);
          return true;
        }
      }
    }

    // ── Pattern E: "<Name> <attendance-verb>" ────────────────────────────────
    // Catches natural-language queries that avoid explicit time nouns:
    //   "how many days did Ganesh Mahadevan come"
    //   "did Priya arrive today"
    //   "is Rahul present"
    //   "was Suresh absent yesterday"
    const attendanceVerbRe =
      '(?:come|came|comes|coming|attend(?:ed|s|ing)?|arriv(?:e[ds]?|es|ing)|present|absent|presence|absence)';

    // E1: Capitalized name immediately before an attendance verb
    //     "Ganesh Mahadevan come", "Priya arrived"
    const nameBeforeVerbRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${attendanceVerbRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeVerbRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[EntryExit Privacy] Blocked: "${m[1]}" before attendance verb`);
        return true;
      }
    }

    // E2: Auxiliary / question word directly before a capitalized name
    //     "did Ganesh come", "how many days did Priya attend", "is Rahul present"
    //     The regex anchors to an auxiliary followed immediately by a proper name.
    const auxBeforeNameRe = /\b(?:did|does|do|is|was|were|has|have|had|how\s+many\s+days?)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g;
    for (const m of original.matchAll(auxBeforeNameRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[EntryExit Privacy] Blocked: auxiliary question about "${m[1]}"`);
        return true;
      }
    }

    // No person-name pattern detected → safe
    return false;
  }

  /**
   * Privacy classifier — determines whether a query asks about the logged-in
   * user's own data ("self") or about another person's data ("other").
   *
   * Strategy (LLM-first, regex fallback):
   *   1. Use gpt-4o-mini with the admin-configurable few-shot examples from
   *      fewShotConfig.entryexitPrivacy to classify the query semantically.
   *      LLM understands natural-language variations that regex cannot catch
   *      (e.g. "how many days did Ganesh come", "tell me when Rahul signed in").
   *   2. If the LLM call fails (network, quota, parse error), fall back to the
   *      deterministic regex implementation in isQueryAboutOtherPerson().
   *
   * Returns true  → query is about another person (block it)
   *         false → query is about the logged-in user (allow it)
   */
  async classifyPrivacy(query, loggedInUserName) {
    const examples = configService.getFewShotConfigSync().entryexitPrivacy || [];

    if (examples.length > 0) {
      const exampleLines = examples
        .map(e => `Q: "${e.query}" → {"result":"${e.intent}"}`)
        .join('\n');

      const systemPrompt = `You are a privacy classifier for an employee attendance system at Bosch.
Decide whether the query is asking about the LOGGED-IN user's own data, or about ANOTHER person.

Logged-in user: ${loggedInUserName || 'Unknown'}

Rules:
- "self"  : query uses "my", "me", "I", "mine" and refers only to the logged-in user's own data, OR uses the logged-in user's own name.
- "other" : query mentions another employee by name, pronoun (his/her/their/him/her), role word (colleague/teammate/boss), or asks about multiple employees' data.
- "other" : questions like "how many days did [Name] come/attend/arrive", "[Name]'s attendance", "show [Name]'s entry" are always "other".

Few-shot examples:
${exampleLines}

Respond with ONLY valid JSON, no explanation: {"result":"self"} or {"result":"other"}`;

      try {
        const response = await this.openai.chat.completions.create({
          model: getChatModelName('gpt-4o-mini'),
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user',   content: query }
          ],
          max_tokens: 20,
          temperature: 0
        });

        const raw = response.choices[0].message.content.trim();
        const parsed = JSON.parse(raw);
        if (parsed.result === 'other') {
          console.log(`[EntryExit Privacy] LLM → "other" for: "${query}"`);
          return true;  // block
        }
        if (parsed.result === 'self') {
          console.log(`[EntryExit Privacy] LLM → "self" for: "${query}"`);
          return false; // allow
        }
        // Unexpected label — fall through to regex
        console.warn(`[EntryExit Privacy] LLM returned unexpected result: "${parsed.result}" — falling back to regex`);
      } catch (e) {
        console.warn('[EntryExit Privacy] LLM call failed, falling back to regex:', e.message);
      }
    }

    // Regex fallback (deterministic, always available)
    return this.isQueryAboutOtherPerson(query, loggedInUserName);
  }

  /**
   * Classify the user's entry/exit query intent using few-shot LLM prompting.
   * Returns one of: 'current' | 'history' | 'identity' | 'general'
   * Falls back to keyword matching when the LLM call fails.
   *
   * Intent meanings:
   *   current  — today's status / check-in / check-out / working hours so far
   *   history  — day-wise or date-range attendance records (last week, this month…)
   *   identity — "who am I" / employee name lookup
   *   general  — anything else (office timings, how does tracking work, etc.)
   */
  async classifyQueryIntent(query) {
    const examples = configService.getFewShotConfigSync().entryexit || [];
    const exampleLines = examples.map(e => `Q: "${e.query}" → {"intent":"${e.intent}"}`).join('\n');

    const systemPrompt = `You are an intent classifier for an employee attendance and time-tracking assistant at Bosch.
Classify the user query into exactly one of these intents:
- "current"  : user wants their attendance status, entry/exit time, or working hours for today
- "history"  : user wants past attendance records, day-wise details, or a date-range report
- "identity" : user is asking their own name or employee number ("who am I", "what is my name")
- "general"  : any other entry/exit or attendance-related query

Few-shot examples (cover every tricky case):
${exampleLines}

Respond with ONLY valid JSON, no explanation: {"intent":"current"|"history"|"identity"|"general"}`;

    try {
      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: query }
        ],
        max_tokens: 20,
        temperature: 0
      });

      const raw = response.choices[0].message.content.trim();
      const parsed = JSON.parse(raw);
      const valid = ['current', 'history', 'identity', 'general'];
      if (valid.includes(parsed.intent)) {
        console.log(`[EntryExit] LLM intent: "${parsed.intent}" for query: "${query}"`);
        return parsed.intent;
      }
    } catch (e) {
      console.warn('[EntryExit] LLM intent classification failed, using keyword fallback:', e.message);
    }

    return this.classifyQueryIntentFallback(query);
  }

  /**
   * Keyword-based intent fallback used when the LLM call fails.
   */
  classifyQueryIntentFallback(query) {
    const q = query.toLowerCase();
    if (/\b(who\s+am\s+i|my\s+name|employee\s+name|employee\s+number|identify\s+me)\b/i.test(q)) return 'identity';
    if (/\b(day.?wise|last\s+week|this\s+week|this\s+month|last\s+month|history|records?|from\s+\d|to\s+\d|date\s+range|monthly|weekly|past)\b/i.test(q)) return 'history';
    if (/\b(today|this\s+morning|right\s+now|current|check.?in|check.?out|swiped\s+in|swiped\s+out|entry\s+time|exit\s+time|how\s+many\s+hours.*today|am\s+i\s+late)\b/i.test(q)) return 'current';
    return 'general';
  }

  /**
   * Main method to get employee time data
   */
  async getEmployeeTimeData(employeeNumber, query, userName = null, jwtToken = null) {
    try {
      // Privacy check: LLM few-shot classifier (falls back to regex if LLM fails)
      if (await this.classifyPrivacy(query, userName)) {
        console.log(`[EntryExit] Privacy block: query "${query}" about another person (requester: ${userName || employeeNumber})`);
        return {
          success: false,
          answer: "I'm sorry, but I can only provide your own personal information. For privacy and security reasons, I cannot share details about other colleagues such as their attendance, entry/exit times, leave, payslip, or any other personal data. If you need information about a colleague, please ask them directly or contact HR."
        };
      }

      // LLM-based intent classification with few-shot examples.
      // All intents are currently handled by the MCP server; the classification
      // is logged for observability and ready for per-intent tool routing.
      const intent = await this.classifyQueryIntent(query);
      console.log(`[EntryExit] Query intent: "${intent}" | employee: ${employeeNumber} | query: "${query}"`);

      const response = await this.queryChat(employeeNumber, query, jwtToken);
      return response;
    } catch (error) {
      console.error('Error getting employee time data:', error);
      throw error;
    }
  }

  /**
   * Clear cache for an employee
   */
  clearCache(employeeNumber) {
    let cleared = 0;
    for (const [key] of this.cache.entries()) {
      if (key.startsWith(`${employeeNumber}:`)) {
        this.cache.delete(key);
        cleared++;
      }
    }
    return cleared;
  }

  /**
   * Get cache statistics
   */
  getCacheStats() {
    let valid = 0;
    let expired = 0;
    const now = Date.now();

    for (const [, value] of this.cache.entries()) {
      if (now - value.timestamp < this.cacheTimeout) {
        valid++;
      } else {
        expired++;
      }
    }

    return {
      total: this.cache.size,
      valid,
      expired,
      cacheTimeout: this.cacheTimeout
    };
  }
}

module.exports = new EntryExitServiceV2();