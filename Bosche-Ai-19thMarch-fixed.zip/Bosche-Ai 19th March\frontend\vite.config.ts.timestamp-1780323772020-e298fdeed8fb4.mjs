// vite.config.ts
import { defineConfig } from "file:///D:/Documents/web/Bosche-Ai-SSO-24th_March/19thMay2026/Bosche-Ai%2019th%20March/frontend/node_modules/vite/dist/node/index.js";
import react from "file:///D:/Documents/web/Bosche-Ai-SSO-24th_March/19thMay2026/Bosche-Ai%2019th%20March/frontend/node_modules/@vitejs/plugin-react-swc/index.js";
import path from "path";
var __vite_injected_original_dirname = "D:\\Documents\\web\\Bosche-Ai-SSO-24th_March\\19thMay2026\\Bosche-Ai 19th March\\frontend";
var vite_config_default = defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    allowedHosts: true,
    // Allow all hosts (ngrok, tunnels, etc.)
    proxy: {
      // Proxy all /api requests to backend
      "/api": {
        target: "http://127.0.0.1:3001",
        changeOrigin: true,
        secure: false
      }
    }
  },
  plugins: [react()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__vite_injected_original_dirname, "./src")
    }
  },
  optimizeDeps: {
    // Prevents "file does not exist in optimizeDeps directory" errors
    // caused by stale Vite cache entries after hot-reload or package updates.
    force: mode === "development" ? false : false,
    holdUntilCrawlEnd: true
  }
}));
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJEOlxcXFxEb2N1bWVudHNcXFxcd2ViXFxcXEJvc2NoZS1BaS1TU08tMjR0aF9NYXJjaFxcXFwxOXRoTWF5MjAyNlxcXFxCb3NjaGUtQWkgMTl0aCBNYXJjaFxcXFxmcm9udGVuZFwiO2NvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9maWxlbmFtZSA9IFwiRDpcXFxcRG9jdW1lbnRzXFxcXHdlYlxcXFxCb3NjaGUtQWktU1NPLTI0dGhfTWFyY2hcXFxcMTl0aE1heTIwMjZcXFxcQm9zY2hlLUFpIDE5dGggTWFyY2hcXFxcZnJvbnRlbmRcXFxcdml0ZS5jb25maWcudHNcIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfaW1wb3J0X21ldGFfdXJsID0gXCJmaWxlOi8vL0Q6L0RvY3VtZW50cy93ZWIvQm9zY2hlLUFpLVNTTy0yNHRoX01hcmNoLzE5dGhNYXkyMDI2L0Jvc2NoZS1BaSUyMDE5dGglMjBNYXJjaC9mcm9udGVuZC92aXRlLmNvbmZpZy50c1wiO2ltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gXCJ2aXRlXCI7XHJcbmltcG9ydCByZWFjdCBmcm9tIFwiQHZpdGVqcy9wbHVnaW4tcmVhY3Qtc3djXCI7XHJcbmltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCI7XHJcblxyXG4vLyBodHRwczovL3ZpdGVqcy5kZXYvY29uZmlnL1xyXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoKHsgbW9kZSB9KSA9PiAoe1xyXG4gIHNlcnZlcjoge1xyXG4gICAgaG9zdDogXCI6OlwiLFxyXG4gICAgcG9ydDogODA4MCxcclxuICAgIGFsbG93ZWRIb3N0czogdHJ1ZSwgLy8gQWxsb3cgYWxsIGhvc3RzIChuZ3JvaywgdHVubmVscywgZXRjLilcclxuICAgIHByb3h5OiB7XHJcbiAgICAgIC8vIFByb3h5IGFsbCAvYXBpIHJlcXVlc3RzIHRvIGJhY2tlbmRcclxuICAgICAgJy9hcGknOiB7XHJcbiAgICAgICAgdGFyZ2V0OiAnaHR0cDovLzEyNy4wLjAuMTozMDAxJyxcclxuICAgICAgICBjaGFuZ2VPcmlnaW46IHRydWUsXHJcbiAgICAgICAgc2VjdXJlOiBmYWxzZSxcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sXHJcbiAgcGx1Z2luczogW3JlYWN0KCldLmZpbHRlcihCb29sZWFuKSxcclxuICByZXNvbHZlOiB7XHJcbiAgICBhbGlhczoge1xyXG4gICAgICBcIkBcIjogcGF0aC5yZXNvbHZlKF9fZGlybmFtZSwgXCIuL3NyY1wiKSxcclxuICAgIH0sXHJcbiAgfSxcclxuICBvcHRpbWl6ZURlcHM6IHtcclxuICAgIC8vIFByZXZlbnRzIFwiZmlsZSBkb2VzIG5vdCBleGlzdCBpbiBvcHRpbWl6ZURlcHMgZGlyZWN0b3J5XCIgZXJyb3JzXHJcbiAgICAvLyBjYXVzZWQgYnkgc3RhbGUgVml0ZSBjYWNoZSBlbnRyaWVzIGFmdGVyIGhvdC1yZWxvYWQgb3IgcGFja2FnZSB1cGRhdGVzLlxyXG4gICAgZm9yY2U6IG1vZGUgPT09ICdkZXZlbG9wbWVudCcgPyBmYWxzZSA6IGZhbHNlLFxyXG4gICAgaG9sZFVudGlsQ3Jhd2xFbmQ6IHRydWUsXHJcbiAgfSxcclxufSkpO1xyXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQTZiLFNBQVMsb0JBQW9CO0FBQzFkLE9BQU8sV0FBVztBQUNsQixPQUFPLFVBQVU7QUFGakIsSUFBTSxtQ0FBbUM7QUFLekMsSUFBTyxzQkFBUSxhQUFhLENBQUMsRUFBRSxLQUFLLE9BQU87QUFBQSxFQUN6QyxRQUFRO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixjQUFjO0FBQUE7QUFBQSxJQUNkLE9BQU87QUFBQTtBQUFBLE1BRUwsUUFBUTtBQUFBLFFBQ04sUUFBUTtBQUFBLFFBQ1IsY0FBYztBQUFBLFFBQ2QsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sT0FBTztBQUFBLEVBQ2pDLFNBQVM7QUFBQSxJQUNQLE9BQU87QUFBQSxNQUNMLEtBQUssS0FBSyxRQUFRLGtDQUFXLE9BQU87QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFBQSxFQUNBLGNBQWM7QUFBQTtBQUFBO0FBQUEsSUFHWixPQUFPLFNBQVMsZ0JBQWdCLFFBQVE7QUFBQSxJQUN4QyxtQkFBbUI7QUFBQSxFQUNyQjtBQUNGLEVBQUU7IiwKICAibmFtZXMiOiBbXQp9Cg==
