/**
 * Global Configuration Service
 * Manages core service keywords, descriptions, and privacy whitelists
 */

const fs = require('fs-extra');
const path = require('path');

class ConfigService {
  constructor() {
    this.configPath = path.join(__dirname, '../data/app-config.json');
    this.config = null;
    this.initialized = false;
  }

  /**
   * Initialize and load configuration
   */
  async initialize() {
    if (this.initialized) return;

    try {
      await fs.ensureDir(path.dirname(this.configPath));

      if (await fs.pathExists(this.configPath)) {
        this.config = await fs.readJson(this.configPath);
      } else {
        // Initialize with current hardcoded defaults
        this.config = this.getDefaultConfig();
        await this.saveConfig();
      }

      this.initialized = true;
      console.log('[ConfigService] Initialized and loaded');
    } catch (error) {
      console.error('[ConfigService] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * Get default configuration based on current hardcoded values
   */
  getDefaultConfig() {
    return {
      coreServices: {
        canteen: {
          name: 'Canteen Service',
          description: "Handles cafeteria menu, food items, today's menu, snacks, beverages, meal timings, food availability at Bosch canteen",
          keywords: ['menu', 'food', 'lunch', 'dinner', 'breakfast', 'snacks', 'cafeteria', 'canteen', 'meal', 'eat', 'hungry', 'beverage', 'tea', 'coffee', "today's special"]
        },
        entryexit: {
          name: 'Entry/Exit Time Tracking',
          description: 'Handles employee attendance, entry time, exit time, working hours, overtime, swipe records, punch in/out, time tracking, employee name lookup',
          keywords: ['entry', 'exit', 'attendance', 'punch', 'swipe', 'time', 'hours', 'overtime', 'in-time', 'out-time', 'working hours', 'late', 'early', 'leave', 'my name', 'employee name', 'who am i', 'what is my name']
        },
        travel: {
          name: 'Travel Agent',
          description: "Handles travel plans, travel requests, trip booking, travel settlements, expense claims for business travel. Use this for ANY query where the user wants to book, raise, create, submit, arrange, or plan a travel or trip — including phrases like 'raise a travel', 'create a travel request', 'I want to travel', or 'arrange a trip'.",
          keywords: ['travel', 'trip', 'flight', 'hotel', 'booking', 'expense', 'settlement', 'reimbursement', 'business trip', 'travel plan', 'itinerary', 'raise a travel', 'raise travel', 'create a travel', 'submit a travel']
        },
        seatbooking: {
          name: 'Seat Booking',
          description: 'Handles desk/seat booking, workspace reservation, office seat allocation, cancel desk booking',
          keywords: ['seat', 'desk', 'booking', 'reserve', 'workspace', 'office', 'book a seat', 'cancel booking', 'workstation']
        },
        community: {
          name: 'Community',
          description: 'Handles Bosch community information, community list, groups, clubs, employee communities at Bosch Associate Arena',
          keywords: ['community', 'communities', 'groups', 'clubs', 'associate arena', 'join', 'members', 'team', 'enroll', 'participate', 'bosch community', 'bosch communities', 'bosch groups', 'bosch clubs', 'bgsw community', 'bgsw communities', 'bgsw groups', 'bgsw clubs']
        },
        banner: {
          name: 'Banner Service',
          description: "Handles company banners, announcements, events, company events, upcoming events in BGSW, Bosch internal event highlights, news, promotional content, current promotions, office banners, what's new, latest news, event descriptions. Use this for ANY query about events, banners, or announcements — including standalone queries like \"events\", \"show me events\", \"list events\", \"what events are there\".",
          keywords: ['banner', 'banners', 'announcement', 'new', 'announcements', 'news', 'promotion', 'events in BGSW', 'events in Bosch', 'promotions', "what's new", 'latest news', 'updates', 'event', 'events', 'upcoming', 'company events', 'bosch events', 'BGSW', 'bgsw', 'bgsw events', 'upcoming events', 'event description', 'events in bgsw', 'events in bosch', 'current events', 'current promotions', 'bosch banner', 'bgsw banner', 'company banner', 'announcements in bosch', 'announcements in bgsw']
        }
      },
      privacyConfig: {
        nonNames: [
          'the', 'what', 'when', 'where', 'who', 'which', 'how', 'show', 'get', 'tell', 'give', 'find', 'fetch', 'list',
          'today', 'yesterday', 'tomorrow', 'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'thank',
          'hello', 'hi', 'hey', 'time', 'times', 'entry', 'exit', 'late', 'early', 'morning', 'evening', 'night',
          'afternoon', 'seat', 'travel', 'it', 'that', 'this', 'there', 'here', 'let', 'can', 'could', 'would', 'should',
          'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look', 'all', 'any', 'some', 'these', 'those', 'last',
          'next', 'first', 'second', 'working', 'hours', 'attendance', 'schedule', 'booking', 'details', 'information',
          // Action verbs that commonly start a sentence with a capital letter and must
          // never be mistaken for a person's name by CHECK 9 of detectColleagueQuery.
          // e.g. "Raise a travel", "Book a seat", "Create a travel request", "Cancel my booking"
          'raise', 'book', 'create', 'make', 'start', 'initiate', 'submit', 'cancel', 'update',
          'modify', 'change', 'delete', 'remove', 'add', 'open', 'close', 'send', 'request',
          'confirm', 'approve', 'reject', 'process', 'complete', 'finish', 'begin', 'end',
          'schedule', 'plan', 'arrange', 'set', 'reset', 'help', 'assist', 'apply', 'register',
          'join', 'leave', 'move', 'transfer', 'extend', 'renew', 'review', 'edit', 'save',
          'info', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
          'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
          'flight', 'flight', 'train', 'bus', 'cab', 'taxi', 'car', 'rental', 'stay', 'hotel', 'visa', 'trip', 'trips',
          'pune', 'hyderabad', 'mumbai', 'delhi', 'chennai', 'bangalore', 'coimbatore', 'india', 'bosch',
          'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'noida',
          'mysore', 'mangalore', 'hubli', 'belgaum', 'dharwad', 'shimoga', 'udupi', 'kolar', 'tumkur',
          'air', 'required', 'needed', 'accommodation', 'provision', 'arrangement', 'provide', 'provide',
          'provide', 'retrieve', 'display', 'generate', 'calculate', 'access', 'return', 'summarize', 'include',
          'share', 'pull', 'extract', 'compile', 'compute', 'present', 'load', 'read', 'query', 'search',
          'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
          'monthly', 'daily', 'weekly', 'annual', 'yearly', 'summary', 'period', 'range', 'between', 'during',
          'employee', 'user', 'member', 'staff', 'person', 'individual',
          'attendance', 'absences', 'presence', 'duration', 'login', 'logout', 'break',
          'second', 'third', 'fourth', 'fifth', 'quarter', 'half',
          'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'stay', 'hotel', 'visa', 'trip', 'trips',
          'start', 'end', 'date', 'dates', 'being', 'mode', 'with', 'from', 'to', 'into', 'for',
          'accommodation', 'air', 'required', 'needed', 'wants', 'needs', 
          'requires', 'regarding', 'about', 'taxi', 'car', 'rental', 'rooms', 
          'guest', 'guests', 'passenger', 'passengers', 'arrival', 'departure', 'arrive', 'depart',
          'and', 'but', 'nor', 'yet', 'yes', 'sure', 'confirm', 'confirmation', 'confirmed', 'proceed', 'proceeding', 'proceeded', 'approve', 'approved', 'approving', 'verify', 'verified', 'verification', 'cancel', 'canceled', 'cancelled', 'cancelling',
          'new', 'old', 'location', 'locations', 'city', 'cities', 'country', 'countries', 'bengaluru', 'mysuru',
          'book', 'booked', 'booking', 'planning', 'planned', 'trip', 'trips', 'traveling', 'travelling',
          'office', 'building', 'floor', 'desk', 'station', 'meeting', 'room', 'project', 'team', 'department', 'unit',
          'canteen', 'cafeteria', 'parking', 'gym', 'details', 'information', 'info', 'status', 'request', 'requests',
          'order', 'orders', 'summary', 'plan', 'plans', 'schedule', 'schedules', 'history', 'view', 'search', 'find'
        ]
      },
      routingConfig: {
        greetingKeywords: ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings', 'what up'],
        followUpPatterns: {
          whatAbout: "^(what|how) about",
          andWhat: "^and\\s+(what|how|the|for)",
          timeRef: "^(yesterday|tomorrow|today|last|next|this)\\b",
          periodRef: "^(week|month|year)\\b",
          sameRef: "^(same|similar)\\b",
          moreRef: "^(more|less|other)\\b",
          shortQuestion: "^(when|where|why|who|how much|how many)\\?*$",
          thatRef: "^that\\s",
          itRef: "^it\\s",
          theSameRef: "^the\\s+(same|other|previous|next)",
          showMeRef: "^show\\s+(me\\s+)?(more|that|this)",
          okAndRef: "^ok\\s+(and|but|what)",
          confirmAndRef: "^(yes|yeah|sure|ok)[\\s,]+(and|but|what)",
          dateShort1: "^\\d{1,2}(st|nd|rd|th)?\\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)",
          dateShort2: "^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\s*\\d{1,2}",
          dateNumeric: "^\\d{1,2}[\\/\\-]\\d{1,2}",
          onDate: "^on\\s+\\d{1,2}",
          forDate: "^for\\s+(yesterday|tomorrow|today|\\d)",
          travelSpec: "\\b(one way|return|round trip|one-way)\\b",
          correction: "^(i am sorry|sorry|my bad|apologies|oops|i meant|i mean|actually|no wait|wait|correction|i said|i meant to say|i was wrong|i made a mistake)\\b"
        },
        subjectKeywords: [
          // Canteen
          'menu', 'food', 'lunch', 'dinner', 'breakfast', 'canteen', 'cafeteria',
          // Entry/Exit
          'entry', 'exit', 'attendance', 'swipe', 'punch', 'check-in', 'check-out', 'working hours',
          // Travel
          'travel', 'ticket', 'flight', 'train', 'trip', 'itinerary', 'bus', 'visa', 'hotel',
          // Seat booking
          'seat', 'desk', 'booking', 'workspace', 'workstation',
          // Community
          'community', 'communities', 'membership', 'memberships', 'club', 'enroll', 'register',
          // Banner
          'banner', 'announcement', 'event', 'promotion',
          // Identity
          'who am i', 'my name', 'what is my name', 'employee name', 'identify me'
        ],
        topicKeywords: {
          canteen: ['menu', 'food', 'breakfast', 'lunch', 'dinner', 'snacks'],
          entryexit: ['entry time', 'exit time', 'attendance', 'working hours', 'swipe'],
          travel: ['travel plan', 'trip', 'booking', 'settlement'],
          seatbooking: ['desk', 'seat', 'workspace', 'booking'],
          community: ['community', 'group', 'club'],
          banner: ['banner', 'announcement', 'news']
        }
      },
      // ── Centralised keyword configuration ──
      // Previously hardcoded across server.js, travel-service.js, seatbooking-service.js.
      // Editable via Admin UI → Keywords tab.
      keywordConfig: {
        privacyDetection: {
          personalDataKeywords: [
            'entry', 'exit', 'attendance', 'check.?in', 'check.?out', 'swipe',
            'leave', 'payslip', 'salary', 'pay', 'compensation',
            'working hours', 'work hours', 'hours worked', 'time tracking',
            'late', 'absent', 'shift', 'overtime',
            'schedule', 'booking', 'seat', 'travel',
            'effort', 'performance', 'appraisal',
            'data', 'details', 'info', 'information', 'record', 'records'
          ],
          colleaguePatternWords: [
            'friend', 'colleague', 'coworker', 'co-worker', 'team mate', 'teammate',
            'boss', 'manager', 'reportee', 'subordinate', 'buddy', 'peer',
            'other employee', 'another employee', 'someone else',
            'other person', 'another person', 'other people'
          ],
          bulkPatternPhrases: [
            'all employee', 'everyone', 'everybody',
            'team attendance', 'team entry', 'team exit', 'department attendance',
            'who all came', 'who came', 'who left', 'who is absent',
            'list of employees', 'employee list',
            'how many employees', 'how many people',
            'all staff', 'entire team', 'full team', 'whole team', 'all members',
            'group attendance', 'others attendance', 'others entry', 'others exit'
          ],
          impersonationSkipWords: [
            'looking', 'asking', 'checking', 'wondering', 'interested',
            'trying', 'requesting', 'here', 'logged', 'the', 'a', 'an',
            'not', 'also', 'just'
          ],
          aiRewriteVerbs: [
            'provide', 'retrieve', 'display', 'generate', 'show', 'give', 'tell',
            'fetch', 'list', 'find', 'get', 'share', 'compile', 'present',
            'summarize', 'include', 'access', 'return', 'load',
            'detailed', 'complete', 'full', 'specific', 'exact', 'accurate',
            'recent', 'comprehensive', 'monthly', 'daily', 'weekly', 'annual',
            'summary', 'period', 'range', 'between', 'during',
            'employee', 'user', 'member', 'staff', 'person', 'individual',
            'duration', 'more', 'additional'
          ]
        },
        travelService: {
          travelDataKeywords: [
            'travel', 'trip', 'flight', 'booking', 'expense',
            'settlement', 'reimbursement', 'itinerary', 'ticket'
          ],
          travelEntities: [
            'indigo', 'vistara', 'spicejet', 'airindia', 'emirates', 'lufthansa', 'etihad',
            'qatar', 'turkish', 'qantas', 'delta', 'united', 'american', 'southwest', 'jetblue',
            'ryanair', 'easyjet', 'cathay', 'thai', 'japan', 'korean', 'british', 'singapore',
            'airasia', 'goair', 'akasa', 'alliance', 'oneworld', 'skyteam', 'staralliance',
            'marriott', 'hilton', 'hyatt', 'sheraton', 'westin', 'radisson', 'novotel', 'ibis',
            'oberoi', 'leela', 'taj', 'itc', 'crowne', 'ramada', 'accor', 'intercontinental',
            'houston', 'chicago', 'boston', 'seattle', 'portland', 'denver', 'dallas', 'austin',
            'atlanta', 'miami', 'orlando', 'phoenix', 'detroit', 'minneapolis', 'philadelphia',
            'london', 'paris', 'berlin', 'munich', 'frankfurt', 'amsterdam', 'rome', 'milan',
            'madrid', 'barcelona', 'vienna', 'zurich', 'geneva', 'brussels', 'prague', 'warsaw',
            'dublin', 'lisbon', 'stockholm', 'helsinki', 'oslo', 'copenhagen', 'athens', 'istanbul',
            'tokyo', 'osaka', 'seoul', 'beijing', 'shanghai', 'guangzhou', 'shenzhen', 'taipei',
            'singapore', 'bangkok', 'jakarta', 'manila', 'hanoi', 'kuala', 'lumpur', 'colombo',
            'dubai', 'doha', 'riyadh', 'muscat', 'bahrain', 'kuwait', 'jeddah', 'abu', 'dhabi',
            'sydney', 'melbourne', 'auckland', 'perth', 'brisbane', 'adelaide',
            'cairo', 'nairobi', 'capetown', 'johannesburg', 'lagos', 'casablanca', 'addis',
            'toronto', 'vancouver', 'montreal', 'ottawa', 'calgary',
            'mexico', 'bogota', 'lima', 'santiago', 'buenos', 'aires', 'sao', 'paulo',
            'airport', 'terminal', 'station', 'junction', 'central', 'metro',
            'north', 'south', 'east', 'west', 'new', 'old', 'international', 'domestic',
            'cleartrip', 'makemytrip', 'goibibo', 'yatra', 'expedia', 'kayak'
          ]
        },
        seatBookingService: {
          seatKeywords: [
            'seat', 'desk', 'booking', 'reserve', 'floor',
            'zone', 'location', 'workstation'
          ]
        },
        communityService: {
          communityDetectionKeywords: ['community', 'communities', 'associate arena'],
          communityNames: [
            'mind buddies', 'art in motion', 'cyco', 'pixture perfect',
            'pathfinders', 'cricket', 'women in tech', 'bioblitz', 'garden club'
          ],
          joinIntentKeywords: ['join', 'register', 'enroll', 'enrol', 'subscribe', 'add me', 'sign me up'],
          listIntentPhrases: [
            'show all', 'list all', 'all communities', 'all active',
            'community list', 'active communities', 'what communities',
            'which communities', 'what are the communities',
            'show me communities', 'show communities', 'list communities'
          ]
        },
        entryExitService: {
          entryExitDataKeywords: [
            'entry', 'exit', 'swipe', 'swiped', 'swiping', 'attendance',
            'hours', 'check', 'checked', 'clock', 'clocked', 'time',
            'late', 'overtime', 'shift', 'punch', 'punched',
            'working hours', 'early', 'status',
            'data', 'details', 'info', 'information', 'record', 'records',
            // Natural-language attendance verbs — cover queries like
            // "how many days did Ganesh come", "did Priya arrive today"
            'come', 'came', 'coming',
            'attend', 'attended', 'attending',
            'arrive', 'arrived', 'arriving',
            'present', 'absent', 'presence', 'absence'
          ]
        }
      },
      // ── Few-shot examples for LLM intent classifiers ──
      // Each entry is { query, intent }. Editable via Admin UI → Few-Shot tab.
      fewShotConfig: {
        travel: [
          { query: 'show my travel plans',                                    intent: 'retrieve' },
          { query: 'list my bookings',                                        intent: 'retrieve' },
          { query: 'what are my upcoming trips?',                             intent: 'retrieve' },
          { query: 'my bookings',                                             intent: 'retrieve' },
          { query: 'view my itinerary',                                       intent: 'retrieve' },
          { query: 'do I have any travel plans this week?',                   intent: 'retrieve' },
          { query: 'show my trips',                                           intent: 'retrieve' },
          { query: 'book a travel',                                           intent: 'book'     },
          { query: 'book a ticket',                                           intent: 'book'     },
          { query: 'I want to book a flight',                                 intent: 'book'     },
          { query: 'book a flight to Delhi',                                  intent: 'book'     },
          { query: 'buy a ticket to Hyderabad',                               intent: 'book'     },
          { query: 'I want to travel from Bangalore to Mumbai on 10th May',   intent: 'book'     },
          { query: 'flight from Delhi to Chennai on 15th April',              intent: 'book'     },
          { query: 'plan a trip',                                             intent: 'book'     },
          { query: 'start a new booking',                                     intent: 'book'     },
          { query: 'yes, confirm my booking',                                 intent: 'book'     },
          { query: 'business class please',                                   intent: 'book'     },
          { query: 'return on 20th May',                                      intent: 'book'     },
          { query: 'start over',                                              intent: 'book'     },
          { query: 'new booking',                                             intent: 'book'     },
          { query: 'train please',                                            intent: 'book'     },
          { query: 'I want to go from Hyderabad to Pune next Friday',         intent: 'book'     },
          // "raise / create / submit a travel" — action-verb synonyms for booking
          { query: 'Raise a travel',                                          intent: 'book'     },
          { query: 'raise a travel request',                                  intent: 'book'     },
          { query: 'create a travel',                                         intent: 'book'     },
          { query: 'I want to raise a travel',                                intent: 'book'     },
          { query: 'submit a travel request',                                 intent: 'book'     }
        ],
        seatbooking: [
          { query: 'book a desk for tomorrow',                                intent: 'book'     },
          { query: 'reserve a seat on 5th floor for Monday',                  intent: 'book'     },
          { query: 'I want to book a workstation for next week',              intent: 'book'     },
          { query: 'book seat for today',                                     intent: 'book'     },
          { query: 'need a desk for Friday',                                  intent: 'book'     },
          { query: 'cancel my booking for tomorrow',                          intent: 'cancel'   },
          { query: "I want to cancel today's desk reservation",               intent: 'cancel'   },
          { query: 'remove my seat booking for Monday',                       intent: 'cancel'   },
          { query: 'show my seat bookings',                                   intent: 'list'     },
          { query: 'what desk did I book for today?',                         intent: 'list'     },
          { query: 'my bookings this week',                                   intent: 'list'     },
          { query: 'do I have a seat booked for tomorrow?',                   intent: 'list'     },
          { query: 'check my reservation for Friday',                         intent: 'list'     },
          { query: 'how does seat booking work?',                             intent: 'general'  },
          { query: 'what floors are available for booking?',                  intent: 'general'  }
        ],
        community: [
          { query: 'join Art in Motion in Bangalore',                         intent: 'join'     },
          { query: 'register me to Mind Buddies in Hyderabad',                intent: 'join'     },
          { query: 'can I join mindbuddies community',                        intent: 'join'     },
          { query: 'I want to enroll in the wellness community',              intent: 'join'     },
          { query: 'sign me up for Art in Motion',                            intent: 'join'     },
          { query: 'add me to Mind Buddies',                                  intent: 'join'     },
          { query: 'show me all communities',                                 intent: 'list'     },
          { query: 'what communities are available?',                         intent: 'list'     },
          { query: 'can I get the list of communities',                       intent: 'list'     },
          { query: 'which communities can I join?',                           intent: 'list'     },
          { query: 'list all active communities',                             intent: 'list'     },
          { query: 'what are the communities here?',                          intent: 'list'     },
          { query: 'tell me about Art in Motion Community',                   intent: 'info'     },
          { query: 'what is Mind Buddies about?',                             intent: 'info'     },
          { query: 'details of the wellness community',                       intent: 'info'     },
          { query: 'describe Mind Buddies',                                   intent: 'info'     },
          { query: 'is hockey community available',                           intent: 'info'     },
          { query: 'is there a football community',                           intent: 'info'     },
          { query: 'do you have a swimming community',                        intent: 'info'     },
          { query: 'does a yoga community exist at Bosch',                    intent: 'info'     },
          { query: 'is cooking community available at BGSW',                  intent: 'info'     },
          { query: 'is cricket community present',                            intent: 'info'     },
          { query: 'which all community I am part of',                       intent: 'membership' },
          { query: 'which communities am I part of',                         intent: 'membership' },
          { query: 'communities I belong to',                                intent: 'membership' },
          { query: 'what communities am I a member of',                      intent: 'membership' },
          { query: 'show communities I am enrolled in',                      intent: 'membership' },
          { query: 'my communities',                                         intent: 'membership' },
          { query: 'my community',                                           intent: 'membership' },
          { query: 'show my community',                                      intent: 'membership' },
          { query: 'which communities have I joined',                        intent: 'membership' },
          { query: 'list communities I am registered to',                    intent: 'membership' },
          { query: 'show my registered communities',                         intent: 'membership' },
          { query: 'communities I have signed up for',                       intent: 'membership' },
          { query: 'my memberships',                                         intent: 'membership' },
          { query: 'show my memberships',                                    intent: 'membership' },
          { query: 'is hockey community available',                          intent: 'info'     },
          { query: 'is there a football community',                          intent: 'info'     },
          { query: 'do you have a swimming community',                       intent: 'info'     },
          { query: 'does a yoga community exist at Bosch',                   intent: 'info'     },
          { query: 'is cooking community available at BGSW',                 intent: 'info'     },
          { query: 'is cricket community present',                           intent: 'info'     },
          { query: 'how do communities work?',                               intent: 'general'  },
          { query: 'what is the purpose of communities?',                    intent: 'general'  }
        ],
        entryexit: [
          { query: 'what is my entry time today?',                            intent: 'current'  },
          { query: 'when did I check in today?',                              intent: 'current'  },
          { query: 'what time did I swipe in this morning?',                  intent: 'current'  },
          { query: 'am I in the office today?',                               intent: 'current'  },
          { query: 'show my current attendance status',                       intent: 'current'  },
          { query: 'what is my exit time today?',                             intent: 'current'  },
          { query: 'when did I check out?',                                   intent: 'current'  },
          { query: 'how many hours have I worked today?',                     intent: 'current'  },
          { query: 'am I late today?',                                        intent: 'current'  },
          { query: 'show my attendance for this week',                        intent: 'history'  },
          { query: 'give me day-wise entry exit details for April',           intent: 'history'  },
          { query: 'my attendance from Monday to Friday',                     intent: 'history'  },
          { query: 'show entry exit records for last month',                  intent: 'history'  },
          { query: 'what were my working hours last week?',                   intent: 'history'  },
          { query: 'attendance history for this month',                       intent: 'history'  },
          { query: 'day-wise details for March',                              intent: 'history'  },
          { query: 'show my swipe records from 1st April to 10th April',      intent: 'history'  },
          { query: 'my overtime details for this month',                      intent: 'history'  },
          { query: 'entry and exit for last 7 days',                          intent: 'history'  },
          { query: 'what is my name?',                                        intent: 'identity' },
          { query: 'who am I?',                                               intent: 'identity' },
          { query: 'what is my employee name?',                               intent: 'identity' },
          { query: 'tell me my name',                                         intent: 'identity' },
          { query: 'identify me',                                             intent: 'identity' },
          { query: 'what is my employee number?',                             intent: 'identity' },
          { query: 'how does attendance tracking work?',                      intent: 'general'  },
          { query: 'what is the office timing?',                              intent: 'general'  }
        ],
        // ── Privacy few-shot: classify whether a query is about the logged-in
        //    user ("self") or about another person ("other").
        //    Used by classifyPrivacy() as the primary check before the regex fallback.
        entryexitPrivacy: [
          // ── self: the logged-in user is asking about their own data ──────
          { query: 'what time did I come today',                              intent: 'self' },
          { query: 'show my attendance for last week',                        intent: 'self' },
          { query: 'my entry time this morning',                              intent: 'self' },
          { query: 'when did I check in yesterday',                           intent: 'self' },
          { query: 'is my attendance good this month',                        intent: 'self' },
          { query: 'how many hours did I work today',                         intent: 'self' },
          { query: 'my check-in status',                                      intent: 'self' },
          { query: 'show me my entry exit for this week',                     intent: 'self' },
          { query: 'am I late today',                                         intent: 'self' },
          { query: 'what is my attendance for April',                         intent: 'self' },
          { query: 'did I come to office yesterday',                          intent: 'self' },
          { query: 'give me my day-wise attendance for March',                intent: 'self' },
          // ── other: asking about a colleague / another employee ───────────
          { query: 'how many days did Ganesh Mahadevan come',                 intent: 'other' },
          { query: "Priya's entry time today",                                intent: 'other' },
          { query: 'when did Rahul arrive',                                   intent: 'other' },
          { query: 'show entry time for Suresh',                              intent: 'other' },
          { query: 'is Kavya present today',                                  intent: 'other' },
          { query: 'did Anand attend office yesterday',                       intent: 'other' },
          { query: 'show attendance of Kumar',                                intent: 'other' },
          { query: 'how many hours did Ravi work this week',                  intent: 'other' },
          { query: 'entry details of my colleague',                           intent: 'other' },
          { query: 'attendance report for Deepak',                            intent: 'other' },
          { query: 'when was Nisha last in office',                           intent: 'other' },
          { query: 'tell me the entry time of Arjun',                        intent: 'other' },
          { query: 'show me the check-in details of the whole team',         intent: 'other' }
        ],

        // ── General privacy guard — used by classifyGeneralPrivacy() in server.js ──
        // Covers ALL services (travel, seat, canteen, community, entry/exit).
        // intent: 'self'  → query is about the logged-in user's own data → ALLOW
        // intent: 'other' → query is about another person's data         → BLOCK
        // The system prompt injects the logged-in user's name so the LLM can
        // correctly distinguish "book a travel for me" from "book a travel for Rahul".
        generalPrivacy: [
          // ── self / action: user acting on their own behalf ───────────────
          { query: 'raise a travel request',                                  intent: 'self' },
          { query: 'book a seat for me tomorrow',                             intent: 'self' },
          { query: 'I want to book a flight to Delhi',                        intent: 'self' },
          { query: 'create a travel request from Bangalore to Mumbai',        intent: 'self' },
          { query: 'show my travel history',                                  intent: 'self' },
          { query: 'what is my seat booking for today',                       intent: 'self' },
          { query: 'cancel my travel booking',                                intent: 'self' },
          { query: 'my entry time today',                                     intent: 'self' },
          { query: 'show my attendance for this week',                        intent: 'self' },
          { query: 'book a desk for me on Friday',                            intent: 'self' },
          { query: 'show seat availability across all floors',                intent: 'self' },
          { query: 'which floors have available desks',                       intent: 'self' },
          { query: 'show available seats on floor 5',                         intent: 'self' },
          { query: 'seat availability across all the floors',                 intent: 'self' },
          { query: 'I need to travel to Chennai next week',                   intent: 'self' },
          { query: 'submit a travel request for official trip',               intent: 'self' },
          { query: 'what communities can I join',                             intent: 'self' },
          { query: 'register me to the photography community',                intent: 'self' },
          { query: 'show today\'s canteen menu',                              intent: 'self' },
          { query: 'what\'s for lunch today',                                 intent: 'self' },
          { query: 'help me book a travel',                                   intent: 'self' },
          { query: 'initiate a travel for next Monday',                       intent: 'self' },
          { query: 'when did I arrive today',                                 intent: 'self' },
          { query: 'am I present today',                                      intent: 'self' },
          // ── other: asking about or acting on behalf of another person ────
          { query: 'book a travel for Rahul',                                 intent: 'other' },
          { query: 'what is Priya\'s seat booking today',                     intent: 'other' },
          { query: 'show me Anand\'s attendance',                             intent: 'other' },
          { query: 'when did Suresh check in',                                intent: 'other' },
          { query: 'can you raise a travel for my colleague',                 intent: 'other' },
          { query: 'book a seat for Kavya tomorrow',                          intent: 'other' },
          { query: 'show travel history for Deepak',                          intent: 'other' },
          { query: 'is Nisha present today',                                  intent: 'other' },
          { query: 'entry details of Ravi',                                   intent: 'other' },
          { query: 'how many days did Kumar come this month',                 intent: 'other' },
          { query: 'check attendance of my friend',                           intent: 'other' },
          { query: 'register my manager to the art community',               intent: 'other' }
        ]
      },
      // ── Booking validation rules ──
      // allowPreviousDateBooking: false → reject requests whose travel/desk date
      // is strictly before today (IST). Set to true to permit past-date bookings
      // (useful for admin testing or retroactive expense requests).
      bookingConfig: {
        travel: {
          allowPreviousDateBooking: false
        },
        seatbooking: {
          allowPreviousDateBooking: false
        }
      }
    };
  }

  /**
   * Save configuration to disk
   */
  async saveConfig() {
    try {
      await fs.writeJson(this.configPath, this.config, { spaces: 2 });
    } catch (error) {
      console.error('[ConfigService] Save failed:', error);
      throw error;
    }
  }

  /**
   * Get all core services
   */
  async getCoreServices() {
    if (!this.initialized) await this.initialize();
    return this.config.coreServices;
  }

  /**
   * Get privacy whitelist (nonNames)
   */
  async getPrivacyWhitelist() {
    if (!this.initialized) await this.initialize();
    return this.config.privacyConfig.nonNames;
  }

  /**
   * Update core service configuration
   */
  async updateCoreService(serviceId, serviceConfig) {
    if (!this.initialized) await this.initialize();
    this.config.coreServices[serviceId] = { ...this.config.coreServices[serviceId], ...serviceConfig };
    await this.saveConfig();
    return this.config.coreServices[serviceId];
  }

  /**
   * Update privacy whitelist
   */
  async updatePrivacyWhitelist(nonNames) {
    if (!this.initialized) await this.initialize();
    if (Array.isArray(nonNames)) {
      this.config.privacyConfig.nonNames = nonNames;
      await this.saveConfig();
    }
    return this.config.privacyConfig.nonNames;
  }

  /**
   * Update routing configuration
   */
  async updateRoutingConfig(routingConfig) {
    if (!this.initialized) await this.initialize();
    this.config.routingConfig = { ...this.config.routingConfig, ...routingConfig };
    await this.saveConfig();
    return this.config.routingConfig;
  }

  /**
   * Get all core services (Sync)
   */
  getCoreServicesSync() {
    return this.config ? this.config.coreServices : this.getDefaultConfig().coreServices;
  }

  /**
   * Get privacy whitelist (nonNames) (Sync)
   */
  getPrivacyWhitelistSync() {
    return this.config ? this.config.privacyConfig.nonNames : this.getDefaultConfig().privacyConfig.nonNames;
  }

  /**
   * Get routing configuration (Sync)
   */
  getRoutingConfigSync() {
    return this.config ? this.config.routingConfig : this.getDefaultConfig().routingConfig;
  }

  // ── Keyword Config (centralised keyword management) ──

  /**
   * Get keyword configuration (Sync)
   * Falls back to defaults if keywordConfig missing (backward compat)
   */
  getKeywordConfigSync() {
    if (this.config && this.config.keywordConfig) return this.config.keywordConfig;
    return this.getDefaultConfig().keywordConfig;
  }

  /**
   * Get keyword configuration (Async)
   */
  async getKeywordConfig() {
    if (!this.initialized) await this.initialize();
    return this.getKeywordConfigSync();
  }

  /**
   * Update a specific section of keywordConfig.
   * @param {string} section - One of: 'privacyDetection', 'travelService', 'seatBookingService', 'communityService', 'entryExitService'
   * @param {object} data    - The updated section object (replaces the section entirely)
   */
  async updateKeywordConfig(section, data) {
    if (!this.initialized) await this.initialize();
    if (!this.config.keywordConfig) {
      this.config.keywordConfig = this.getDefaultConfig().keywordConfig;
    }
    if (!this.config.keywordConfig[section]) {
      throw new Error(`Unknown keywordConfig section: ${section}`);
    }
    this.config.keywordConfig[section] = { ...this.config.keywordConfig[section], ...data };
    await this.saveConfig();
    return this.config.keywordConfig[section];
  }

  /**
   * Get few-shot config (Sync)
   * Falls back to defaults if fewShotConfig missing (backward compat)
   */
  getFewShotConfigSync() {
    if (this.config && this.config.fewShotConfig) return this.config.fewShotConfig;
    return this.getDefaultConfig().fewShotConfig;
  }

  /**
   * Update few-shot examples for a specific service.
   * @param {string} service - One of: 'travel', 'seatbooking', 'community'
   * @param {Array<{query:string, intent:string}>} examples
   */
  async updateFewShotConfig(service, examples) {
    if (!this.initialized) await this.initialize();
    const allowed = ['travel', 'seatbooking', 'community', 'entryexit', 'entryexitPrivacy', 'generalPrivacy'];
    if (!allowed.includes(service)) {
      throw new Error(`Unknown fewShotConfig service: ${service}`);
    }
    if (!this.config.fewShotConfig) {
      this.config.fewShotConfig = this.getDefaultConfig().fewShotConfig;
    }
    this.config.fewShotConfig[service] = examples;
    await this.saveConfig();
    return this.config.fewShotConfig[service];
  }

  /**
   * Get booking validation config (Sync).
   * Falls back to defaults if bookingConfig is missing (backward compat with older config files).
   */
  getBookingConfigSync() {
    if (this.config && this.config.bookingConfig) return this.config.bookingConfig;
    return this.getDefaultConfig().bookingConfig;
  }

  /**
   * Update booking validation config for a specific service.
   * @param {string} service - One of: 'travel', 'seatbooking'
   * @param {{ allowPreviousDateBooking: boolean }} data
   */
  async updateBookingConfig(service, data) {
    if (!this.initialized) await this.initialize();
    const allowed = ['travel', 'seatbooking'];
    if (!allowed.includes(service)) {
      throw new Error(`Unknown bookingConfig service: ${service}`);
    }
    if (!this.config.bookingConfig) {
      this.config.bookingConfig = this.getDefaultConfig().bookingConfig;
    }
    this.config.bookingConfig[service] = {
      ...this.config.bookingConfig[service],
      ...data
    };
    await this.saveConfig();
    return this.config.bookingConfig[service];
  }

  /**
   * Get complete config (for Admin UI)
   */
  async getFullConfig() {
    if (!this.initialized) await this.initialize();
    // Ensure optional sections are present even for older config files
    if (!this.config.keywordConfig) {
      this.config.keywordConfig = this.getDefaultConfig().keywordConfig;
    }
    if (!this.config.fewShotConfig) {
      this.config.fewShotConfig = this.getDefaultConfig().fewShotConfig;
    }
    if (!this.config.bookingConfig) {
      this.config.bookingConfig = this.getDefaultConfig().bookingConfig;
    }
    return this.config;
  }
}

module.exports = new ConfigService();
