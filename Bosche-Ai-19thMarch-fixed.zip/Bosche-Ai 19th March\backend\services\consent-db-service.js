/**
 * Consent Database Service
 * Handles reading and writing user consent records to MS SQL Azure DB
 * Table: dbo.user_consents
 *
 * Schema:
 *   id           INT IDENTITY(1,1) PRIMARY KEY
 *   user_id      NVARCHAR(255) NULL        -- employee number / username
 *   user_name    NVARCHAR(255) NULL        -- display name
 *   nt_id        NVARCHAR(255) NOT NULL    -- NT ID (primary lookup key)
 *   has_consented BIT NOT NULL DEFAULT 1
 *   created_at   DATETIME2 DEFAULT SYSDATETIME()
 *   updated_at   DATETIME2 DEFAULT SYSDATETIME()
 *
 * Supports both SSO and credential-based login users.
 * nt_id is used as the stable identifier; user_id/user_name are stored for auditing.
 */

const sql = require('mssql');

class ConsentDbService {
    constructor() {
        this.pool = null;
        this.connectionString = process.env.MSSQL_CONNECTION_STRING || '';
        this.isConnected = false;
    }

    /**
     * Parse the ADO.NET-style connection string into mssql config
     * (same pattern as conversation-db-service)
     */
    _parseConnectionString(connStr) {
        const parts = {};
        connStr.split(';').forEach(part => {
            const [key, ...valueParts] = part.split('=');
            if (key && valueParts.length > 0) {
                parts[key.trim().toLowerCase()] = valueParts.join('=').trim();
            }
        });

        let server = parts['server'] || parts['data source'] || '';
        let port = 1433;

        server = server.replace(/^tcp:/i, '');

        if (server.includes(',')) {
            const [host, p] = server.split(',');
            server = host;
            port = parseInt(p, 10);
        }

        return {
            server,
            port,
            database: parts['initial catalog'] || parts['database'] || '',
            user: parts['user id'] || parts['uid'] || '',
            password: parts['password'] || parts['pwd'] || '',
            options: {
                encrypt: (parts['encrypt'] || 'true').toLowerCase() === 'true',
                // Connection string takes priority; MSSQL_TRUST_SERVER_CERT=true is the
                // dev escape hatch for local SQL Server instances with self-signed certs.
                trustServerCertificate:
                    (parts['trustservercertificate'] || 'false').toLowerCase() === 'true' ||
                    process.env.MSSQL_TRUST_SERVER_CERT === 'true',
                connectTimeout: parseInt(parts['connection timeout'] || '30', 10) * 1000,
                requestTimeout: 30000,
            },
            pool: {
                max: 10,
                min: 0,
                idleTimeoutMillis: 30000
            }
        };
    }

    /**
     * Connect to the database (lazy, cached)
     */
    async connect() {
        if (this.isConnected && this.pool) {
            return this.pool;
        }

        if (!this.connectionString) {
            console.warn('[ConsentDB] No MSSQL_CONNECTION_STRING configured. Consent DB disabled.');
            return null;
        }

        try {
            const config = this._parseConnectionString(this.connectionString);
            console.log(`[ConsentDB] Connecting to ${config.server}:${config.port}/${config.database}...`);

            this.pool = await sql.connect(config);
            this.isConnected = true;
            console.log('[ConsentDB] Connected successfully to MS SQL Azure DB');

            this.pool.on('error', (err) => {
                console.error('[ConsentDB] Pool error:', err.message);
                this.isConnected = false;
                this.pool = null;
            });

            return this.pool;
        } catch (error) {
            console.error('[ConsentDB] Connection failed:', error.message);
            this.isConnected = false;
            this.pool = null;
            return null;
        }
    }

    /**
     * Check whether a user has already given consent.
     * Looks up by nt_id (primary identifier for both SSO and credential users).
     *
     * @param {string} ntId - The user's NT ID
     * @returns {{ hasConsented: boolean, record: object|null }}
     */
    async checkConsent(ntId) {
        try {
            const pool = await this.connect();
            if (!pool) {
                // If DB is unavailable, fail open so users are not blocked
                console.warn('[ConsentDB] DB unavailable — treating consent as not given');
                return { hasConsented: false, record: null };
            }

            const result = await pool.request()
                .input('nt_id', sql.NVarChar(255), ntId)
                .query(`
                    SELECT id, user_id, user_name, nt_id, has_consented, created_at, updated_at
                    FROM [dbo].[user_consents]
                    WHERE nt_id = @nt_id
                `);

            if (result.recordset.length === 0) {
                console.log(`[ConsentDB] No consent record found for nt_id: ${ntId}`);
                return { hasConsented: false, record: null };
            }

            const record = result.recordset[0];
            const hasConsented = record.has_consented === true || record.has_consented === 1;
            console.log(`[ConsentDB] Consent check for nt_id=${ntId}: hasConsented=${hasConsented}`);
            return { hasConsented, record };

        } catch (error) {
            console.error('[ConsentDB] Error checking consent:', error.message);
            return { hasConsented: false, record: null };
        }
    }

    /**
     * Record consent for a user (INSERT or UPDATE via MERGE).
     * Safe to call multiple times — will update the existing record if present.
     *
     * @param {string} userId   - Employee number / username (nullable)
     * @param {string} userName - Display name (nullable)
     * @param {string} ntId     - NT ID (required — must be non-empty)
     * @returns {boolean} - true on success
     */
    async saveConsent(userId, userName, ntId) {
        try {
            if (!ntId || ntId.trim() === '') {
                console.error('[ConsentDB] saveConsent called without a valid nt_id');
                return false;
            }

            const pool = await this.connect();
            if (!pool) {
                console.warn('[ConsentDB] DB unavailable — cannot save consent');
                return false;
            }

            // MERGE: update if exists, insert if not
            await pool.request()
                .input('user_id',   sql.NVarChar(255), userId   || null)
                .input('user_name', sql.NVarChar(255), userName || null)
                .input('nt_id',     sql.NVarChar(255), ntId.trim())
                .query(`
                    MERGE INTO [dbo].[user_consents] AS target
                    USING (SELECT @nt_id AS nt_id) AS source
                        ON target.nt_id = source.nt_id
                    WHEN MATCHED THEN
                        UPDATE SET
                            has_consented = 1,
                            user_id       = @user_id,
                            user_name     = @user_name,
                            updated_at    = SYSDATETIME()
                    WHEN NOT MATCHED THEN
                        INSERT (user_id, user_name, nt_id, has_consented)
                        VALUES (@user_id, @user_name, @nt_id, 1);
                `);

            console.log(`[ConsentDB] Consent saved for nt_id=${ntId}, user_id=${userId}`);
            return true;

        } catch (error) {
            console.error('[ConsentDB] Error saving consent:', error.message);
            return false;
        }
    }

    /**
     * Test DB connectivity
     */
    async testConnection() {
        try {
            const pool = await this.connect();
            if (!pool) return { success: false, error: 'No connection string configured' };
            await pool.request().query('SELECT 1 AS test');
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

module.exports = new ConsentDbService();
