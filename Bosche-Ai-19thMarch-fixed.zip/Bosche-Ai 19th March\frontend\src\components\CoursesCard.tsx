import { BookOpen, TrendingUp } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const CoursesCard = () => {
  return (
    <DashboardCard title="Active Courses" icon={BookOpen}>
      <div className="space-y-3">
        <div className="p-3 bg-primary/10 rounded-lg">
          <h4 className="text-sm font-semibold text-foreground mb-2">Advanced ML with TensorFlow</h4>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-medium text-foreground">45%</span>
          </div>
          <div className="w-full bg-background/40 rounded-full h-2">
            <div className="bg-gradient-accent h-2 rounded-full" style={{ width: '45%' }}></div>
          </div>
          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <TrendingUp className="w-3 h-3" />
            <span>3 modules remaining</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2 bg-secondary/40 rounded-lg text-center">
            <p className="text-lg font-bold text-foreground">42h</p>
            <p className="text-xs text-muted-foreground">This Quarter</p>
          </div>
          <div className="p-2 bg-secondary/40 rounded-lg text-center">
            <p className="text-lg font-bold text-success">8</p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </div>
        </div>
        <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 text-sm">
          Browse Catalog
        </button>
      </div>
    </DashboardCard>
  );
};
