import { Calendar, CheckCircle, Clock, X } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const LeaveCard = () => {
  return (
    <DashboardCard title="Leave Summary" icon={Calendar}>
      <div className="space-y-4">
        {/* Leave Balance */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-3 bg-primary/10 rounded-lg text-center">
            <p className="text-xs text-muted-foreground mb-1">Casual</p>
            <p className="text-xl font-bold text-foreground">8</p>
            <p className="text-xs text-muted-foreground">days left</p>
          </div>
          <div className="p-3 bg-primary/10 rounded-lg text-center">
            <p className="text-xs text-muted-foreground mb-1">Earned</p>
            <p className="text-xl font-bold text-foreground">15</p>
            <p className="text-xs text-muted-foreground">days left</p>
          </div>
          <div className="p-3 bg-primary/10 rounded-lg text-center">
            <p className="text-xs text-muted-foreground mb-1">Optional</p>
            <p className="text-xl font-bold text-foreground">2</p>
            <p className="text-xs text-muted-foreground">days left</p>
          </div>
        </div>

        {/* Pending Approvals */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-foreground">Pending Approvals:</p>

          <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="text-sm font-semibold text-foreground">Dec 20-22, 2025</p>
                <p className="text-xs text-muted-foreground">3 days • Casual Leave</p>
              </div>
              <span className="text-xs px-2 py-1 bg-warning/20 text-warning rounded-full flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Pending
              </span>
            </div>
            <p className="text-xs text-muted-foreground">Reason: Family function</p>
          </div>
        </div>

        {/* Recent History */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-foreground">Recent History:</p>

          <div className="p-2 bg-secondary/40 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-foreground">Nov 10-12, 2025</p>
              <p className="text-xs text-muted-foreground">3 days • Earned Leave</p>
            </div>
            <CheckCircle className="w-4 h-4 text-success" />
          </div>

          <div className="p-2 bg-secondary/40 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-foreground">Oct 2, 2025</p>
              <p className="text-xs text-muted-foreground">1 day • Optional Holiday</p>
            </div>
            <CheckCircle className="w-4 h-4 text-success" />
          </div>
        </div>

        {/* Apply Leave Button */}
        <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 text-sm">
          Apply for Leave
        </button>

        {/* AI Suggestion */}
        <div className="p-2 bg-gradient-accent/10 border border-accent/20 rounded-lg">
          <p className="text-xs text-muted-foreground">
            💡 <span className="font-semibold text-foreground">AI Tip:</span> Plan leaves around long weekends to maximize your time off!
          </p>
        </div>
      </div>
    </DashboardCard>
  );
};
