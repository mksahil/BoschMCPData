import { useState, useEffect } from "react";
import { Navigation } from "@/components/Navigation";
import { SolarSystem } from "@/components/SolarSystem";
import { AIChat } from "@/components/AIChat";
import { InsightsStrip } from "@/components/InsightsStrip";
import { ChatWindow } from "@/components/ChatWindow";
import { Footer } from "@/components/Footer";

import { InsightsSection } from "./sections/InsightsSection";
import { ActionsSection } from "./sections/ActionsSection";
import { MentorshipSection } from "./sections/MentorshipSection";
import { LearningSection } from "./sections/LearningSection";
import { WellnessSection } from "./sections/WellnessSection";

import { useAuth } from "@/context/AuthContext";
import logger from "@/lib/logger";

const Index = () => {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState("home");
  const [contextTitle, setContextTitle] = useState<string>();

  const [chatWindowOpen, setChatWindowOpen] = useState(false);

  // Log page load
  useEffect(() => {
    logger.logPageView('Dashboard Home', {
      initialSection: 'home',
      timestamp: new Date().toISOString()
    });
  }, []);

  // Log section changes
  useEffect(() => {
    if (activeSection !== 'home') {
      logger.logNavigation('home', activeSection, {
        contextTitle
      });
    }
  }, [activeSection]);

  const renderSection = () => {
    switch (activeSection) {
      case "insights":
        return <InsightsSection />;
      case "actions":
        return <ActionsSection />;
      case "mentorship":
        return <MentorshipSection />;
      case "learning":
        return <LearningSection />;
      case "wellness":
        return <WellnessSection />;
      default:
        return <HomeSection chatWindowOpen={chatWindowOpen} onPlanetSelect={() => setChatWindowOpen(false)} />;
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col">

      <Navigation
        activeSection={activeSection}
        onSectionChange={(section) => {
          setActiveSection(section);
          setContextTitle(undefined);
        }}
        contextTitle={contextTitle}
      />

      {/* <InsightsStrip /> */}

      <div className="relative z-10 bg-transparent flex-1 flex flex-col">
        {activeSection === "home" ? (
          /* Home: fill remaining height, center solar system vertically */
          <main className="flex-1 flex items-center w-full bg-transparent">
            {renderSection()}
          </main>
        ) : (
          /* Other sections: normal top-aligned scrollable layout */
          <main
            className="flex-1 w-full bg-transparent py-8 pb-20"
            style={{ paddingLeft: "clamp(1rem, 3vw, 2.5rem)", paddingRight: "clamp(1rem, 3vw, 2.5rem)" }}
          >
            <div className="container mx-auto">
              {renderSection()}
            </div>
          </main>
        )}
      </div>

      {/* AI Chat Widget - Hidden on home, visible elsewhere */}
      {activeSection !== "home" && <AIChat />}

      {/* Unified Chat - Always visible on home, expands when focused */}
      {activeSection === "home" && (
        <ChatWindow
          isOpen={chatWindowOpen}
          onClose={() => setChatWindowOpen(!chatWindowOpen)}
        />
      )}

      {/* Footer */}
      <Footer />
    </div>
  );
};

const HomeSection = ({ onPlanetSelect }: { chatWindowOpen: boolean; onPlanetSelect: () => void }) => {
  return (
    <div className="w-full animate-fade-in">
      <SolarSystem isShifted={false} onPlanetSelect={onPlanetSelect} />
    </div>
  );
};

export default Index;
