
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ArrowLeft, Plus, Trash2, Save, Server, ExternalLink, Sparkles, Loader2, ShieldCheck, Settings, Globe, Zap, Tag, Plane, Armchair, Users, Clock, Brain, CalendarX, Activity, RefreshCw, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { useNavigate } from 'react-router-dom';
import { API_ENDPOINTS, ADMIN_BASE_URL } from '@/config';
import { useAuth } from '@/context/AuthContext';

interface Service {
    id: string;
    name: string;
    baseUrl: string;
    description: string;
    keywords: string[];
}

interface CoreService {
    name: string;
    description: string;
    keywords: string[];
}

interface KeywordConfig {
    privacyDetection: {
        personalDataKeywords: string[];
        colleaguePatternWords: string[];
        bulkPatternPhrases: string[];
        impersonationSkipWords: string[];
        aiRewriteVerbs: string[];
    };
    travelService: {
        travelDataKeywords: string[];
        travelEntities: string[];
    };
    seatBookingService: {
        seatKeywords: string[];
    };
    communityService: {
        communityDetectionKeywords: string[];
        communityNames: string[];
        joinIntentKeywords: string[];
        listIntentPhrases: string[];
    };
    entryExitService: {
        entryExitDataKeywords: string[];
    };
}

interface FewShotExample {
    query: string;
    intent: string;
}

type ServiceStatus = 'up' | 'down' | 'unconfigured';
interface ServiceHealth { status: ServiceStatus; label: string; }

interface FullConfig {
    coreServices: Record<string, CoreService>;
    privacyConfig: {
        nonNames: string[];
    };
    routingConfig: {
        greetingKeywords: string[];
        followUpPatterns: Record<string, string>;
        subjectKeywords: string[];
        topicKeywords: Record<string, string[]>;
    };
    keywordConfig?: KeywordConfig;
    fewShotConfig?: {
        travel?: FewShotExample[];
        seatbooking?: FewShotExample[];
        community?: FewShotExample[];
        entryexit?: FewShotExample[];
        entryexitPrivacy?: FewShotExample[];
        generalPrivacy?: FewShotExample[];
    };
    bookingConfig?: {
        travel?: { allowPreviousDateBooking: boolean };
        seatbooking?: { allowPreviousDateBooking: boolean };
    };
}

const Admin = () => {
    const [services, setServices] = useState<Service[]>([]);
    const [loading, setLoading] = useState(true);
    const [isAdding, setIsAdding] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);
    const [newService, setNewService] = useState<Service>({
        id: '',
        name: '',
        baseUrl: '',
        description: '',
        keywords: []
    });
    const [keywordsInput, setKeywordsInput] = useState('');
    
    // Global Config State
    const [fullConfig, setFullConfig] = useState<FullConfig | null>(null);
    const [privacyInput, setPrivacyInput] = useState('');
    const [routingInput, setRoutingInput] = useState<any>(null);
    const [savingConfig, setSavingConfig] = useState(false);

    // Keyword Config State (per-field comma strings for textareas)
    const [kwPrivacy, setKwPrivacy] = useState({
        personalDataKeywords: '',
        colleaguePatternWords: '',
        bulkPatternPhrases: '',
        impersonationSkipWords: '',
        aiRewriteVerbs: '',
    });
    const [kwTravel, setKwTravel] = useState({
        travelDataKeywords: '',
        travelEntities: '',
    });
    const [kwSeatBooking, setKwSeatBooking] = useState({ seatKeywords: '' });
    const [kwCommunity, setKwCommunity] = useState({ communityDetectionKeywords: '', communityNames: '', joinIntentKeywords: '', listIntentPhrases: '' });
    const [kwEntryExit, setKwEntryExit] = useState({ entryExitDataKeywords: '' });
    const [savingKeywords, setSavingKeywords] = useState<string | null>(null); // which section is saving

    // Few-Shot Config State
    const [fewShots, setFewShots] = useState<{ travel: FewShotExample[]; seatbooking: FewShotExample[]; community: FewShotExample[]; entryexit: FewShotExample[]; entryexitPrivacy: FewShotExample[]; generalPrivacy: FewShotExample[] }>({
        travel: [], seatbooking: [], community: [], entryexit: [], entryexitPrivacy: [], generalPrivacy: []
    });
    const [newFewShot, setNewFewShot] = useState<{ travel: FewShotExample; seatbooking: FewShotExample; community: FewShotExample; entryexit: FewShotExample; entryexitPrivacy: FewShotExample; generalPrivacy: FewShotExample }>({
        travel: { query: '', intent: 'retrieve' },
        seatbooking: { query: '', intent: 'book' },
        community: { query: '', intent: 'join' },
        entryexit: { query: '', intent: 'current' },
        entryexitPrivacy: { query: '', intent: 'self' },
        generalPrivacy: { query: '', intent: 'self' },
    });
    const [savingFewShots, setSavingFewShots] = useState<string | null>(null);

    // Booking Rules State
    const [bookingConfig, setBookingConfig] = useState({
        travel:      { allowPreviousDateBooking: false },
        seatbooking: { allowPreviousDateBooking: false },
    });
    const [savingBooking, setSavingBooking] = useState<string | null>(null);

    // Service Health State
    const [serviceHealth, setServiceHealth] = useState<Record<string, ServiceHealth> | null>(null);
    const [healthOverallStatus, setHealthOverallStatus] = useState<string | null>(null);
    const [healthResponseTime, setHealthResponseTime] = useState<number | null>(null);
    const [healthLastChecked, setHealthLastChecked] = useState<Date | null>(null);
    const [healthLoading, setHealthLoading] = useState(false);

    const { toast } = useToast();
    const navigate = useNavigate();
    const { user } = useAuth();

    const adminFetch = (url: string, options: RequestInit = {}) => {
        const authHeaders: Record<string, string> = {
            'Content-Type': 'application/json',
            ...(user?.accessToken ? { 'Authorization': `Bearer ${user.accessToken}` } : {}),
            ...(user?.employeeNumber ? { 'X-Employee-Number': user.employeeNumber } : {}),
        };
        return fetch(url, {
            ...options,
            headers: { ...authHeaders, ...(options.headers as Record<string, string> || {}) },
        });
    };

    const availablePlanets = [
        { id: 'gym', name: 'Gym' },
        { id: 'parking', name: 'Parking' },
        { id: 'effort', name: 'Effort' },
        { id: 'projects', name: 'Projects' },
        { id: 'meetings', name: 'Meetings' },
        { id: 'courses', name: 'Courses' },
        { id: 'certifications', name: 'Badges' },
        { id: 'blogs', name: 'Blogs' },
        { id: 'watchlist', name: 'Watchlist' },
        { id: 'music', name: 'Music' },
        { id: 'wayfinder', name: 'WayFinder' },
        { id: 'holidays', name: 'Holidays' },
    ];

    useEffect(() => {
        fetchAllData();
    }, []);

    // Health polling — separate from config load, refreshes every 30 s
    const fetchHealth = async () => {
        setHealthLoading(true);
        try {
            const res = await fetch(API_ENDPOINTS.health);
            if (res.ok) {
                const data = await res.json();
                setServiceHealth(data.services as Record<string, ServiceHealth>);
                setHealthOverallStatus(data.status ?? null);
                setHealthResponseTime(data.responseTimeMs ?? null);
                setHealthLastChecked(new Date());
            }
        } catch {
            // network error — keep stale data visible
        } finally {
            setHealthLoading(false);
        }
    };

    useEffect(() => {
        fetchHealth();
        const interval = setInterval(fetchHealth, 30_000);
        return () => clearInterval(interval);
    }, []);

    const fetchAllData = async () => {
        setLoading(true);
        await Promise.all([
            fetchServices(),
            fetchFullConfig()
        ]);
        setLoading(false);
    };

    const fetchFullConfig = async () => {
        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config`);
            const data = await response.json();
            if (data.success && data.config) {
                setFullConfig(data.config);
                setPrivacyInput(data.config.privacyConfig.nonNames.join(', '));
                setRoutingInput(data.config.routingConfig);
                // Populate keyword config state
                if (data.config.keywordConfig) {
                    const kc = data.config.keywordConfig;
                    if (kc.privacyDetection) {
                        setKwPrivacy({
                            personalDataKeywords: (kc.privacyDetection.personalDataKeywords || []).join(', '),
                            colleaguePatternWords: (kc.privacyDetection.colleaguePatternWords || []).join(', '),
                            bulkPatternPhrases: (kc.privacyDetection.bulkPatternPhrases || []).join(', '),
                            impersonationSkipWords: (kc.privacyDetection.impersonationSkipWords || []).join(', '),
                            aiRewriteVerbs: (kc.privacyDetection.aiRewriteVerbs || []).join(', '),
                        });
                    }
                    if (kc.travelService) {
                        setKwTravel({
                            travelDataKeywords: (kc.travelService.travelDataKeywords || []).join(', '),
                            travelEntities: (kc.travelService.travelEntities || []).join(', '),
                        });
                    }
                    if (kc.seatBookingService) {
                        setKwSeatBooking({
                            seatKeywords: (kc.seatBookingService.seatKeywords || []).join(', '),
                        });
                    }
                    if (kc.communityService) {
                        setKwCommunity({
                            communityDetectionKeywords: (kc.communityService.communityDetectionKeywords || []).join(', '),
                            communityNames: (kc.communityService.communityNames || []).join(', '),
                            joinIntentKeywords: (kc.communityService.joinIntentKeywords || []).join(', '),
                            listIntentPhrases: (kc.communityService.listIntentPhrases || []).join(', '),
                        });
                    }
                    if (kc.entryExitService) {
                        setKwEntryExit({
                            entryExitDataKeywords: (kc.entryExitService.entryExitDataKeywords || []).join(', '),
                        });
                    }
                }
                if (data.config.fewShotConfig) {
                    const fc = data.config.fewShotConfig;
                    setFewShots({
                        travel: fc.travel || [],
                        seatbooking: fc.seatbooking || [],
                        community: fc.community || [],
                        entryexit: fc.entryexit || [],
                        entryexitPrivacy: fc.entryexitPrivacy || [],
                        generalPrivacy: fc.generalPrivacy || [],
                    });
                }
                if (data.config.bookingConfig) {
                    const bc = data.config.bookingConfig;
                    setBookingConfig({
                        travel:      { allowPreviousDateBooking: bc.travel?.allowPreviousDateBooking ?? false },
                        seatbooking: { allowPreviousDateBooking: bc.seatbooking?.allowPreviousDateBooking ?? false },
                    });
                }
            }
        } catch (error) {
            console.error('Failed to fetch full config:', error);
        }
    };

    const handleAutoDetect = async () => {
        if (!newService.baseUrl) {
            toast({
                title: "URL Required",
                description: "Please enter an MCP URL first.",
                variant: "destructive",
            });
            return;
        }

        setAnalyzing(true);
        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/services/discover`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: newService.baseUrl }),
            });

            const data = await response.json();

            if (data.success && data.analysis) {
                setNewService(prev => ({
                    ...prev,
                    name: data.analysis.name || prev.name,
                    description: data.analysis.description || prev.description,
                    id: data.analysis.recommendedPlanetId || prev.id,
                    baseUrl: data.analysis.derivedFromUrl || prev.baseUrl
                }));

                if (data.analysis.keywords && Array.isArray(data.analysis.keywords)) {
                    setKeywordsInput(data.analysis.keywords.join(', '));
                }

                toast({
                    title: "Discovery Successful",
                    description: "Smart analysis complete! Fields have been auto-filled.",
                });
            } else {
                throw new Error(data.error || 'Discovery failed');
            }
        } catch (error) {
            console.error(error);
            toast({
                title: "Discovery Failed",
                description: "Could not analyze the MCP. Please fill details manually.",
                variant: "destructive",
            });
        } finally {
            setAnalyzing(false);
        }
    };

    const fetchServices = async () => {
        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/services`);
            const data = await response.json();
            if (data.success && data.services) {
                setServices(data.services);
            }
        } catch (error) {
            console.error('Admin: Failed to fetch services:', error);
        }
    };

    const handleSaveService = async () => {
        try {
            if (!newService.id || !newService.name || !newService.baseUrl) {
                toast({
                    title: "Validation Error",
                    description: "Please fill in all required fields",
                    variant: "destructive"
                });
                return;
            }

            const keywords = keywordsInput.split(',').map(k => k.trim()).filter(k => k);
            const serviceToSave = { ...newService, keywords };

            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/services`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(serviceToSave)
            });

            const data = await response.json();
            if (data.success) {
                toast({
                    title: "Success",
                    description: "Service saved successfully"
                });
                setIsAdding(false);
                setNewService({ id: '', name: '', baseUrl: '', description: '', keywords: [] });
                setKeywordsInput('');
                fetchServices();
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to save service",
                variant: "destructive"
            });
        }
    };

    const handleDeleteService = async (id: string) => {
        if (!confirm('Are you sure you want to delete this service?')) return;

        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/services/${id}`, {
                method: 'DELETE'
            });
            const data = await response.json();

            if (data.success) {
                toast({ title: "Service deleted" });
                fetchServices();
            }
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to delete service",
                variant: "destructive"
            });
        }
    };

    const handleUpdateCoreService = async (serviceId: string, updatedService: CoreService) => {
        setSavingConfig(true);
        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/core/${serviceId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedService)
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Core Service Updated", description: `${updatedService.name} keywords saved.` });
                fetchFullConfig();
            }
        } catch (error) {
            toast({ title: "Update Failed", variant: "destructive" });
        } finally {
            setSavingConfig(false);
        }
    };

    const handleSavePrivacy = async () => {
        setSavingConfig(true);
        try {
            const nonNames = privacyInput.split(',').map(k => k.trim()).filter(k => k);
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/privacy`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nonNames })
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Whitelist Saved", description: "Privacy whitelists updated across all services." });
                fetchFullConfig();
            }
        } finally {
            setSavingConfig(false);
        }
    };

    const handleSaveRouting = async () => {
        if (!routingInput) return;
        setSavingConfig(true);
        try {
            const response = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/routing`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(routingInput)
            });
            const data = await response.json();
            if (data.success) {
                toast({ title: "Routing Updated", description: "Global routing heuristics and follow-up patterns saved." });
                fetchFullConfig();
            }
        } catch (error) {
            toast({ title: "Save Failed", variant: "destructive" });
        } finally {
            setSavingConfig(false);
        }
    };

    // ── Keyword config save helpers ──
    const toArr = (s: string) => s.split(',').map(k => k.trim()).filter(k => k);

    const handleSaveKeywordsPrivacy = async () => {
        setSavingKeywords('privacy');
        try {
            const body = {
                personalDataKeywords: toArr(kwPrivacy.personalDataKeywords),
                colleaguePatternWords: toArr(kwPrivacy.colleaguePatternWords),
                bulkPatternPhrases: toArr(kwPrivacy.bulkPatternPhrases),
                impersonationSkipWords: toArr(kwPrivacy.impersonationSkipWords),
                aiRewriteVerbs: toArr(kwPrivacy.aiRewriteVerbs),
            };
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/keywords/privacy`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Privacy Detection Keywords Saved', description: 'All privacy detection keyword lists updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsTravel = async () => {
        setSavingKeywords('travel');
        try {
            const body = {
                travelDataKeywords: toArr(kwTravel.travelDataKeywords),
                travelEntities: toArr(kwTravel.travelEntities),
            };
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/keywords/travel`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Travel Keywords Saved', description: 'Travel data keywords and entities updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsSeatBooking = async () => {
        setSavingKeywords('seatbooking');
        try {
            const body = { seatKeywords: toArr(kwSeatBooking.seatKeywords) };
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/keywords/seatbooking`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Seat Booking Keywords Saved', description: 'Seat booking keyword list updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsCommunity = async () => {
        setSavingKeywords('community');
        try {
            const body = {
                communityDetectionKeywords: toArr(kwCommunity.communityDetectionKeywords),
                communityNames: toArr(kwCommunity.communityNames),
                joinIntentKeywords: toArr(kwCommunity.joinIntentKeywords),
                listIntentPhrases: toArr(kwCommunity.listIntentPhrases),
            };
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/keywords/community`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Community Keywords Saved', description: 'Community keyword lists updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveKeywordsEntryExit = async () => {
        setSavingKeywords('entryexit');
        try {
            const body = { entryExitDataKeywords: toArr(kwEntryExit.entryExitDataKeywords) };
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/keywords/entryexit`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Entry/Exit Keywords Saved', description: 'Entry/Exit keyword list updated.' });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingKeywords(null); }
    };

    const handleSaveFewShots = async (service: 'travel' | 'seatbooking' | 'community' | 'entryexit' | 'entryexitPrivacy' | 'generalPrivacy') => {
        setSavingFewShots(service);
        try {
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/fewshots/${service}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ examples: fewShots[service] }),
            });
            const data = await res.json();
            if (data.success) {
                toast({ title: 'Few-Shot Examples Saved', description: `${service} examples updated.` });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingFewShots(null); }
    };

    const handleSaveBookingConfig = async (service: 'travel' | 'seatbooking') => {
        setSavingBooking(service);
        try {
            const res = await adminFetch(`${ADMIN_BASE_URL}/api/admin/config/booking/${service}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookingConfig[service]),
            });
            const data = await res.json();
            if (data.success) {
                const label = service === 'travel' ? 'Travel' : 'Seat Booking';
                toast({ title: `${label} Booking Rules Saved`, description: `Previous date booking is now ${bookingConfig[service].allowPreviousDateBooking ? 'allowed' : 'blocked'}.` });
                fetchFullConfig();
            } else throw new Error(data.error);
        } catch (e: any) {
            toast({ title: 'Save Failed', description: e.message, variant: 'destructive' });
        } finally { setSavingBooking(null); }
    };

    const addFewShot = (service: 'travel' | 'seatbooking' | 'community' | 'entryexit' | 'entryexitPrivacy' | 'generalPrivacy') => {
        const example = newFewShot[service];
        if (!example.query.trim() || !example.intent.trim()) return;
        setFewShots(prev => ({ ...prev, [service]: [...prev[service], { query: example.query.trim(), intent: example.intent }] }));
        setNewFewShot(prev => ({ ...prev, [service]: { query: '', intent: example.intent } }));
    };

    const removeFewShot = (service: 'travel' | 'seatbooking' | 'community' | 'entryexit' | 'entryexitPrivacy' | 'generalPrivacy', index: number) => {
        setFewShots(prev => ({ ...prev, [service]: prev[service].filter((_, i) => i !== index) }));
    };

    return (
        <div className="min-h-screen bg-slate-50 p-8">
            <div className="max-w-5xl mx-auto space-y-8">
                
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" onClick={() => navigate('/')}>
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Bosch AI Admin</h1>
                            <p className="text-slate-500">Unified configuration for services, keywords, and privacy</p>
                        </div>
                    </div>
                </div>

                <Tabs defaultValue="dynamic" className="w-full">
                    <TabsList className="grid w-full grid-cols-8 mb-8 bg-white border shadow-sm">
                        <TabsTrigger value="dynamic" className="flex items-center gap-2">
                            <Globe className="h-4 w-4" /> Dynamic MCPs
                        </TabsTrigger>
                        <TabsTrigger value="core" className="flex items-center gap-2">
                            <Settings className="h-4 w-4" /> Core Services
                        </TabsTrigger>
                        <TabsTrigger value="privacy" className="flex items-center gap-2">
                            <ShieldCheck className="h-4 w-4" /> Privacy Settings
                        </TabsTrigger>
                        <TabsTrigger value="keywords" className="flex items-center gap-2">
                            <Tag className="h-4 w-4" /> Keywords
                        </TabsTrigger>
                        <TabsTrigger value="routing" className="flex items-center gap-2">
                            <Zap className="h-4 w-4" /> Advanced Routing
                        </TabsTrigger>
                        <TabsTrigger value="fewshots" className="flex items-center gap-2">
                            <Brain className="h-4 w-4" /> Few-Shot AI
                        </TabsTrigger>
                        <TabsTrigger value="booking" className="flex items-center gap-2">
                            <CalendarX className="h-4 w-4" /> Booking Rules
                        </TabsTrigger>
                        <TabsTrigger value="health" className="flex items-center gap-2">
                            <Activity className="h-4 w-4" /> Service Health
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="dynamic" className="space-y-6">
                        <div className="flex justify-between items-center decoration-slate-200">
                             <h2 className="text-xl font-semibold text-slate-800">External MCP Services</h2>
                             <Button onClick={() => setIsAdding(true)} variant="default" className="bg-blue-600 hover:bg-blue-700">
                                <Plus className="h-4 w-4 mr-2" /> Add Service
                            </Button>
                        </div>

                        {isAdding && (
                            <Card className="border-blue-200 bg-blue-50/30 shadow-md">
                                <CardHeader>
                                    <CardTitle>Add New MCP Service</CardTitle>
                                    <CardDescription>Configure a new dynamic service planet</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                     <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label>Planet Category</Label>
                                            <select 
                                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                                value={newService.id}
                                                onChange={(e) => {
                                                    const planet = availablePlanets.find(p => p.id === e.target.value);
                                                    setNewService({ ...newService, id: e.target.value, name: planet ? `${planet.name} Assistant` : '' })
                                                }}
                                            >
                                                <option value="">Select a Planet...</option>
                                                {availablePlanets.map(planet => (
                                                    <option key={planet.id} value={planet.id}>{planet.name}</option>
                                                ))}
                                                <option value="custom">Custom ID...</option>
                                            </select>
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Service Name</Label>
                                            <Input 
                                                value={newService.name}
                                                onChange={(e) => setNewService({...newService, name: e.target.value})}
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Server URL</Label>
                                        <div className="flex gap-2">
                                            <Input 
                                                className="font-mono text-xs"
                                                value={newService.baseUrl}
                                                onChange={(e) => setNewService({...newService, baseUrl: e.target.value})}
                                                placeholder="https://..."
                                            />
                                            <Button variant="secondary" onClick={handleAutoDetect} disabled={analyzing}>
                                                {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                                            </Button>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Keywords</Label>
                                        <Input 
                                            value={keywordsInput}
                                            onChange={(e) => setKeywordsInput(e.target.value)}
                                            placeholder="comma separated keywords"
                                        />
                                    </div>
                                </CardContent>
                                <CardFooter className="flex justify-end gap-2">
                                    <Button variant="ghost" onClick={() => setIsAdding(false)}>Cancel</Button>
                                    <Button onClick={handleSaveService}>Save Connection</Button>
                                </CardFooter>
                            </Card>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {services.map(service => (
                                <Card key={service.id} className="bg-white hover:shadow-md transition-shadow border-slate-200">
                                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                        <div>
                                            <CardTitle className="text-lg text-slate-800">{service.name}</CardTitle>
                                            <Badge variant="outline" className="mt-1 text-slate-500">{service.id}</Badge>
                                        </div>
                                        <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-500" onClick={() => handleDeleteService(service.id)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-sm text-slate-500 mb-3">{service.description}</p>
                                        <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 mb-4 bg-slate-50 p-2 rounded">
                                            <Server className="h-3 w-3" /> {service.baseUrl}
                                        </div>
                                        <div className="flex flex-wrap gap-1">
                                            {service.keywords && service.keywords.map(k => (
                                                <Badge key={k} variant="secondary" className="text-[10px] bg-slate-100 text-slate-600 border-none">{k}</Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="core" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Core Services Routing</h2>
                            <Badge variant="secondary" className="bg-blue-100 text-blue-700 border-none">System Built-in</Badge>
                        </div>
                        
                        {!fullConfig ? (
                            <div className="text-center py-10"><Loader2 className="animate-spin h-8 w-8 mx-auto text-slate-300" /></div>
                        ) : (
                            <div className="space-y-4">
                                {Object.entries(fullConfig.coreServices).map(([id, s]) => (
                                    <Card key={id} className="bg-white border-slate-200">
                                        <CardContent className="pt-6 space-y-4">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-xl">
                                                        {id === 'canteen' ? '🍴' : id === 'entryexit' ? '⏰' : id === 'travel' ? '✈️' : id === 'seatbooking' ? '💺' : id === 'community' ? '👥' : '📋'}
                                                    </div>
                                                    <div>
                                                        <h3 className="font-bold text-slate-800">{s.name}</h3>
                                                        <p className="text-xs text-slate-400 uppercase tracking-wider">{id}</p>
                                                    </div>
                                                </div>
                                                <Button 
                                                    size="sm" 
                                                    variant="outline" 
                                                    onClick={() => handleUpdateCoreService(id, fullConfig.coreServices[id])}
                                                    disabled={savingConfig}
                                                >
                                                    {savingConfig ? <Loader2 className="animate-spin h-4 w-4" /> : <Save className="h-4 w-4 mr-2" />} Save
                                                </Button>
                                            </div>
                                            
                                            <div className="grid grid-cols-1 gap-4">
                                                <div className="space-y-2">
                                                    <Label className="text-xs font-semibold text-slate-500 uppercase">Description (Impacts AI Routing)</Label>
                                                    <Input 
                                                        value={s.description} 
                                                        onChange={(e) => {
                                                            const newServices = { ...fullConfig.coreServices };
                                                            newServices[id] = { ...s, description: e.target.value };
                                                            setFullConfig({ ...fullConfig, coreServices: newServices });
                                                        }}
                                                    />
                                                </div>
                                                <div className="space-y-2">
                                                    <Label className="text-xs font-semibold text-slate-500 uppercase">Routing Keywords</Label>
                                                    <Textarea 
                                                        value={s.keywords.join(', ')} 
                                                        className="min-h-[60px] text-sm"
                                                        onChange={(e) => {
                                                            const newKeywords = e.target.value.split(',').map(k => k.trim());
                                                            const newServices = { ...fullConfig.coreServices };
                                                            newServices[id] = { ...s, keywords: newKeywords };
                                                            setFullConfig({ ...fullConfig, coreServices: newServices });
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="privacy" className="space-y-6">
                        <Card className="bg-white border-slate-200">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <ShieldCheck className="h-5 w-5 text-green-600" />
                                    Privacy Guard Whitelist
                                </CardTitle>
                                <CardDescription>
                                    Define keywords that should NOT be treated as colleague names. This prevents false positives in the privacy guard for words like "confirmed", "today", or "bangalore".
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="p-4 bg-orange-50 border border-orange-100 rounded-md">
                                    <p className="text-sm text-orange-800">
                                        <strong>How it works:</strong> If a user query contains a word in this list, the Bosch AI assistant will 
                                        <em> ignore</em> it when searching for potential colleague names.
                                    </p>
                                </div>
                                <div className="space-y-2">
                                    <Label>Global Whitelist (Comma-separated)</Label>
                                    <Textarea 
                                        className="min-h-[300px] font-mono text-sm leading-relaxed"
                                        value={privacyInput}
                                        onChange={(e) => setPrivacyInput(e.target.value)}
                                        placeholder="Enter keywords separated by commas..."
                                    />
                                </div>
                                <div className="flex items-center gap-2 text-xs text-slate-400">
                                    <Badge variant="secondary" className="bg-slate-100 text-slate-500 border-none font-normal">
                                        Total Keywords: {privacyInput.split(',').filter(k => k.trim()).length}
                                    </Badge>
                                    <span>Tip: Keep generic locations, common verbs, and confirmation words here.</span>
                                </div>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button 
                                    className="bg-green-600 hover:bg-green-700" 
                                    onClick={handleSavePrivacy}
                                    disabled={savingConfig}
                                >
                                    {savingConfig ? (
                                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                                    ) : (
                                        <><Save className="h-4 w-4 mr-2" /> Save Whitelist</>
                                    )}
                                </Button>
                            </CardFooter>
                        </Card>
                    </TabsContent>
                    {/* ════════════ KEYWORDS TAB ════════════ */}
                    <TabsContent value="keywords" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Keyword Management</h2>
                            <Badge variant="secondary" className="bg-indigo-100 text-indigo-700 border-none">Centralised Config</Badge>
                        </div>
                        <p className="text-sm text-slate-500 -mt-4">
                            These keyword lists power the privacy guard, service routing, and entity recognition across all services.
                            Changes take effect immediately after saving.
                        </p>

                        {/* ── Card 1: Privacy Detection ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <ShieldCheck className="h-5 w-5 text-orange-500" /> Privacy Detection Keywords
                                </CardTitle>
                                <CardDescription>Keywords used by the privacy guard to detect personal data queries, colleague references, and bulk data requests.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="p-3 bg-orange-50 border border-orange-100 rounded-md mb-4">
                                    <p className="text-xs text-orange-700">
                                        <strong>Note:</strong> Some entries support regex syntax (e.g. <code className="bg-orange-100 px-1 rounded">check.?in</code>).
                                        Phrases with spaces (e.g. <code className="bg-orange-100 px-1 rounded">team mate</code>) are auto-converted to flexible patterns.
                                    </p>
                                </div>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="personalDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Personal Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.personalDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that indicate a query is about personal/sensitive data (attendance, salary, etc.)</p>
                                            <Textarea className="min-h-[100px] font-mono text-xs" value={kwPrivacy.personalDataKeywords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, personalDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="colleaguePatternWords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Colleague Pattern Words
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.colleaguePatternWords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that indicate the query is about another person (friend, boss, colleague, etc.)</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwPrivacy.colleaguePatternWords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, colleaguePatternWords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="bulkPatternPhrases">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Bulk Request Patterns
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.bulkPatternPhrases).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Phrases that indicate a request for bulk/collective employee data (all employees, team attendance, etc.)</p>
                                            <Textarea className="min-h-[100px] font-mono text-xs" value={kwPrivacy.bulkPatternPhrases}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, bulkPatternPhrases: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="impersonationSkipWords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Impersonation Skip Words
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.impersonationSkipWords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words after "I am..." that are NOT person names (looking, checking, etc.) to avoid false impersonation flags.</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwPrivacy.impersonationSkipWords}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, impersonationSkipWords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="aiRewriteVerbs">
                                        <AccordionTrigger className="text-sm font-medium">
                                            AI Rewrite Verbs
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwPrivacy.aiRewriteVerbs).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Verbs/descriptors the AI may introduce when rewriting queries (provide, retrieve, comprehensive, etc.). Prevents false-positive name detection on AI-generated words.</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwPrivacy.aiRewriteVerbs}
                                                onChange={(e) => setKwPrivacy({ ...kwPrivacy, aiRewriteVerbs: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-orange-600 hover:bg-orange-700" onClick={handleSaveKeywordsPrivacy} disabled={savingKeywords === 'privacy'}>
                                    {savingKeywords === 'privacy' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Privacy Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 2: Travel Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Plane className="h-5 w-5 text-blue-500" /> Travel Service Keywords
                                </CardTitle>
                                <CardDescription>Keywords and entity lists for the travel booking service privacy guard.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="p-3 bg-blue-50 border border-blue-100 rounded-md mb-4">
                                    <p className="text-xs text-blue-700">
                                        <strong>Travel Entities</strong> prevent false-positive name detection for airlines, hotels, cities, and transport terms.
                                        Add new cities or airlines here instead of editing source code.
                                    </p>
                                </div>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="travelDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Travel Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwTravel.travelDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate a travel-related query (travel, trip, flight, etc.)</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwTravel.travelDataKeywords}
                                                onChange={(e) => setKwTravel({ ...kwTravel, travelDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="travelEntities">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Travel Entities (Airlines, Hotels, Cities, etc.)
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwTravel.travelEntities).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Proper nouns that are NOT person names: airline names, hotel chains, city names, transport terms, booking platforms.</p>
                                            <Textarea className="min-h-[200px] font-mono text-xs" value={kwTravel.travelEntities}
                                                onChange={(e) => setKwTravel({ ...kwTravel, travelEntities: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleSaveKeywordsTravel} disabled={savingKeywords === 'travel'}>
                                    {savingKeywords === 'travel' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Travel Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 3: Seat Booking Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Armchair className="h-5 w-5 text-purple-500" /> Seat Booking Keywords
                                </CardTitle>
                                <CardDescription>Keywords for the seat/desk booking service privacy guard gate.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="seatKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Seat Booking Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwSeatBooking.seatKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate a seat/desk booking query (seat, desk, booking, etc.)</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwSeatBooking.seatKeywords}
                                                onChange={(e) => setKwSeatBooking({ seatKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-purple-600 hover:bg-purple-700" onClick={handleSaveKeywordsSeatBooking} disabled={savingKeywords === 'seatbooking'}>
                                    {savingKeywords === 'seatbooking' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Seat Booking Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 4: Community Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Users className="h-5 w-5 text-green-500" /> Community Keywords
                                </CardTitle>
                                <CardDescription>Detection keywords, community names, join & list intent phrases for the community service.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="communityDetection">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Detection Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.communityDetectionKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words that identify a query as community-related (community, communities, associate arena).</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwCommunity.communityDetectionKeywords}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, communityDetectionKeywords: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="communityNames">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Community Names
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.communityNames).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Known community names (Mind Buddies, Art in Motion, Cyco, etc.). These bypass the privacy guard and trigger community routing.</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwCommunity.communityNames}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, communityNames: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="joinIntent">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Join Intent Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.joinIntentKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Words indicating the user wants to join/register for a community.</p>
                                            <Textarea className="min-h-[60px] font-mono text-xs" value={kwCommunity.joinIntentKeywords}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, joinIntentKeywords: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                    <AccordionItem value="listIntent">
                                        <AccordionTrigger className="text-sm font-medium">
                                            List Intent Phrases
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwCommunity.listIntentPhrases).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Phrases that trigger showing all communities (show all, list all, all communities, etc.).</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwCommunity.listIntentPhrases}
                                                onChange={(e) => setKwCommunity(prev => ({ ...prev, listIntentPhrases: e.target.value }))} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-green-600 hover:bg-green-700" onClick={handleSaveKeywordsCommunity} disabled={savingKeywords === 'community'}>
                                    {savingKeywords === 'community' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Community Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Card 5: Entry/Exit Service ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Clock className="h-5 w-5 text-teal-500" /> Entry/Exit Keywords
                                </CardTitle>
                                <CardDescription>Data keywords for the entry/exit time tracking privacy guard gate.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" className="w-full">
                                    <AccordionItem value="entryExitDataKeywords">
                                        <AccordionTrigger className="text-sm font-medium">
                                            Entry/Exit Data Keywords
                                            <Badge variant="outline" className="ml-2 text-xs">{toArr(kwEntryExit.entryExitDataKeywords).length}</Badge>
                                        </AccordionTrigger>
                                        <AccordionContent>
                                            <p className="text-xs text-slate-400 mb-2">Keywords that indicate entry/exit personal data (entry, exit, swipe, attendance, etc.).</p>
                                            <Textarea className="min-h-[80px] font-mono text-xs" value={kwEntryExit.entryExitDataKeywords}
                                                onChange={(e) => setKwEntryExit({ entryExitDataKeywords: e.target.value })} />
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button className="bg-teal-600 hover:bg-teal-700" onClick={handleSaveKeywordsEntryExit} disabled={savingKeywords === 'entryexit'}>
                                    {savingKeywords === 'entryexit' ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : <><Save className="h-4 w-4 mr-2" /> Save Entry/Exit Keywords</>}
                                </Button>
                            </CardFooter>
                        </Card>
                    </TabsContent>

                    <TabsContent value="routing" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Advanced Routing & Context</h2>
                            <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 border-none">Expert Only</Badge>
                        </div>

                        {!routingInput ? (
                            <div className="text-center py-10"><Loader2 className="animate-spin h-8 w-8 mx-auto text-slate-300" /></div>
                        ) : (
                            <div className="space-y-6">
                                <Card className="bg-white border-slate-200 shadow-sm">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Globe className="h-4 w-4 text-blue-500" /> Greeting Keywords
                                        </CardTitle>
                                        <CardDescription>Keywords that trigger the "general" assistant response (concconcatenated by OR logic).</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Textarea 
                                            value={routingInput.greetingKeywords.join(', ')}
                                            className="min-h-[100px] font-mono text-sm"
                                            onChange={(e) => setRoutingInput({
                                                ...routingInput,
                                                greetingKeywords: e.target.value.split(',').map(k => k.trim()).filter(k => k)
                                            })}
                                        />
                                    </CardContent>
                                </Card>

                                <Card className="bg-white border-slate-200 shadow-sm">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Sparkles className="h-4 w-4 text-purple-500" /> Subject Recognition
                                        </CardTitle>
                                        <CardDescription>Advanced: Keywords used to detect if a short query has a specific subject. Impacts follow-up logic.</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Textarea 
                                            value={routingInput.subjectKeywords.join(', ')}
                                            className="min-h-[100px] font-mono text-sm"
                                            onChange={(e) => setRoutingInput({
                                                ...routingInput,
                                                subjectKeywords: e.target.value.split(',').map(k => k.trim()).filter(k => k)
                                            })}
                                        />
                                    </CardContent>
                                </Card>

                                <Card className="bg-slate-900 text-white border-none shadow-lg">
                                    <CardHeader>
                                        <CardTitle className="text-base font-bold flex items-center gap-2">
                                            <Save className="h-4 w-4" /> Persist Heuristics
                                        </CardTitle>
                                        <CardDescription className="text-slate-400">These changes affect global conversation context and routing accuracy.</CardDescription>
                                    </CardHeader>
                                    <CardFooter className="pt-0">
                                        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold" onClick={handleSaveRouting} disabled={savingConfig}>
                                            {savingConfig ? (
                                                <><Loader2 className="animate-spin mr-2 h-4 w-4" /> Updating System...</>
                                            ) : (
                                                <><Save className="mr-2 h-4 w-4" /> Update Routing Engine</>
                                            )}
                                        </Button>
                                    </CardFooter>
                                </Card>
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="fewshots" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Few-Shot AI Training Examples</h2>
                            <Badge variant="secondary" className="bg-purple-100 text-purple-700 border-none">LLM Powered</Badge>
                        </div>
                        <p className="text-sm text-slate-500">
                            These examples are injected into the LLM system prompt so the AI can correctly classify user intent for each service.
                            Add more examples to improve accuracy for edge cases.
                        </p>

                        {(
                            [
                                {
                                    key: 'travel' as const,
                                    label: 'Travel Service',
                                    icon: <Plane className="h-5 w-5 text-blue-500" />,
                                    color: 'blue',
                                    intents: ['retrieve', 'book'],
                                },
                                {
                                    key: 'seatbooking' as const,
                                    label: 'Seat Booking Service',
                                    icon: <Armchair className="h-5 w-5 text-green-500" />,
                                    color: 'green',
                                    intents: ['book', 'cancel', 'list', 'general'],
                                },
                                {
                                    key: 'community' as const,
                                    label: 'Community Service',
                                    icon: <Users className="h-5 w-5 text-purple-500" />,
                                    color: 'purple',
                                    intents: ['join', 'list', 'membership', 'info', 'general'],
                                },
                                {
                                    key: 'entryexit' as const,
                                    label: 'Entry/Exit — Intent',
                                    icon: <Clock className="h-5 w-5 text-teal-500" />,
                                    color: 'teal',
                                    intents: ['current', 'history', 'identity', 'general'],
                                    description: 'Classifies what the user wants (today\'s status, history, identity…)',
                                },
                                {
                                    key: 'entryexitPrivacy' as const,
                                    label: 'Entry/Exit — Privacy Guard',
                                    icon: <ShieldCheck className="h-5 w-5 text-rose-500" />,
                                    color: 'rose',
                                    intents: ['self', 'other'],
                                    description: 'Classifies whether the query is about the logged-in user ("self") or a colleague ("other"). "other" queries are blocked.',
                                },
                                {
                                    key: 'generalPrivacy' as const,
                                    label: 'General Privacy Guard',
                                    icon: <ShieldCheck className="h-5 w-5 text-violet-500" />,
                                    color: 'violet',
                                    intents: ['self', 'other'],
                                    description: 'LLM-first privacy gate applied to ALL services before routing. Classifies any query as "self" (allow) or "other" (block). Replaces brittle regex for 1000+ users.',
                                },
                            ] as const
                        ).map(({ key, label, icon, intents }) => (
                            <Card key={key} className="bg-white border-slate-200 shadow-sm">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-base">
                                        {icon} {label}
                                        <Badge variant="outline" className="ml-auto text-xs">{fewShots[key].length} examples</Badge>
                                    </CardTitle>
                                    <CardDescription className="space-y-1">
                                        {((key as string) === 'entryexitPrivacy' || (key as string) === 'generalPrivacy') && (
                                            <p className={`text-xs font-medium mb-1 ${(key as string) === 'generalPrivacy' ? 'text-violet-700' : 'text-rose-600'}`}>
                                                🛡️ Privacy Guard — queries classified as <code className={`px-1 rounded ${(key as string) === 'generalPrivacy' ? 'bg-violet-50' : 'bg-rose-50'}`}>other</code> are blocked before reaching any service.
                                                {(key as string) === 'generalPrivacy' && <span className="block mt-0.5 text-violet-600">This is the primary gate — LLM-first with regex fallback.</span>}
                                            </p>
                                        )}
                                        <span>Intent labels: {intents.map(i => (
                                            <code key={i} className={`mx-1 px-1 py-0.5 rounded text-xs ${
                                                i === 'other' ? 'bg-red-100 text-red-700' :
                                                i === 'self'  ? 'bg-green-100 text-green-700' :
                                                                'bg-slate-100'
                                            }`}>{i}</code>
                                        ))}</span>
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {/* Existing examples table */}
                                    <div className="rounded-md border border-slate-200 overflow-hidden">
                                        <table className="w-full text-sm">
                                            <thead className="bg-slate-50 border-b border-slate-200">
                                                <tr>
                                                    <th className="text-left px-3 py-2 font-medium text-slate-600 w-3/4">Query</th>
                                                    <th className="text-left px-3 py-2 font-medium text-slate-600">Intent</th>
                                                    <th className="px-3 py-2 w-8"></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {fewShots[key].length === 0 ? (
                                                    <tr>
                                                        <td colSpan={3} className="text-center py-6 text-slate-400 text-xs">No examples yet. Add one below.</td>
                                                    </tr>
                                                ) : (
                                                    fewShots[key].map((ex, idx) => (
                                                        <tr key={idx} className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
                                                            <td className="px-3 py-2 font-mono text-xs text-slate-700">{ex.query}</td>
                                                            <td className="px-3 py-2">
                                                                <Badge variant="secondary" className="text-xs">{ex.intent}</Badge>
                                                            </td>
                                                            <td className="px-3 py-2">
                                                                <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-red-500"
                                                                    onClick={() => removeFewShot(key, idx)}>
                                                                    <Trash2 className="h-3 w-3" />
                                                                </Button>
                                                            </td>
                                                        </tr>
                                                    ))
                                                )}
                                            </tbody>
                                        </table>
                                    </div>

                                    {/* Add new example */}
                                    <div className="flex gap-2 items-end pt-1">
                                        <div className="flex-1">
                                            <Label className="text-xs text-slate-500 mb-1 block">New query example</Label>
                                            <Input
                                                placeholder={`e.g. "${
                                                    key === 'travel'           ? 'show my travel bookings' :
                                                    key === 'seatbooking'      ? 'book a desk for tomorrow' :
                                                    key === 'community'        ? 'show available communities' :
                                                    key === 'entryexitPrivacy' ? 'how many days did Ganesh come' :
                                                    key === 'generalPrivacy'   ? 'raise a travel for Rahul' :
                                                                                 'what time did I check in today'
                                                }"`}
                                                className="text-sm font-mono"
                                                value={newFewShot[key].query}
                                                onChange={(e) => setNewFewShot(prev => ({ ...prev, [key]: { ...prev[key], query: e.target.value } }))}
                                                onKeyDown={(e) => e.key === 'Enter' && addFewShot(key)}
                                            />
                                        </div>
                                        <div>
                                            <Label className="text-xs text-slate-500 mb-1 block">Intent</Label>
                                            <select
                                                className="h-9 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
                                                value={newFewShot[key].intent}
                                                onChange={(e) => setNewFewShot(prev => ({ ...prev, [key]: { ...prev[key], intent: e.target.value } }))}
                                            >
                                                {intents.map(i => <option key={i} value={i}>{i}</option>)}
                                            </select>
                                        </div>
                                        <Button variant="outline" size="sm" onClick={() => addFewShot(key)} className="gap-1">
                                            <Plus className="h-3 w-3" /> Add
                                        </Button>
                                    </div>
                                </CardContent>
                                <CardFooter className="bg-slate-50/50 flex justify-end">
                                    <Button
                                        className="bg-purple-600 hover:bg-purple-700 text-white"
                                        onClick={() => handleSaveFewShots(key)}
                                        disabled={savingFewShots === key}
                                    >
                                        {savingFewShots === key
                                            ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                                            : <><Save className="h-4 w-4 mr-2" /> Save {label} Examples</>
                                        }
                                    </Button>
                                </CardFooter>
                            </Card>
                        ))}
                    </TabsContent>
                    {/* ════════════ BOOKING RULES TAB ════════════ */}
                    <TabsContent value="booking" className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                            <h2 className="text-xl font-semibold text-slate-800">Booking Rules</h2>
                            <Badge variant="secondary" className="bg-red-100 text-red-700 border-none">Date Validation</Badge>
                        </div>
                        <p className="text-sm text-slate-500 -mt-4">
                            Control whether employees can submit bookings for dates that have already passed.
                            When <strong>Previous Date Booking</strong> is <strong>OFF</strong>, any request for a past date
                            is rejected with a clear error message before reaching the agent.
                        </p>

                        {/* ── Travel Booking Rules ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Plane className="h-5 w-5 text-blue-500" /> Travel Booking Rules
                                </CardTitle>
                                <CardDescription>
                                    Applies to all travel requests processed by the Travel A2A Agent.
                                    The departure date is checked against today (IST) once all booking slots are collected.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
                                    <div className="space-y-0.5">
                                        <Label className="text-sm font-medium text-slate-800">
                                            Allow Previous Date Booking
                                        </Label>
                                        <p className="text-xs text-slate-500">
                                            {bookingConfig.travel.allowPreviousDateBooking
                                                ? '✅ Enabled — users can book travel for past dates (e.g. for retroactive expense requests).'
                                                : '🚫 Disabled — travel requests with a past departure date are rejected automatically.'}
                                        </p>
                                    </div>
                                    <Switch
                                        checked={bookingConfig.travel.allowPreviousDateBooking}
                                        onCheckedChange={(checked) =>
                                            setBookingConfig(prev => ({ ...prev, travel: { allowPreviousDateBooking: checked } }))
                                        }
                                    />
                                </div>
                                <div className="p-3 bg-blue-50 border border-blue-100 rounded-md">
                                    <p className="text-xs text-blue-700">
                                        <strong>When OFF:</strong> If a user requests travel with a departure date before today, the booking is blocked and they are asked to provide a future date. The travel state is reset so they can immediately retry.
                                    </p>
                                </div>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button
                                    className="bg-blue-600 hover:bg-blue-700 text-white"
                                    onClick={() => handleSaveBookingConfig('travel')}
                                    disabled={savingBooking === 'travel'}
                                >
                                    {savingBooking === 'travel'
                                        ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                                        : <><Save className="h-4 w-4 mr-2" /> Save Travel Rules</>
                                    }
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* ── Seat Booking Rules ── */}
                        <Card className="bg-white border-slate-200 shadow-sm">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Armchair className="h-5 w-5 text-purple-500" /> Seat Booking Rules
                                </CardTitle>
                                <CardDescription>
                                    Applies to desk/seat booking requests processed by the Seat Booking A2A Agent.
                                    Date extraction scans the query for explicit and relative past dates before forwarding to the agent.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
                                    <div className="space-y-0.5">
                                        <Label className="text-sm font-medium text-slate-800">
                                            Allow Previous Date Booking
                                        </Label>
                                        <p className="text-xs text-slate-500">
                                            {bookingConfig.seatbooking.allowPreviousDateBooking
                                                ? '✅ Enabled — users can book seats for past dates.'
                                                : '🚫 Disabled — seat booking requests mentioning past dates are rejected automatically.'}
                                        </p>
                                    </div>
                                    <Switch
                                        checked={bookingConfig.seatbooking.allowPreviousDateBooking}
                                        onCheckedChange={(checked) =>
                                            setBookingConfig(prev => ({ ...prev, seatbooking: { allowPreviousDateBooking: checked } }))
                                        }
                                    />
                                </div>
                                <div className="p-3 bg-purple-50 border border-purple-100 rounded-md">
                                    <p className="text-xs text-purple-700">
                                        <strong>Detected patterns (when OFF):</strong> "yesterday", "last Monday", explicit dates like "10th April", "2024-04-10", "10/04/2024" that are strictly before today. Listing and cancellation queries are always allowed regardless of this setting.
                                    </p>
                                </div>
                            </CardContent>
                            <CardFooter className="bg-slate-50/50 flex justify-end">
                                <Button
                                    className="bg-purple-600 hover:bg-purple-700 text-white"
                                    onClick={() => handleSaveBookingConfig('seatbooking')}
                                    disabled={savingBooking === 'seatbooking'}
                                >
                                    {savingBooking === 'seatbooking'
                                        ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
                                        : <><Save className="h-4 w-4 mr-2" /> Save Seat Booking Rules</>
                                    }
                                </Button>
                            </CardFooter>
                        </Card>
                    </TabsContent>

                    {/* ════════════ SERVICE HEALTH TAB ════════════ */}
                    <TabsContent value="health" className="space-y-6">

                        {/* ── Header row ── */}
                        <div className="flex items-center justify-between flex-wrap gap-3">
                            <div>
                                <h2 className="text-xl font-semibold text-slate-800">Service Health</h2>
                                <p className="text-sm text-slate-500 mt-1">
                                    Live status of all backend services. Auto-refreshes every 30 seconds.
                                </p>
                            </div>
                            <div className="flex items-center gap-3">
                                {healthLastChecked && (
                                    <span className="text-xs text-slate-400">
                                        Last checked: {healthLastChecked.toLocaleTimeString()}
                                        {healthResponseTime != null && (
                                            <span className="ml-1 text-slate-300">· {healthResponseTime} ms</span>
                                        )}
                                    </span>
                                )}
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={fetchHealth}
                                    disabled={healthLoading}
                                    className="flex items-center gap-2"
                                >
                                    {healthLoading
                                        ? <Loader2 className="h-4 w-4 animate-spin" />
                                        : <RefreshCw className="h-4 w-4" />}
                                    Refresh
                                </Button>
                            </div>
                        </div>

                        {/* ── Overall status banner ── */}
                        {serviceHealth && healthOverallStatus && (() => {
                            const isOk       = healthOverallStatus === 'OK';
                            const isDegraded = healthOverallStatus === 'DEGRADED';
                            const downCount  = Object.values(serviceHealth).filter(s => s.status === 'down').length;
                            const totalCount = Object.keys(serviceHealth).length;
                            return (
                                <div className={`flex items-center gap-3 px-4 py-3 rounded-lg border ${
                                    isOk       ? 'bg-emerald-50 border-emerald-200' :
                                    isDegraded ? 'bg-amber-50 border-amber-200' :
                                                 'bg-red-50 border-red-200'
                                }`}>
                                    {isOk
                                        ? <CheckCircle2 className="h-5 w-5 text-emerald-600 flex-shrink-0" />
                                        : isDegraded
                                        ? <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                                        : <XCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
                                    }
                                    <div>
                                        <p className={`font-semibold text-sm ${
                                            isOk ? 'text-emerald-700' : isDegraded ? 'text-amber-700' : 'text-red-700'
                                        }`}>
                                            {isOk       ? 'All Systems Operational'  :
                                             isDegraded ? 'Partial Service Degradation' :
                                                          'Service Outage Detected'}
                                        </p>
                                        <p className="text-xs text-slate-500 mt-0.5">
                                            {downCount === 0
                                                ? `All ${totalCount} services are reachable.`
                                                : `${downCount} of ${totalCount} services unavailable.`}
                                        </p>
                                    </div>
                                </div>
                            );
                        })()}

                        {/* ── Service grid ── */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {healthLoading && !serviceHealth ? (
                                /* Skeleton cards while first fetch is in-flight */
                                Array.from({ length: 7 }).map((_, i) => (
                                    <Card key={i} className="border-slate-200 animate-pulse">
                                        <CardContent className="p-4 flex items-center gap-3">
                                            <div className="w-3 h-3 rounded-full bg-slate-200 flex-shrink-0" />
                                            <div className="flex-1 space-y-2">
                                                <div className="h-3 bg-slate-200 rounded w-3/4" />
                                                <div className="h-2.5 bg-slate-100 rounded w-1/2" />
                                            </div>
                                            <div className="w-8 h-5 bg-slate-200 rounded-full" />
                                        </CardContent>
                                    </Card>
                                ))
                            ) : serviceHealth ? (
                                Object.entries(serviceHealth).map(([key, svc]) => {
                                    const isUp   = svc.status === 'up';
                                    const isDown = svc.status === 'down';
                                    const isNone = svc.status === 'unconfigured';
                                    return (
                                        <Card key={key} className={`transition-all border ${
                                            isUp   ? 'border-emerald-200 bg-emerald-50/30' :
                                            isDown ? 'border-red-200 bg-red-50/30' :
                                                     'border-amber-200 bg-amber-50/30'
                                        }`}>
                                            <CardContent className="p-4 flex items-center gap-3">
                                                {/* Status dot */}
                                                <span className={`w-3 h-3 rounded-full flex-shrink-0 ${
                                                    isUp   ? 'bg-emerald-400 shadow-[0_0_6px_2px_rgba(52,211,153,0.55)]' :
                                                    isDown ? 'bg-red-400' :
                                                             'bg-amber-400'
                                                }`} />
                                                {/* Label + sub-label */}
                                                <div className="flex-1 min-w-0">
                                                    <p className="text-sm font-medium text-slate-800 truncate">{svc.label}</p>
                                                    <p className={`text-xs ${
                                                        isUp   ? 'text-emerald-600' :
                                                        isDown ? 'text-red-500' :
                                                                 'text-amber-600'
                                                    }`}>
                                                        {isUp ? 'Operational' : isDown ? 'Unavailable' : 'Not configured'}
                                                    </p>
                                                </div>
                                                {/* Badge */}
                                                <Badge className={`text-[10px] border-none font-semibold ${
                                                    isUp   ? 'bg-emerald-100 text-emerald-700' :
                                                    isDown ? 'bg-red-100 text-red-700' :
                                                             'bg-amber-100 text-amber-700'
                                                }`}>
                                                    {isUp ? 'UP' : isDown ? 'DOWN' : 'N/A'}
                                                </Badge>
                                            </CardContent>
                                        </Card>
                                    );
                                })
                            ) : (
                                <div className="col-span-3 text-center py-12 text-slate-400">
                                    <Activity className="h-10 w-10 mx-auto mb-3 opacity-30" />
                                    <p className="text-sm">Unable to reach health endpoint.</p>
                                    <p className="text-xs mt-1">Check that the backend server is running.</p>
                                </div>
                            )}
                        </div>

                        {/* ── Legend ── */}
                        {serviceHealth && (
                            <div className="flex items-center gap-5 text-xs text-slate-400 pt-1">
                                <span className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                                    Operational
                                </span>
                                <span className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full bg-red-400 inline-block" />
                                    Unavailable
                                </span>
                                <span className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
                                    Not configured
                                </span>
                            </div>
                        )}

                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
};

export default Admin;
