import { useEffect, useState } from "react";

/**
 * Returns the current viewport width, updated on resize via rAF-throttling.
 * Used by glass-styling helpers to scale blur/tint/saturation with screen size
 * so the liquid glass effect reads consistently across 1272px → 2560px+ screens.
 */
export const useViewportWidth = (): number => {
  const [width, setWidth] = useState<number>(() =>
    typeof window === "undefined" ? 1280 : window.innerWidth
  );

  useEffect(() => {
    let frame = 0;
    const onResize = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        setWidth(window.innerWidth);
        frame = 0;
      });
    };

    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  return width;
};
