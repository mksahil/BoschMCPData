const { spawn } = require('child_process');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

class MCPStdioClient {
  constructor() {
    this.mcpProcess = null;
    this.buffer = '';
    this.responseHandlers = new Map();
    this.initialized = false;
  }

  async connect() {
    if (this.mcpProcess) {
      return;
    }

    // Path to your MCP server
    const mcpServerPath = path.join(__dirname, '..', 'mcp-canteen-server', 'dist', 'index.js');

    console.log('Starting MCP server at:', mcpServerPath);

    // Spawn the MCP server process
    this.mcpProcess = spawn('node', [mcpServerPath], {
      env: {
        ...process.env,
        DB_HOST: process.env.DB_HOST,
        DB_USER: process.env.DB_USER,
        DB_PASSWORD: process.env.DB_PASSWORD,
        DB_NAME: process.env.DB_NAME || 'mcp_canteen_menu_globesowin',
        DB_PORT: process.env.DB_PORT || '3306'
      },
      stdio: ['pipe', 'pipe', 'pipe']
    });

    // Handle stdout for responses
    this.mcpProcess.stdout.on('data', (data) => {
      this.buffer += data.toString();
      this.processBuffer();
    });

    // Handle stderr for debug logs
    this.mcpProcess.stderr.on('data', (data) => {
      const message = data.toString();
      if (!message.includes('Database connected successfully') &&
        !message.includes('Canteen MCP server started')) {
        console.error('MCP stderr:', message);
      }
    });

    // Handle process errors
    this.mcpProcess.on('error', (err) => {
      console.error('MCP process error:', err);
    });

    this.mcpProcess.on('close', (code) => {
      console.log(`MCP process exited with code ${code}`);
      this.mcpProcess = null;
      this.initialized = false;
    });

    // Wait a bit for the server to start
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Initialize the connection
    await this.initialize();
  }

  processBuffer() {
    const lines = this.buffer.split('\n');
    this.buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.trim()) {
        try {
          const message = JSON.parse(line);
          this.handleMessage(message);
        } catch (err) {
          console.error('Failed to parse MCP message:', line);
        }
      }
    }
  }

  handleMessage(message) {
    if (message.id && this.responseHandlers.has(message.id)) {
      const handler = this.responseHandlers.get(message.id);
      this.responseHandlers.delete(message.id);

      if (message.error) {
        handler.reject(new Error(message.error.message || 'Unknown error'));
      } else {
        handler.resolve(message.result);
      }
    }
  }

  async sendRequest(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = uuidv4();

      const request = {
        jsonrpc: '2.0',
        id,
        method,
        params
      };

      this.responseHandlers.set(id, { resolve, reject });

      // Write request to stdin
      this.mcpProcess.stdin.write(JSON.stringify(request) + '\n');

      // Timeout after 30 seconds
      setTimeout(() => {
        if (this.responseHandlers.has(id)) {
          this.responseHandlers.delete(id);
          reject(new Error('Request timeout'));
        }
      }, 30000);
    });
  }

  async initialize() {
    const result = await this.sendRequest('initialize', {
      protocolVersion: '2024.11.05',
      capabilities: {},
      clientInfo: {
        name: 'mybgs-companion',
        version: '1.0.0'
      }
    });

    this.initialized = true;
    console.log('MCP initialized successfully');
    return result;
  }

  async listTools() {
    return this.sendRequest('tools/list');
  }

  async callTool(name, args = {}) {
    if (!this.initialized) {
      throw new Error('MCP client not initialized');
    }

    return this.sendRequest('tools/call', {
      name,
      arguments: args
    });
  }

  // Parse natural language query and call appropriate tool
  async processCanteenQuery(query) {
    const lowerQuery = query.toLowerCase();

    try {
      let result;

      // Detect query intent and call appropriate tool
      if (lowerQuery.includes('today') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch') || lowerQuery.includes('breakfast'))) {
        result = await this.callTool('get_menu_by_date', { date: 'today' });
      }
      else if (lowerQuery.includes('tomorrow') && (lowerQuery.includes('menu') || lowerQuery.includes('lunch'))) {
        result = await this.callTool('get_menu_by_date', { date: 'tomorrow' });
      }
      else if (lowerQuery.includes('yesterday') && lowerQuery.includes('menu')) {
        result = await this.callTool('get_menu_by_date', { date: 'yesterday' });
      }
      else if (lowerQuery.includes('week') && lowerQuery.includes('menu')) {
        result = await this.callTool('get_weekly_menu', {});
      }
      else {
        // Search for specific food items
        const foodItems = ['dosa', 'biryani', 'paneer', 'chicken', 'fish', 'egg', 'idli', 'vada', 'rice', 'chapati', 'roti', 'dal', 'sambar'];
        const foundItem = foodItems.find(item => lowerQuery.includes(item));

        if (foundItem) {
          if (lowerQuery.includes('when') || lowerQuery.includes('available') || lowerQuery.includes('next')) {
            result = await this.callTool('check_item_availability', { itemName: foundItem });
          } else {
            result = await this.callTool('search_menu_item', { searchTerm: foundItem });
          }
        }
        else if (lowerQuery.includes('special')) {
          result = await this.callTool('get_special_menu_days', {});
        }
        else {
          // Default to today's menu if can't determine intent
          result = await this.callTool('get_menu_by_date', { date: 'today' });
        }
      }

      return result;

    } catch (error) {
      console.error('Error processing canteen query:', error);
      throw error;
    }
  }

  disconnect() {
    if (this.mcpProcess) {
      this.mcpProcess.kill();
      this.mcpProcess = null;
      this.initialized = false;
    }
  }
}

// Singleton instance
let mcpClient = null;

module.exports = {
  getClient: async () => {
    if (!mcpClient) {
      mcpClient = new MCPStdioClient();
      await mcpClient.connect();
    }
    return mcpClient;
  }
};
