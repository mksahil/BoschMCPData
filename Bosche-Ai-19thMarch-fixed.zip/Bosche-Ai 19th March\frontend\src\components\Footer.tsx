import { useTheme } from "next-themes";

export const Footer = () => {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  return (
    <footer
      className="fixed bottom-0 left-0 right-0 z-50 w-full py-4 px-4 border-t backdrop-blur-md"
      style={{
        background: isDark
          ? "rgba(6,6,14,0.72)"
          : "rgba(235,240,255,0.80)",
        borderColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
      }}
    >
      <div className="container mx-auto flex flex-col items-center gap-1">
        <p
          className="text-center text-xs"
          style={{ color: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.50)" }}
        >
          Inside myBGSW page Process Owner - BGSW/BDO. Brought to you by BD/APA-IN
        </p>
        <a
          href="/dpn.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs underline underline-offset-2 transition-colors hover:text-primary"
          style={{ color: isDark ? "rgba(255,255,255,0.40)" : "rgba(0,0,0,0.45)" }}
        >
          Data Protection Notice
        </a>
      </div>
    </footer>
  );
};
