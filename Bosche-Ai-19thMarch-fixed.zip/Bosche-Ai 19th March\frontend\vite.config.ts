import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    allowedHosts: true, // Allow all hosts (ngrok, tunnels, etc.)
    proxy: {
      // Proxy all /api requests to backend
      '/api': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true,
        secure: false,
      }
    }
  },
  plugins: [react()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  optimizeDeps: {
    // Prevents "file does not exist in optimizeDeps directory" errors
    // caused by stale Vite cache entries after hot-reload or package updates.
    force: mode === 'development' ? false : false,
    holdUntilCrawlEnd: true,
  },
}));
