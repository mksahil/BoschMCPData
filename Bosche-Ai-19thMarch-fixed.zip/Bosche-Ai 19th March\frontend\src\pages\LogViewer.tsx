import { useState, useEffect } from "react";
import { format } from "date-fns";
import { 
  Search, 
  Calendar, 
  Download, 
  FileJson, 
  FileSpreadsheet,
  User,
  Activity,
  Clock,
  RefreshCw,
  Filter
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { API_ENDPOINTS } from "@/config";

interface LogEntry {
  sessionId: string;
  timestamp: string;
  action: string;
  page: string;
  details?: any;
  serverTimestamp: string;
  ip: string;
}

export const LogViewer = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [sessions, setSessions] = useState<string[]>([]);
  const [selectedSession, setSelectedSession] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedSession) params.append('sessionId', selectedSession);
      else if (selectedDate) params.append('date', selectedDate);
      params.append('limit', '200');

      const response = await fetch(`${API_ENDPOINTS.logs}?${params}`);
      const data = await response.json();
      setLogs(data.logs || []);
    } catch (error) {
      console.error('Error fetching logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSessions = async () => {
    try {
      const response = await fetch(API_ENDPOINTS.sessions);
      const data = await response.json();
      setSessions(data.sessions || []);
    } catch (error) {
      console.error('Error fetching sessions:', error);
    }
  };

  useEffect(() => {
    fetchLogs();
    fetchSessions();
  }, [selectedSession, selectedDate]);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(fetchLogs, 2000);
    return () => clearInterval(interval);
  }, [autoRefresh, selectedSession, selectedDate]);

  const downloadLogs = async (format: 'json' | 'csv') => {
    const params = new URLSearchParams();
    if (selectedDate) params.append('date', selectedDate);
    params.append('format', format);

    window.open(`${API_ENDPOINTS.logsDownload}?${params}`);
  };

  const getActionColor = (action: string) => {
    if (action.includes('error')) return 'text-destructive';
    if (action.includes('chat')) return 'text-primary';
    if (action.includes('button_click')) return 'text-success';
    if (action.includes('page_view')) return 'text-info';
    return 'text-muted-foreground';
  };

  const getActionIcon = (action: string) => {
    if (action.includes('chat')) return '💬';
    if (action.includes('button_click')) return '🖱️';
    if (action.includes('page_view')) return '📄';
    if (action.includes('error')) return '❌';
    return '📌';
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-card rounded-xl shadow-elevated p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">Activity Logs Viewer</h1>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => downloadLogs('json')}
                className="px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg flex items-center gap-2 text-sm"
              >
                <Download className="w-4 h-4" />
                JSON
              </button>
              <button
                onClick={() => downloadLogs('csv')}
                className="px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg flex items-center gap-2 text-sm"
              >
                <Download className="w-4 h-4" />
                CSV
              </button>
              <button
                onClick={fetchLogs}
                disabled={loading}
                className="px-4 py-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg flex items-center gap-2 text-sm disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Calendar className="w-4 h-4" />
                Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setSelectedSession('');
                }}
                className="w-full px-3 py-2 bg-secondary rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                <User className="w-4 h-4" />
                Session
              </label>
              <select
                value={selectedSession}
                onChange={(e) => setSelectedSession(e.target.value)}
                className="w-full px-3 py-2 bg-secondary rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">All Sessions</option>
                {sessions.map(session => (
                  <option key={session} value={session}>{session}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Filter className="w-4 h-4" />
                Auto-Refresh
              </label>
              <button
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={`w-full px-3 py-2 rounded-lg border transition-colors ${
                  autoRefresh 
                    ? 'bg-primary text-primary-foreground border-primary' 
                    : 'bg-secondary border-border hover:bg-secondary/80'
                }`}
              >
                {autoRefresh ? 'Enabled (2s)' : 'Disabled'}
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Total Logs</p>
              <p className="text-xl font-bold text-foreground">{logs.length}</p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Page Views</p>
              <p className="text-xl font-bold text-foreground">
                {logs.filter(log => log.action === 'page_view').length}
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Chat Messages</p>
              <p className="text-xl font-bold text-foreground">
                {logs.filter(log => log.action === 'chat_message').length}
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Button Clicks</p>
              <p className="text-xl font-bold text-foreground">
                {logs.filter(log => log.action === 'button_click').length}
              </p>
            </div>
          </div>

          {/* Logs Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 font-medium text-foreground">Time</th>
                  <th className="text-left py-3 px-2 font-medium text-foreground">Action</th>
                  <th className="text-left py-3 px-2 font-medium text-foreground">Page</th>
                  <th className="text-left py-3 px-2 font-medium text-foreground">Details</th>
                  <th className="text-left py-3 px-2 font-medium text-foreground">Session</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {logs.map((log, idx) => (
                  <tr key={idx} className="hover:bg-secondary/50 transition-colors">
                    <td className="py-3 px-2 text-xs text-muted-foreground">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className={`py-3 px-2 font-medium ${getActionColor(log.action)}`}>
                      <span className="flex items-center gap-2">
                        <span>{getActionIcon(log.action)}</span>
                        <span>{log.action}</span>
                      </span>
                    </td>
                    <td className="py-3 px-2 text-muted-foreground">{log.page || '-'}</td>
                    <td className="py-3 px-2 text-xs text-muted-foreground max-w-xs truncate">
                      {log.details ? JSON.stringify(log.details) : '-'}
                    </td>
                    <td className="py-3 px-2 text-xs text-muted-foreground">
                      {log.sessionId.substring(0, 8)}...
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {logs.length === 0 && !loading && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No logs found for the selected filters</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
