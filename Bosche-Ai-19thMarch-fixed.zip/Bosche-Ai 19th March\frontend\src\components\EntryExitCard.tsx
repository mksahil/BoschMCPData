import { useState, useEffect } from "react";
import { LogIn, Loader2, RefreshCw } from "lucide-react";
import { useTheme } from "next-themes";
import { DashboardCard } from "./DashboardCard";
import { useAuth } from "@/context/AuthContext";
import { API_BASE_URL } from "@/config";
import { useRateLimit } from "@/hooks/useRateLimit";
import { formatCountdown } from "./RateLimitBanner";

interface EmployeeStatus {
  name: string;
  status: 'IN' | 'OUT' | 'unknown';
  lastSwipe: string | null;
  location: string | null;
}

export const EntryExitCard = () => {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const labelColor = isDark ? "#cecece" : undefined;
  const iconFilter = isDark ? "brightness(0) invert(0.81)" : undefined;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [employeeData, setEmployeeData] = useState<EmployeeStatus>({
    name: 'Loading...',
    status: 'unknown',
    lastSwipe: null,
    location: null
  });

  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  const fetchEmployeeData = async () => {
    setLoading(true);
    setError(null);

    const employeeNumber = user?.employeeNumber || '34835634';

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Employee-Number': employeeNumber
    };

    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }

    try {
      const [nameResponse, statusResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/api/time-tracking/employee-name`, { headers }),
        fetch(`${API_BASE_URL}/api/time-tracking/current-status`, { headers })
      ]);

      if (nameResponse.status === 429 || statusResponse.status === 429) {
        const limitedResponse = nameResponse.status === 429 ? nameResponse : statusResponse;
        const limitedData = await limitedResponse.json();
        handleRateLimitResponse(limitedResponse, limitedData);
        setError('Too many requests. Please wait before retrying.');
        return;
      }

      const nameData = await nameResponse.json();
      const statusData = await statusResponse.json();

      setEmployeeData({
        name: nameData.success ? nameData.name : 'Unknown',
        status: statusData.success ? statusData.status : 'unknown',
        lastSwipe: statusData.success ? statusData.lastSwipe : null,
        location: statusData.success ? statusData.location : null
      });
    } catch (err) {
      console.error('Error fetching employee data:', err);
      setError('Failed to load data');
      setEmployeeData({
        name: user?.name || 'Unknown',
        status: 'unknown',
        lastSwipe: null,
        location: null
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeeData();
  }, [user?.employeeNumber, user?.accessToken]);

  const formatLastSwipe = (swipeTime: string | null) => {
    if (!swipeTime) return 'N/A';
    try {
      const date = new Date(swipeTime);
      const datePart = date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric'
      });
      const timePart = date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
      return `${datePart}, ${timePart}`;
    } catch {
      return swipeTime;
    }
  };

  const isCheckedIn = employeeData.status === 'IN';

  return (
    <DashboardCard title="Entry & Exit" icon={LogIn}>
      <div className="flex flex-col h-full space-y-4">

        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between pb-3">
            <span className="text-xs font-semibold text-foreground">
              Employee Info
            </span>
            <button
              onClick={fetchEmployeeData}
              disabled={loading || isRateLimited}
              className="p-1 hover:bg-secondary/40 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title={isRateLimited ? `Rate limited — retry in ${formatCountdown(retryAfter)}` : "Refresh"}
            >
              <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <hr className="border-border/50" />
        </div>

        {/* Content area */}
        <div className="flex-1 flex flex-col justify-center">
          {loading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
            </div>
          ) : error ? (
            <div
              className="flex flex-col items-center justify-center flex-1 h-full min-h-[180px] gap-3 p-6 text-center rounded-2xl"
              style={{ background: "#000000" }}
            >
              <img
                src="/error.svg"
                alt="Error"
                className="w-10 h-10 mb-1"
                style={{ filter: "invert(1)" }}
              />
              <p className="text-sm font-medium max-w-[280px]" style={{ color: "#ffffff" }}>
                {error || "Check-in data unavailable"}
              </p>
              {isRateLimited && (
                <p className="text-xs font-medium tracking-wide" style={{ color: "#ffffff" }}>
                  Available again in {formatCountdown(retryAfter)}...
                </p>
              )}
              <button
                onClick={fetchEmployeeData}
                disabled={isRateLimited}
                className="px-6 py-2 mt-2 rounded-lg text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed w-32"
                style={{ background: "#ffffff", color: "#000000" }}
              >
                {isRateLimited ? "Paused" : "Try Again"}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-4 items-start">
              {/* Name */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground" style={{ color: labelColor }}>
                  <img src="/grey_user.svg" alt="User" className="w-4 h-4" style={{ filter: iconFilter }} />
                  <span className="text-xs font-medium">Name</span>
                </div>
                <p className="text-lg md:text-xl font-semibold text-foreground leading-tight line-clamp-2" title={employeeData.name}>
                  {employeeData.name}
                </p>
              </div>

              {/* Last Swipe */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground" style={{ color: labelColor }}>
                  <img src="/last_swipe.svg" alt="Last Swipe" className="w-4 h-4" style={{ filter: iconFilter }} />
                  <span className="text-xs font-medium">Last Swipe</span>
                </div>
                <p className="text-base md:text-lg font-medium text-foreground leading-snug whitespace-nowrap">
                  {formatLastSwipe(employeeData.lastSwipe)}
                </p>
              </div>

              {/* Location */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground" style={{ color: labelColor }}>
                  <img src="/location.svg" alt="Location" className="w-3.5 h-4 object-contain" style={{ filter: iconFilter }} />
                  <span className="text-xs font-medium">Location</span>
                </div>
                <p className="text-lg md:text-xl font-medium text-foreground">
                  {employeeData.location || "N/A"}
                </p>
              </div>

              {/* Status Pill */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground" style={{ color: labelColor }}>
                  <img src="/entry_exit_status.svg" alt="Status" className="w-4 h-4" style={{ filter: iconFilter }} />
                  <span className="text-xs font-medium">Status</span>
                </div>
                <div>
                  {/* Conic arc ring — liquid premium border */}
                  <div
                    style={{
                      display: "inline-flex",
                      borderRadius: "9999px",
                      padding: "1.5px",
                      background: "conic-gradient(from 0deg, #0a84ff 0deg, #0a84ff 100deg, rgba(255,255,255,0.50) 104deg, rgba(255,255,255,0.50) 108deg, #0a84ff 112deg, #0a84ff 280deg, rgba(255,255,255,0.95) 284deg, rgba(255,255,255,0.95) 288deg, #0a84ff 292deg, #0a84ff 360deg)",
                      boxShadow: "0 2px 10px rgba(0, 102, 170, 0.45)",
                    }}
                  >
                    <span
                      className="inline-flex items-center px-4 py-1.5 rounded-full text-sm font-semibold"
                      style={{
                        background: "rgb(10, 132, 255)",
                        color: "#ffffff",
                      }}
                    >
                      {employeeData.status === 'IN' ? 'Work From Office' :
                        employeeData.status === 'OUT' ? 'Checked Out' : 'Unknown'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Status Indicator (Bottom Label) */}
        {!loading && !error && (
          <div
            className="mt-4 p-2.5 rounded-3xl flex items-center gap-2"
            style={{ background: isCheckedIn ? "#B8EFC9" : "#FFD9D9" }}
          >
            <img
              src={isCheckedIn ? "/alert_sucess.svg" : "/error.svg"}
              alt="Status"
              className="w-4 h-4 flex-shrink-0"
            />
            <span className="text-[13px] font-medium" style={{ color: "#000000" }}>
              {isCheckedIn ? 'You are currently IN office' :
                employeeData.status === 'OUT' ? 'You have checked OUT' :
                  'Status unavailable'}
            </span>
          </div>
        )}

      </div>
    </DashboardCard>
  );
};
