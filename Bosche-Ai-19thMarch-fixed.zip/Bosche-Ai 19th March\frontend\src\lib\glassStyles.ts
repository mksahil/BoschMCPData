import type { CSSProperties } from "react";

/**
 * Shared liquid-glass styling. Single source of truth used by DashboardCard,
 * ChatWindow and any future glass surface so changes propagate everywhere
 * at once instead of drifting per-component.
 *
 * Blur, tint and saturation scale with viewport width so the glass effect
 * looks consistent across screens — at 1920px+ the larger card surface needs
 * a stronger blur and a slightly more opaque tint to match the perceived
 * depth of the same glass at 1280px.
 */

export const GLASS_RADIUS_PX = 24;

export const GLASS_ARC_BORDER_GRADIENT =
  "conic-gradient(from 0deg, rgba(255,255,255,0) 0deg, rgba(255,255,255,0) 125deg, rgba(255,255,255,0.45) 129deg, rgba(255,255,255,0.45) 133deg, rgba(255,255,255,0) 137deg, rgba(255,255,255,0) 308deg, rgba(255,255,255,0.90) 312deg, rgba(255,255,255,0.90) 317deg, rgba(255,255,255,0) 321deg, rgba(255,255,255,0) 360deg)";

const BREAKPOINT_MIN = 1280;
const BREAKPOINT_MAX = 2560;

/** Linear interpolate `a → b` based on viewport width, clamped at both ends. */
const interpolate = (vw: number, a: number, b: number): number => {
  const t = Math.min(Math.max((vw - BREAKPOINT_MIN) / (BREAKPOINT_MAX - BREAKPOINT_MIN), 0), 1);
  return a + (b - a) * t;
};

/** Inline style for the inner glass container (background, blur, border, shadow). */
export const getGlassContainerStyles = (isDark: boolean, viewportWidth: number = BREAKPOINT_MIN): CSSProperties => {
  const blurPx = interpolate(viewportWidth, 30, 56);
  const saturationPct = interpolate(viewportWidth, 175, 205);
  const tintAlpha = isDark
    ? interpolate(viewportWidth, 0.20, 0.36)
    : interpolate(viewportWidth, 0.18, 0.32);

  const filter = `blur(${blurPx.toFixed(1)}px) saturate(${saturationPct.toFixed(0)}%)`;

  return {
    background: isDark
      ? `rgba(24,28,48,${tintAlpha.toFixed(3)})`
      : `rgba(245,245,255,${tintAlpha.toFixed(3)})`,
    backdropFilter: filter,
    WebkitBackdropFilter: filter,
    border: isDark ? "1px solid rgba(255,255,255,0.17)" : "1px solid rgba(0,0,0,0.08)",
    boxShadow: isDark
      ? "inset 0 1px rgba(255,255,255,0.20), inset 0 -1px rgba(255,255,255,0.04), 0 12px 40px rgba(0,0,0,0.28)"
      : "inset 0 1px 1px rgba(255,255,255,0.8), inset 0 -1px 1px rgba(255,255,255,0.3), 0 16px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.03)",
  };
};

/** Conic gradient masked to a 1px border ring. Renders the two liquid-arc highlights. */
export const getGlassArcBorderStyles = (radius: number = GLASS_RADIUS_PX): CSSProperties => ({
  position: "absolute",
  inset: 0,
  borderRadius: `${radius}px`,
  padding: "1px",
  background: GLASS_ARC_BORDER_GRADIENT,
  WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
  WebkitMaskComposite: "xor",
  mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
  maskComposite: "exclude",
  pointerEvents: "none",
  zIndex: 1,
});

/** Subtle top-of-card light reflection. */
export const getGlassSpecularStyles = (radius: number = GLASS_RADIUS_PX): CSSProperties => ({
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "40%",
  borderRadius: `${radius}px ${radius}px 0 0`,
  background: "linear-gradient(180deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 100%)",
  pointerEvents: "none",
  zIndex: 0,
});
