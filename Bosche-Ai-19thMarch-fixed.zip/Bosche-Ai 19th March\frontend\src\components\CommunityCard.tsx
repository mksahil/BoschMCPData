import { useState, useEffect } from "react";
import { Users, RefreshCw, Loader2, AlertCircle, MapPin, CheckCircle2, Info, ChevronDown, ChevronUp } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { API_BASE_URL } from "@/config";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { useRateLimit } from "@/hooks/useRateLimit";
import { formatCountdown } from "./RateLimitBanner";

// ── Name normalisation helper ─────────────────────────────────────────────
// The registered-community API and the main community-list API sometimes
// differ on whether the word "Community" (or "Club", "Group") is part of
// the name.  e.g. registered list → "Art in Motion Community", main list
// → "Art in Motion".  Strip those generic suffixes before comparing so
// both resolve to the same key.
function normalizeCommunityName(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/\b(community|club|group|association|society|team)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ── Joined-community persistence ──────────────────────────────────────────
// We have no API field for "is the logged-in user already a member?".
// Instead we track joined community IDs in sessionStorage so the planet card
// can suppress the "Join Community" button for communities already joined —
// whether the join happened via the planet UI or via the chat interface.
// sessionStorage lifetime matches the login session (cleared on tab close).
const JOINED_COMM_KEY = 'mybgsw_joined_communities';

export function loadJoinedCommunityIds(): Set<number> {
  try {
    const stored = sessionStorage.getItem(JOINED_COMM_KEY);
    return stored ? new Set(JSON.parse(stored) as number[]) : new Set();
  } catch { return new Set(); }
}

export function persistJoinedCommunityId(communityId: number): void {
  try {
    const ids = loadJoinedCommunityIds();
    ids.add(communityId);
    sessionStorage.setItem(JOINED_COMM_KEY, JSON.stringify([...ids]));
  } catch { /* storage quota or private-mode — ignore */ }
}

interface CommunityLocation {
  id: number;
  name: string;
  code: string;
}

interface Community {
  id: number;
  name: string;
  description: string;
  members: number;
  color: string;
  icon: string | null;
  category: string;
  locations: CommunityLocation[];
}

export const CommunityCard = () => {
  const { user } = useAuth();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [viewAll, setViewAll] = useState(false);

  // Accordion state tracks the open community ID
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [joining, setJoining] = useState(false);
  const [joinSuccess, setJoinSuccess] = useState<string | null>(null);

  // IDs of communities the user has joined (this session or detected via chat).
  // Initialised from sessionStorage so reopening the planet card shows correct state.
  const [joinedIds, setJoinedIds] = useState<Set<number>>(() => loadJoinedCommunityIds());
  // Normalised lowercase names from the registered-community API.
  // Used as a fallback when the registered API uses different numeric IDs
  // than the main community-list API for the same communities.
  const [joinedNames, setJoinedNames] = useState<Set<string>>(new Set());

  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  const handleJoinCommunity = async (community: Community, location: CommunityLocation) => {
    setJoining(true);
    setJoinSuccess(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
        },
        body: JSON.stringify({
          communityId: community.id,
          locationId: location.id,
        }),
      });
      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        const retry = parseInt(response.headers.get('Retry-After') || '60', 10);
        toast.error(`Too many requests. Please wait ${formatCountdown(retry)} before retrying.`);
        return;
      }

      // Detect if the backend is telling us the user is already an existing
      // member of this community. In that case we must NOT increment the
      // member count — regardless of whether the upstream flag says success.
      const rawMessage: string = (data.message || data.error || '').toString();
      const alreadyMemberRegex = /already\s+(a\s+)?(member|registered|joined|part|enrolled|subscribed)|already\s+exists?|duplicate\s+registration|member\s+exists/i;
      const isAlreadyMember = alreadyMemberRegex.test(rawMessage);

      if (data.success && !isAlreadyMember) {
        setJoinSuccess(data.message || `Successfully joined ${community.name}!`);
        toast.success(data.message || `Successfully joined ${community.name}!`);

        // Persist the joined community ID so the planet card shows "Member ✓"
        // even if the user closes and reopens it later in the same session.
        persistJoinedCommunityId(community.id);
        setJoinedIds(prev => { const next = new Set(prev); next.add(community.id); return next; });
        setJoinedNames(prev => { const next = new Set(prev); next.add(normalizeCommunityName(community.name)); return next; });

        setCommunities(prev => prev.map(c =>
          c.id === community.id
            ? { ...c, members: c.members + 1 }
            : c
        ));

        // Re-fetch the authoritative list after a short delay so the count
        // reflects the server value once the backend cache has been busted.
        setTimeout(() => fetchCommunities(), 1500);

      } else if (isAlreadyMember) {
        const friendlyMsg = rawMessage || `You are already a member of ${community.name}.`;
        setJoinSuccess(friendlyMsg);
        toast.info(friendlyMsg);

        // Mark as joined so future visits in this session skip the Join button.
        persistJoinedCommunityId(community.id);
        setJoinedIds(prev => { const next = new Set(prev); next.add(community.id); return next; });
        setJoinedNames(prev => { const next = new Set(prev); next.add(normalizeCommunityName(community.name)); return next; });
      } else {
        toast.error(rawMessage || 'Failed to join community');
      }
    } catch (err) {
      console.error('Error joining community:', err);
      toast.error('Unable to join community. Please try again.');
    } finally {
      setJoining(false);
      setShowLocationPicker(false);
    }
  };

  // Fetches the communities the user is actually registered to from the server.
  // This is the authoritative source — sessionStorage is only a local cache.
  const fetchRegisteredCommunities = async () => {
    if (!user?.accessToken) return;
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/registered`, {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json',
          // Required so the backend passes the correct employee identity headers
          // to the Bosch registered-community API (same as the chat flow does)
          'X-Employee-Number': user.employeeNumber || '',
          'X-User-Name': user.name || '',
        },
      });
      const data = await response.json();
      if (data.success) {
        // ── IDs ──────────────────────────────────────────────────────────────
        // IMPORTANT: data.communityIds contains RegisteredCommunityId values
        // from the Bosch registered-community API.  These live in a DIFFERENT
        // numeric namespace from the CommunityId values used in the main
        // community-list API.  Adding them to joinedIds causes false positives
        // (e.g. RegisteredCommunityId 3 for "Women's Cricket" coincidentally
        // equals CommunityId 3 for "Path Finder" → Path Finder gets highlighted
        // even though the user never joined it).
        //
        // Therefore we do NOT merge server IDs into joinedIds.
        // joinedIds is kept exclusively for optimistic in-session joins
        // (handleJoinCommunity / sessionStorage) where the ID comes directly
        // from community.id in the main list and is guaranteed correct.
        const storedIds = loadJoinedCommunityIds();
        setJoinedIds(storedIds);

        // ── Names (primary server-side match) ────────────────────────────────
        // Normalise names by stripping generic suffixes ("community", "club" …)
        // so "Art in Motion Community" (registered API) and "Art in Motion"
        // (main list) both normalise to "art in motion" and compare equal.
        if (Array.isArray(data.communityNames)) {
          setJoinedNames(new Set<string>(
            (data.communityNames as string[]).map(n => normalizeCommunityName(n))
          ));
        }
      }
    } catch (err) {
      console.warn('[CommunityCard] Could not fetch registered communities:', err);
      // Fall back to whatever sessionStorage has — already in state
    }
  };

  const fetchCommunities = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/list?page=1&pageSize=50`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        }
      });
      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        setError('Too many requests. Please wait before retrying.');
        return;
      }

      if (data.success && data.communities) {
        setCommunities(data.communities);
        setTotalCount(data.totalCount || data.communities.length);
      } else {
        setError('Failed to load communities');
      }
    } catch (err) {
      console.error('Error fetching communities:', err);
      setError('Unable to connect to community service');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCommunities();
    // Fetch the user's actual registered communities from the server on every
    // mount — this is the authoritative source and replaces the brittle
    // sessionStorage-only approach (which breaks on refresh or new tab).
    fetchRegisteredCommunities();
  }, []);

  if (loading) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <span className="ml-2 text-sm text-muted-foreground">Loading communities...</span>
        </div>
      </DashboardCard>
    );
  }

  if (error) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex flex-col items-center justify-center flex-1 h-full min-h-[256px] gap-3 p-6 text-center">
          <div className="w-12 h-12 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-2">
            <AlertCircle className="w-6 h-6 text-amber-500" />
          </div>
          <p className="text-sm text-foreground font-medium max-w-[280px]">
            {error || "Communities unavailable"}
          </p>
          {isRateLimited && (
            <p className="text-xs text-amber-500 font-medium tracking-wide">
              Available again in {formatCountdown(retryAfter)}...
            </p>
          )}
          <button
            onClick={fetchCommunities}
            disabled={isRateLimited}
            className="px-6 py-2 mt-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed w-32"
          >
            {isRateLimited ? "Paused" : "Try Again"}
          </button>
        </div>
      </DashboardCard>
    );
  }

  const displayedCommunities = viewAll ? communities : communities.slice(0, 6);

  // Group communities by their category for the Section Titles
  const groupedCommunities = displayedCommunities.reduce((acc, community) => {
    const category = community.category && community.category !== 'General' && !community.category.startsWith('#')
      ? community.category
      : 'General';
    if (!acc[category]) acc[category] = [];
    acc[category].push(community);
    return acc;
  }, {} as Record<string, Community[]>);

  return (
    <DashboardCard
      title="Community & Events"
      icon={Users}
      action={
        <button
          onClick={fetchCommunities}
          disabled={loading || isRateLimited}
          className="p-1 hover:bg-secondary/40 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          title={isRateLimited ? `Rate limited — retry in ${formatCountdown(retryAfter)}` : "Refresh"}
        >
          <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
        </button>
      }
    >
      <div className="space-y-4">
        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between pb-3">
            <span className="text-xs font-semibold text-foreground">
              {totalCount} Active Communities
            </span>
            {totalCount > 6 && (
              <button
                onClick={() => setViewAll(!viewAll)}
                className="text-xs text-[#0a84ff] hover:underline font-medium"
              >
                {viewAll ? "Show less" : `View all (${totalCount})`}
              </button>
            )}
          </div>
          <hr className="border-border/50" />
        </div>

        {/* Accordion List */}
        <div className={cn(
          "space-y-6 overflow-y-auto pr-1 transition-all duration-300 custom-scrollbar",
          viewAll ? "max-h-[450px]" : "max-h-[320px]"
        )}>
          {Object.entries(groupedCommunities).map(([category, comms]) => (
            <div key={category} className="space-y-0">
              <h4 className="text-[11px] font-bold text-muted-foreground tracking-wide mb-2 px-1">
                {category === 'General' ? '' : category}
              </h4>

              <div className="border-t border-border/50">
                {comms.map((community) => {
                  const isExpanded = expandedId === community.id;
                  // Match by ID first; fall back to normalised name comparison
                  // because RegisteredCommunityId in the registered API may differ
                  // numerically from CommunityId in the main community-list API.
                  // Both sides must use normalizeCommunityName so that e.g.
                  // "Art in Motion" (main list) matches "Art in Motion Community"
                  // (registered API) — both normalise to "art in motion".
                  const isMember = joinedIds.has(community.id)
                    || joinedNames.has(normalizeCommunityName(community.name));

                  return (
                    <div
                      key={community.id}
                      className={cn(
                        "border-b border-border/50 flex flex-col transition-colors",
                        isMember && "bg-green-500/5 dark:bg-green-500/8"
                      )}
                    >
                      {/* Row Header */}
                      <button
                        onClick={() => {
                          if (isExpanded) {
                            setExpandedId(null);
                            setShowLocationPicker(false);
                            setJoinSuccess(null);
                          } else {
                            setExpandedId(community.id);
                            setShowLocationPicker(false);
                            setJoinSuccess(null);
                          }
                        }}
                        className="flex items-center w-full py-3.5 px-2 hover:bg-secondary/20 transition-colors text-left relative"
                      >
                        {/* Left accent — green for members, blue otherwise */}
                        <div className={cn(
                          "absolute left-0 top-0 bottom-0 w-1",
                          isMember ? "bg-green-500" : "bg-[#0a84ff]"
                        )} />

                        <div className="flex items-center gap-3 ml-3 flex-1">
                          <div className="relative flex items-center justify-center p-0.5">
                            {isMember
                              ? <CheckCircle2 className="w-4 h-4 text-green-500" />
                              : <Info className="w-4 h-4 text-muted-foreground" />
                            }
                            {!isMember && (
                              <div className="absolute top-0 right-0 w-1.5 h-1.5 rounded-full bg-[#0a84ff]" />
                            )}
                          </div>
                          <span className={cn(
                            "text-[13px] font-medium flex-1 pr-2 tracking-wide",
                            isMember ? "text-green-700 dark:text-green-300" : "text-foreground"
                          )}>
                            {community.name}
                          </span>
                          {/* Member badge */}
                          {isMember && (
                            <span className="flex items-center gap-1 text-[10px] bg-green-500/15 text-green-700 dark:text-green-400 border border-green-500/25 px-2 py-0.5 rounded-full font-semibold flex-shrink-0">
                              <CheckCircle2 className="w-3 h-3" /> Member
                            </span>
                          )}
                        </div>

                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </button>

                      {/* Accordion Body */}
                      {isExpanded && (
                        <div className="px-5 py-4 bg-secondary/5 space-y-4 animate-in slide-in-from-top-2 duration-200 border-l-[4px] border-[#0a84ff]">
                          {/* Description */}
                          <div>
                            <p className="text-[11px] font-bold text-muted-foreground tracking-wide mb-1.5 uppercase">About</p>
                            <p className="text-xs text-foreground/80 leading-relaxed">
                              {community.description && !community.description.startsWith('#')
                                ? community.description
                                : 'No description available for this community.'}
                            </p>
                          </div>

                          {/* Members */}
                          <div className="flex items-center gap-2 bg-background/50 inline-flex px-3 py-1.5 rounded-full">
                            <Users className="w-3.5 h-3.5 text-[#0a84ff]" />
                            <span className="text-[11px] font-semibold text-foreground">{community.members} members</span>
                          </div>

                          {/* Join Actions */}
                          {isMember && !showLocationPicker ? (
                            // Community was already joined (this session or via chat) — show member badge
                            <div className="flex items-center gap-2 p-2.5 bg-green-500/10 border border-green-500/20 rounded-lg mt-2">
                              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                              <p className="text-xs text-green-700 dark:text-green-400">
                                {joinSuccess || `You are already a member of ${community.name}.`}
                              </p>
                            </div>
                          ) : joinSuccess ? (
                            <div className="flex items-center gap-2 p-2.5 bg-green-500/10 border border-green-500/20 rounded-lg mt-2">
                              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                              <p className="text-xs text-green-700 dark:text-green-400">{joinSuccess}</p>
                            </div>
                          ) : showLocationPicker ? (
                            <div className="space-y-2 pt-2 border-t border-border/50 mt-2">
                              <p className="text-xs font-medium text-foreground flex items-center gap-1 mb-2">
                                <MapPin className="w-3 h-3" /> Select your location
                              </p>
                              <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
                                {community.locations && community.locations.length > 0 ? (
                                  community.locations.map((loc) => (
                                    <button
                                      key={loc.id}
                                      disabled={joining}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleJoinCommunity(community, loc);
                                      }}
                                      className="w-full text-left px-3 py-2 text-xs bg-secondary/40 hover:bg-primary/10 hover:text-primary rounded-md transition-colors flex items-center justify-between disabled:opacity-50"
                                    >
                                      <span>{loc.name}</span>
                                      {joining ? (
                                        <Loader2 className="w-3 h-3 animate-spin" />
                                      ) : (
                                        <span className="text-[10px] text-muted-foreground">{loc.code}</span>
                                      )}
                                    </button>
                                  ))
                                ) : (
                                  <p className="text-xs text-muted-foreground py-2">No locations available.</p>
                                )}
                              </div>
                              <button
                                onClick={(e) => { e.stopPropagation(); setShowLocationPicker(false); }}
                                className="text-xs text-muted-foreground hover:text-foreground transition-colors mt-1"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="pt-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setJoinSuccess(null);
                                  setShowLocationPicker(true);
                                }}
                                className="arc-btn arc-btn--rect w-full"
                              >
                                <span className="arc-btn-inner gap-1.5">
                                  <Users className="w-3.5 h-3.5" />
                                  Join Community
                                </span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardCard>
  );
};
