import { Calendar, Gift, Palmtree, Star } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const HolidayCalendarCard = () => {
  return (
    <DashboardCard title="Holiday Calendar" icon={Calendar}>
      <div className="space-y-4">
        {/* Next Holiday */}
        <div className="p-4 bg-gradient-accent/10 border border-accent/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Gift className="w-4 h-4 text-accent" />
            <h4 className="text-sm font-semibold text-foreground">Next Holiday</h4>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-lg font-bold text-foreground">Christmas Day</p>
              <p className="text-xs text-muted-foreground">December 25, 2025</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-accent">8</p>
              <p className="text-xs text-muted-foreground">days away</p>
            </div>
          </div>
        </div>

        {/* Upcoming Holidays */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">Upcoming Holidays</h4>

          <div className="p-3 bg-secondary/40 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">New Year's Day</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Jan 1, 2026</p>
          </div>

          <div className="p-3 bg-secondary/40 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Palmtree className="w-4 h-4 text-success" />
                <span className="text-sm font-medium text-foreground">Republic Day</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Jan 26, 2026</p>
          </div>

          <div className="p-3 bg-secondary/40 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Gift className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium text-foreground">Holi</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Mar 14, 2026</p>
          </div>
        </div>

        {/* Summary */}
        <div className="p-3 bg-primary/10 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Total holidays remaining</span>
            <span className="text-lg font-bold text-primary">12</span>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
