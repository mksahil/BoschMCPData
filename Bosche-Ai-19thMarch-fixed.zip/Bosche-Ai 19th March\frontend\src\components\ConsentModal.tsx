import { useState } from 'react';
import { Loader2, ShieldCheck, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ConsentModalProps {
  /** Called after the user submits consent. The parent will save it and dismiss. */
  onConsent: () => Promise<void>;
  /** Display name shown in the greeting */
  userName?: string;
}

/**
 * ConsentModal
 *
 * Shown once after login when the user has not yet given consent.
 * - Non-dismissible (no close button, no backdrop click)
 * - "Continue" is disabled until both checkboxes are ticked
 * - Each document label is a clickable link that opens the PDF in a new tab
 */
export const ConsentModal = ({ onConsent, userName }: ConsentModalProps) => {
  const [checked, setChecked] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canSubmit = checked && !isSubmitting;

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setIsSubmitting(true);
    try {
      await onConsent();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    /* Full-screen overlay — pointer-events blocked so nothing behind is clickable */
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div
        className="relative w-full max-w-lg mx-4 rounded-2xl border border-border/60 bg-card shadow-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="consent-title"
      >
        {/* ── Header ── */}
        <div className="flex flex-col items-center gap-3 px-8 pt-8 pb-4">
          <div className="flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
            <ShieldCheck className="w-7 h-7 text-primary" />
          </div>

          <h2
            id="consent-title"
            className="text-xl font-bold text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
          >
            User Consent Required
          </h2>




          <p className="text-sm text-muted-foreground text-center">
            Please review and accept the following before using MyBGSW.AI.
          </p>

        </div>

        {/* ── Divider ── */}
        <div className="h-px bg-border mx-8" />

        {/* ── Single Checkbox ── */}
        <div className="px-8 py-6">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={checked}
              onChange={(e) => setChecked(e.target.checked)}
              disabled={isSubmitting}
              className="mt-0.5 h-4 w-4 shrink-0 rounded border-gray-300 text-primary
                         focus:ring-primary accent-primary cursor-pointer"
            />
            <span className="text-sm text-foreground leading-relaxed">
              I have read and understood the{' '}
              <a
                href="/terms-of-use.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 font-medium text-primary underline
                           underline-offset-2 hover:text-primary/80 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                Terms of Use
                <ExternalLink className="w-3 h-3" />
              </a>
              {' '}and the{' '}
              <a
                href="/dpn.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 font-medium text-primary underline
                           underline-offset-2 hover:text-primary/80 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                Data Protection Notice
                <ExternalLink className="w-3 h-3" />
              </a>
            </span>
          </label>
        </div>

        {/* ── Divider ── */}
        <div className="h-px bg-border mx-8" />

        {/* ── Footer / CTA ── */}
        <div className="px-8 py-6 flex flex-col gap-3">
          <Button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="w-full h-11 bg-gradient-to-r from-primary to-accent
                       hover:opacity-90 transition-opacity disabled:opacity-40"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving…
              </>
            ) : (
              'I Agree — Continue to MyBGSW.AI'
            )}
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            You must accept both documents to use this application. This consent is recorded
            once and will not be shown again.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConsentModal;
