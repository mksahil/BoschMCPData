import { LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { DarkModeToggle } from "./DarkModeToggle";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { useTheme } from "next-themes";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavigationProps {
  activeSection?: string;
  onSectionChange?: (section: string) => void;
  contextTitle?: string;
}

const navItems = [
  { id: "home", label: "Home" },
  { id: "insights", label: "Insights" },
  { id: "actions", label: "Actions" },
  { id: "mentorship", label: "Mentorship" },
  { id: "learning", label: "Learning" },
  { id: "wellness", label: "Wellness" },
];

export const Navigation = ({ activeSection = "home", onSectionChange, contextTitle }: NavigationProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getInitials = () => {
    if (user?.name && user.name.trim()) {
      const names = user.name.trim().split(' ');
      if (names.length >= 2) return `${names[0][0]}${names[1][0]}`.toUpperCase();
      return names[0].substring(0, 2).toUpperCase();
    }
    return user?.employeeNumber?.substring(0, 2) || 'U';
  };

  return (
    <div className="sticky top-0 z-50 w-full">
      {/* Bosch rainbow strip — at top */}
      <div className="w-full h-1 relative overflow-hidden">
        <img src="/bosch-rainbow.svg" alt="" className="w-full h-full object-cover" />
      </div>

      {/* Full-width header bar */}
      <div
        className="w-full flex items-center justify-between px-5 h-14"
      // style={{
      //   backdropFilter: "blur(20px) saturate(160%)",
      //   WebkitBackdropFilter: "blur(20px) saturate(160%)",
      // }}
      >
        {/* Left: Logo + brand */}
        <div className="flex items-center gap-3 flex-shrink-0 min-w-[180px]">
          <img src="/bgsw-logo.png" alt="MyBGSW Logo" className="w-8 h-8 object-contain" />

          <h1 className={cn("text-sm font-bold leading-none", isDark ? "text-white" : "text-black")}>
            {contextTitle || "MyBGSW.Ai"}
          </h1>

          {/* Divider */}
          <div className="h-4 w-px bg-white/20 mx-1" />

          {/* BGSW block */}
          <div className="flex flex-col leading-none">
            <span className={cn("text-s font-bold tracking-wide", isDark ? "text-white" : "text-black")}>BGSW</span>
            <span className={cn("text-[10px]", isDark ? "text-white" : "text-black")}>alt_future</span>
          </div>
        </div>

        {/* Center: floating nav pill — liquid glass */}
        <div
          className="hidden md:rounded-full md:flex"
          style={{ position: "relative", padding: isDark ? "2px" : undefined }}
        >
          {/* Arc border — conic gradient masked to the 2px border ring only */}
          {isDark && (
            <div
              style={{
                position: "absolute",
                inset: "1px",
                borderRadius: "9999px",
                padding: "2px",
                background: "conic-gradient(from 0deg, rgba(255,255,255,0) 0deg, rgba(255,255,255,0) 87deg, rgba(255,255,255,0.55) 91deg, rgba(255,255,255,0.55) 94deg, rgba(255,255,255,0) 97deg, rgba(255,255,255,0) 265deg, rgba(255,255,255,0.92) 269deg, rgba(255,255,255,0.92) 274deg, rgba(255,255,255,0) 277deg, rgba(255,255,255,0) 360deg)",
                WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                WebkitMaskComposite: "xor",
                mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                maskComposite: "exclude",
                pointerEvents: "none",
                zIndex: 1,
              }}
            />
          )}
          <div
            className="flex items-center gap-0.5 px-1.5 py-1.5 rounded-full"
            style={{
              position: "relative",
              zIndex: 2,
              background: isDark ? "rgba(255,255,255,0.03)" : "rgba(225,225,235,0.20)",
              backdropFilter: isDark ? "blur(24px) saturate(200%)" : undefined,
              WebkitBackdropFilter: isDark ? "blur(24px) saturate(200%)" : undefined,
              boxShadow: isDark
                ? "0 8px 32px rgba(0,0,0,0.12)"
                : "inset 0 1.5px 0 rgba(255,255,255,0.95), inset 0 -1px 0 rgba(0,0,0,0.06), 0 8px 32px rgba(0,0,0,0.10)",
              border: isDark ? undefined : "1px solid rgba(0,0,0,0.08)",
            }}
          >
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange?.(item.id)}
                  className={cn(
                    "nav-pill-btn px-3.5 py-1.5 rounded-full text-sm font-medium whitespace-nowrap",
                    "transition-all duration-[220ms] ease-[cubic-bezier(0.22,1,0.36,1)] will-change-transform",
                    "hover:-translate-y-0.5 hover:brightness-110",
                    "active:translate-y-0 active:scale-[0.97] active:brightness-90",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0a84ff]/60 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent",
                    isActive
                      ? (isDark ? "nav-pill-btn--active-dark" : "nav-pill-btn--active-light")
                      : (isDark ? "nav-pill-btn--dark" : "nav-pill-btn--light")
                  )}
                  style={isActive ? {
                    color: isDark ? "white" : "rgba(0,136,255,1)",
                  } : {
                    color: isDark ? "#8C8C8C" : "#6B7280",
                  }}
                >
                  {item.label}
                </button>
              );
            })}
            {/* Admin button — target-only feature */}
            <button
              onClick={() => navigate('/admin')}
              className={cn(
                "nav-pill-btn px-3.5 py-1.5 rounded-full text-sm font-medium whitespace-nowrap",
                "transition-all duration-[220ms] ease-[cubic-bezier(0.22,1,0.36,1)] will-change-transform",
                "hover:-translate-y-0.5 hover:brightness-110",
                "active:translate-y-0 active:scale-[0.97] active:brightness-90",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0a84ff]/60 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent",
                isDark ? "nav-pill-btn--dark" : "nav-pill-btn--light"
              )}
              style={{ color: isDark ? "#8C8C8C" : "#6B7280" }}
            >
              Admin
            </button>
          </div>
        </div>

        {/* Right: controls */}
        <div className="flex items-center gap-2 flex-shrink-0 min-w-[140px] justify-end">
          {user && (
            <div
              className="hidden sm:flex items-center px-2.5 py-1 rounded-full"
              style={{
                background: isDark ? "rgba(10,132,255,0.12)" : "rgba(10,132,255,0.08)",
                border: "1px solid rgba(10,132,255,0.22)",
              }}
            >
              <span className="text-[11px] font-medium text-[#0a84ff]">
                {user.employeeNumber}
              </span>
            </div>
          )}

          <DarkModeToggle />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 focus:outline-none"
                style={{
                  background: "linear-gradient(135deg, hsl(195 80% 45%), hsl(205 100% 50%))",
                  boxShadow: "0 0 10px rgba(10,132,255,0.30)",
                }}
              >
                <span className="text-white font-semibold text-xs">{getInitials()}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span className="font-semibold">{user?.name?.trim() || 'User'}</span>
                  <span className="text-xs text-muted-foreground font-normal">
                    Employee: {user?.employeeNumber}
                  </span>
                  {user?.entityName && (
                    <span className="text-xs text-muted-foreground font-normal">
                      Entity: {user.entityName}
                    </span>
                  )}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={handleLogout}
                className="text-destructive focus:text-destructive cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};
