import { Users, Search, Star, MessageCircle, Calendar, Award } from "lucide-react";
import { DashboardCard } from "@/components/DashboardCard";
import { ActionCard } from "@/components/ActionCard";

export const MentorshipSection = () => {
  const mentors = [
    {
      name: "Dr. Sarah Chen",
      role: "Senior AI Architect",
      expertise: ["Machine Learning", "Cloud Architecture", "Python"],
      rating: 4.9,
      sessions: 45,
      avatar: "SC"
    },
    {
      name: "Michael Rodriguez",
      role: "IoT Platform Lead",
      expertise: ["IoT", "Edge Computing", "DevOps"],
      rating: 4.8,
      sessions: 38,
      avatar: "MR"
    },
    {
      name: "Priya Sharma",
      role: "Product Management Director",
      expertise: ["Product Strategy", "Leadership", "Innovation"],
      rating: 5.0,
      sessions: 62,
      avatar: "PS"
    }
  ];

  return (
    <div className="relative space-y-8 animate-fade-in">
      {/* Coming Soon badge */}
      <span className="absolute top-0 right-0 inline-flex items-center gap-1.5 bg-amber-100 text-amber-700 border border-amber-300 text-xs font-semibold px-3 py-1.5 rounded-full shadow-sm select-none z-10">
        🚀 Coming Soon
      </span>

      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Mentorship & Networking 🤝
        </h2>
        <p className="text-muted-foreground">
          Connect with leaders, grow your network, and accelerate your career
        </p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ActionCard
          icon={Search}
          title="Find a Mentor"
          description="Search by skills, department, or interests"
        />
        <ActionCard
          icon={MessageCircle}
          title="My Mentorship Sessions"
          description="View upcoming and past mentoring meetings"
        />
        <ActionCard
          icon={Award}
          title="Become a Mentor"
          description="Share your expertise and guide others"
        />
      </div>

      {/* Recommended Mentors */}
      <section>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="w-1 h-6 bg-gradient-primary rounded-full"></div>
          Recommended Mentors for You
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {mentors.map((mentor, idx) => (
            <div
              key={idx}
              className="bg-card rounded-xl p-6 shadow-card hover:shadow-elevated transition-all duration-300 border border-border"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-accent rounded-full flex items-center justify-center text-xl font-bold text-accent-foreground">
                  {mentor.avatar}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground">{mentor.name}</h4>
                  <p className="text-sm text-muted-foreground">{mentor.role}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Star className="w-4 h-4 text-accent fill-accent" />
                    <span className="text-sm font-medium text-foreground">{mentor.rating}</span>
                    <span className="text-xs text-muted-foreground">({mentor.sessions} sessions)</span>
                  </div>
                </div>
              </div>
              <div className="mb-4">
                <p className="text-xs text-muted-foreground mb-2">Expertise:</p>
                <div className="flex flex-wrap gap-2">
                  {mentor.expertise.map((skill, i) => (
                    <span key={i} className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <button className="w-full py-2 bg-gradient-primary text-primary-foreground rounded-lg hover:shadow-glow transition-all duration-300">
                Request Session
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* My Mentorship Activity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DashboardCard title="Upcoming Sessions" icon={Calendar}>
          <div className="space-y-3">
            <div className="p-3 bg-secondary/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Dr. Sarah Chen</p>
                <span className="text-xs px-2 py-1 bg-accent/10 text-accent rounded-full">Tomorrow</span>
              </div>
              <p className="text-xs text-muted-foreground">Career Growth Strategy • 2:00 PM - 3:00 PM</p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-foreground">Michael Rodriguez</p>
                <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">Next Week</span>
              </div>
              <p className="text-xs text-muted-foreground">IoT Best Practices • Dec 18, 10:00 AM</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="My Network Growth" icon={Users}>
          <div className="space-y-4">
            <div className="p-4 bg-gradient-primary rounded-lg">
              <p className="text-xs text-primary-foreground/80 mb-1">Total Connections</p>
              <p className="text-2xl font-bold text-primary-foreground">127</p>
              <p className="text-xs text-primary-foreground/60 mt-1">+12 this month</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground">Mentors</p>
                <p className="text-xl font-bold text-foreground">3</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground">Mentees</p>
                <p className="text-xl font-bold text-foreground">2</p>
              </div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  );
};
