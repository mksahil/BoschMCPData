import { useAuth } from '@/context/AuthContext';
import { useSessionTimeout } from '@/hooks/useSessionTimeout';
import { SessionTimeoutModal } from './SessionTimeoutModal';

interface SessionTimeoutWrapperProps {
  children: React.ReactNode;
}

/**
 * SessionTimeoutWrapper
 *
 * Sits directly inside <AuthProvider> and outside <BrowserRouter>.
 * Connects the useSessionTimeout hook to SessionTimeoutModal and ensures
 * the timeout logic is active for every authenticated route without being
 * mounted on the Login page.
 *
 * Usage in App.tsx:
 *   <AuthProvider>
 *     <SessionTimeoutWrapper>
 *       <BrowserRouter>…routes…</BrowserRouter>
 *     </SessionTimeoutWrapper>
 *   </AuthProvider>
 */
export function SessionTimeoutWrapper({ children }: SessionTimeoutWrapperProps) {
  const { isAuthenticated } = useAuth();
  const { showWarning, countdown, handleStayLoggedIn, handleLogout } =
    useSessionTimeout();

  return (
    <>
      {/* Only mount the modal when the user is actually logged in */}
      {isAuthenticated && (
        <SessionTimeoutModal
          open={showWarning}
          countdown={countdown}
          onStayLoggedIn={handleStayLoggedIn}
          onLogout={handleLogout}
        />
      )}
      {children}
    </>
  );
}

export default SessionTimeoutWrapper;
