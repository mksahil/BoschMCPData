import { ReactNode, useEffect } from "react";
import { LucideIcon } from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";
import {
  getGlassContainerStyles,
  getGlassArcBorderStyles,
  getGlassSpecularStyles,
} from "@/lib/glassStyles";
import { useViewportWidth } from "@/hooks/useViewportWidth";

interface DashboardCardProps {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
  className?: string;
  accent?: boolean;
  action?: ReactNode;
  hideHeader?: boolean;
}

export const DashboardCard = ({ title, children, className, accent, action, hideHeader }: DashboardCardProps) => {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const viewportWidth = useViewportWidth();

  useEffect(() => {
    logger.logFeatureUsage(`dashboard-card-${title.toLowerCase().replace(/\s+/g, '-')}`, {
      cardTitle: title,
      isAccent: accent || false,
      timestamp: new Date().toISOString()
    });
  }, [title, accent]);

  return (
    <div
      className={cn("rounded-3xl transition-all duration-300 ease-out p-px relative", className)}
    >
      {/* Conic-gradient arc border (dark mode only) */}
      {isDark && <div style={getGlassArcBorderStyles()} />}

      {/* Glass container */}
      <div
        className="rounded-3xl flex flex-col h-full relative overflow-hidden"
        style={{ ...getGlassContainerStyles(isDark, viewportWidth), zIndex: 2 }}
      >
        {/* Top specular reflection (dark mode only) */}
        {isDark && <div style={getGlassSpecularStyles()} />}

        {/* Content */}
        <div
          role="button"
          tabIndex={0}
          onClick={() => {
            logger.log('dashboard_card_click', {
              cardTitle: title,
              isAccent: accent || false
            });
          }}
          onKeyDown={(e) => {
            if ((e.key === 'Enter' || e.key === ' ') && e.target === e.currentTarget) {
              e.preventDefault();
              logger.log('dashboard_card_click', {
                cardTitle: title,
                isAccent: accent || false
              });
            }
          }}
          className={cn(
            "relative z-10 p-6 flex flex-col h-full",
            accent && "bg-gradient-subtle"
          )}
        >
          {/* Drag handle */}
          <div className="flex justify-center pb-3 flex-shrink-0">
            <div
              className="w-10 h-1 rounded-full"
              style={{ background: isDark ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.15)" }}
            />
          </div>

          {!hideHeader && (
            <div className="relative flex items-center justify-center mb-4 min-h-[32px]">
              <h3
                className="text-lg font-bold text-center drop-shadow-sm tracking-wide"
                style={{ color: isDark ? "#fff" : "#111" }}
              >
                {title}
              </h3>
              {action && <div className="absolute right-0">{action}</div>}
            </div>
          )}
          <div className="space-y-3">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
