// Mimic the backend privacy logic to verify the fix
const rewriteSafe = new Set([
    'me', 'myself', 'today', 'yesterday', 'tomorrow', 'now', 'free', 'monday', 'tuesday', 'wednesday',
    'thursday', 'friday', 'saturday', 'sunday', 'week', 'month', 'year', 'this', 'that', 'next', 'last',
    'bangalore', 'coimbatore', 'bosch', 'india', 'delhi', 'mumbai', 'chennai', 'hyderabad', 'pune',
    'kolkata', 'goa', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august',
    'september', 'october', 'november', 'december', 'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug',
    'sep', 'oct', 'nov', 'dec', 'entry', 'exit', 'time', 'times', 'attendance', 'check', 'leave',
    'travel', 'booking', 'seat', 'swipe', 'swiped', 'data', 'record', 'records', 'report', 'log',
    'hours', 'working', 'the', 'whole', 'entire', 'complete', 'full', 'past', 'previous', 'current', 'some', 'any',
    'every', 'each', 'all', 'days', 'day', 'lunch', 'dinner', 'breakfast', 'business', 'personal',
    'official', 'work', 'home', 'office', 'anyone', 'everyone', 'nothing', 'everything',
    'yes', 'no', 'ok', 'confirm', 'confirmation', 'approve', 'approved', 'proceed', 'proceeding',
    'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'mode', 'stay', 'hotel', 'visa', 'trip', 'trips',
    'available', 'availability', 'location', 'locations', 'building', 'buildings', 'floor', 'floors',
    'desk', 'desks', 'station', 'stations', 'meeting', 'meetings', 'room', 'rooms', 'project', 'projects',
    'team', 'teams', 'department', 'departments', 'unit', 'units', 'canteen', 'cafeteria', 'parking', 'gym',
    'details', 'information', 'info', 'status', 'request', 'requests', 'order', 'orders', 'summary',
    'plan', 'plans', 'schedule', 'schedules', 'history', 'view', 'search', 'find', 'choose', 'select',
    'option', 'options', 'preferred', 'preference', 'preferences', 'requirement', 'requirements'
]);

function checkPrivacy(effectiveQuery) {
    const forNameMatch = effectiveQuery.match(/\bfor\s+([A-Z][a-z]{3,}(?:\s+[A-Z][a-z]{3,})?)\s*[?.!]?$/);
    if (forNameMatch) {
        const matchedPhrase = forNameMatch[1];
        const words = matchedPhrase.toLowerCase().split(/\s+/).filter(Boolean);
        const hasInsecureWord = words.some(word => !rewriteSafe.has(word));
        if (hasInsecureWord) {
            return { blocked: true, reason: `Insecure word in: ${matchedPhrase}` };
        }
    }
    return { blocked: false };
}

const testCases = [
    "Book a seat for April",
    "Book a ticket",
    "9th April",
    "Show details for Pune Office",
    "Request for Information",
    "Schedule for Monday",
    "Book a ticket for Mumbai",
    "Plan for June",
    "Booking for Pune",
    "Seat for Bangalore Office"
];

console.log("=== PRIVACY GUARD VERIFICATION ===");
testCases.forEach(tc => {
    const result = checkPrivacy(tc);
    console.log(`Query: "${tc}" -> ${result.blocked ? '❌ BLOCKED: ' + result.reason : '✅ ALLOWED'}`);
});

// A real violation should still be blocked (if the person's name is not in whitelist)
const violationMatch = checkPrivacy("Show attendance for Rahul");
console.log(`Query: "Show attendance for Rahul" -> ${violationMatch.blocked ? '✅ BLOCKED (Correct)' : '❌ ALLOWED (Error)'}`);
