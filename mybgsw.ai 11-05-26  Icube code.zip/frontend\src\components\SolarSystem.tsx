import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { useTheme } from "next-themes";
import {
  User, DollarSign, Briefcase, BookOpen, Coffee, Plane, FileText,
  Calendar, Award, MessageSquare, GraduationCap, Music, Armchair,
  LogIn, Gift, Dumbbell, Navigation as NavigationIcon, Car, Eye, Megaphone, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";
import { BoBCard } from "./BoBCard";
import { LeaveCard } from "./LeaveCard";
import { EffortBookingCard } from "./EffortBookingCard";
import { JKLCard } from "./JKLCard";
import { TravelCard } from "./TravelCard";
import { CafeteriaCard } from "./CafeteriaCard";
import { PayslipCard } from "./PayslipCard";
import { ProjectsCard } from "./ProjectsCard";
import { MeetingsCard } from "./MeetingsCard";
import { CoursesCard } from "./CoursesCard";
import { CertificationsCard } from "./CertificationsCard";
import { CommunityCard } from "./CommunityCard";
import { MusicCard } from "./MusicCard";
import { SeatBookingCard } from "./SeatBookingCard";
import { VitalContactsCard } from "./VitalContactsCard";
import { EntryExitCard } from "./EntryExitCard";
import { HolidayCalendarCard } from "./HolidayCalendarCard";
import { GymCard } from "./GymCard";
import { WayFinderCard } from "./WayFinderCard";
import { BlogsCard } from "./BlogsCard";
import { ParkingCard } from "./ParkingCard";
import { WatchlistCard } from "./WatchlistCard";
import { BannersCard } from "./BannersCard";

// 8 concentric ellipses — 3:1 aspect ratio (rx:ry), uniform delta_rx=77, delta_ry=26
// Visual gap ratio drops from 5× to ~3× for much more even perceived spacing
// dashLen ≈ 2π√((rx²+ry²)/2) × 1.1
const ORBITS = [
  { rx: 80, ry: 27, dashLen: 440 },
  { rx: 157, ry: 53, dashLen: 870 },
  { rx: 234, ry: 79, dashLen: 1310 },
  { rx: 311, ry: 105, dashLen: 1760 },
  { rx: 388, ry: 131, dashLen: 2210 },
  { rx: 465, ry: 157, dashLen: 2660 },
  { rx: 542, ry: 183, dashLen: 3120 },
  { rx: 619, ry: 209, dashLen: 3580 },
];

// Progressive depth: inner orbits heavier/brighter, outer fade away
const ORBIT_OPACITY = [0.90, 0.82, 0.74, 0.65, 0.54, 0.44, 0.34, 0.24];
const ORBIT_STROKE_W = [1.8, 1.6, 1.4, 1.2, 1.0, 0.9, 0.82, 0.72];

const ORBIT_DELAYS = [0, 0.35, 0.70, 1.05, 1.40, 1.75, 2.10, 2.45];
const ORBIT_DURATIONS = [0.45, 0.5, 0.6, 0.65, 0.75, 0.85, 0.95, 1.05];
// Last orbit finishes at 2.45 + 1.05 = 3.5s → planets appear at 3.7s
const PLANETS_APPEAR_MS = 3700;

const SVG_W = 1400;
const SVG_H = 700;
const CX = 700;  // ellipse center x
const CY = 310;  // ~44% down — profile visually centered, orbits fan above+below
const TILT_DEG = -18; // stronger tilt for more pronounced perspective

const TILT_RAD = TILT_DEG * (Math.PI / 180);
const cos_t = Math.cos(TILT_RAD);
const sin_t = Math.sin(TILT_RAD);

// Map a planet's orbit + angle to pixel coords in the 1400×700 canvas
function planetPos(orbitIndex: number, angleDeg: number): { x: number; y: number } {
  const { rx, ry } = ORBITS[orbitIndex];
  const a = angleDeg * (Math.PI / 180);
  const lx = rx * Math.cos(a);
  const ly = ry * Math.sin(a);
  // Rotate the ellipse-local point by TILT so it matches the SVG group transform
  const wx = lx * cos_t - ly * sin_t;
  const wy = lx * sin_t + ly * cos_t;
  return { x: CX + wx, y: CY + wy };
}

interface PlanetDef {
  id: string;
  name: string;
  color: string;
  size: number;
  orbitIndex: number;
  angle: number;
  icon: React.ComponentType<{ className?: string }>;
}

const planets: PlanetDef[] = [
  // Orbit 0 — innermost: 1 planet, right-bottom bias
  { id: 'bob', name: 'Benefits', color: 'hsl(205 100% 40%)', size: 52, orbitIndex: 6, angle: 0, icon: DollarSign },

  // Orbit 1: 2 planets — right-bottom + left-bottom
  { id: 'cafeteria', name: 'Cafeteria', color: '#ef4444', size: 50, orbitIndex: 1, angle: 35, icon: Coffee },
  { id: 'payslip', name: 'Payslip', color: 'hsl(280 70% 55%)', size: 48, orbitIndex: 1, angle: 155, icon: FileText },

  // Orbit 2: 1 planet (Travel moved to orbit 6)
  { id: 'effort', name: 'Effort', color: 'hsl(142 76% 42%)', size: 50, orbitIndex: 4, angle: 67, icon: Briefcase },

  // Orbit 3: 2 planets — spread bottom (Entry/Exit moved to orbit 7)
  { id: 'meetings', name: 'Meetings', color: 'hsl(200 75% 52%)', size: 50, orbitIndex: 3, angle: 30, icon: Calendar },
  { id: 'parking', name: 'Parking', color: 'hsl(240 75% 58%)', size: 48, orbitIndex: 3, angle: 230, icon: Car },

  // Orbit 4: 3 planets
  { id: 'jkl', name: 'JKL', color: 'hsl(260 80% 58%)', size: 52, orbitIndex: 4, angle: 25, icon: GraduationCap },
  { id: 'courses', name: 'Courses', color: 'hsl(320 75% 58%)', size: 50, orbitIndex: 3, angle: 97, icon: BookOpen },
  { id: 'projects', name: 'Projects', color: 'hsl(30 85% 52%)', size: 52, orbitIndex: 4, angle: 210, icon: Briefcase },

  // Orbit 5: 4 planets — more spread, bottom-heavy
  { id: 'certifications', name: 'Badges', color: 'hsl(40 90% 55%)', size: 48, orbitIndex: 5, angle: 20, icon: Award },
  { id: 'watchlist', name: 'Watchlist', color: 'hsl(180 75% 50%)', size: 48, orbitIndex: 5, angle: 87, icon: Eye },
  { id: 'music', name: 'Music', color: 'hsl(340 80% 58%)', size: 46, orbitIndex: 5, angle: 185, icon: Music },
  { id: 'blogs', name: 'Blogs', color: 'hsl(100 70% 50%)', size: 50, orbitIndex: 5, angle: 310, icon: FileText },

  // Orbit 6: 5 planets — kept away from extreme left/right (avoid 0°/180°)
  { id: 'seatbooking', name: 'Seat', color: 'hsl(220 75% 58%)', size: 52, orbitIndex: 6, angle: 42, icon: Armchair },
  { id: 'gym', name: 'Gym', color: 'hsl(10 80% 58%)', size: 50, orbitIndex: 3, angle: 168, icon: Dumbbell },
  { id: 'community', name: 'Community', color: 'hsl(160 70% 50%)', size: 48, orbitIndex: 6, angle: 205, icon: MessageSquare },
  { id: 'travel', name: 'Travel', color: 'hsl(55 85% 52%)', size: 48, orbitIndex: 6, angle: 250, icon: Plane },
  { id: 'holidays', name: 'Holidays', color: 'hsl(280 75% 58%)', size: 48, orbitIndex: 6, angle: 310, icon: Gift },

  // Orbit 7 — outermost: angles biased toward bottom to stay off extreme edges
  { id: 'wayfinder', name: 'WayFinder', color: 'hsl(120 70% 50%)', size: 50, orbitIndex: 7, angle: 55, icon: NavigationIcon },
  { id: 'banner', name: 'News', color: 'hsl(20 85% 58%)', size: 46, orbitIndex: 4, angle: 300, icon: Megaphone },
  { id: 'contacts', name: 'Contacts', color: 'hsl(200 80% 55%)', size: 48, orbitIndex: 7, angle: 230, icon: MessageSquare },
  { id: 'entryexit', name: 'Entry/Exit', color: 'hsl(160 75% 48%)', size: 50, orbitIndex: 7, angle: 270, icon: LogIn },
];

export const SolarSystem = ({
  isShifted = false,
  onPlanetSelect,
}: {
  isShifted?: boolean;
  onPlanetSelect?: () => void;
}) => {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const [selectedPlanet, setSelectedPlanet] = useState<string | null>(null);
  const [activePlanets, setActivePlanets] = useState<string[]>([]);
  const [planetsVisible, setPlanetsVisible] = useState(false);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const res = await fetch("http://localhost:3001/api/services");
        const data = await res.json();
        if (data.services) {
          setActivePlanets(data.services.map((s: { id: string }) => s.id));
        }
      } catch {
        setActivePlanets(["cafeteria", "entryexit", "community", "travel", "seatbooking", "banner"]);
      }
    };
    fetchServices();
  }, []);

  // Reveal planets after orbit draw-in animation finishes
  useEffect(() => {
    const t = setTimeout(() => setPlanetsVisible(true), PLANETS_APPEAR_MS);
    return () => clearTimeout(t);
  }, []);

  // Lock background scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = selectedPlanet ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [selectedPlanet]);

  const displayName = user?.name || `Employee ${user?.employeeNumber || ""}`;
  const employeeId = user?.employeeNumber || "";
  const entityName = user?.entityName || "Bosch";

  const renderPlanetCard = () => {
    switch (selectedPlanet) {
      case "bob": return <BoBCard />;
      case "leave": return <LeaveCard />;
      case "effort": return <EffortBookingCard />;
      case "jkl": return <JKLCard />;
      case "travel": return <TravelCard />;
      case "cafeteria": return <CafeteriaCard />;
      case "payslip": return <PayslipCard />;
      case "projects": return <ProjectsCard />;
      case "meetings": return <MeetingsCard />;
      case "courses": return <CoursesCard />;
      case "certifications": return <CertificationsCard />;
      case "community": return <CommunityCard />;
      case "music": return <MusicCard />;
      case "seatbooking": return <SeatBookingCard />;
      case "contacts": return <VitalContactsCard />;
      case "entryexit": return <EntryExitCard />;
      case "holidays": return <HolidayCalendarCard />;
      case "gym": return <GymCard />;
      case "wayfinder": return <WayFinderCard />;
      case "blogs": return <BlogsCard />;
      case "parking": return <ParkingCard />;
      case "watchlist": return <WatchlistCard />;
      case "banner": return <BannersCard />;
      default: return null;
    }
  };

  return (
    <div
      className={cn(
        "relative w-full overflow-hidden transition-transform duration-500",
        isShifted && "-translate-x-48"
      )}
      style={{ height: "700px" }}
    >

      {/* ── Orbit lines (SVG, fixed 1400×700 canvas, centered) ── */}
      <svg
        width={SVG_W}
        height={SVG_H}
        viewBox={`0 0 ${SVG_W} ${SVG_H}`}
        className="absolute top-0"
        style={{
          left: "50%",
          transform: "translateX(-50%)",
          pointerEvents: "none",
        }}
        aria-hidden="true"
      >
        <defs>
          {/* Blur for orbit line glow */}
          <filter id="orbitGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          {/* Heavy blur for 3D orbital plane glow */}
          <filter id="planeGlowBlur" x="-60%" y="-200%" width="220%" height="500%">
            <feGaussianBlur stdDeviation="18" />
          </filter>
        </defs>

        {/* 3D orbital plane glow — blue, inside tilt group so it follows orbit perspective */}
        <g transform={`rotate(${TILT_DEG} ${CX} ${CY})`}>
          <ellipse cx={CX} cy={CY} rx={ORBITS[1].rx * 0.9} ry={ORBITS[1].ry * 0.9}
            fill="rgba(60,120,255,0.22)" filter="url(#planeGlowBlur)" />
          <ellipse cx={CX} cy={CY} rx={ORBITS[3].rx * 0.85} ry={ORBITS[3].ry * 0.85}
            fill="rgba(80,140,255,0.12)" filter="url(#planeGlowBlur)" />
          <ellipse cx={CX} cy={CY} rx={ORBITS[5].rx * 0.80} ry={ORBITS[5].ry * 0.80}
            fill="rgba(100,160,255,0.06)" filter="url(#planeGlowBlur)" />
        </g>

        {/* 8 orbit ellipses — progressive depth, each draws in sequentially */}
        <g transform={`rotate(${TILT_DEG} ${CX} ${CY})`} filter="url(#orbitGlow)">
          {ORBITS.map((orbit, i) => (
            <ellipse
              key={i}
              cx={CX}
              cy={CY}
              rx={orbit.rx}
              ry={orbit.ry}
              stroke={`rgba(100,160,255,${ORBIT_OPACITY[i]})`}
              fill="none"
              strokeWidth={ORBIT_STROKE_W[i]}
              strokeDasharray={orbit.dashLen}
              strokeDashoffset={orbit.dashLen}
              opacity="0"
            >
              <animate
                attributeName="stroke-dashoffset"
                from={orbit.dashLen}
                to="0"
                dur={`${ORBIT_DURATIONS[i]}s`}
                begin={`${ORBIT_DELAYS[i]}s`}
                fill="freeze"
              />
              <animate
                attributeName="opacity"
                from="0"
                to={ORBIT_OPACITY[i]}
                dur="0.3s"
                begin={`${ORBIT_DELAYS[i]}s`}
                fill="freeze"
              />
            </ellipse>
          ))}
        </g>
      </svg>

      {/* ── Planets + center avatar — same 1400×700 coordinate space ── */}
      <div
        className="absolute top-0"
        style={{
          width: SVG_W + "px",
          height: SVG_H + "px",
          left: "50%",
          transform: "translateX(-50%)",
        }}
      >
        {/* User info — sits just above the profile circle (CY - half avatar - gap) */}
        <div
          className="absolute z-30 text-center whitespace-nowrap"
          style={{ top: (CY - 44 - 52 - 40) + "px", left: CX + "px", transform: "translateX(-50%)" }}
        >
          <h2 className={cn("text-2xl font-bold text-white tracking-wide", isDark ? "text-white" : "text-black")}>{displayName}</h2>
          <p className={cn("text-xs mt-1", isDark ? "text-green-400" : "text-green-700")} style={{}}>{employeeId} | {entityName} • Bangalore</p>
        </div>

        {/* Center: Eclipse + profile avatar */}
        <div
          className="absolute z-20"
          style={{
            left: CX + "px",
            top: CY + "px",
            transform: "translate(-50%, -50%)",
            pointerEvents: "none",
          }}
        >
          {/* Upper-right corona burst */}
          <img
            src="/Glow.png"
            alt=""
            aria-hidden="true"
            style={{
              position: "absolute",
              width: "160px",
              height: "160px",
              minWidth: "160px",
              minHeight: "160px",
              top: "-83px",
              left: "-78px",
              mixBlendMode: "screen",
              pointerEvents: "none",
              animation: "glowFadeIn 1.2s ease-out 0.8s both",
            }}
          />


          {/* Profile avatar circle — always-on warm glow ring + blue fill */}
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: "88px",
              height: "88px",
              borderRadius: "50%",
              background: "radial-gradient(circle at 35% 35%, #3b82f6, #1e3a8a)",
              border: "2px solid rgba(255,255,255,0.18)",
              boxShadow: "0 0 0 1px rgba(0,0,0,0.4)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 2,
              animation: "eclipseAppear 1.2s cubic-bezier(0.34,1.56,0.64,1) both",
            }}
          >
            <User style={{ width: "44px", height: "44px", color: "rgba(255,255,255,0.9)" }} />
          </div>
        </div>

        <style>{`
          @keyframes glowFadeIn {
            0%   { opacity: 0; transform: scale(0.7); }
            100% { opacity: 0.95; transform: scale(1); }
          }
          @keyframes glowFadeInBelow {
            0%   { opacity: 0; transform: scale(0.7); }
            100% { opacity: 0.60; transform: scale(1); }
          }
          @keyframes eclipseAppear {
            0%   { opacity: 0; transform: translate(-50%, -50%) scale(0.3); }
            60%  { opacity: 1; transform: translate(-50%, -50%) scale(1.08); }
            100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
          }
          @keyframes planetFloat {
            0%, 100% { transform: translate(-50%, -50%) translateY(0px); }
            50%       { transform: translate(-50%, -50%) translateY(-5px); }
          }
        `}</style>

        {/* Planets — fixed positions, fade in after orbits draw */}
        {planets.map((planet, idx) => {
          const pos = planetPos(planet.orbitIndex, planet.angle);
          const isActive = activePlanets.includes(planet.id) ||
            (planet.id === "cafeteria" && activePlanets.includes("canteen")) ||
            (planet.id === "canteen" && activePlanets.includes("cafeteria"));
          const Icon = planet.icon;
          const floatDelay = (idx * 0.7) % 6;

          return (
            <div
              key={planet.id}
              className={cn(
                "absolute group z-10",
                isActive ? "cursor-pointer" : "cursor-not-allowed"
              )}
              style={{
                left: pos.x + "px",
                top: pos.y + "px",
                transform: "translate(-50%, -50%)",
                opacity: planetsVisible ? (isActive ? 1 : 0.32) : 0,
                transition: "opacity 0.8s ease",
                overflow: "visible",
                animation: planetsVisible && isActive
                  ? `planetFloat ${5 + (idx % 3)}s ease-in-out ${floatDelay}s infinite`
                  : undefined,
              }}
              onClick={() => {
                if (!isActive) return;
                logger.logButtonClick(`planet-${planet.id}`, planet.name, {
                  planetId: planet.id,
                  planetName: planet.name,
                  action: "planet-click",
                });
                setSelectedPlanet(planet.id);
                onPlanetSelect?.();
              }}
              onKeyDown={(e) => {
                if ((e.key === "Enter" || e.key === " ") && isActive) {
                  setSelectedPlanet(planet.id);
                  onPlanetSelect?.();
                }
              }}
              tabIndex={isActive ? 0 : -1}
              role="button"
              aria-label={planet.name}
            >
              {/* Glow.png corona — renders behind planet via DOM order, shown on hover */}
              {isActive && (
                <img
                  src="/Glow.png"
                  alt=""
                  aria-hidden="true"
                  className="absolute pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{
                    width: planet.size * 2.5 + "px",
                    height: planet.size * 2.5 + "px",
                    minWidth: planet.size * 2.5 + "px",
                    minHeight: planet.size * 2.5 + "px",
                    left: "50%",
                    top: "50%",
                    transform: "translate(-50%, -50%)",
                    mixBlendMode: "screen",
                    flexShrink: 0,
                  }}
                />
              )}

              {/* Planet button — liquid glass style, sits on top of glow via z-index */}
              <div
                className={cn(
                  "relative rounded-full flex items-center justify-center",
                  "border border-white/20 transition-all duration-300",
                  isActive && "group-hover:scale-125 group-focus:scale-125",
                  selectedPlanet === planet.id && isActive && "ring-2 ring-white/60 scale-125"
                )}
                style={{
                  background: isActive
                    ? planet.color
                    : "rgba(70,70,80,0.45)",
                  backdropFilter: "blur(10px) saturate(150%)",
                  WebkitBackdropFilter: "blur(10px) saturate(150%)",
                  boxShadow: isActive
                    ? `0 0 10px rgba(255,255,255,0.4), 0 4px 20px ${planet.color}55, inset 0 1px 1px rgba(255,255,255,0.4)`
                    : "0 2px 8px rgba(0,0,0,0.4)",
                  width: planet.size + "px",
                  height: planet.size + "px",
                  position: "relative",
                  zIndex: 1,
                }}
              >
                <Icon className="w-5 h-5 text-white drop-shadow" />
              </div>

              {/* Hover-only label above planet */}
              <div className="absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 whitespace-nowrap pointer-events-none z-30 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <span
                  className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                  style={{
                    color: "rgba(255,255,255,0.9)",
                    background: "rgba(0,0,0,0.55)",
                    backdropFilter: "blur(8px)",
                    WebkitBackdropFilter: "blur(8px)",
                  }}
                >
                  {planet.name}{!isActive && " (Soon)"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Planet card modal ── */}
      {selectedPlanet &&
        createPortal(
          <div
            className="fixed inset-0 flex items-center justify-center z-[200] p-4 transition-colors duration-300"
            style={{
              background: isDark ? null : "rgba(255,255,255,0.2)",
              backdropFilter: "blur(4px)",
              WebkitBackdropFilter: "blur(4px)"
            }}
            onClick={() => setSelectedPlanet(null)}
            onKeyDown={(e) => e.key === "Escape" && setSelectedPlanet(null)}
          >
            <div
              className="relative max-w-2xl w-full max-h-[85vh] overflow-y-auto animate-scale-in  custom-scrollbar rounded-3xl"
              onClick={(e) => e.stopPropagation()}
              onKeyDown={(e) => e.stopPropagation()}
              role="presentation"
            >
              <div className="sticky top-2 right-2 z-20 flex justify-end px-2 pointer-events-none mb-[-2rem]">
                <button
                  onClick={() => setSelectedPlanet(null)}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 pointer-events-auto backdrop-blur-sm shadow-sm"
                  style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}
                  aria-label="Close card"
                >
                  <X
                    className="w-3.5 h-3.5"
                    style={{ color: isDark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)" }}
                  />
                </button>
              </div>
              {renderPlanetCard()}
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};
