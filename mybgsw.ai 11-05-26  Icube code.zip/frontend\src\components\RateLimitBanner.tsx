import { Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface RateLimitBannerProps {
  retryAfter: number; // live ticking seconds from useRateLimit hook
  className?: string;
}

/** Format seconds as M:SS (e.g. 45 → "0:45", 90 → "1:30") */
export const formatCountdown = (seconds: number): string => {
  const s = Math.max(0, seconds);
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem.toString().padStart(2, "0")}`;
};

/**
 * Inline rate-limit banner for chat interfaces.
 * Renders an amber warning strip with a live countdown clock.
 * Parent should conditionally render this only when `isRateLimited === true`
 * so it auto-dismisses when the hook's timer expires.
 */
export const RateLimitBanner = ({ retryAfter, className }: RateLimitBannerProps) => {
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        "flex items-center gap-3 px-4 py-3 my-2 mx-1 rounded-xl",
        "bg-amber-500/10 border border-amber-500/20",
        "animate-in fade-in slide-in-from-bottom-2 duration-200",
        className
      )}
    >
      {/* Shield icon */}
      <div className="w-9 h-9 rounded-full bg-amber-500/15 flex items-center justify-center flex-shrink-0">
        <Shield className="w-4 h-4 text-amber-500" />
      </div>

      {/* Description */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-amber-700 dark:text-amber-400 leading-tight">
          You're going a bit fast
        </p>
        <p className="text-xs text-amber-600/70 dark:text-amber-400/70 mt-0.5 leading-tight">
          The assistant will be ready again shortly
        </p>
      </div>

      {/* Live clock — the primary visual focus */}
      <div className="flex-shrink-0 text-right">
        <span className="font-mono font-bold text-2xl text-amber-500 tabular-nums leading-none">
          {formatCountdown(retryAfter)}
        </span>
        <p className="text-[10px] text-amber-500/50 mt-0.5 text-center tracking-wide uppercase">
          remaining
        </p>
      </div>
    </div>
  );
};
