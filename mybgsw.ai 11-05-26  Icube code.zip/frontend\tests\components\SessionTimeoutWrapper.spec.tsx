/**
 * SessionTimeoutWrapper — integration tests
 *
 * Coverage targets:
 *   ✓ Renders children regardless of auth state
 *   ✓ Modal is NOT mounted when user is unauthenticated
 *   ✓ Modal is mounted (but closed) when user is authenticated
 *   ✓ Modal becomes visible (open) when showWarning is true
 *   ✓ Clicking "Stay Logged In" closes the modal
 *   ✓ Clicking "Log Out Now" clears the session and closes the modal
 *   ✓ Cross-tab SHOW_WARNING message opens the modal in the wrapper
 *   ✓ Cross-tab RESET message closes the modal in the wrapper
 *   ✓ Cross-tab LOGOUT message clears the session via the wrapper
 */

import { render, screen, fireEvent, act } from '@testing-library/react';
import { createElement } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import { SessionTimeoutWrapper } from '@/components/SessionTimeoutWrapper';
import {
  INACTIVITY_MS,
} from '@/hooks/useSessionTimeout';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function seedUser(loginMethod: 'credential' | 'sso' = 'credential') {
  sessionStorage.setItem('mybgsw_user', JSON.stringify({
    employeeNumber: 'EMP001',
    name: 'Test User',
    accessToken: 'tok',
    tokenType: 'Bearer',
    entityId: '1',
    entityName: 'BGSW',
    isTemporaryPassword: false,
    loginTimestamp: new Date().toISOString(),
    ntid: 'ntid01',
    expiresIn: 3600,
    issuedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
    loginMethod,
  }));
}

const wrapper = ({ children }: { children: React.ReactNode }) =>
  createElement(AuthProvider, null, children);

// ─── BroadcastChannel mock factory ────────────────────────────────────────────

function makeMockChannel() {
  const channel = {
    onmessage: null as ((e: MessageEvent) => void) | null,
    postMessage: jasmine.createSpy('postMessage'),
    close: jasmine.createSpy('close'),
    receive(data: Record<string, unknown>) {
      if (channel.onmessage) {
        channel.onmessage({ data } as MessageEvent);
      }
    },
  };
  return channel;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('SessionTimeoutWrapper', () => {
  let mockChannel: ReturnType<typeof makeMockChannel>;

  beforeEach(() => {
    sessionStorage.clear();
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date());

    mockChannel = makeMockChannel();
    (window as unknown as Record<string, unknown>)['BroadcastChannel'] =
      jasmine.createSpy('BroadcastChannel').and.returnValue(mockChannel);
  });

  afterEach(() => {
    jasmine.clock().uninstall();
    sessionStorage.clear();
  });

  // ── Children rendering ──────────────────────────────────────────────────────

  it('always renders its children regardless of auth state', async () => {
    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div data-testid="child-content">Hello World</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    expect(screen.getByTestId('child-content')).toBeTruthy();
  });

  it('renders children when user is authenticated', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div data-testid="protected-content">Protected</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    expect(screen.getByTestId('protected-content')).toBeTruthy();
  });

  // ── Modal visibility gating ─────────────────────────────────────────────────

  it('does NOT render the timeout modal when unauthenticated', async () => {
    // No seedUser — unauthenticated
    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  it('renders the timeout modal (hidden) when authenticated', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Modal is mounted when authenticated; it may be hidden (open=false) but the
    // wrapper element should exist in the DOM
    // The Radix Dialog only renders content when open=true, so we just confirm
    // the modal does NOT appear initially (showWarning starts as false)
    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  // ── Modal opens after inactivity ────────────────────────────────────────────

  it('opens the modal after INACTIVITY_MS of idle time', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Advance past the inactivity threshold
    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();
  });

  it('shows the "Stay Logged In" and "Log Out Now" buttons when modal is open', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    expect(screen.getByTestId('stay-logged-in-button')).toBeTruthy();
    expect(screen.getByTestId('logout-button')).toBeTruthy();
  });

  // ── "Stay Logged In" interaction ────────────────────────────────────────────

  it('closes the modal when "Stay Logged In" is clicked', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Open the modal
    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();

    // Click "Stay Logged In"
    await act(async () => {
      fireEvent.click(screen.getByTestId('stay-logged-in-button'));
    });

    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  it('broadcasts RESET to other tabs when "Stay Logged In" is clicked', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('stay-logged-in-button'));
    });

    const resetBroadcast = (mockChannel.postMessage as jasmine.Spy).calls
      .all()
      .find((c: jasmine.CallInfo) => c.args[0]?.type === 'RESET');
    expect(resetBroadcast).toBeTruthy();
  });

  // ── "Log Out Now" interaction ───────────────────────────────────────────────

  it('clears the session when "Log Out Now" is clicked', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('logout-button'));
    });

    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  it('broadcasts LOGOUT to other tabs when "Log Out Now" is clicked', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('logout-button'));
    });

    const logoutBroadcast = (mockChannel.postMessage as jasmine.Spy).calls
      .all()
      .find((c: jasmine.CallInfo) => c.args[0]?.type === 'LOGOUT');
    expect(logoutBroadcast).toBeTruthy();
  });

  // ── Cross-tab: SHOW_WARNING ─────────────────────────────────────────────────

  it('opens the modal when SHOW_WARNING received from another tab', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Simulate another tab broadcasting SHOW_WARNING
    await act(async () => {
      mockChannel.receive({ type: 'SHOW_WARNING' });
    });

    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();
  });

  // ── Cross-tab: RESET ────────────────────────────────────────────────────────

  it('closes the modal when RESET received from another tab', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Open modal locally
    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();

    // Another tab resets
    await act(async () => {
      mockChannel.receive({ type: 'RESET' });
    });

    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  // ── Cross-tab: LOGOUT ───────────────────────────────────────────────────────

  it('clears the session when LOGOUT received from another tab', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      mockChannel.receive({ type: 'LOGOUT' });
    });

    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── Cross-tab: ACTIVITY ─────────────────────────────────────────────────────

  it('closes the modal when ACTIVITY received from another tab during warning', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    // Advance to warning
    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();

    // Another tab reports activity with a more recent timestamp
    await act(async () => {
      mockChannel.receive({ type: 'ACTIVITY', timestamp: Date.now() + 1 });
    });

    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  // ── User activity dismissal ─────────────────────────────────────────────────

  it('does NOT close the modal when user moves the mouse during warning phase', async () => {
    seedUser();

    await act(async () => {
      render(
        <AuthProvider>
          <SessionTimeoutWrapper>
            <div>Content</div>
          </SessionTimeoutWrapper>
        </AuthProvider>
      );
    });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();

    await act(async () => {
      document.dispatchEvent(new MouseEvent('mousemove'));
      jasmine.clock().tick(100);
    });

    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();
  });
});
