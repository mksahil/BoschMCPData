import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { logoutAzureAD, getAccessTokenSilently } from '@/services/azureAuthService';

interface User {
  employeeNumber: string;
  name: string;
  accessToken: string;
  tokenType: string;
  entityId: string;
  entityName: string;
  isTemporaryPassword: boolean;
  loginTimestamp: string;
  ntid: string;
  expiresIn: number;
  issuedAt: string;
  expiresAt: string;
  sessionId?: string;
  loginMethod?: 'credential' | 'sso';
}

interface ArenaTokenResponse {
  userName: string;
  Name?: string;
  access_token: string;
  token_type: string;
  EntityId: string;
  EntityName: string;
  IsTemporaryPassword: string;
  LoginTimeStamp: string;
  NTID: string;
  expires_in: number;
  '.issued': string;
  '.expires': string;
  sessionId?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  /**
   * null  = consent status not yet known (still loading after login)
   * false = user has NOT consented yet — show ConsentModal
   * true  = user has consented — allow app access
   */
  hasConsented: boolean | null;
  login: (employeeNumber: string, password: string, isPreEncrypted?: boolean) => Promise<{ success: boolean; error?: string }>;
  ssoLogin: (arenaTokenData: ArenaTokenResponse) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  /**
   * refreshSession — called by useSessionTimeout when the user clicks "Stay Logged In".
   * For SSO users: silently acquires a new Azure AD access token.
   * For credential users: no-op (returns true — timer reset is sufficient).
   * Returns false and calls logout() if the underlying refresh token has expired.
   */
  refreshSession: () => Promise<boolean>;
  /** Save consent to the backend and flip hasConsented to true locally. */
  recordConsent: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// ── Consent helpers ──────────────────────────────────────────────────────────

const API_BASE = import.meta.env.PROD
  ? 'https://my-bgsw-ai-api-dev.azurewebsites.net'
  : 'http://localhost:3001';

/**
 * Derive the stable NT-ID used for consent lookup.
 * Falls back to employeeNumber so credential-only users without an NTID still work.
 */
function resolveNtId(user: User): string {
  return (user.ntid || user.employeeNumber || '').trim();
}

async function fetchConsentStatus(ntId: string): Promise<boolean> {
  try {
    const resp = await fetch(`${API_BASE}/api/auth/consent?nt_id=${encodeURIComponent(ntId)}`);
    if (!resp.ok) return false;
    const data = await resp.json() as { hasConsented: boolean };
    return data.hasConsented === true;
  } catch {
    return false;
  }
}

async function postConsent(userId: string, userName: string, ntId: string): Promise<boolean> {
  try {
    const resp = await fetch(`${API_BASE}/api/auth/consent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, user_name: userName, nt_id: ntId }),
    });
    if (!resp.ok) return false;
    const data = await resp.json() as { success: boolean };
    return data.success === true;
  } catch {
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  /** null = not yet checked, false = no consent, true = consented */
  const [hasConsented, setHasConsented] = useState<boolean | null>(null);

  useEffect(() => {
    const init = async () => {
      const storedUser = sessionStorage.getItem('mybgsw_user');
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser) as User;
          const expiresAt = new Date(parsedUser.expiresAt);
          if (expiresAt > new Date()) {
            setUser(parsedUser);
            // Re-check consent on page reload so the gate is always enforced
            const ntId = resolveNtId(parsedUser);
            if (ntId) {
              const consented = await fetchConsentStatus(ntId);
              setHasConsented(consented);
            } else {
              setHasConsented(false);
            }
          } else {
            sessionStorage.removeItem('mybgsw_user');
          }
        } catch {
          sessionStorage.removeItem('mybgsw_user');
        }
      }
      setIsLoading(false);
    };
    init();
  }, []);

  const login = async (
    employeeNumber: string,
    password: string,
    isPreEncrypted: boolean = false,
  ): Promise<{ success: boolean; error?: string; retryAfter?: number }> => {
    try {
      setIsLoading(true);

      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: employeeNumber,
          password,
          isPreEncrypted,
        }),
      });

      const data = (await response.json()) as ArenaTokenResponse;

      if (response.status === 429) {
        const retryAfter = parseInt(response.headers.get('Retry-After') || '60', 10);
        return { success: false, error: (data as { error?: string }).error || 'Too many login attempts. Please wait before trying again.', retryAfter };
      }

      if (!response.ok) {
        return { success: false, error: (data as { error?: string }).error || 'Login failed' };
      }

      const userData: User = {
        employeeNumber: data.userName,
        name: data.Name?.trim() || data.userName,
        accessToken: data.access_token,
        tokenType: data.token_type,
        entityId: data.EntityId,
        entityName: data.EntityName,
        isTemporaryPassword: data.IsTemporaryPassword === 'True',
        loginTimestamp: data.LoginTimeStamp,
        ntid: data.NTID,
        expiresIn: data.expires_in,
        issuedAt: data['.issued'],
        expiresAt: data['.expires'],
        sessionId: data.sessionId,
        loginMethod: 'credential',
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));

      // Check consent status immediately after login
      const ntId = resolveNtId(userData);
      if (ntId) {
        const consented = await fetchConsentStatus(ntId);
        setHasConsented(consented);
      } else {
        setHasConsented(false);
      }

      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  const ssoLogin = async (arenaTokenData: ArenaTokenResponse): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      if (!arenaTokenData) {
        return { success: false, error: 'No token data provided' };
      }

      const userData: User = {
        employeeNumber: arenaTokenData.userName,
        name: arenaTokenData.Name?.trim() || arenaTokenData.userName,
        accessToken: arenaTokenData.access_token,
        tokenType: arenaTokenData.token_type,
        entityId: arenaTokenData.EntityId,
        entityName: arenaTokenData.EntityName,
        isTemporaryPassword: arenaTokenData.IsTemporaryPassword === 'True',
        loginTimestamp: arenaTokenData.LoginTimeStamp,
        ntid: arenaTokenData.NTID,
        expiresIn: arenaTokenData.expires_in,
        issuedAt: arenaTokenData['.issued'],
        expiresAt: arenaTokenData['.expires'],
        sessionId: arenaTokenData.sessionId,
        loginMethod: 'sso',
      };

      setUser(userData);
      sessionStorage.setItem('mybgsw_user', JSON.stringify(userData));

      // Check consent status immediately after SSO login
      const ntId = resolveNtId(userData);
      if (ntId) {
        const consented = await fetchConsentStatus(ntId);
        setHasConsented(consented);
      } else {
        setHasConsented(false);
      }

      return { success: true };
    } catch (error) {
      console.error('SSO login error:', error);
      return { success: false, error: 'SSO login failed. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Save consent to the backend then update local state.
   * Called by ConsentModal after the user ticks both checkboxes and clicks Continue.
   */
  const recordConsent = async (): Promise<void> => {
    if (!user) return;
    const ntId = resolveNtId(user);
    if (!ntId) return;
    await postConsent(user.employeeNumber, user.name, ntId);
    setHasConsented(true);
  };

  const refreshSession = async (): Promise<boolean> => {
    try {
      if (user?.loginMethod === 'sso') {
        const token = await getAccessTokenSilently();
        if (!token) {
          // Refresh token has expired — force re-authentication
          await logout();
          return false;
        }
      }
      // Credential users: timer reset alone is sufficient
      return true;
    } catch (error) {
      console.error('[AuthContext] Session refresh failed:', error);
      await logout();
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      if (user?.loginMethod === 'sso') {
        await logoutAzureAD();
      }
      setUser(null);
      setHasConsented(null);
      sessionStorage.removeItem('mybgsw_user');
    } catch (error) {
      console.error('Logout error:', error);
      setUser(null);
      setHasConsented(null);
      sessionStorage.removeItem('mybgsw_user');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        hasConsented,
        login,
        ssoLogin,
        logout,
        refreshSession,
        recordConsent,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
