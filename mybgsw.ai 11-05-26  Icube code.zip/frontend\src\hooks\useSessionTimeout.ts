import { useEffect, useRef, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';

// ─── Timeout constants — driven by .env so dev can test without waiting ──────
// Set VITE_INACTIVITY_MINUTES / VITE_WARNING_MINUTES in frontend/.env to override.
// Production defaults: 13 min inactivity + 2 min warning = 15 min total.
export const INACTIVITY_MS = (Number(import.meta.env.VITE_INACTIVITY_MINUTES) || 13) * 60 * 1000;
export const WARNING_MS    = (Number(import.meta.env.VITE_WARNING_MINUTES)    ||  2) * 60 * 1000;
export const TOTAL_MS      = INACTIVITY_MS + WARNING_MS;

// ─── Debug logger (prefix makes logs easy to filter in DevTools) ─────────────
const LOG = (...args: unknown[]) =>
  console.log('[SessionTimeout]', new Date().toLocaleTimeString(), ...args);

// ─── Cross-tab BroadcastChannel message types ────────────────────────────────
type MsgType = 'ACTIVITY' | 'SHOW_WARNING' | 'RESET' | 'LOGOUT';
const CHANNEL_NAME = 'mybgsw_session';
// sessionStorage key — persists last-activity across MSAL re-auth cycles
// (avoids the bug where isAuthenticated toggles false→true on laptop wake,
//  re-running the effect and resetting the timer to Date.now())
const STORAGE_KEY = 'mybgsw_last_activity';

// ─── Activity event list (passive listeners — no perf impact) ────────────────
const ACTIVITY_EVENTS = [
  'mousemove', 'mousedown', 'keydown',
  'touchstart', 'scroll', 'click',
] as const;

// Activity throttle — process at most one event per 500ms
const THROTTLE_MS = 500;

export interface SessionTimeoutState {
  showWarning: boolean;
  countdown: number;          // seconds remaining in the 2-min warning window
  handleStayLoggedIn: () => Promise<void>;
  handleLogout: () => void;
}

/**
 * useSessionTimeout
 *
 * Monitors user inactivity and drives a 15-minute session timeout with a
 * 2-minute warning popup:
 *
 *   0 ─────────────────── 13 min ──── 15 min
 *   │   active / idle      │ warning  │ forced logout
 *
 * Features:
 *   • Real-time elapsed calculation (handles tab throttling & device sleep)
 *   • BroadcastChannel cross-tab sync — activity in any tab resets all tabs
 *   • Silent Azure AD token refresh on "Stay Logged In" for SSO users
 *   • Immediate logout on device wake if >15 min has elapsed
 */
export function useSessionTimeout(): SessionTimeoutState {
  const { isAuthenticated, logout, refreshSession } = useAuth();

  const [showWarning, setShowWarning] = useState(false);
  const [countdown, setCountdown] = useState(WARNING_MS / 1000);

  // Refs survive re-renders without causing them — used inside setInterval
  const lastActivityRef = useRef<number>(Date.now());
  const warningShownRef = useRef<boolean>(false);
  const channelRef = useRef<BroadcastChannel | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const throttleRef = useRef<number>(0);

  // ── Helpers ──────────────────────────────────────────────────────────────

  const broadcast = useCallback((type: MsgType, extra?: Record<string, unknown>) => {
    try { channelRef.current?.postMessage({ type, ...extra }); } catch { /* ignore */ }
  }, []);

  /** Reset all timer state — called both locally and in response to cross-tab RESET */
  const doReset = useCallback(() => {
    const now = Date.now();
    lastActivityRef.current = now;
    warningShownRef.current = false;
    setShowWarning(false);
    setCountdown(WARNING_MS / 1000);
    // Keep sessionStorage in sync so future effect re-runs see the reset timestamp
    try { sessionStorage.setItem(STORAGE_KEY, String(now)); } catch { /* ignore */ }
  }, []);

  /** Force logout — broadcasts to other tabs first */
  const doLogout = useCallback(() => {
    broadcast('LOGOUT');
    try { sessionStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
    logout();
  }, [broadcast, logout]);

  // ── Public API ────────────────────────────────────────────────────────────

  const handleStayLoggedIn = useCallback(async () => {
    doReset();
    broadcast('RESET');
    // For SSO users this silently refreshes the Azure AD token.
    // For credential users it's a no-op (returns true immediately).
    // If the underlying refresh token has expired, refreshSession() calls
    // logout() internally and returns false.
    await refreshSession();
  }, [doReset, broadcast, refreshSession]);

  const handleLogout = useCallback(() => {
    doLogout();
  }, [doLogout]);

  // ── Main effect — runs when auth state changes ────────────────────────────

  useEffect(() => {
    LOG('effect fired — isAuthenticated:', isAuthenticated,
        '| INACTIVITY_MS:', INACTIVITY_MS / 1000, 's',
        '| WARNING_MS:', WARNING_MS / 1000, 's');

    if (!isAuthenticated) {
      LOG('not authenticated — hook is idle');
      return;
    }

    // ── Restore or initialise the last-activity timestamp ────────────────
    // IMPORTANT: Do NOT blindly stamp Date.now() here. The useEffect re-fires
    // whenever isAuthenticated toggles (e.g. MSAL silent re-auth on laptop
    // wake), which would reset the elapsed time and prevent auto-logout.
    // Instead, we read the timestamp we persisted in sessionStorage.
    const storedTs = Number(sessionStorage.getItem(STORAGE_KEY) ?? 0);
    const now = Date.now();
    const storedElapsed = storedTs > 0 ? now - storedTs : 0;

    if (storedTs > 0 && storedElapsed >= TOTAL_MS) {
      // Laptop was asleep / away for longer than the total timeout.
      // Skip the warning and logout immediately.
      LOG(`wake detected — stored elapsed ${Math.round(storedElapsed / 1000)}s >= TOTAL_MS — forcing logout`);
      try { sessionStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
      logout();
      return;
    }

    if (storedTs > 0 && storedElapsed >= INACTIVITY_MS) {
      // Already past the inactivity threshold — restore timestamp and show warning.
      LOG(`wake detected — stored elapsed ${Math.round(storedElapsed / 1000)}s >= INACTIVITY_MS — showing warning`);
      lastActivityRef.current = storedTs;
      warningShownRef.current = true;
      setShowWarning(true);
      setCountdown(Math.max(0, Math.ceil((TOTAL_MS - storedElapsed) / 1000)));
    } else if (storedTs > 0) {
      // Session still active — resume from the persisted timestamp.
      LOG(`resuming session — stored elapsed ${Math.round(storedElapsed / 1000)}s`);
      lastActivityRef.current = storedTs;
      warningShownRef.current = false;
      setShowWarning(false);
      setCountdown(WARNING_MS / 1000);
    } else {
      // No prior session (true first login) — start fresh.
      lastActivityRef.current = now;
      warningShownRef.current = false;
      setShowWarning(false);
      setCountdown(WARNING_MS / 1000);
      try { sessionStorage.setItem(STORAGE_KEY, String(now)); } catch { /* ignore */ }
      LOG('timer started — session clock running');
    }

    // ── Cross-tab synchronisation ──────────────────────────────────────────
    try {
      const ch = new BroadcastChannel(CHANNEL_NAME);
      ch.onmessage = ({ data }) => {
        switch (data.type as MsgType) {
          case 'ACTIVITY':
            // Accept newer timestamp from other tabs
            if ((data.timestamp as number) > lastActivityRef.current) {
              lastActivityRef.current = data.timestamp as number;
              LOG('cross-tab ACTIVITY received — timestamp updated');
              if (warningShownRef.current) {
                warningShownRef.current = false;
                setShowWarning(false);
                setCountdown(WARNING_MS / 1000);
              }
            }
            break;
          case 'SHOW_WARNING':
            if (!warningShownRef.current) {
              warningShownRef.current = true;
              setShowWarning(true);
              setCountdown(WARNING_MS / 1000);
              LOG('cross-tab SHOW_WARNING received — modal shown');
            }
            break;
          case 'RESET':
            LOG('cross-tab RESET received');
            doReset();
            break;
          case 'LOGOUT':
            LOG('cross-tab LOGOUT received');
            logout(); // other tab initiated logout — don't broadcast again
            break;
        }
      };
      channelRef.current = ch;
    } catch {
      // BroadcastChannel unavailable (some private-browsing modes) — degrade gracefully
    }

    // ── Local activity listener ────────────────────────────────────────────
    let lastActivityLog = 0; // separate log throttle — log at most once per 10s
    const onActivity = () => {
      // Once the warning is visible the user must explicitly click
      // "Stay Logged In" — passive events like mousemove must not hide it.
      if (warningShownRef.current) return;

      const now = Date.now();
      if (now - throttleRef.current < THROTTLE_MS) return; // throttle
      throttleRef.current = now;

      const prevActivity = lastActivityRef.current;
      lastActivityRef.current = now;
      // Persist so subsequent effect re-runs (e.g. MSAL silent re-auth) see
      // the real last-activity time rather than resetting to Date.now().
      try { sessionStorage.setItem(STORAGE_KEY, String(now)); } catch { /* ignore */ }

      if (now - lastActivityLog > 10_000) {
        lastActivityLog = now;
        LOG('activity detected — timer reset (elapsed was',
            Math.round((now - prevActivity) / 1000), 's)');
      }

      broadcast('ACTIVITY', { timestamp: now });
    };

    ACTIVITY_EVENTS.forEach(e => document.addEventListener(e, onActivity, { passive: true }));

    // ── 1-second interval tick ─────────────────────────────────────────────
    let lastStatusLog = 0;
    intervalRef.current = setInterval(() => {
      const now = Date.now();
      const elapsed = now - lastActivityRef.current;

      // Log status every 30 seconds so the console shows the hook is alive
      if (now - lastStatusLog > 30_000) {
        lastStatusLog = now;
        LOG(`status — elapsed: ${Math.round(elapsed / 1000)}s`,
            `| warning in: ${Math.round((INACTIVITY_MS - elapsed) / 1000)}s`,
            `| warningShown: ${warningShownRef.current}`);
      }

      if (elapsed >= TOTAL_MS) {
        // Device was asleep / hibernated — skip warning, logout immediately
        LOG('elapsed >= TOTAL_MS on wake — forcing logout immediately');
        if (intervalRef.current) clearInterval(intervalRef.current);
        logout();
        return;
      }

      if (elapsed >= INACTIVITY_MS && !warningShownRef.current) {
        // 13 min of inactivity — show warning to all tabs
        LOG('inactivity threshold reached — showing warning modal');
        warningShownRef.current = true;
        setShowWarning(true);
        setCountdown(WARNING_MS / 1000);
        broadcast('SHOW_WARNING');
        return;
      }

      if (warningShownRef.current) {
        // Tick down the countdown
        const remaining = Math.max(0, Math.ceil((TOTAL_MS - elapsed) / 1000));
        setCountdown(remaining);

        if (remaining === 0) {
          // Countdown hit zero — forced logout
          LOG('countdown reached 0 — forcing logout');
          if (intervalRef.current) clearInterval(intervalRef.current);
          logout();
        }
      }
    }, 1000);

    // ── Cleanup ────────────────────────────────────────────────────────────
    return () => {
      ACTIVITY_EVENTS.forEach(e => document.removeEventListener(e, onActivity));
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      channelRef.current?.close();
      channelRef.current = null;
      // Note: do NOT clear sessionStorage here — the cleanup runs on every
      // effect re-run (e.g. MSAL re-auth), so clearing it would defeat the
      // persistence. Only doLogout() clears it intentionally.
    };
  }, [isAuthenticated, doReset, logout, broadcast, refreshSession]);

  return { showWarning, countdown, handleStayLoggedIn, handleLogout };
}
