import { Navigation as NavigationIcon, MapPin, Coffee, Utensils, Users } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const WayFinderCard = () => {
  return (
    <DashboardCard title="Way Finder" icon={NavigationIcon}>
      <div className="space-y-4">
        {/* Quick Navigation */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <h4 className="text-sm font-semibold text-foreground mb-3">Quick Navigation</h4>
          <div className="space-y-2">
            <button className="w-full p-2 bg-secondary/40 hover:bg-secondary/80 rounded-lg transition-all flex items-center gap-2">
              <Coffee className="w-4 h-4 text-primary" />
              <span className="text-xs text-foreground">Cafeteria - Floor 1</span>
              <span className="text-xs text-muted-foreground ml-auto">2 min</span>
            </button>
            <button className="w-full p-2 bg-secondary/40 hover:bg-secondary/80 rounded-lg transition-all flex items-center gap-2">
              <Users className="w-4 h-4 text-accent" />
              <span className="text-xs text-foreground">Meeting Room A - Floor 3</span>
              <span className="text-xs text-muted-foreground ml-auto">5 min</span>
            </button>
            <button className="w-full p-2 bg-secondary/40 hover:bg-secondary/80 rounded-lg transition-all flex items-center gap-2">
              <MapPin className="w-4 h-4 text-success" />
              <span className="text-xs text-foreground">Parking Lot B</span>
              <span className="text-xs text-muted-foreground ml-auto">3 min</span>
            </button>
          </div>
        </div>

        {/* Popular Destinations */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">Popular Destinations</h4>
          
          <div className="grid grid-cols-2 gap-2">
            <div className="p-3 bg-secondary/40 rounded-lg text-center">
              <MapPin className="w-5 h-5 text-primary mx-auto mb-1" />
              <p className="text-xs font-medium text-foreground">Reception</p>
              <p className="text-xs text-muted-foreground">Ground Floor</p>
            </div>
            <div className="p-3 bg-secondary/40 rounded-lg text-center">
              <Coffee className="w-5 h-5 text-accent mx-auto mb-1" />
              <p className="text-xs font-medium text-foreground">Gym</p>
              <p className="text-xs text-muted-foreground">Floor 2</p>
            </div>
          </div>
        </div>

        {/* Search */}
        <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all text-sm">
          Search Location
        </button>
      </div>
    </DashboardCard>
  );
};
