import { useState, useEffect } from "react";
import { Navigation } from "@/components/Navigation";
import { SolarSystem } from "@/components/SolarSystem";
import { AIChat } from "@/components/AIChat";
import { InsightsStrip } from "@/components/InsightsStrip";
import { ChatWindow } from "@/components/ChatWindow";
import { Footer } from "@/components/Footer";

import { InProgressOverlay } from "@/components/InProgressOverlay";
import { InsightsSection } from "./sections/InsightsSection";
import { ActionsSection } from "./sections/ActionsSection";
import { MentorshipSection } from "./sections/MentorshipSection";
import { LearningSection } from "./sections/LearningSection";
import { WellnessSection } from "./sections/WellnessSection";

import { useAuth } from "@/context/AuthContext";
import logger from "@/lib/logger";

const Index = () => {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState("home");
  const [contextTitle, setContextTitle] = useState<string>();

  const [chatWindowOpen, setChatWindowOpen] = useState(false);

  // Log page load
  useEffect(() => {
    logger.logPageView('Dashboard Home', {
      initialSection: 'home',
      timestamp: new Date().toISOString()
    });
  }, []);

  // Log section changes
  useEffect(() => {
    if (activeSection !== 'home') {
      logger.logNavigation('home', activeSection, {
        contextTitle
      });
    }
  }, [activeSection]);

  const renderSection = () => {
    switch (activeSection) {
      case "insights":
        return (
          <InProgressOverlay>
            <InsightsSection />
          </InProgressOverlay>
        );
      case "actions":
        return (
          <InProgressOverlay>
            <ActionsSection />
          </InProgressOverlay>
        );
      case "mentorship":
        return (
          <InProgressOverlay>
            <MentorshipSection />
          </InProgressOverlay>
        );
      case "learning":
        return (
          <InProgressOverlay>
            <LearningSection />
          </InProgressOverlay>
        );
      case "wellness":
        return (
          <InProgressOverlay>
            <WellnessSection />
          </InProgressOverlay>
        );
      default:
        return <HomeSection chatWindowOpen={chatWindowOpen} onPlanetSelect={() => setChatWindowOpen(false)} />;
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">

      <Navigation
        activeSection={activeSection}
        onSectionChange={(section) => {
          setActiveSection(section);
          setContextTitle(undefined);
        }}
        contextTitle={contextTitle}
      />

      {/* <InsightsStrip /> */}

      <div className="relative z-10 bg-transparent">
        {/* Main Content */}
        <main className={`flex-1 px-4 w-full bg-transparent ${activeSection === "home" ? "pb-8 pt-0" : "py-8 pb-20"}`}>
          <div className={activeSection === "home" ? "w-full" : "container mx-auto"}>
            {renderSection()}
          </div>
        </main>
      </div>

      {/* AI Chat Widget - Hidden on home, visible elsewhere */}
      {activeSection !== "home" && <AIChat />}

      {/* Unified Chat - Always visible on home, expands when focused */}
      {activeSection === "home" && (
        <ChatWindow
          isOpen={chatWindowOpen}
          onClose={() => setChatWindowOpen(!chatWindowOpen)}
        />
      )}

      <Footer />
    </div>
  );
};

const HomeSection = ({ chatWindowOpen, onPlanetSelect }: { chatWindowOpen: boolean; onPlanetSelect: () => void }) => {
  return (
    <div className="w-full animate-fade-in">


      {/* Solar System */}
      <SolarSystem isShifted={false} onPlanetSelect={onPlanetSelect} />
    </div>
  );
};

export default Index;
