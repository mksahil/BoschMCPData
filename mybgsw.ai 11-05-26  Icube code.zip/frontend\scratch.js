const http = require('http');

// Set TEST_BEARER_TOKEN in your environment before running:
//   $env:TEST_BEARER_TOKEN="your-token-here"  (PowerShell)
//   export TEST_BEARER_TOKEN="your-token-here" (bash)
const token = process.env.TEST_BEARER_TOKEN || '';

const options = {
  hostname: 'localhost',
  port: 8080,
  path: '/api/community/register',
  method: 'POST',
  headers: {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9",
    "authorization": `Bearer ${token}`,
    "cache-control": "no-cache",
    "content-type": "application/json",
    "pragma": "no-cache"
  }
};

const req = http.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', data);
  });
});

req.on('error', (e) => {
  console.error(`Problem with request: ${e.message}`);
});

req.write(JSON.stringify({communityId:2, locationId:1}));
req.end();
