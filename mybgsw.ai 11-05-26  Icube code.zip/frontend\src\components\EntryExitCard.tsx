import { useState, useEffect } from "react";
import { LogIn, Clock, User, CheckCircle, XCircle, Loader2, RefreshCw, AlertCircle, MapPin } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { useAuth } from "@/context/AuthContext";
import { API_BASE_URL } from "@/config";
import { useRateLimit } from "@/hooks/useRateLimit";
import { formatCountdown } from "./RateLimitBanner";

interface EmployeeStatus {
  name: string;
  status: 'IN' | 'OUT' | 'unknown';
  lastSwipe: string | null;
  location: string | null;
}

export const EntryExitCard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [employeeData, setEmployeeData] = useState<EmployeeStatus>({
    name: 'Loading...',
    status: 'unknown',
    lastSwipe: null,
    location: null
  });

  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  const fetchEmployeeData = async () => {
    setLoading(true);
    setError(null);

    const employeeNumber = user?.employeeNumber || '34835634';

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Employee-Number': employeeNumber
    };

    if (user?.accessToken) {
      headers['Authorization'] = `Bearer ${user.accessToken}`;
    }

    try {
      const [nameResponse, statusResponse] = await Promise.all([
        fetch(`${API_BASE_URL}/api/time-tracking/employee-name`, { headers }),
        fetch(`${API_BASE_URL}/api/time-tracking/current-status`, { headers })
      ]);

      if (nameResponse.status === 429 || statusResponse.status === 429) {
        const limitedResponse = nameResponse.status === 429 ? nameResponse : statusResponse;
        const limitedData = await limitedResponse.json();
        handleRateLimitResponse(limitedResponse, limitedData);
        setError('Too many requests. Please wait before retrying.');
        return;
      }

      const nameData = await nameResponse.json();
      const statusData = await statusResponse.json();

      setEmployeeData({
        name: nameData.success ? nameData.name : 'Unknown',
        status: statusData.success ? statusData.status : 'unknown',
        lastSwipe: statusData.success ? statusData.lastSwipe : null,
        location: statusData.success ? statusData.location : null
      });
    } catch (err) {
      console.error('Error fetching employee data:', err);
      setError('Failed to load data');
      setEmployeeData({
        name: user?.name || 'Unknown',
        status: 'unknown',
        lastSwipe: null,
        location: null
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeeData();
  }, [user]);

  const formatLastSwipe = (swipeTime: string | null) => {
    if (!swipeTime) return 'N/A';
    try {
      const date = new Date(swipeTime);
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return swipeTime;
    }
  };

  const isCheckedIn = employeeData.status === 'IN';
  const statusColor = isCheckedIn ? 'text-black' : 'text-destructive';
  const StatusIcon = isCheckedIn ? CheckCircle : XCircle;

  return (
    <DashboardCard title="Entry & Exit" icon={LogIn}>
      <div className="flex flex-col h-full space-y-4">

        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between pb-3">
            <span className="text-xs font-semibold text-foreground">
              Employee Info
            </span>
            <button
              onClick={fetchEmployeeData}
              disabled={loading || isRateLimited}
              className="p-1 hover:bg-secondary/40 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title={isRateLimited ? `Rate limited — retry in ${formatCountdown(retryAfter)}` : "Refresh"}
            >
              <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <hr className="border-border/50" />
        </div>

        {/* Content area */}
        <div className="flex-1 flex flex-col justify-center">
          {loading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center flex-1 h-full min-h-[180px] gap-3 p-4 text-center">
              <div className="w-10 h-10 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-1">
                <AlertCircle className="w-5 h-5 text-amber-500" />
              </div>
              <p className="text-sm text-foreground font-medium max-w-[280px]">
                {error || "Check-in data unavailable"}
              </p>
              {isRateLimited && (
                <p className="text-xs text-amber-500 font-medium tracking-wide">
                  Available again in {formatCountdown(retryAfter)}...
                </p>
              )}
              <button
                onClick={fetchEmployeeData}
                disabled={isRateLimited}
                className="px-6 py-2 mt-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed w-32"
              >
                {isRateLimited ? "Paused" : "Try Again"}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 items-end py-4">
              {/* Name */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <img src="/grey_user.svg" alt="User" className="w-4 h-4" />
                  <span className="text-xs font-medium">Name</span>
                </div>
                <p className="text-lg md:text-xl font-semibold text-foreground leading-tight truncate" title={employeeData.name}>
                  {employeeData.name}
                </p>
              </div>

              {/* Last Swipe */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <img src="/last_swipe.svg" alt="Last Swipe" className="w-4 h-4" />
                  <span className="text-xs font-medium">Last Swipe</span>
                </div>
                <p className="text-lg md:text-xl font-medium text-foreground">
                  {formatLastSwipe(employeeData.lastSwipe)}
                </p>
              </div>

              {/* Location */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <img src="/location.svg" alt="Location" className="w-3.5 h-4 object-contain" />
                  <span className="text-xs font-medium">Location</span>
                </div>
                <p className="text-lg md:text-xl font-medium text-foreground">
                  {employeeData.location || "N/A"}
                </p>
              </div>

              {/* Status Pill */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <img src="/entry_exit_status.svg" alt="Status" className="w-4 h-4" />
                  <span className="text-xs font-medium">Status</span>
                </div>
                <div>
                  <span className={`inline-flex items-center px-4 py-1.5 rounded-full text-sm font-medium ${isCheckedIn ? 'bg-[#0a84ff] text-white shadow-md shadow-[#0a84ff]/20' : 'bg-secondary/60 text-foreground'
                    }`}>
                    {employeeData.status === 'IN' ? 'Checked In' :
                      employeeData.status === 'OUT' ? 'Checked Out' : 'Unknown'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Status Indicator (Bottom Label) */}
        {!loading && !error && (
          <div className={`mt-4 p-3.5 rounded-xl border ${isCheckedIn
            ? 'bg-green-200 border-green-500/30'
            : 'bg-destructive/10 border-destructive/20'
            }`}>
            <div className="flex items-center gap-2">
              <StatusIcon className={`w-4 h-4 ${statusColor}`} />
              <span className={`text-[13px] font-medium ${statusColor}`}>
                {isCheckedIn ? 'You are currently IN office' :
                  employeeData.status === 'OUT' ? 'You have checked OUT' :
                    'Status unavailable'}
              </span>
            </div>
          </div>
        )}

      </div>
    </DashboardCard>
  );
};
