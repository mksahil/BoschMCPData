# Tests

All test files for the Bosche-Ai project are consolidated here.

```
tests/
├── backend/          # Node.js API endpoint & rate-limit tests
├── frontend/         # A2A seat-booking agent & seat API tests (Node ESM)
├── e2e/              # End-to-end browser tests (Playwright/Cypress, future)
└── stress_test.py    # Python multi-threaded rate-limit stress test (all routes)
```

---

## Prerequisites

```bash
# Install backend test dependencies (from repo root)
cd backend && npm install
```

For the Python stress test:
```bash
pip install requests   # stdlib only — no extra deps needed
```

---

## Backend Tests (`tests/backend/`)

All run from the **repo root** with the backend server running on `http://localhost:3001`.

| File | What it tests |
|---|---|
| `rateLimit.test.js` | Unit tests for all 4 rate limiters (Jest + supertest, no real server needed) |
| `stress-rate-limit.js` | Live stress test — fires 14 rapid requests per endpoint, confirms 429 fires |
| `test-chat-api.js` | `/api/chat` — banner routing, seat intent, rate-limit burst |
| `test-canteen-api.js` | `/api/canteen/query` — Bangalore/Coimbatore menus, rate-limit burst |
| `test-community-api.js` | `/api/community/list`, `/api/community/register`, entry-exit routes, rate-limit burst |
| `test-seat-api.js` | A2A seat-booking agent (direct HTTPS call) |
| `test-banner-service.js` | Banner service unit test |
| `test-encryption-api.js` | Encryption endpoint |
| `test-local-login.js` | Local auth login flow |
| `test-privacy-fix.js` | Privacy guard (colleague-query detection) |
| `test-split-prompt.js` | Split-prompt logic |
| `test-token.js` | Token generation & caching |
| `test-travel-logic.js` | Travel service routing logic |
| `test-travel-reset-intent.js` | Travel intent reset behaviour |
| `test_followup_fix.js` | Follow-up query handling |
| `test_priv.js` | Privacy detection edge cases |
| `test_privacy_fix.js` | Privacy fix regression |

### Run individual backend tests

```bash
# Unit tests (no server needed)
cd backend && npx jest tests/rateLimit.test.js --no-coverage

# Live API tests (server must be running on :3001)
node tests/backend/test-chat-api.js
node tests/backend/test-canteen-api.js
node tests/backend/test-community-api.js

# Live stress test (coloured output, employee-isolation check)
node tests/backend/stress-rate-limit.js
# or with custom URL / employee number:
node tests/backend/stress-rate-limit.js http://localhost:3001 30945143
```

### Environment variables (optional)

```bash
TEST_AUTH_TOKEN=<bearer_token>   # pass Authorization header
TEST_EMPLOYEE_NUM=30945143       # pass X-Employee-Number header
```

---

## Frontend Tests (`tests/frontend/`)

Seat-booking A2A agent candidates — each fires an HTTPS call to the deployed agent
and saves the raw response to a JSON file.

```bash
# Run from repo root (Node 18+ required for ESM .mjs)
node tests/frontend/test-seat-E.mjs        # Candidate E (stringified user_data)
node tests/frontend/test-seat-G.mjs        # Candidate G
node tests/frontend/test-seat-H.mjs        # ... and so on
node tests/frontend/test-system-instruction.mjs  # System instruction format
```

Results are written to `tests/frontend/test-result-*.json`.

---

## Python Stress Test (`tests/stress_test.py`)

Multi-threaded test that hits all rate-limited endpoints simultaneously.

```bash
python tests/stress_test.py
```

Set `AUTH_TOKEN` and `EMPLOYEE_NUMBER` at the top of the file,
or leave them empty to rely on IP-based key fallback.

### Rate-limit thresholds under test

| Limiter | Routes | Limit |
|---|---|---|
| `chatRateLimiter` | `/api/chat` | 2 req / min |
| `serviceRateLimiter` | `/api/canteen/query`, `/api/community/list`, `/api/community/register`, `/api/entryexit/query`, `/api/time-tracking/*` | 2 req / min |
| `globalRateLimiter` | All routes | 100 req / min |

---

## E2E Tests (`tests/e2e/`)

Reserved for future Playwright / Cypress browser automation tests.
