/**
 * Rate-Limiting Test Suite
 *
 * Tests a minimal Express app that mirrors the exact rate-limit config in server.js.
 * No Azure OpenAI / MCP calls are made — only the middleware behaviour is verified.
 *
 * Limits under test (match server.js):
 *   aiRateLimiter    — 10 req / 60 s, key = X-Employee-Number || IP
 *   loginRateLimiter — 10 req / 60 s, key = IP
 *   globalRateLimiter— 60 req / 60 s, key = IP
 */

const request = require('supertest');
const express = require('express');
const { rateLimit } = require('express-rate-limit');

// ─── helpers ────────────────────────────────────────────────────────────────

function buildApp({ windowMs = 1000, globalMax = 30 } = {}) {
  const app = express();
  app.use(express.json());

  // Production limits: all three are 10 req / 60 s.
  // Test scaling: AI and login → 3 / 1 s (same ratio).
  // Global is set high (30) by default so it doesn't interfere when testing
  // AI or login limiter behaviour in isolation. The Global Rate Limiter test
  // group passes globalMax=4 to exercise it directly.

  const aiRateLimiter = rateLimit({
    windowMs,
    max: 3,
    keyGenerator: (req) => req.headers['x-employee-number'] || req.ip,
    validate: { keyGeneratorIpFallback: false }, // req.ip is consistent in test loopback
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'Too many requests. You can send up to 10 messages per minute. Please wait before trying again.',
      retryAfter: 60,
    },
  });

  const loginRateLimiter = rateLimit({
    windowMs,
    max: 3,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'Too many login attempts. Please wait a minute before trying again.',
      retryAfter: 60,
    },
  });

  const globalRateLimiter = rateLimit({
    windowMs,
    max: globalMax,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests from this IP. Please slow down.', retryAfter: 60 },
  });

  app.use(globalRateLimiter);

  // AI routes
  app.post('/api/canteen/query', aiRateLimiter, (_req, res) => res.json({ ok: true }));
  app.post('/api/entryexit/query', aiRateLimiter, (_req, res) => res.json({ ok: true }));
  app.post('/api/chat', aiRateLimiter, (_req, res) => res.json({ ok: true }));
  app.post('/api/time-tracking/query', aiRateLimiter, (_req, res) => res.json({ ok: true }));

  // Auth
  app.post('/api/auth/login', loginRateLimiter, (_req, res) => res.json({ ok: true }));

  // Non-limited
  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

  return app;
}

// ─── helper: fire N identical requests ──────────────────────────────────────

async function fireRequests(app, { method = 'post', path, headers = {}, count }) {
  const results = [];
  for (let i = 0; i < count; i++) {
    const req = request(app)[method](path).set(headers);
    const res = await req;
    results.push(res.status);
  }
  return results;
}

// ─── AI rate limiter tests ───────────────────────────────────────────────────

describe('AI Rate Limiter — per-employee key', () => {
  const AI_ROUTES = [
    '/api/canteen/query',
    '/api/entryexit/query',
    '/api/chat',
    '/api/time-tracking/query',
  ];

  for (const route of AI_ROUTES) {
    describe(route, () => {
      let app;
      beforeEach(() => { app = buildApp(); });

      test('allows requests up to the limit', async () => {
        const statuses = await fireRequests(app, {
          path: route,
          headers: { 'x-employee-number': 'EMP001' },
          count: 3,
        });
        expect(statuses.every((s) => s === 200)).toBe(true);
      });

      test('returns 429 on the request that exceeds the limit', async () => {
        const statuses = await fireRequests(app, {
          path: route,
          headers: { 'x-employee-number': 'EMP002' },
          count: 4, // 1 over limit
        });
        expect(statuses[3]).toBe(429);
      });

      test('429 body contains a user-friendly error message', async () => {
        await fireRequests(app, {
          path: route,
          headers: { 'x-employee-number': 'EMP003' },
          count: 3,
        });
        const res = await request(app)
          .post(route)
          .set('x-employee-number', 'EMP003');
        expect(res.status).toBe(429);
        expect(res.body).toHaveProperty('error');
        expect(typeof res.body.error).toBe('string');
        expect(res.body.error.length).toBeGreaterThan(0);
      });

      test('429 response includes RateLimit-* standard headers', async () => {
        await fireRequests(app, {
          path: route,
          headers: { 'x-employee-number': 'EMP004' },
          count: 3,
        });
        const res = await request(app)
          .post(route)
          .set('x-employee-number', 'EMP004');
        expect(res.status).toBe(429);
        // express-rate-limit v7+ uses RateLimit-* headers
        const headerKeys = Object.keys(res.headers).map((k) => k.toLowerCase());
        const hasRateLimitHeader = headerKeys.some((k) => k.startsWith('ratelimit'));
        expect(hasRateLimitHeader).toBe(true);
      });

      test('different employees get independent counters', async () => {
        // EMP-A exhausts their quota
        await fireRequests(app, {
          path: route,
          headers: { 'x-employee-number': 'EMP-A' },
          count: 3,
        });
        const blocked = await request(app).post(route).set('x-employee-number', 'EMP-A');
        expect(blocked.status).toBe(429);

        // EMP-B has not been used — should still get 200
        const fresh = await request(app).post(route).set('x-employee-number', 'EMP-B');
        expect(fresh.status).toBe(200);
      });

      test('falls back to IP key when X-Employee-Number header is absent', async () => {
        // Send 3 requests without the employee header — uses IP as key
        const statuses = await fireRequests(app, { path: route, count: 3 });
        expect(statuses.every((s) => s === 200)).toBe(true);

        // 4th request over limit — still gets 429
        const res = await request(app).post(route);
        expect(res.status).toBe(429);
      });
    });
  }
});

// ─── Login rate limiter tests ────────────────────────────────────────────────

describe('Login Rate Limiter', () => {
  let app;
  beforeEach(() => { app = buildApp(); });

  test('allows up to the limit', async () => {
    const statuses = await fireRequests(app, { path: '/api/auth/login', count: 3 });
    expect(statuses.every((s) => s === 200)).toBe(true);
  });

  test('returns 429 after the limit is exceeded', async () => {
    const statuses = await fireRequests(app, { path: '/api/auth/login', count: 4 });
    expect(statuses[3]).toBe(429);
  });

  test('429 body contains login-specific message', async () => {
    await fireRequests(app, { path: '/api/auth/login', count: 3 });
    const res = await request(app).post('/api/auth/login');
    expect(res.status).toBe(429);
    expect(res.body.error).toMatch(/login/i);
  });
});

// ─── Global rate limiter tests ───────────────────────────────────────────────

// Global limiter tests use globalMax=4 so the boundary is exercised directly
// without interference from the AI/login limiters (which use max=3).
describe('Global Rate Limiter', () => {
  let app;
  beforeEach(() => { app = buildApp({ globalMax: 4 }); });

  test('allows up to the global limit on non-AI routes', async () => {
    // /api/health has no per-route limiter — only global (max 4 in this test group)
    const statuses = await fireRequests(app, { method: 'get', path: '/api/health', count: 4 });
    expect(statuses.every((s) => s === 200)).toBe(true);
  });

  test('global limiter blocks after limit is exceeded', async () => {
    const statuses = await fireRequests(app, { method: 'get', path: '/api/health', count: 5 });
    expect(statuses[4]).toBe(429);
  });

  test('global limit is consumed by AI route requests too', async () => {
    // AI route requests count against both aiRateLimiter AND globalRateLimiter
    await fireRequests(app, {
      path: '/api/chat',
      headers: { 'x-employee-number': 'EMP-GLOBAL' },
      count: 3, // uses 3 of 4 global slots (also exhausts AI limiter for EMP-GLOBAL)
    });
    // One more health request — still OK (3 + 1 = 4)
    const statuses = await fireRequests(app, { method: 'get', path: '/api/health', count: 1 });
    expect(statuses.every((s) => s === 200)).toBe(true);

    // 5th request total — blocked by global
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(429);
  });
});
