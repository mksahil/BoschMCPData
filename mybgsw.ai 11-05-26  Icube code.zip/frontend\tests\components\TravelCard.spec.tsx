/**
 * TravelCard — rate-limit 429 handling tests
 *
 * Coverage targets:
 *   ✓ Renders initial AI travel assistant greeting
 *   ✓ Sends user message and displays AI response
 *   ✓ Shows 429 error bubble in chat
 *   ✓ Input is disabled while rate-limited
 *   ✓ Send button is disabled while rate-limited
 *   ✓ Placeholder text changes to show countdown when rate-limited
 *   ✓ Enter key does not send while rate-limited
 *
 * Note: DashboardCard renders a <div role="button"> wrapper, so native <button>
 * elements are isolated using el.tagName === 'BUTTON'.
 *
 * Note: jasmine.clock() is intentionally NOT used here — it breaks waitFor's
 * internal polling. Timer-expiry behaviour is covered in useRateLimit.spec.ts.
 */

import { render, screen, fireEvent, act, waitFor } from '@testing-library/react';
import { TravelCard } from '@/components/TravelCard';
import { AuthProvider } from '@/context/AuthContext';

window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

function buildResponse(body: object, status = 200) {
  return Promise.resolve({
    ok: status >= 200 && status < 300,
    status,
    json: () => Promise.resolve(body),
    headers: new Headers({ 'Retry-After': '10' }),
  } as unknown as Response);
}

function seedUser() {
  sessionStorage.setItem(
    'mybgsw_user',
    JSON.stringify({ employeeNumber: 'EMP001', accessToken: 'tok' })
  );
}

/** Native <button> elements only — excludes DashboardCard's div[role=button] */
function getNativeButtons() {
  return screen.getAllByRole('button').filter(el => el.tagName === 'BUTTON');
}

/** The single send button in the card */
function getSendButton() {
  const buttons = getNativeButtons();
  return buttons[buttons.length - 1];
}

const renderCard = () =>
  render(
    <AuthProvider>
      <TravelCard />
    </AuthProvider>
  );

describe('TravelCard — 429 rate-limit handling', () => {
  beforeEach(() => {
    seedUser();
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  it('shows the initial AI travel greeting', () => {
    renderCard();
    expect(screen.getByText(/AI Travel Assistant/i)).toBeTruthy();
  });

  it('sends a message and displays AI response', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ response: 'Trip to Delhi booked.' })
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book Delhi trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      expect(screen.getByText('Trip to Delhi booked.')).toBeTruthy();
    });
  });

  it('shows a 429 error bubble in the chat', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Too many requests' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      expect(screen.getByText(/Too many requests|Please wait/i)).toBeTruthy();
    });
  });

  it('disables the input while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      expect(screen.getByRole('textbox').hasAttribute('disabled')).toBeTrue();
    });
  });

  it('disables the send button while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      expect(getSendButton().hasAttribute('disabled')).toBeTrue();
    });
  });

  it('changes placeholder to show countdown when rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      const placeholder = screen.getByRole('textbox').getAttribute('placeholder') || '';
      expect(placeholder).toMatch(/Rate limited|retry in/i);
    });
  });

  it('does not fire a second fetch when Enter is pressed while rate-limited', async () => {
    const fetchSpy = spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Book trip' } });
      fireEvent.click(getSendButton());
    });

    await waitFor(() => {
      expect(screen.getByRole('textbox').hasAttribute('disabled')).toBeTrue();
    });

    const countAfterLimit = fetchSpy.calls.count();

    await act(async () => {
      fireEvent.keyPress(screen.getByRole('textbox'), {
        key: 'Enter', code: 'Enter', charCode: 13,
      });
    });

    expect(fetchSpy.calls.count()).toBe(countAfterLimit);
  });
});
