/**
 * EntryExitCard — rate-limit 429 handling tests
 *
 * Coverage targets:
 *   ✓ Shows loading spinner on mount (Refresh button disabled while loading)
 *   ✓ Renders employee name and status when both API calls succeed
 *   ✓ Shows rate-limit error when employee-name endpoint returns 429
 *   ✓ Shows rate-limit error when current-status endpoint returns 429
 *   ✓ Refresh button is disabled while rate-limited
 *   ✓ Refresh tooltip shows countdown when rate-limited
 *   ✓ Try-again button is disabled while rate-limited
 *   ✓ Try-again button shows countdown label when rate-limited
 *
 * Note: DashboardCard renders a <div role="button"> wrapper, so native <button>
 * elements are isolated using el.tagName === 'BUTTON'.
 *
 * Note: jasmine.clock() is intentionally NOT used here — it breaks waitFor's
 * internal polling. Timer-expiry behaviour is covered in useRateLimit.spec.ts.
 */

import { render, screen, waitFor } from '@testing-library/react';
import { EntryExitCard } from '@/components/EntryExitCard';
import { AuthProvider } from '@/context/AuthContext';

window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

function buildResponse(body: object, status = 200) {
  return Promise.resolve({
    ok: status >= 200 && status < 300,
    status,
    json: () => Promise.resolve(body),
    headers: new Headers({ 'Retry-After': '10' }),
  } as unknown as Response);
}

function seedUser() {
  sessionStorage.setItem(
    'mybgsw_user',
    JSON.stringify({
      employeeNumber: 'EMP001',
      accessToken: 'tok',
      expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
    })
  );
}

/** Native <button> elements only — excludes DashboardCard's div[role=button] */
function getNativeButtons() {
  return screen.getAllByRole('button').filter(el => el.tagName === 'BUTTON');
}

const renderCard = () =>
  render(
    <AuthProvider>
      <EntryExitCard />
    </AuthProvider>
  );

describe('EntryExitCard — 429 rate-limit handling', () => {
  beforeEach(() => {
    seedUser();
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  it('shows loading state on mount — Refresh button is disabled while loading', () => {
    spyOn(window, 'fetch').and.returnValue(new Promise(() => {})); // never resolves

    renderCard();

    const refreshBtn = getNativeButtons().find(
      b => b.title === 'Refresh' || b.getAttribute('title') === 'Refresh'
    );
    expect(refreshBtn).toBeTruthy();
    expect(refreshBtn!.hasAttribute('disabled')).toBeTrue();
  });

  it('renders employee name and status when both API calls succeed', async () => {
    spyOn(window, 'fetch').and.callFake((url: string) => {
      if ((url as string).includes('employee-name')) {
        return buildResponse({ success: true, name: 'Alice Johnson' });
      }
      return buildResponse({ success: true, status: 'IN', lastSwipe: null, location: 'Bangalore' });
    });

    renderCard();

    await waitFor(() => {
      expect(screen.getByText('Alice Johnson')).toBeTruthy();
      expect(screen.getByText('Checked In')).toBeTruthy();
    });
  });

  it('shows rate-limit error when employee-name endpoint returns 429', async () => {
    spyOn(window, 'fetch').and.callFake((url: string) => {
      if ((url as string).includes('employee-name')) {
        return buildResponse({ error: 'Too many requests' }, 429);
      }
      return buildResponse({ success: true, status: 'IN', lastSwipe: null, location: null });
    });

    renderCard();

    await waitFor(() => {
      expect(screen.getByText(/Too many requests\./i)).toBeTruthy();
    });
  });

  it('shows rate-limit error when current-status endpoint returns 429', async () => {
    spyOn(window, 'fetch').and.callFake((url: string) => {
      if ((url as string).includes('current-status')) {
        return buildResponse({ error: 'Too many requests' }, 429);
      }
      return buildResponse({ success: true, name: 'Bob' });
    });

    renderCard();

    // Use a specific pattern that only matches the error <p>, not the
    // "Retry in Xs" button text — getByText throws when multiple elements match.
    await waitFor(() => {
      expect(screen.getByText(/Too many requests\./i)).toBeTruthy();
    });
  });

  it('disables the Refresh button while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    // Wait until the rate-limit error text appears, then check the Refresh button.
    // Using two separate waitFor calls avoids a race where both conditions are
    // checked in a single callback before state has fully settled.
    await waitFor(() => {
      expect(screen.getByText(/Too many requests\./i)).toBeTruthy();
    });

    // The Refresh button is always rendered (outside the loading/error branches).
    // Its title becomes "Rate limited — retry in Xs" and disabled=true after 429.
    const refreshBtn = getNativeButtons().find(
      b => /rate limited/i.test(b.getAttribute('title') || '')
    );
    expect(refreshBtn).toBeTruthy();
    expect(refreshBtn!.hasAttribute('disabled')).toBeTrue();
  });

  it('shows countdown in Refresh button tooltip while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await waitFor(() => {
      const refreshBtn = getNativeButtons().find(
        b => /retry in \d+s/i.test(b.getAttribute('title') || '')
      );
      expect(refreshBtn).toBeTruthy();
    });
  });

  it('disables the Try again button while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await waitFor(() => {
      const tryAgainBtn = getNativeButtons().find(
        b => /Retry in \d+s/i.test(b.textContent || '')
      );
      expect(tryAgainBtn).toBeTruthy();
      expect(tryAgainBtn!.hasAttribute('disabled')).toBeTrue();
    });
  });

  it('shows countdown label on the Try again button while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await waitFor(() => {
      expect(screen.getByText(/Retry in \d+s/i)).toBeTruthy();
    });
  });
});
