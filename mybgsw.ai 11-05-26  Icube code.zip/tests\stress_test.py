import time
from collections import Counter
import json
import urllib.request
from urllib.error import HTTPError, URLError
from concurrent.futures import ThreadPoolExecutor

# ==========================================
# CONFIGURATION
# ==========================================
BASE_URL = "http://localhost:3001"

# --- Auth ---
# Fill these in to test authenticated endpoints.
# Leave AUTH_TOKEN empty to test IP-based key tracking (the new fallback).
AUTH_TOKEN = ""
EMPLOYEE_NUMBER = ""  # e.g. "30945143"

# Rate-limit thresholds (should match server.js):
#   - chatRateLimiter:    2 req/min  → trigger 429 on 3rd request
#   - serviceRateLimiter: 2 req/min  → trigger 429 on 3rd request
#   - globalRateLimiter:  100 req/min → should never trigger in this test
RATE_LIMIT_MAX = 2   # update if you change max in server.js

# We fire enough requests to reliably trigger the rate limit (RATE_LIMIT_MAX + 3)
TOTAL_REQUESTS_PER_ROUTE = RATE_LIMIT_MAX + 3
# Space them slightly so timing jitter doesn't hide 429s
DELAY_BETWEEN_REQUESTS = 0.5  # seconds

# ==========================================
# ROUTES UNDER TEST
# ==========================================
# Each entry: path, method, payload (or None), limiter type for annotation
ROUTES = [
    # ── Global (no specific limiter beyond globalRateLimiter) ──────────────
    {
        "path": "/",
        "method": "GET",
        "payload": None,
        "limiter": "global (100/min)",
    },
    # ── serviceRateLimiter routes (2/min) ─────────────────────────────────
    {
        "path": "/api/canteen/query",
        "method": "POST",
        "payload": {"query": "today's menu", "sessionId": "stress-test-canteen", "locationId": 1},
        "limiter": "service (2/min)",
    },
    {
        "path": "/api/time-tracking/today-entry/30945143",
        "method": "GET",
        "payload": None,
        "limiter": "service (2/min)",
    },
    {
        "path": "/api/time-tracking/current-status",
        "method": "GET",
        "payload": None,
        "limiter": "service (2/min)",
    },
    {
        "path": "/api/time-tracking/employee-name",
        "method": "GET",
        "payload": None,
        "limiter": "service (2/min)",
    },
    {
        "path": "/api/community/list",
        "method": "GET",
        "payload": None,
        "limiter": "service (2/min)",
    },
    {
        "path": "/api/entryexit/query",
        "method": "POST",
        "payload": {"query": "what time did I arrive today", "employeeNumber": "30945143"},
        "limiter": "service (2/min)",
    },
    # ── chatRateLimiter route (2/min) ───────────────────────────────────────
    {
        "path": "/api/chat",
        "method": "POST",
        "payload": {
            "query": "get all banners",
            "service": "banner",
            "employeeNumber": EMPLOYEE_NUMBER or "30945143",
        },
        "limiter": "chat (2/min)",
    },
]


# ==========================================
# REQUEST HELPER
# ==========================================
def make_request(route):
    url = f"{BASE_URL}{route['path']}"
    headers = {"Content-Type": "application/json"}

    if AUTH_TOKEN:
        headers["Authorization"] = f"Bearer {AUTH_TOKEN}"
    if EMPLOYEE_NUMBER:
        headers["X-Employee-Number"] = EMPLOYEE_NUMBER

    data = None
    if route.get("payload") and route["method"] in ("POST", "PUT", "PATCH"):
        data = json.dumps(route["payload"]).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers=headers, method=route["method"])

    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.getcode(), response.headers.get("Retry-After")
    except HTTPError as e:
        return e.code, e.headers.get("Retry-After") if hasattr(e, "headers") else None
    except URLError as e:
        return f"URLError: {e.reason}", None
    except Exception as e:
        return str(e), None


# ==========================================
# SINGLE-ROUTE TEST
# ==========================================
def test_route(route):
    print(f"\n[START] {route['method']} {route['path']}  |  limiter: {route['limiter']}")
    results = []  # (status_code, retry_after)

    for i in range(TOTAL_REQUESTS_PER_ROUTE):
        start = time.time()
        status, retry_after = make_request(route)
        results.append((status, retry_after))

        tag = ""
        if status == 429:
            tag = f"  ← RATE LIMIT (Retry-After: {retry_after}s)"
        print(f"  [{i+1:02d}] Status {status}{tag}")

        elapsed = time.time() - start
        sleep_time = max(0, DELAY_BETWEEN_REQUESTS - elapsed)
        if i < TOTAL_REQUESTS_PER_ROUTE - 1:
            time.sleep(sleep_time)

    return route["path"], route["limiter"], results


# ==========================================
# MAIN RUNNER
# ==========================================
def run_stress_test():
    print("=" * 60)
    print("  Bosche-Ai  — Rate Limit Stress Test")
    print("=" * 60)
    print(f"  Backend  : {BASE_URL}")
    print(f"  Auth     : {'token set' if AUTH_TOKEN else 'none (IP-based key)'}")
    print(f"  Emp#     : {EMPLOYEE_NUMBER or 'none (IP-based key)'}")
    print(f"  Requests : {TOTAL_REQUESTS_PER_ROUTE} per route (limit is {RATE_LIMIT_MAX})")
    print(f"  Delay    : {DELAY_BETWEEN_REQUESTS}s between requests")
    print(f"  Routes   : {len(ROUTES)}")
    print("=" * 60)

    start_time = time.time()
    all_results = []

    with ThreadPoolExecutor(max_workers=len(ROUTES)) as executor:
        futures = [executor.submit(test_route, route) for route in ROUTES]
        for future in futures:
            all_results.append(future.result())

    elapsed_total = time.time() - start_time

    print("\n\n" + "=" * 60)
    print("  SUMMARY")
    print("=" * 60)
    print(f"  Total time: {elapsed_total:.1f}s\n")

    passed = 0
    failed = 0

    for path, limiter, results in all_results:
        codes = [r[0] for r in results]
        counter = Counter(codes)
        hit_429 = counter.get(429, 0)
        expected_429 = TOTAL_REQUESTS_PER_ROUTE - RATE_LIMIT_MAX  # requests beyond the limit

        # Only service/chat limiters are expected to produce 429s in this test
        expect_limit = "2/min" in limiter

        if expect_limit:
            ok = hit_429 >= 1  # at minimum 1 blocked request
            status_tag = "✓ PASS (rate limit triggered)" if ok else "✗ FAIL (429 never fired — check keyGenerator!)"
        else:
            ok = True
            status_tag = "✓ OK (global limiter — no 429 expected)"

        if ok:
            passed += 1
        else:
            failed += 1

        print(f"  {path}  [{limiter}]")
        for code, count in sorted(counter.items(), key=lambda x: str(x[0])):
            marker = ""
            if code == 429:
                marker = " ← RATE LIMIT"
            elif code == 200:
                marker = " ← OK"
            elif isinstance(code, int) and code >= 400:
                marker = " ← ERROR"
            print(f"      {code} × {count}{marker}")
        print(f"      → {status_tag}\n")

    print("-" * 60)
    print(f"  Routes passed: {passed}/{passed + failed}")
    if failed:
        print("  ⚠ Some routes did NOT fire 429s. The rate limiter key may be")
        print("    falling back to 'ip-unknown' if headers are missing.")
    print("=" * 60)


if __name__ == "__main__":
    run_stress_test()
