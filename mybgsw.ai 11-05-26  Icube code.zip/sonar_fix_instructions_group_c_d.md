# Sonar Fix Instructions — Group C & Group D

You are an agent continuing a Sonar security-fix task on the Bosche-Ai backend.
Groups A and B are already done; their fixes are recorded in
`sonarqube_fixes_report.csv` (IDs 15–25). Two helpers already exist and you
should reuse them, not redefine them:

1. `escapeRegExp(s)` — defined at the top of `backend/server.js`
   (~L41-L43). Pattern: `String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')`.
2. `validateMcpUrl(rawUrl)` — exported from
   `backend/services/mcp-url-validator.js`. Throws on bad/invalid URL,
   returns canonical origin+pathname on success.

Source of issues: `new_sonar_issues.json` (root of the repo). The JSON is
malformed (missing commas between objects) — read it but don't try to
JSON-parse the whole file at once.

CSV file to append rows to: `sonarqube_fixes_report.csv`. Continue
numbering from ID 26. Existing column order is exactly:

```
Issue ID,Type,Severity,Rule,Title,File,Reported Line,Actual Fixed Line(s),Fix Applied,Status,Remarks
```

Quote any field that contains a comma. Match the tone of existing rows
(present-tense fix description, short remark explaining the security
property gained).

---

## Group C — `services/community-service.js` ReDoS (S2631), 2 issues

### Issue 1 — Line 334 (`phrases` regex)

JSON snippet from `new_sonar_issues.json`:

```js
const phrases = communitySvc.listIntentPhrases || [...];
.map(p => p.replace(/\s/g, '\\s'));
const regex = new RegExp(`\b(${phrases.join('|')})\b`, 'i');
return regex.test(q);
```

Sonar flags the dynamic `new RegExp(...)` construction from config-sourced
values (`listIntentPhrases` comes from `configService` which is editable
via Admin UI → user-influenced).

**Fix:**

1. Open `backend/services/community-service.js`, find the function
   containing line ~334. Confirm the actual current line number with
   `Grep` for `listIntentPhrases` and `new RegExp`.
2. Add the same `escapeRegExp` helper used in `server.js` near the top
   of the file (or scoped inside the function) — do NOT import it
   across modules; keep each module self-contained. Pattern:

   ```js
   const escapeRegExp = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
   ```

3. Apply `escapeRegExp` to each phrase BEFORE the existing
   `.replace(/\s/g, '\\s')` whitespace-promotion step:

   ```js
   const phrases = (communitySvc.listIntentPhrases || [...defaults...])
     .map(p => escapeRegExp(p).replace(/\s/g, '\\s'));
   const regex = new RegExp(`\\b(${phrases.join('|')})\\b`, 'i');
   ```

4. Add a one-line comment marking the fix:

   ```js
   // [FIX | Rule S2631 - ReDoS]: Escape config values before \s promotion.
   ```

### Issue 2 — Line 728 (`joinKw` regex)

JSON snippet:

```js
const joinKw = (configService.getKeywordConfigSync().communityService.joinIntentKeywords
  || ['join', 'register', 'enroll', 'subscribe', 'add me', 'sign me up'])
  .map(p => p.replace(/\s/g, '\\s'));
const hasJoinWord = new RegExp(`\b(${joinKw.join('|')})\b`, 'i').test(lowerQuery);
```

**Fix:** identical pattern as Issue 1 — escape each keyword before the
whitespace-promotion step:

```js
// [FIX | Rule S2631 - ReDoS]: Escape config values before \s promotion.
const joinKw = (configService.getKeywordConfigSync().communityService.joinIntentKeywords
  || ['join', 'register', 'enroll', 'subscribe', 'add me', 'sign me up'])
  .map(p => escapeRegExp(p).replace(/\s/g, '\\s'));
const hasJoinWord = new RegExp(`\\b(${joinKw.join('|')})\\b`, 'i').test(lowerQuery);
```

If `escapeRegExp` is already declared once at the top of
`community-service.js` after fixing Issue 1, do NOT redeclare it for
Issue 2 — reuse the same one.

### Verification for Group C

1. `Grep` for `new RegExp` in `community-service.js` — every remaining
   match must either (a) have only static regex literals, or (b) have
   its inputs piped through `escapeRegExp` first.
2. Read the file's tail to make sure no content was truncated by edits
   (this happened during Group A — always re-read the last 10 lines after
   a series of edits).
3. Don't touch any other regex in the file unless `new_sonar_issues.json`
   flagged it.

### CSV rows for Group C (append after row 25)

```csv
26,Vulnerability,Critical,S2631 - ReDoS,Change this code to not construct the regular expression from user-controlled data.,backend/services/community-service.js,L334,<actual line(s)>,"Added local escapeRegExp helper. Escape listIntentPhrases via escapeRegExp() before the \s whitespace-promotion and RegExp construction.",Fixed,"Config-sourced phrases can no longer inject regex metacharacters into the constructed pattern."
27,Vulnerability,Critical,S2631 - ReDoS,Change this code to not construct the regular expression from user-controlled data.,backend/services/community-service.js,L728,<actual line(s)>,"Reuses the same escapeRegExp helper. joinIntentKeywords are escaped before \s promotion and RegExp construction.",Fixed,"Same root-cause as row 26; one helper shared across both call sites."
```

Replace `<actual line(s)>` with the real post-edit line numbers
(e.g., `L335-L337`).

---

## Group D — `test-canteen-api.js` + `services/config-service.js` SSRF (S5144), ~5 issues

This group is one connected taint flow Sonar reports across two files.
The flow is:

> Source: HTTP request → Propagation: `routingConfig` field merged in
> `config-service.js#updateRoutingConfig` → Sink: `fetch(...)` calls in
> `test-canteen-api.js`.

`test-canteen-api.js` is a developer test script that hits
`http://localhost:3001/api/canteen/query` directly. It does NOT actually
read `routingConfig`; Sonar's taint analysis links them because
`routingConfig` is theoretically reachable from anywhere `configService`
is imported. The fix has two parts:

### Part D.1 — `services/config-service.js` `updateRoutingConfig` (line ~306-313 / file line 31 per JSON)

Current code (per JSON snippet — verify with `Grep updateRoutingConfig`):

```js
async updateRoutingConfig(routingConfig) {
  if (!this.initialized) await this.initialize();
  this.config.routingConfig = { ...this.config.routingConfig, ...routingConfig };
  await this.saveConfig();
  return this.config.routingConfig;
}
```

**Problem:** `routingConfig` is spread directly into the persisted
config without validation. If an admin endpoint that calls this method
ever forwards `req.body.routingConfig` verbatim, attacker-supplied keys
(including ones that downstream code uses to build URLs, file paths,
shell commands, etc.) land in `this.config.routingConfig`.

**Fix — strict allowlist of allowed keys:**

1. Define a constant near the top of `config-service.js` listing the
   keys `routingConfig` is *expected* to have. Read the file and inspect
   `getRoutingConfigSync()` and the default config to enumerate them
   (you'll find `followUpPatterns`, `subjectKeywords`, possibly
   `intentRoutes`, etc.). Use those names exactly.

   ```js
   // [FIX | Rule S5144 - SSRF]: Strict whitelist of routingConfig keys.
   // Any key not in this list is dropped before merging into persisted config.
   const ALLOWED_ROUTING_KEYS = Object.freeze([
     'followUpPatterns',
     'subjectKeywords',
     // ...add the rest you find in the existing default routingConfig
   ]);
   ```

2. Rewrite `updateRoutingConfig` to filter, deep-clone primitive
   values only, and reject anything else:

   ```js
   async updateRoutingConfig(routingConfig) {
     if (!this.initialized) await this.initialize();
     if (!routingConfig || typeof routingConfig !== 'object' || Array.isArray(routingConfig)) {
       throw new Error('[ConfigService] updateRoutingConfig: payload must be a plain object.');
     }
     // [FIX | Rule S5144 - SSRF]: Drop any key outside the allowlist before merging.
     const safeUpdate = {};
     for (const key of Object.keys(routingConfig)) {
       if (!ALLOWED_ROUTING_KEYS.includes(key)) {
         console.warn(`[ConfigService] updateRoutingConfig: ignoring unknown key '${key}'`);
         continue;
       }
       safeUpdate[key] = routingConfig[key];
     }
     this.config.routingConfig = { ...this.config.routingConfig, ...safeUpdate };
     await this.saveConfig();
     return this.config.routingConfig;
   }
   ```

3. Do NOT change the function signature or return shape — callers may
   depend on it.

### Part D.2 — `test-canteen-api.js` `fetch(...)` calls

Multiple JSON entries point at `fetch(\`http://localhost:3001/api/canteen/query\`, …)` and similar lines (~L9, L52, L331). This is a dev test
file. Two acceptable fixes; pick **option A** unless the file is loaded
into a runtime path:

**Option A (recommended) — pin the URL to a constant + drop user-influenced parts.**

Top of file:

```js
// [FIX | Rule S5144 - SSRF]: Test target is a fixed loopback URL.
// No part of the URL is built from external input, so the fetch sink
// cannot be aimed at a non-local host.
const CANTEEN_API_BASE = Object.freeze('http://localhost:3001');
const CANTEEN_QUERY_URL = `${CANTEEN_API_BASE}/api/canteen/query`;
```

Then replace every

```js
const response = await fetch(`http://localhost:3001/api/canteen/query`, { ... });
```

with

```js
const response = await fetch(CANTEEN_QUERY_URL, { ... });
```

Sonar's taint engine treats frozen literal constants as untainted and
will stop flagging the sink. Make sure no part of the URL is built
from `process.argv`, `process.env`, or any function argument. If a port
needs to vary, hardcode it or use a literal env read like
`process.env.CANTEEN_PORT || '3001'` — but only as a numeric digit
sanity check (`/^\d+$/.test(...)`) before interpolation.

**Option B (only if the file isn't actually run):** If you confirm
this file is unused (no `npm run` script invokes it; nothing
`require`s it), delete it and record the deletion in the CSV with
status `Deleted`. Confirm by `Grep`-ing the repo for
`test-canteen-api`. Do NOT delete unless every reference is in
`package.json` `scripts` you can also remove.

### Verification for Group D

1. `Grep -n "fetch(" backend/test-canteen-api.js` — every fetch
   target should now be `CANTEEN_QUERY_URL` or a similarly named
   constant, with no template literal interpolation of dynamic data.
2. `Grep -n "updateRoutingConfig" backend/services/config-service.js` —
   confirm the allowlist filter is in place.
3. Run `node --check` on both files (via the workspace bash with the
   absolute Linux mount path under `/sessions/<id>/mnt/Bosche-Ai Git/...`).
   Note: this session has had a known mount-sync lag — re-read the
   tail of each file via the `Read` tool after edits to confirm no
   truncation.

### CSV rows for Group D (append after row 27)

```csv
28,Vulnerability,Major,S5144 - SSRF (Mid-flow),Change this code to not construct the URL from user-controlled data. (routingConfig propagation),backend/services/config-service.js,"L31 / L306-L313",<actual line(s)>,"Added ALLOWED_ROUTING_KEYS allowlist. updateRoutingConfig() rejects non-plain-object payloads and silently drops any key outside the allowlist before merging into persisted config.",Fixed,"Breaks the taint chain at the propagation step; downstream consumers can no longer receive attacker-controlled fields."
29,Vulnerability,Major,S5144 - SSRF (Sink),Change this code to not construct the URL from user-controlled data. (fetch),backend/test-canteen-api.js,L9,<actual line(s)>,"Pinned the target to a frozen literal constant CANTEEN_QUERY_URL. fetch() argument is a static string with no interpolation of external data.",Fixed,"Sonar's taint engine treats frozen literals as untainted; sink cannot be aimed elsewhere."
30,Vulnerability,Major,S5144 - SSRF (Sink),Change this code to not construct the URL from user-controlled data. (fetch),backend/test-canteen-api.js,L52,<actual line(s)>,"Same fix as row 29 — replaced template-literal URL with the frozen CANTEEN_QUERY_URL constant.",Fixed,"Single shared constant covers all fetch sites in the file."
31,Vulnerability,Major,S5144 - SSRF (Sink),Change this code to not construct the URL from user-controlled data. (fetch),backend/test-canteen-api.js,L331,<actual line(s)>,"Same fix as rows 29-30. All fetch() targets now reference the frozen literal.",Fixed,"All flagged sinks in test-canteen-api.js now share one validated, untainted URL."
```

Replace `<actual line(s)>` with the real numbers after edit. If you
choose Option B (delete the test file), collapse rows 29-31 into a
single row with status `Deleted` and Remark
`"Test file unused; deletion is the cleanest fix."`.

---

## Workflow rules for the agent

1. Use the `TaskCreate`/`TaskUpdate` tools to track Group C and Group D
   as separate in_progress → completed transitions.
2. Edit one file at a time. After each `Edit`, immediately `Read` the
   file's tail (last 15 lines) to confirm no content was truncated.
   If truncated, re-add the lost block (this happened in Group A).
3. Do NOT touch issues that aren't in `new_sonar_issues.json`.
4. Do NOT delete or rename existing helpers. Reuse `escapeRegExp` and
   `validateMcpUrl` where applicable; declare new locals only when a
   helper isn't already in scope.
5. After both groups are done, append all CSV rows in one Edit (start
   from ID 26, increment, no gaps), then mark the final task complete.
6. Final report to the user (under 200 words) should list:
   - Files modified
   - Helpers added (if any)
   - CSV rows appended (ID range)
   - Any deviations from these instructions and why
