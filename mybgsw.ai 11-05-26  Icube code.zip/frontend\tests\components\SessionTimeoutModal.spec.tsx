/**
 * SessionTimeoutModal — unit tests
 *
 * Coverage targets:
 *   ✓ Modal is not rendered when open=false
 *   ✓ Modal is rendered and visible when open=true
 *   ✓ Countdown formats correctly: MM:SS (e.g. 2:00, 1:30, 0:09)
 *   ✓ Countdown display has correct ARIA attributes (role=timer, aria-live=assertive)
 *   ✓ "Stay Logged In" button is present and calls onStayLoggedIn
 *   ✓ "Log Out Now" button is present and calls onLogout
 *   ✓ "Stay Logged In" button has autoFocus
 *   ✓ Dialog title and description are rendered
 *   ✓ data-testid attributes are present on key elements
 *   ✓ Backdrop click does NOT close the dialog (onInteractOutside blocked)
 *   ✓ Countdown updates when prop changes
 */

import { render, screen, fireEvent } from '@testing-library/react';
import { SessionTimeoutModal } from '@/components/SessionTimeoutModal';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function renderModal(overrides: {
  open?: boolean;
  countdown?: number;
  onStayLoggedIn?: () => void;
  onLogout?: () => void;
} = {}) {
  const defaults = {
    open: true,
    countdown: 120, // 2:00
    onStayLoggedIn: jasmine.createSpy('onStayLoggedIn'),
    onLogout: jasmine.createSpy('onLogout'),
  };
  const props = { ...defaults, ...overrides };
  return { ...render(<SessionTimeoutModal {...props} />), props };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('SessionTimeoutModal', () => {
  // ── Visibility ──────────────────────────────────────────────────────────────

  it('does not render the modal content when open is false', () => {
    renderModal({ open: false });
    expect(screen.queryByTestId('session-timeout-modal')).toBeNull();
  });

  it('renders the modal when open is true', () => {
    renderModal({ open: true });
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();
  });

  // ── Title & Description ─────────────────────────────────────────────────────

  it('displays the dialog title "Session About to Expire"', () => {
    renderModal();
    expect(screen.getByText('Session About to Expire')).toBeTruthy();
  });

  it('displays the inactivity description text', () => {
    renderModal();
    expect(
      screen.getByText(/You have been inactive/i)
    ).toBeTruthy();
  });

  // ── Countdown formatting ────────────────────────────────────────────────────

  it('formats 120 seconds as "2:00"', () => {
    renderModal({ countdown: 120 });
    const display = screen.getByTestId('countdown-display');
    expect(display.textContent).toBe('2:00');
  });

  it('formats 90 seconds as "1:30"', () => {
    renderModal({ countdown: 90 });
    const display = screen.getByTestId('countdown-display');
    expect(display.textContent).toBe('1:30');
  });

  it('formats 9 seconds as "0:09" (zero-padded)', () => {
    renderModal({ countdown: 9 });
    const display = screen.getByTestId('countdown-display');
    expect(display.textContent).toBe('0:09');
  });

  it('formats 0 seconds as "0:00"', () => {
    renderModal({ countdown: 0 });
    const display = screen.getByTestId('countdown-display');
    expect(display.textContent).toBe('0:00');
  });

  it('formats 65 seconds as "1:05"', () => {
    renderModal({ countdown: 65 });
    const display = screen.getByTestId('countdown-display');
    expect(display.textContent).toBe('1:05');
  });

  // ── ARIA attributes on countdown ────────────────────────────────────────────

  it('countdown element has role="timer"', () => {
    renderModal();
    const display = screen.getByTestId('countdown-display');
    expect(display.getAttribute('role')).toBe('timer');
  });

  it('countdown element has aria-live="assertive"', () => {
    renderModal();
    const display = screen.getByTestId('countdown-display');
    expect(display.getAttribute('aria-live')).toBe('assertive');
  });

  it('countdown element has aria-atomic="true"', () => {
    renderModal();
    const display = screen.getByTestId('countdown-display');
    expect(display.getAttribute('aria-atomic')).toBe('true');
  });

  it('countdown element has a descriptive aria-label', () => {
    renderModal({ countdown: 120 });
    const display = screen.getByTestId('countdown-display');
    expect(display.getAttribute('aria-label')).toContain('2:00');
  });

  // ── Buttons ─────────────────────────────────────────────────────────────────

  it('renders the "Stay Logged In" button', () => {
    renderModal();
    expect(screen.getByTestId('stay-logged-in-button')).toBeTruthy();
  });

  it('renders the "Log Out Now" button', () => {
    renderModal();
    expect(screen.getByTestId('logout-button')).toBeTruthy();
  });

  it('calls onStayLoggedIn when "Stay Logged In" is clicked', () => {
    const onStayLoggedIn = jasmine.createSpy('onStayLoggedIn');
    renderModal({ onStayLoggedIn });
    fireEvent.click(screen.getByTestId('stay-logged-in-button'));
    expect(onStayLoggedIn).toHaveBeenCalledTimes(1);
  });

  it('calls onLogout when "Log Out Now" is clicked', () => {
    const onLogout = jasmine.createSpy('onLogout');
    renderModal({ onLogout });
    fireEvent.click(screen.getByTestId('logout-button'));
    expect(onLogout).toHaveBeenCalledTimes(1);
  });

  it('does not call onLogout when "Stay Logged In" is clicked', () => {
    const onLogout = jasmine.createSpy('onLogout');
    renderModal({ onLogout });
    fireEvent.click(screen.getByTestId('stay-logged-in-button'));
    expect(onLogout).not.toHaveBeenCalled();
  });

  it('does not call onStayLoggedIn when "Log Out Now" is clicked', () => {
    const onStayLoggedIn = jasmine.createSpy('onStayLoggedIn');
    renderModal({ onStayLoggedIn });
    fireEvent.click(screen.getByTestId('logout-button'));
    expect(onStayLoggedIn).not.toHaveBeenCalled();
  });

  // ── Countdown updates ───────────────────────────────────────────────────────

  it('updates the displayed countdown when the countdown prop changes', () => {
    const { rerender } = renderModal({ countdown: 120 });
    expect(screen.getByTestId('countdown-display').textContent).toBe('2:00');

    rerender(
      <SessionTimeoutModal
        open={true}
        countdown={45}
        onStayLoggedIn={() => {}}
        onLogout={() => {}}
      />
    );
    expect(screen.getByTestId('countdown-display').textContent).toBe('0:45');
  });

  // ── data-testid completeness ────────────────────────────────────────────────

  it('has data-testid on the modal content wrapper', () => {
    renderModal();
    expect(screen.getByTestId('session-timeout-modal')).toBeTruthy();
  });

  it('has data-testid on the countdown display', () => {
    renderModal();
    expect(screen.getByTestId('countdown-display')).toBeTruthy();
  });

  it('has data-testid on the stay-logged-in button', () => {
    renderModal();
    expect(screen.getByTestId('stay-logged-in-button')).toBeTruthy();
  });

  it('has data-testid on the logout button', () => {
    renderModal();
    expect(screen.getByTestId('logout-button')).toBeTruthy();
  });
});
