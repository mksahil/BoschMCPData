const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
    rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

async function runTest() {
    const token = process.env.TEST_TOKEN;
    const clientId = process.env.TEST_CLIENT_ID;
    if (!token || !clientId) {
        console.error('TEST_TOKEN and TEST_CLIENT_ID environment variables must be set');
        process.exit(1);
    }
    const baseUrl = 'https://dev.boschassociatearena.com/api';

    try {
        console.log('Testing JWT generation with frontend token...');
        const response = await axios.get(`${baseUrl}/Token/GenrateTokenDetails`, {
            params: { clientID: clientId },
            headers: { 'Authorization': `Bearer ${token}` },
            httpsAgent
        });
        console.log('SUCCESS:', response.data);
    } catch (error) {
        if (error.response) {
            console.error('FAILED (401 expected):', error.response.status);
            console.error('Data:', error.response.data);
        } else {
            console.error('FAILED (other):', error.message);
        }
    }
}

runTest();
