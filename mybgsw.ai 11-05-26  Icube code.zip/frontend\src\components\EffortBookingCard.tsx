import { Clock, Copy, Calendar, CheckCircle } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const EffortBookingCard = () => {
  const requiredHours = 42.5; // 8.5 * 5 days
  const loggedHours = 34.0;
  const percentage = (loggedHours / requiredHours) * 100;

  return (
    <DashboardCard title="Effort Booking" icon={Clock}>
      <div className="space-y-4">
        {/* Weekly Progress */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-muted-foreground">This Week</span>
            <span className="text-xs font-semibold text-foreground">
              {loggedHours}/{requiredHours} hrs
            </span>
          </div>
          <div className="w-full bg-background/40 rounded-full h-3 overflow-hidden">
            <div 
              className="bg-gradient-accent h-full rounded-full transition-all duration-300"
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {requiredHours - loggedHours} hours remaining
          </p>
        </div>

        {/* Activity Tags */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-foreground">Activity Distribution:</p>
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <p className="text-xs text-muted-foreground">Project Work</p>
              <p className="text-sm font-semibold text-foreground">20 hrs</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <p className="text-xs text-muted-foreground">Meetings</p>
              <p className="text-sm font-semibold text-foreground">8 hrs</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <p className="text-xs text-muted-foreground">Review</p>
              <p className="text-sm font-semibold text-foreground">4 hrs</p>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <p className="text-xs text-muted-foreground">Admin</p>
              <p className="text-sm font-semibold text-foreground">2 hrs</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm">
            <Calendar className="w-4 h-4" />
            Log Today's Effort
          </button>
          <button className="w-full py-2 px-4 bg-secondary/40 hover:bg-gradient-accent hover:text-accent-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm text-foreground">
            <Copy className="w-4 h-4" />
            Copy Last Week
          </button>
        </div>

        {/* Status Alert */}
        <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
          <div className="flex items-start gap-2">
            <Clock className="w-4 h-4 text-warning mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-foreground">Reminder</p>
              <p className="text-xs text-muted-foreground">Don't forget to log Friday's effort!</p>
            </div>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
