/**
 * CafeteriaCard — rate-limit 429 handling tests
 *
 * Coverage targets:
 *   ✓ Shows location picker initially
 *   ✓ Fetches menu after location is selected
 *   ✓ Displays menu items when API returns structured menuData
 *   ✓ Shows error message when API returns 429
 *   ✓ Retry button is disabled while rate-limited
 *   ✓ Retry button label shows countdown when rate-limited
 *   ✓ Countdown text is displayed below the error
 *   ✓ Change Location button resets to picker
 *
 * Note: DashboardCard renders a <div role="button"> wrapper, so native <button>
 * elements are isolated by filtering on el.tagName === 'BUTTON'.
 *
 * Note: jasmine.clock() is intentionally NOT used here — it breaks waitFor's
 * internal polling. Timer-expiry behaviour is covered in useRateLimit.spec.ts.
 */

import { render, screen, fireEvent, act, waitFor } from '@testing-library/react';
import { CafeteriaCard } from '@/components/CafeteriaCard';
import { AuthProvider } from '@/context/AuthContext';

window.HTMLElement.prototype.scrollIntoView = jasmine.createSpy('scrollIntoView');

function buildResponse(body: object, status = 200) {
  return Promise.resolve({
    ok: status >= 200 && status < 300,
    status,
    json: () => Promise.resolve(body),
    headers: new Headers({ 'Retry-After': '30' }),
  } as unknown as Response);
}

function seedUser() {
  sessionStorage.setItem(
    'mybgsw_user',
    JSON.stringify({ employeeNumber: 'EMP001', accessToken: 'tok' })
  );
}

/** Returns all native <button> elements (excludes DashboardCard's div[role=button]) */
function getNativeButtons() {
  return screen.getAllByRole('button').filter(el => el.tagName === 'BUTTON');
}

const renderCard = () =>
  render(
    <AuthProvider>
      <CafeteriaCard />
    </AuthProvider>
  );

describe('CafeteriaCard — 429 rate-limit handling', () => {
  beforeEach(() => {
    seedUser();
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  it('renders location picker before a location is selected', () => {
    renderCard();
    expect(screen.getByText('Select Your Location')).toBeTruthy();
    expect(screen.getByText('Bangalore')).toBeTruthy();
    expect(screen.getByText('Coimbatore')).toBeTruthy();
  });

  it('calls fetch after clicking a location', async () => {
    const fetchSpy = spyOn(window, 'fetch').and.returnValue(
      buildResponse({ menuData: { breakfast: 'Idli', lunch: 'Rice', snacks: 'Tea' } })
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(fetchSpy).toHaveBeenCalled();
    });
  });

  it('displays menu items when API returns structured menuData', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({
        menuData: {
          breakfast: 'Idli, Vada',
          lunch: 'Rice, Dal',
          snacks: 'Biscuits, Tea',
        },
      })
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(screen.getByText(/Idli/)).toBeTruthy();
    });
  });

  it('shows an error message on 429 response', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Too many requests' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(screen.getByText(/Too many requests|Please wait/i)).toBeTruthy();
    });
  });

  it('disables Retry button while rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      const retryBtn = getNativeButtons().find(b => /Retry/i.test(b.textContent || ''));
      expect(retryBtn).toBeTruthy();
      expect(retryBtn!.hasAttribute('disabled')).toBeTrue();
    });
  });

  it('shows countdown in Retry button label when rate-limited', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(screen.getByText(/Retry in \d+s/i)).toBeTruthy();
    });
  });

  it('shows countdown text below the error', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(screen.getByText(/Retry available in \d+s/i)).toBeTruthy();
    });
  });

  it('Change Location resets back to the location picker', async () => {
    spyOn(window, 'fetch').and.returnValue(
      buildResponse({ error: 'Rate limited' }, 429)
    );

    renderCard();

    await act(async () => {
      fireEvent.click(screen.getByText('Bangalore'));
    });

    await waitFor(() => {
      expect(screen.getByText(/Change Location/i)).toBeTruthy();
    });

    await act(async () => {
      const changeBtns = getNativeButtons().filter(
        b => /Change Location/i.test(b.textContent || '')
      );
      fireEvent.click(changeBtns[0]);
    });

    expect(screen.getByText('Select Your Location')).toBeTruthy();
  });
});
