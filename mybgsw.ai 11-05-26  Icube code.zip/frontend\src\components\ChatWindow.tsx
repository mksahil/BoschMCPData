import { useState, useRef, useEffect, KeyboardEvent, useCallback } from "react";
import { X, MapPin, ThumbsUp, ThumbsDown, MicOff } from "lucide-react";
import { useTheme } from "next-themes";
import { cn, generateUUID, renderMarkdown } from "@/lib/utils";
import { Input } from "./ui/input";
import { toast } from "sonner";
import { API_ENDPOINTS } from "@/config";
import { RateLimitBanner } from "./RateLimitBanner";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";
import { useRateLimit } from "@/hooks/useRateLimit";
import { detectIntent, shouldResetActiveService } from "@/lib/intentDetector";
import { checkSensitivity } from "@/lib/privacy-utils";


// Web Speech API type declaration
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

interface Banner {
  id: string;
  title: string;
  description: string;
  tag: string;
  hasImage: boolean;
  imageBase64?: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  banners?: Banner[];
  conversationId?: number | null;
  feedback?: number; // -1 = thumbs down, 0 = no feedback, 1 = thumbs up
  isOutOfScope?: boolean;
  isBlocked?: boolean;
}

interface ChatWindowProps {
  isOpen: boolean;
  onClose: () => void; // This toggles the open state
}

const SENSITIVE_PATTERNS = [
  // Financial PII
  { pattern: /\b(?:\d[ -]*?){13,16}\b/, category: 'Financial PII', level: 'high' },
  // Identity PII
  { pattern: /\b[A-Z]{5}[0-9]{4}[A-Z]\b/i, category: 'Identity PII', level: 'high' },
  { pattern: /\b\d{4}\s\d{4}\s\d{4}\b/, category: 'Identity PII', level: 'high' },
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/, category: 'Identity PII', level: 'high' },
  // Authentication
  { pattern: /\b(?:password|pwd|secret|api[_\-\s]?key|token)\s*[:=]\s*\S+/i, category: 'Authentication credentials', level: 'high' },
  // Business (Low risk hint)
  { pattern: /\b(?:revenue|profit|merger|acquisition|nda|unreleased|restructuring)\b/i, category: 'Business-critical info', level: 'low' },
  // Health (Low risk hint)
  { pattern: /\b(?:diagnosis|prescription|disease|illness|medical condition)\b/i, category: 'Health info', level: 'low' }
];



const getServicePrefix = (query: string, activeService: string | null): string => {
  const q = query.toLowerCase();

  // Seat booking keywords
  if (q.includes('seat') || q.includes('desk') || (q.includes('book') && (q.includes('office') || q.includes('workstation') || q.includes('floor')))) {
    return 'seat booking: ';
  }

  // Travel keywords (broader set)
  if (['travel', 'flight', 'trip', 'hotel', 'visa', 'business trip', 'train', 'bus', 'ticket', 'booking', 'delhi', 'bangalore', 'mumbai', 'to', 'from'].some(k => q.includes(k))) {
    return 'travel: ';
  }

  // Canteen keywords
  if (['canteen', 'cafeteria', 'lunch', 'breakfast', 'menu', 'food', 'eat', 'hungry'].some(k => q.includes(k))) {
    return 'canteen: ';
  }

  // Fallback to active service context
  if (activeService) {
    const s = activeService.toLowerCase();
    if (s.includes('travel')) return 'travel: ';
    if (s.includes('canteen') || s.includes('cafeteria')) return 'canteen: ';
    if (s.includes('seat')) return 'seat booking: ';
  }

  return '';
};

export const ChatWindow = ({ isOpen, onClose: onToggle }: ChatWindowProps) => {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI companion. I can help you with:\n• Checking your schedule and tasks\n• Booking commute and cafeteria\n• Finding mentors and learning paths\n• Managing leave and travel\n• Tracking your progress\n\nHow can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [waitingForLocation, setWaitingForLocation] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null);
  const [activeService, setActiveService] = useState<string | null>(null);
  const [sensitivityWarning, setSensitivityWarning] = useState<{ isSensitive: boolean, level: string, category: string | null }>({ isSensitive: false, level: 'none', category: null });
  const [isListening, setIsListening] = useState(false);
  const [isSpeechRecognitionSupported, setIsSpeechRecognitionSupported] = useState(true);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Check if browser supports Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setIsSpeechRecognitionSupported(false);
    }
  }, []);

  // Auto-scroll to the latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    if (message.trim().length > 0) {
      setSensitivityWarning(checkSensitivity(message));
    } else {
      setSensitivityWarning({ isSensitive: false, level: 'none', category: null });
    }
  }, [message]);

  // Speech recognition handler
  const toggleVoice = useCallback(() => {
    if (isListening) {
      // Stop listening
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const isBrowser = typeof window !== 'undefined';
      const isFirefox = isBrowser && /Firefox/.test(navigator.userAgent);
      const message = isFirefox
        ? 'Voice input is not supported in Firefox. Please use Chrome, Edge, or Safari.'
        : 'Speech recognition is not supported in your browser. Try Chrome, Edge, or Safari.';
      toast.error(message);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setMessage(prev => prev ? prev + ' ' + transcript : transcript);
      toast.success('Voice captured!');
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please allow microphone permissions.');
      } else {
        toast.error('Voice input failed. Please try again.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, [isListening]);


  // Generate unique session ID for conversation context
  const [sessionId] = useState(() => generateUUID());

  // Intent detection lives in @/lib/intentDetector — see detectIntent / shouldResetActiveService.
  // The previous in-component substring matcher is intentionally removed to kill false positives
  // on words like "to" / "from" and to share logic with AIChat.

  const handleLocationSelect = async (locationId: number) => {
    const locationName = locationId === 1 ? 'Bangalore' : 'Coimbatore';
    const userMessage: Message = {
      role: 'user',
      content: locationName,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setSelectedLocation(locationId);
    setWaitingForLocation(false);
    setIsTyping(true);

    const finalQuery = getServicePrefix(activeService) + locationName;

    // Send unmodified history. Don't relabel past messages with service prefixes.
    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    try {
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: finalQuery,
          service: activeService,
          sessionId,
          locationId: locationId, // Use parameter directly instead of state
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        // RateLimitBanner renders inline — no message push needed
      } else if (response.ok) {
        if (data.needs_location) {
          setWaitingForLocation(true);
        }

        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date(),
          banners: data.banners,
          conversationId: data.conversationId || null,
          feedback: 0,
          isOutOfScope: !!data.isOutOfScope, // Flag out-of-scope responses
          isBlocked: data.service === 'privacy_guard' // Flag blocked responses
        };

        if (data.isOutOfScope) {
          setActiveService(null);
        } else if (data.service) {
          setActiveService(data.service);
        }

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      }]);
    }

    setIsTyping(false);
  };

  const handleSend = async (incomingMessage?: string) => {
    const messageToSend = incomingMessage || message;
    if (!messageToSend.trim() || sensitivityWarning.level === 'high') return; // 'high' blocks send

    const userMessage: Message = {
      role: "user",
      content: messageToSend,
      timestamp: new Date()
    };

    logger.logChatMessage(messageToSend, true, {
      messageLength: messageToSend.length,
      sessionTime: new Date().getTime() - new Date(sessionStorage.getItem('sessionStartTime') || '').getTime()
    });

    // Detect intent. If the user is starting a new flow, drop the locked-in active service so
    // we don't pollute the request with stale travel/seat context.
    const intent = detectIntent(messageToSend);
    const reset = shouldResetActiveService(messageToSend, activeService);
    if (reset && activeService) {
      console.log('[ChatWindow] Resetting active service:', activeService, '→', intent.service ?? '(none)');
      setActiveService(null);
    }
    const effectiveActiveService = reset ? null : activeService;
    const detectedService = intent.service ?? effectiveActiveService ?? null;

    const qPrefix = getServicePrefix(messageToSend, effectiveActiveService);
    let finalQuery = `${qPrefix}${messageToSend}`;

    // REINFORCED: Natural Language Context Wrapping
    // If we are in a service mode, always use the explicit "my own" wrapper to bypass backend guardrails.
    if (effectiveActiveService) {
      const s = effectiveActiveService.toLowerCase();
      if (s.includes('travel')) {
        finalQuery = `travel: I am providing details for my own travel booking: ${messageToSend}`;
      } else if (s.includes('seat')) {
        finalQuery = `seat booking: I am providing details for my own seat booking: ${messageToSend}`;
      } else if (s.includes('canteen') || s.includes('cafeteria')) {
        finalQuery = `canteen: I am providing details for my canteen order: ${messageToSend}`;
      }
    }

    // Get last 5 messages for context.
    // Wrap past user messages with service prefix to give the backend a strong signal of locked service mode.
    const actualConversation = messages.slice(1);
    const conversationHistory = actualConversation.slice(-5).map(msg => {
      const msgPrefix = getServicePrefix(msg.content, effectiveActiveService);
      let content = msg.content;

      // Wrap user messages in history too if they were follow-ups in an active service
      if (msg.role === 'user' && !msgPrefix && effectiveActiveService) {
        const s = effectiveActiveService.toLowerCase();
        if (s.includes('travel')) content = `I am providing details for my own travel booking: ${msg.content}`;
        else if (s.includes('seat')) content = `I am providing details for my own seat booking: ${msg.content}`;
        else if (s.includes('canteen')) content = `I am providing details for my canteen order: ${msg.content}`;
      }

      const finalService = msgPrefix.replace(': ', '') || effectiveActiveService || '';
      const finalPrefix = finalService ? `${finalService.toLowerCase()}: ` : '';

      return {
        role: msg.role,
        content: `${finalPrefix}${content}`
      };
    });

    // message routing logs removed for security

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsTyping(true);

    try {
      // Use unified smart chat endpoint - AI will route to correct service
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: finalQuery,
          // Service hint: freshly detected intent if any, else the (possibly reset) active service.
          // The backend treats this as a tiebreaker, not a forced override.
          service: detectedService,
          sessionId,
          locationId: selectedLocation,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name,
          conversationHistory  // Send last 5 messages for context
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        // RateLimitBanner renders inline — no message push needed
      } else if (response.ok) {
        // Handle location selection for canteen queries
        if (data.needs_location) {
          setWaitingForLocation(true);
        }

        const aiMessage: Message = {
          role: "assistant",
          content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
          timestamp: new Date(),
          banners: data.banners, // Include banner data if available
          conversationId: data.conversationId || null,
          feedback: 0, // No feedback yet
          isOutOfScope: data.isOutOfScope || false
        };

        // Log AI response with service info
        logger.logChatMessage(aiMessage.content, false, {
          responseTime: new Date().getTime() - userMessage.timestamp.getTime(),
          userQuery: messageToSend,
          service: data.service,
          serviceName: data.serviceName
        });

        // Update active service for next turns
        if (data.isOutOfScope) {
          setActiveService(null);
        } else if (data.service) {
          setActiveService(data.service);
        }

        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Chat query error:', error);
      const errorMessage: Message = {
        role: "assistant",
        content: "I'm having trouble processing your request right now. Please try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }

    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (message.trim() && !isTyping && sensitivityWarning.level !== 'high') handleSend();
    }
  };

  // Handle feedback (thumbs up/down)
  const handleFeedback = async (messageIndex: number, feedback: number) => {
    const msg = messages[messageIndex];
    if (!msg.conversationId) return;

    // Optimistically update UI
    setMessages(prev => prev.map((m, i) =>
      i === messageIndex ? { ...m, feedback } : m
    ));

    try {
      const response = await fetch(API_ENDPOINTS.chatFeedback, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: msg.conversationId,
          feedback
        })
      });

      if (!response.ok) {
        throw new Error('Failed to save feedback');
      }

      toast.success(feedback === 1 ? 'Thanks for the positive feedback!' : 'Thanks for your feedback!');
    } catch (error) {
      console.error('Feedback error:', error);
      // Revert on error
      setMessages(prev => prev.map((m, i) =>
        i === messageIndex ? { ...m, feedback: 0 } : m
      ));
      toast.error('Failed to save feedback');
    }
  };

  // Autofocus input when not typing or waiting for action
  useEffect(() => {
    if (isOpen && !isTyping && !waitingForLocation) {
      // Small timeout to allow transitions to complete
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen, isTyping, waitingForLocation]);

  return (
    <div
      className="fixed left-0 right-0 z-40 pointer-events-none"
      style={{ bottom: '70px' }}
    >
      <div className="container mx-auto px-4 max-w-2xl pointer-events-auto">

        {/* ── ONE glass container with gradient-border liquid glass ── */}
        <div
          className={cn("rounded-3xl transition-all duration-300 ease-out", isOpen ? "p-px" : "")}
          style={isOpen ? {
            background: isDark
              ? "linear-gradient(180deg, rgba(255,255,255,0.20) 0%, rgba(255,255,255,0.06) 50%, rgba(255,255,255,0.02) 100%)"
              : "none", // Removed gradient border for light mode as it relies on the inner background
          } : {}}
        >
          <div
            className={cn("flex flex-col rounded-3xl transition-all duration-300 ease-out", isOpen ? "overflow-hidden" : "overflow-visible")}
            style={{
              height: isOpen ? "min(70vh, 600px)" : "64px",
              background: isOpen
                ? isDark
                  ? "rgba(18,18,24,0.65)"
                  : "rgba(255, 255, 255, 0.2)"
                : "transparent",
              backdropFilter: isOpen ? (isDark ? "blur(0px) saturate(200%)" : "none") : "none",
              WebkitBackdropFilter: isOpen ? (isDark ? "blur(0px) saturate(200%)" : "none") : "none",
              boxShadow: isOpen
                ? isDark
                  ? "inset 0 1.5px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.30), 0 24px 64px rgba(0,0,0,0.60)"
                  : "inset 0 1px 1px rgba(255,255,255,0.8), inset 0 -1px 1px rgba(255,255,255,0.3), 0 16px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.03)"
                : "none",
            }}
          >

            {/* ── Collapsible section — drag handle + header + messages ── */}
            <div
              className={cn(
                "flex flex-col min-h-0 transition-all duration-300 overflow-hidden",
                isOpen ? "flex-1 opacity-100" : "h-0 opacity-0 pointer-events-none"
              )}
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
                <div
                  className="w-10 h-1 rounded-full"
                  style={{ background: isDark ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.15)" }}
                />
              </div>

              {/* Header */}
              <div
                className="flex items-center justify-between px-5 py-3 flex-shrink-0"

              >
                <div className="w-8" />
                <h3
                  className="font-semibold text-sm tracking-wide"
                  style={{ color: isDark ? "#fff" : "#111" }}
                >
                  Ask myBGSW.Ai
                </h3>
                <button
                  onClick={onToggle}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
                  style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}
                  aria-label="Close chat"
                >
                  <X
                    className="w-3.5 h-3.5"
                    style={{ color: isDark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)" }}
                  />
                </button>
              </div>

              {/* Messages */}
              <div className="flex-1 px-4 py-4 overflow-y-auto space-y-5 custom-scrollbar min-h-0">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}
                  >
                    {msg.role === "assistant" && (
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ background: "#1c1c1e" }}
                      >
                        <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
                      </div>
                    )}
                    <div className="flex flex-col max-w-[78%]">
                      <div className="relative">
                        {/* Triangle tail */}
                        <div
                          style={msg.role === "assistant" ? {
                            position: "absolute",
                            left: "-7px",
                            top: "12px",
                            width: 0,
                            height: 0,
                            borderTop: "6px solid transparent",
                            borderBottom: "6px solid transparent",
                            borderRight: "8px solid rgba(28, 28, 30, 1)",
                          } : {
                            position: "absolute",
                            right: "-7px",
                            top: "12px",
                            width: 0,
                            height: 0,
                            borderTop: "6px solid transparent",
                            borderBottom: "6px solid transparent",
                            borderLeft: "8px solid #0a84ff",
                          }}
                        />
                        <div
                          className="rounded-2xl px-4 py-3"
                          style={
                            msg.role === "user"
                              ? {
                                background: "#0a84ff",
                                color: "#fff",
                              }
                              : {
                                background: msg.isOutOfScope ? "rgba(40,20,0,0.92)" : "rgba(28,28,30,1)",
                                color: "#fff",
                                border: msg.isOutOfScope ? "1px solid rgba(255,165,0,0.3)" : "none",
                              }
                          }
                        >
                          {msg.isOutOfScope && (
                            <div className="flex items-center gap-1.5 mb-2 px-2 py-1 rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-medium w-fit">
                              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                              Outside Supported Scope
                            </div>
                          )}
                          <p
                            className="text-sm leading-relaxed whitespace-pre-line"
                            dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                          />
                          {msg.banners && msg.banners.length > 0 && (
                            <div className="mt-3 space-y-3">
                              {msg.banners.map((banner, bi) =>
                                banner.hasImage && banner.imageBase64 ? (
                                  <div key={bi} className="rounded-xl overflow-hidden border border-white/10">
                                    <img
                                      src={`data:image/png;base64,${banner.imageBase64}`}
                                      alt={banner.title}
                                      className="w-full h-auto max-h-48 object-cover"
                                      onError={(e) => {
                                        const img = e.target as HTMLImageElement;
                                        if (img.src.includes("image/png"))
                                          img.src = `data:image/jpeg;base64,${banner.imageBase64}`;
                                      }}
                                    />
                                    <div className="p-2">
                                      <p className="text-xs font-medium text-white/80">{banner.title}</p>
                                    </div>
                                  </div>
                                ) : null
                              )}
                            </div>
                          )}
                          {/* Hint for failed/blocked messages */}
                          {(msg.isOutOfScope || msg.isBlocked) && (
                            <div className="mt-3 pt-3 border-t border-white/10 text-xs text-white/50">
                              <span className="font-medium text-white/70">Hint:</span>{' '}
                              Don't enter any sensitive personal or business-critical information.
                            </div>
                          )}
                          {/* Timestamp + feedback inside bubble */}
                          <div className={cn(
                            "flex items-center gap-2 mt-2",
                            msg.role === "user" ? "justify-end" : "justify-start"
                          )}>
                            <span
                              className="text-[11px]"
                              style={{ color: "rgba(255,255,255,0.4)" }}
                            >
                              {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>

                            {msg.role === "assistant" && idx > 0 && (
                              <>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(idx, 1); }}
                                  disabled={msg.feedback === 1}
                                  title="Helpful"
                                  className={cn("p-0.5 rounded transition-all duration-200",
                                    msg.feedback === 1 ? "text-green-400" : "text-white/30 hover:text-green-400")}
                                >
                                  <ThumbsUp className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(idx, -1); }}
                                  disabled={msg.feedback === -1}
                                  title="Not helpful"
                                  className={cn("p-0.5 rounded transition-all duration-200",
                                    msg.feedback === -1 ? "text-red-400" : "text-white/30 hover:text-red-400")}
                                >
                                  <ThumbsDown className="w-3 h-3" />
                                </button>
                              </>
                            )}

                          </div>
                        </div>
                      </div>{/* end relative */}
                    </div>
                    {msg.role === "user" && (
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ background: "#0a84ff" }}
                      >
                        <img src="/user.svg" alt="You" className="w-5 h-5" />
                      </div>
                    )}
                  </div>
                ))}

                {isTyping && (
                  <div className="flex gap-3 items-start">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: "#1c1c1e" }}>
                      <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
                    </div>
                    <div className="rounded-2xl px-4 py-3"
                      style={{ background: isDark ? "rgba(44,44,46,0.85)" : "rgba(28,28,30,0.88)" }}>
                      <div className="flex gap-1 items-center h-4">
                        {[0, 150, 300].map((delay) => (
                          <div key={delay} className="w-2 h-2 rounded-full animate-bounce"
                            style={{ background: "rgba(255,255,255,0.5)", animationDelay: `${delay}ms` }} />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {waitingForLocation && !isTyping && (
                  <div className="flex flex-col gap-3 items-center py-2">
                    <div className="flex items-center gap-2 text-sm"
                      style={{ color: isDark ? "rgba(255,255,255,0.6)" : "rgba(0,0,0,0.5)" }}>
                      <MapPin className="w-4 h-4" />
                      <span>Select your location:</span>
                    </div>
                    <div className="flex gap-3">
                      {["Bangalore", "Coimbatore"].map((loc, i) => (
                        <button key={loc} onClick={() => handleLocationSelect(i + 1)}
                          className="px-5 py-2 rounded-full text-sm font-medium text-white transition-all hover:scale-105"
                          style={{ background: "linear-gradient(135deg, rgba(89,83,255,1), rgba(208,38,217,1))" }}>
                          {loc}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {isRateLimited && <RateLimitBanner retryAfter={retryAfter} />}
                <div ref={messagesEndRef} />
              </div>
            </div>



            {/* ══ INPUT PILL — flex-shrink-0 last child, always at container bottom ══
              Gradient border via 1px wrapper: gradient bg + p-px, inner fills it. ══ */}
            <div className="flex-shrink-0 px-3 py-3">
              {sensitivityWarning.isSensitive && sensitivityWarning.level === 'high' && (
                <div className="text-xs text-red-400 font-medium px-4 mb-2 animate-in slide-in-from-bottom-1">
                  ⚠️ Sensitive data detected ({sensitivityWarning.category}). Please remove before sending.
                </div>
              )}
              {/* Liquid glass input pill — gradient border simulates light on curved glass */}
              <div
                className="rounded-full p-px"
                style={{
                  background: isDark
                    ? "linear-gradient(160deg, rgba(255,255,255,0.28) 0%, rgba(89,83,255,0.35) 40%, rgba(208,38,217,0.18) 70%, rgba(255,255,255,0.04) 100%)"
                    : "linear-gradient(160deg, rgba(255,255,255,0.60) 0%, rgba(89,83,255,0.25) 40%, rgba(208,38,217,0.20) 70%, rgba(200,200,215,0.15) 100%)",
                }}
              >
                <div
                  className="chat-input-pill flex items-center gap-2 px-4  rounded-full"
                  style={{
                    background: isDark ? "rgba(18,18,24,0.85)" : "rgba(255,255,255,0.5)",
                    // backdropFilter: "blur(0px) saturate(200%)",
                    // WebkitBackdropFilter: "blur(0px) saturate(200%)",
                    boxShadow: isDark
                      ? "inset 0 1.5px 0 rgba(255,255,255,0.10), inset 0 -1px 0 rgba(0,0,0,0.25)"
                      : "inset 0 1px 1px rgba(255,255,255,0.8), inset 0 -1px 1px rgba(255,255,255,0.4), 0 4px 12px rgba(0,0,0,0.05)",
                  }}
                >
                  <button
                    onClick={onToggle}
                    className="flex-shrink-0 flex items-center justify-center transition-all hover:scale-110"
                    aria-label="Toggle chat"
                  >
                    <img src="/input-chat-star.svg" alt="" className="w-6 h-6 opacity-60" />
                  </button>

                  <div className="flex-1">
                    <Input
                      ref={inputRef}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyPress}
                      onFocus={() => !isOpen && onToggle()}
                      placeholder={isRateLimited ? "Too many requests. Please wait…" : "Enter your queries here"}
                      className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-sm"
                      style={{ color: isDark ? "rgba(255,255,255,0.9)" : "rgba(0,0,0,0.85)" }}
                      disabled={isTyping || isRateLimited}
                    />
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={toggleVoice}
                      disabled={!isSpeechRecognitionSupported}
                      title={
                        !isSpeechRecognitionSupported
                          ? "Voice not supported in this browser"
                          : isListening ? "Stop listening" : "Voice input"
                      }
                      className={cn(
                        "flex items-center justify-center transition-all duration-200",
                        !isSpeechRecognitionSupported && "opacity-30 cursor-not-allowed",
                        isListening && "animate-pulse"
                      )}
                    >
                      {isListening
                        ? <MicOff className="w-5 h-5" style={{ color: "rgba(255,59,48,0.9)" }} />
                        : <img src="/microphone.svg" alt="mic" className="w-5 h-5 opacity-55" />
                      }
                    </button>

                    <button
                      onClick={() => handleSend()}
                      disabled={!message.trim() || isTyping || isRateLimited}
                      title="Send message"
                      className="flex items-center justify-center transition-all duration-200 hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
                    >
                      <img
                        src="/send.svg"
                        alt="send"
                        className="w-5 h-5"
                        style={{
                          opacity: message.trim() && !isTyping ? 1 : 0.45,
                          filter: message.trim() && !isTyping
                            ? "drop-shadow(0 0 4px rgba(89,83,255,0.8))"
                            : "none",
                        }}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>{/* end gradient-border wrapper */}
      </div>
    </div>
  );
};
