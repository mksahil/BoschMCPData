// Mock of the updated isFollowUpQuery
function isFollowUpQuery(query) {
    const lowerQuery = query.toLowerCase().trim();

    // Common follow-up patterns (copied from the updated conversation-context-service.js)
    const followUpPatterns = [
      /^(what|how) about/i,                    // "what about yesterday", "how about tomorrow"
      /^and\s+(what|how|the|for)/i,            // "and what about...", "and for yesterday"
      /^(yesterday|tomorrow|today|last|next|this)\b/i,  // starts with time reference
      /^(week|month|year)\b/i,                 // starts with time period
      /^(same|similar)\b/i,                    // "same for yesterday"
      /^(more|less|other)\b/i,                 // "more details", "other dates"
      /^(when|where|why|who|how much|how many)\?*$/i,  // simple questions
      /^that\s/i,                              // "that one", "that day"
      /^it\s/i,                                // "it was..."
      /^the\s+(same|other|previous|next)/i,   // "the same for...", "the previous day"
      /^show\s+(me\s+)?(more|that|this)/i,    // "show me more"
      /^\?$/,                                  // just a question mark
      /^ok\s+(and|but|what)/i,                // "ok and what about"
      /^(yes|yeah|sure|ok)[\s,]+(and|but|what)/i, // "yes, and what about"
      /^\d{1,2}(st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, // "30th November"
      /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*\d{1,2}/i, // "November 30"
      /^\d{1,2}[\/\-]\d{1,2}/,                 // "30/11" or "30-11"
      /^on\s+\d{1,2}/i,                        // "on 10th"
      /^for\s+(yesterday|tomorrow|today|\d)/i, // "for yesterday", "for 10th"
      /\b(one way|return|round trip|one-way)\b/i, // Travel specifics
    ];

    const wordCount = query.split(/\s+/).length;
    const hasSubject = /menu|food|entry|exit|attendance|travel|seat|booking|community|banner|swipe|punch|who am i|my name|what is my name|employee name|identify me/i.test(query);

    for (const pattern of followUpPatterns) {
      if (pattern.test(lowerQuery)) {
        return true;
      }
    }

    if (wordCount <= 4 && !hasSubject) {
      return true;
    }

    return false;
}

// Test cases
const tests = [
  "March 30th",
  "30/03",
  "one way",
  "round trip",
  "tomorrow",
  "what about yesterday?",
  "Book me a flight" // Should NOT be a follow-up (has subject "flight" -> matched in hasSubject by 'travel' regex? wait, 'travel' matches, but what about 'flight'?)
];

console.log("=== Follow-Up Detection Test ===");
tests.forEach(test => {
  const isFU = isFollowUpQuery(test);
  console.log(`Query: "${test}" -> Follow-Up: ${isFU}`);
});
