# Files Added & Modified Since First Commit

> Generated: 2026-05-06  
> Base commit: `cb96a1b` — base: 16th April codebase  
> Latest commit: `d01e5e3` — Merge branch 'aspm-sonar-fixes' into main

---

## Legend
- **Added** — new file that did not exist in the base commit
- **Modified** — existing file changed since the base commit
- **Untracked** — new/modified locally, not yet committed

---

## Root-Level Files

| File | Status |
|------|--------|
| `API_Documentation_Security.csv` | Added |
| `Database_Schema_Structure.csv` | Added |
| `Rate_Limiting_Client_Document.md` | Added |
| `SECURITY_FIXES_INDEX.md` | Added |
| `aspm_fixes_report.csv` | Added |
| `sonarqube_fixes_report.csv` | Added |
| `sonar-project.properties` | Added |
| `codebase_to_text.py` | Added |
| `new_sonar_issues.json` | Untracked |
| `sonar_fix_instructions_group_c_d.md` | Untracked |
| `.gitignore` | Modified |
| `AZURE_DEPLOYMENT_GUIDE_v2.md` | Modified |
| `package.json` | Modified |
| `package-lock.json` | Modified |

---

## Backend — Services

| File | Status |
|------|--------|
| `backend/services/privacy-guard-service.js` | Added |
| `backend/services/consent-db-service.js` | Untracked |
| `backend/services/mcp-url-validator.js` | Untracked |
| `backend/services/bosch-auth-service.js` | Modified |
| `backend/services/community-service.js` | Modified |
| `backend/services/conversation-context-service.js` | Modified |
| `backend/services/entry-exit-service-v2.js` | Modified |
| `backend/services/generic-mcp-client.js` | Modified |
| `backend/services/seatbooking-service.js` | Modified |
| `backend/services/travel-service.js` | Modified |

---

## Backend — Server & Scripts

| File | Status |
|------|--------|
| `backend/fix-info-exposure.js` | Added |
| `backend/scratch.js` | Added |
| `backend/test-rate-limit-register.js` | Added |
| `backend/server.js` | Modified (+ Uncommitted changes) |
| `backend/debug-encryption.js` | Modified |
| `backend/debug-seatbooking.js` | Modified |
| `backend/debug-travel.js` | Modified |
| `backend/intelligent-canteen.js` | Modified |
| `backend/mcp-client-http.js` | Modified |
| `backend/mcp-client-stdio.js` | Modified |
| `backend/test-encryption-api.js` | Modified |
| `backend/test-local-login.js` | Modified |
| `backend/test-seat-api.js` | Modified |
| `backend/test-token.js` | Modified |
| `backend/package.json` | Modified |
| `backend/package-lock.json` | Modified |

---

## Backend — Tests

| File | Status |
|------|--------|
| `backend/tests/rateLimit.test.js` | Added |
| `backend/tests/stress-rate-limit.js` | Added |
| `backend/test-canteen-api.js` | Uncommitted changes |

---

## Backend — Conversation Data Files

| File | Status |
|------|--------|
| `backend/data/conversations/28301564_251a1cc0-...` | Added |
| `backend/data/conversations/28301564_27d11710-...` | Added |
| `backend/data/conversations/28301564_33190233-...` | Added |
| `backend/data/conversations/28301564_38cf0811-...` | Added |
| `backend/data/conversations/28301564_48510c5c-...` | Added |
| `backend/data/conversations/28301564_86b5f385-...` | Added |
| `backend/data/conversations/28301564_89a8ecdc-...` | Added |
| `backend/data/conversations/28301564_ab1b6769-...` | Added |
| `backend/data/conversations/28301564_b4336151-...` | Added |
| `backend/data/conversations/28301564_cd8952dc-...` | Added |
| `backend/data/conversations/28301564_e7d136ca-...` | Added |
| `backend/data/conversations/28301564_f5802dcc-...` | Added |
| `backend/data/conversations/28301564_f691c62e-...` | Added |
| `backend/data/conversations/28301564_fb9cd865-...` | Added |
| `backend/data/conversations/28301564_travel-17501b97-...` | Added |
| `backend/data/conversations/28301564_travel-2c5221b3-...` | Added |
| `backend/data/conversations/28301564_travel-eb39cf46-...` | Added |
| `backend/data/conversations/28301564_travel-f5366e11-...` | Added |
| `backend/data/conversations/28301564_6b45ac97-...` | Untracked |

---

## Frontend — Components & Hooks (New)

| File | Status |
|------|--------|
| `frontend/src/components/RateLimitBanner.tsx` | Added |
| `frontend/src/components/SessionTimeoutModal.tsx` | Added |
| `frontend/src/components/SessionTimeoutWrapper.tsx` | Added |
| `frontend/src/hooks/useRateLimit.ts` | Added |
| `frontend/src/hooks/useSessionTimeout.ts` | Added |
| `frontend/src/lib/privacy-utils.ts` | Added |
| `frontend/src/components/ConsentModal.tsx` | Untracked |

---

## Frontend — Components & Pages (Modified)

| File | Status |
|------|--------|
| `frontend/src/components/Footer.tsx` | Modified (+ Uncommitted changes) |
| `frontend/src/components/ProtectedRoute.tsx` | Uncommitted changes |
| `frontend/src/context/AuthContext.tsx` | Modified (+ Uncommitted changes) |
| `frontend/src/pages/Index.tsx` | Modified (+ Uncommitted changes) |
| `frontend/src/App.tsx` | Modified |
| `frontend/src/components/AIChat.tsx` | Modified |
| `frontend/src/components/AnimatedBackground.tsx` | Modified |
| `frontend/src/components/BannersCard.tsx` | Modified |
| `frontend/src/components/BlogsCard.tsx` | Modified |
| `frontend/src/components/BoBCard.tsx` | Modified |
| `frontend/src/components/CafeteriaCard.tsx` | Modified |
| `frontend/src/components/CertificationsCard.tsx` | Modified |
| `frontend/src/components/ChatWindow.tsx` | Modified |
| `frontend/src/components/CommunityCard.tsx` | Modified |
| `frontend/src/components/CoursesCard.tsx` | Modified |
| `frontend/src/components/DashboardCard.tsx` | Modified |
| `frontend/src/components/EffortBookingCard.tsx` | Modified |
| `frontend/src/components/EntryExitCard.tsx` | Modified |
| `frontend/src/components/GymCard.tsx` | Modified |
| `frontend/src/components/HolidayCalendarCard.tsx` | Modified |
| `frontend/src/components/InsightsStrip.tsx` | Modified |
| `frontend/src/components/JKLCard.tsx` | Modified |
| `frontend/src/components/LeaveCard.tsx` | Modified |
| `frontend/src/components/MeetingsCard.tsx` | Modified |
| `frontend/src/components/MusicCard.tsx` | Modified |
| `frontend/src/components/Navigation.tsx` | Modified |
| `frontend/src/components/ParkingCard.tsx` | Modified |
| `frontend/src/components/PayslipCard.tsx` | Modified |
| `frontend/src/components/ProjectsCard.tsx` | Modified |
| `frontend/src/components/SeatBookingCard.tsx` | Modified |
| `frontend/src/components/SolarSystem.tsx` | Modified |
| `frontend/src/components/TravelCard.tsx` | Modified |
| `frontend/src/components/VitalContactsCard.tsx` | Modified |
| `frontend/src/components/WatchlistCard.tsx` | Modified |
| `frontend/src/components/WayFinderCard.tsx` | Modified |
| `frontend/src/pages/Admin.tsx` | Modified |
| `frontend/src/pages/AnalyticsViewer.tsx` | Modified |
| `frontend/src/pages/LogViewer.tsx` | Modified |
| `frontend/src/pages/Login.tsx` | Modified |
| `frontend/src/services/azureAuthService.ts` | Modified |
| `frontend/src/index.css` | Modified |
| `frontend/tsconfig.json` | Modified |

---

## Frontend — Public Assets (New)

| File | Status |
|------|--------|
| `frontend/public/Glow.png` | Added |
| `frontend/public/Glow_bkp1.png` | Added |
| `frontend/public/chat-bubble-robot.svg` | Added |
| `frontend/public/eclipse.svg` | Added |
| `frontend/public/entry_exit_status.svg` | Added |
| `frontend/public/grey_user.svg` | Added |
| `frontend/public/input-chat-star.svg` | Added |
| `frontend/public/last_swipe.svg` | Added |
| `frontend/public/location.svg` | Added |
| `frontend/public/microphone.svg` | Added |
| `frontend/public/send.svg` | Added |
| `frontend/public/stars_bg_black.png` | Added |
| `frontend/public/user.svg` | Added |
| `frontend/public/dpn.pdf` | Untracked |
| `frontend/public/terms-of-use.pdf` | Untracked |

---

## Frontend — Test Suite (New)

| File | Status |
|------|--------|
| `frontend/tests/components/AIChat.spec.tsx` | Added |
| `frontend/tests/components/BannersCard.spec.tsx` | Added |
| `frontend/tests/components/CafeteriaCard.spec.tsx` | Added |
| `frontend/tests/components/ChatWindow.spec.tsx` | Added |
| `frontend/tests/components/DashboardCard.spec.tsx` | Added |
| `frontend/tests/components/EntryExitCard.spec.tsx` | Added |
| `frontend/tests/components/Footer.spec.tsx` | Added |
| `frontend/tests/components/Navigation.spec.tsx` | Added |
| `frontend/tests/components/ProtectedRoute.spec.tsx` | Added |
| `frontend/tests/components/SeatBookingCard.spec.tsx` | Added |
| `frontend/tests/components/SessionTimeoutModal.spec.tsx` | Added |
| `frontend/tests/components/SessionTimeoutWrapper.spec.tsx` | Added |
| `frontend/tests/components/SolarSystem.spec.tsx` | Added |
| `frontend/tests/components/TravelCard.spec.tsx` | Added |
| `frontend/tests/context/AuthContext.spec.tsx` | Added |
| `frontend/tests/hooks/useRateLimit.spec.ts` | Added |
| `frontend/tests/hooks/useSessionTimeout.spec.ts` | Added |
| `frontend/tests/lib/utils.spec.ts` | Added |
| `frontend/tests/pages/Index.spec.tsx` | Added |
| `frontend/tests/pages/NotFound.spec.tsx` | Added |
| `frontend/tests/setup/mocks/azureAuthService.mock.ts` | Added |
| `frontend/tests/setup/spec-helper.ts` | Added |

---

## Frontend — Config & Build Files (New)

| File | Status |
|------|--------|
| `frontend/fix-coverage.js` | Added |
| `frontend/karma.conf.cjs` | Added |
| `frontend/scratch.js` | Added |
| `frontend/sonar-project.properties` | Added |
| `frontend/tsconfig.test.json` | Added |
| `frontend/webpack.test.config.cjs` | Added |

---

## Frontend — Legacy Test Scripts (Modified)

| File | Status |
|------|--------|
| `frontend/test-seat-E.mjs` | Modified |
| `frontend/test-seat-G.mjs` | Modified |
| `frontend/test-seat-H.mjs` | Modified |
| `frontend/test-seat-K.mjs` | Modified |
| `frontend/test-seat-M.mjs` | Modified |
| `frontend/test-seat-N.mjs` | Modified |
| `frontend/test-seat-O.mjs` | Modified |
| `frontend/test-seat-Worker.mjs` | Modified |
| `frontend/test-seat-api.js` | Modified |
| `frontend/test-seat-final.mjs` | Modified |
| `frontend/test-seat-https.js` | Modified |
| `frontend/test-seat-https.mjs` | Modified |
| `frontend/test-system-instruction.mjs` | Modified |
| `frontend/package.json` | Modified |
| `frontend/package-lock.json` | Modified |

---

## Tests — Root-Level Test Suite (New)

| File | Status |
|------|--------|
| `tests/README.md` | Added |
| `tests/frontend/test-seat-E.mjs` | Added |
| `tests/frontend/test-seat-G.mjs` | Added |
| `tests/frontend/test-seat-H.mjs` | Added |
| `tests/frontend/test-seat-K.mjs` | Added |
| `tests/frontend/test-seat-M.mjs` | Added |
| `tests/frontend/test-seat-N.mjs` | Added |
| `tests/frontend/test-seat-O.mjs` | Added |
| `tests/frontend/test-seat-Worker.mjs` | Added |
| `tests/frontend/test-seat-api.js` | Added |
| `tests/frontend/test-seat-final.mjs` | Added |
| `tests/frontend/test-system-instruction.mjs` | Added |
| `tests/frontend/test_priv.js` | Added |
| `tests/stress_test.py` | Added |

---

## Summary

| Category | Added | Modified | Untracked | Total |
|----------|-------|----------|-----------|-------|
| Root-level files | 8 | 4 | 2 | 14 |
| Backend services | 1 | 7 | 2 | 10 |
| Backend server & scripts | 2 | 13 | 0 | 15 |
| Backend tests | 2 | 0 | 1 | 3 |
| Backend conversation data | 18 | 0 | 1 | 19 |
| Frontend components & hooks (new) | 6 | 0 | 1 | 7 |
| Frontend components & pages (modified) | 0 | 41 | 0 | 41 |
| Frontend public assets | 13 | 0 | 2 | 15 |
| Frontend test suite | 22 | 0 | 0 | 22 |
| Frontend config & build files | 6 | 0 | 0 | 6 |
| Frontend legacy test scripts | 0 | 15 | 0 | 15 |
| Tests root-level | 14 | 0 | 0 | 14 |
| **Totals** | **92** | **80** | **9** | **181** |
