import { useState, useEffect, useRef } from 'react';
import { DashboardCard } from './DashboardCard';
import { Loader2, Megaphone, AlertCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { API_ENDPOINTS } from '@/config';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useRateLimit } from '@/hooks/useRateLimit';
import { formatCountdown } from './RateLimitBanner';

interface Banner {
    id: string | number;
    title: string;
    description: string;
    tag: string;
    hasImage: boolean;
    imagePreview?: string | null;
    imageBase64?: string | null;
}

export const BannersCard = () => {
    const { user } = useAuth();
    const [banners, setBanners] = useState<Banner[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const autoPlayRef = useRef<NodeJS.Timeout | null>(null);
    const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

    const fetchBanners = async () => {
        try {
            setLoading(true);
            setError(null);

            if (!user?.accessToken || !user?.employeeNumber) {
                console.warn('[BannersCard] Skipping fetch — user not authenticated yet');
                setBanners([]);
                return;
            }

            const response = await fetch(API_ENDPOINTS.chat, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user.accessToken}`,
                    'X-Employee-Number': user.employeeNumber,
                },
                body: JSON.stringify({
                    query: "get all banners",
                    service: "banner",
                    employeeNumber: user.employeeNumber,
                })
            });

            const data = await response.json();

            if (response.status === 429) {
                handleRateLimitResponse(response, data);
                setError('Too many requests. Please wait before retrying.');
                return;
            }

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            if (data.success && data.banners) {
                setBanners(data.banners);
            }
        } catch (err) {
            console.error('Error fetching banners:', err);
            if (err instanceof Error) {
                setError(`Failed to load banners: ${err.message}`);
            } else {
                setError("Failed to load banners. Please check server connection.");
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (user?.accessToken && user?.employeeNumber) {
            fetchBanners();
        }
    }, [user?.accessToken, user?.employeeNumber]);

    // Auto-play logic
    useEffect(() => {
        if (loading || banners.length <= 1 || isPaused) return;

        autoPlayRef.current = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % banners.length);
        }, 10000);

        return () => {
            if (autoPlayRef.current) clearInterval(autoPlayRef.current);
        };
    }, [banners.length, loading, isPaused]);

    const handleNext = () => setCurrentIndex((prev) => (prev + 1) % banners.length);
    const handlePrev = () => setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);

    const currentBanner = banners[currentIndex];
    const hasDescription = currentBanner?.description && currentBanner.description.trim().length > 0;

    return (
        <DashboardCard title="Company Banners" icon={Megaphone} className="min-w-[600px] max-w-[800px]">
            <div
                className="relative flex flex-col overflow-hidden rounded-xl"
                style={{ height: '420px' }}
                onMouseEnter={() => setIsPaused(true)}
                onMouseLeave={() => setIsPaused(false)}
            >
                {loading ? (
                    <div className="flex flex-col items-center justify-center flex-1 gap-3 text-muted-foreground h-full">
                        <Loader2 className="w-8 h-8 animate-spin text-primary" />
                        <p className="text-sm">Loading announcements...</p>
                    </div>
                ) : error ? (
                    <div className="flex flex-col items-center justify-center flex-1 h-full gap-3 p-6 text-center">
                        <div className="w-12 h-12 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-2">
                            <AlertCircle className="w-6 h-6 text-amber-500" />
                        </div>
                        <p className="text-sm text-foreground font-medium max-w-[280px]">{error}</p>
                        {isRateLimited && (
                            <p className="text-xs text-amber-500 font-medium tracking-wide">
                                Available again in {formatCountdown(retryAfter)}...
                            </p>
                        )}
                        <button
                            onClick={fetchBanners}
                            disabled={isRateLimited}
                            className="px-6 py-2 mt-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isRateLimited ? "Paused" : "Try Again"}
                        </button>
                    </div>
                ) : banners.length === 0 ? (
                    <div className="flex flex-col items-center justify-center flex-1 text-muted-foreground h-full">
                        <Megaphone className="w-12 h-12 mb-4 opacity-20" />
                        <p>No banners available.</p>
                    </div>
                ) : (
                    <>
                        {/* ── Slide Transition Container ── */}
                        <div className="relative flex-1 overflow-hidden">
                            {banners.map((banner, index) => (
                                <div
                                    key={banner.id ?? index}
                                    className={cn(
                                        "absolute inset-0 flex flex-col transition-opacity duration-500",
                                        index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0 pointer-events-none"
                                    )}
                                >
                                    {/* ── Image / Placeholder ── */}
                                    <div className={cn("relative overflow-hidden flex-shrink-0", hasDescription ? "flex-1" : "h-full")}>
                                        {banner.hasImage && banner.imageBase64 ? (
                                            <>
                                                {/* Blurred ambient background */}
                                                <div
                                                    className="absolute inset-0 bg-cover bg-center blur-2xl opacity-40 scale-110"
                                                    style={{ backgroundImage: `url(data:image/jpeg;base64,${banner.imageBase64})` }}
                                                />
                                                <img
                                                    src={`data:image/jpeg;base64,${banner.imageBase64}`}
                                                    alt={banner.title}
                                                    className="relative h-full w-full object-cover z-10"
                                                />
                                            </>
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center bg-secondary/30">
                                                <Megaphone className="w-16 h-16 text-muted-foreground/20" />
                                            </div>
                                        )}

                                        {/* Tag badge */}
                                        {banner.tag && banner.tag !== '#Banners' && (
                                            <div className="absolute top-3 right-3 z-20">
                                                <span className="bg-primary/90 text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full shadow-lg backdrop-blur-sm">
                                                    {banner.tag}
                                                </span>
                                            </div>
                                        )}
                                    </div>

                                    {/* ── Description Panel (only if there is a description) ── */}
                                    {hasDescription && (
                                        <div className="flex-shrink-0 bg-background/95 px-5 py-4">
                                            <p className="text-sm text-foreground leading-relaxed line-clamp-3">
                                                {banner.description}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>

                        {/* ── Bottom Bar: numeric counter + arrows ── */}
                        <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 bg-background/90 backdrop-blur-sm border-t border-border/40">
                            <span className="text-sm text-muted-foreground font-medium">
                                {currentIndex + 1} / {banners.length}
                            </span>
                            {banners.length > 1 && (
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={handlePrev}
                                        className="w-8 h-8 flex items-center justify-center rounded-full bg-secondary/40 hover:bg-secondary/70 transition-colors"
                                        aria-label="Previous banner"
                                    >
                                        <ChevronLeft className="w-4 h-4 text-foreground" />
                                    </button>
                                    <button
                                        onClick={handleNext}
                                        className="w-8 h-8 flex items-center justify-center rounded-full bg-secondary/40 hover:bg-secondary/70 transition-colors"
                                        aria-label="Next banner"
                                    >
                                        <ChevronRight className="w-4 h-4 text-foreground" />
                                    </button>
                                </div>
                            )}
                        </div>
                    </>
                )}
            </div>
        </DashboardCard>
    );
};
