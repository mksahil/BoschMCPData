import { Car, MapPin, Clock, CheckCircle2 } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const ParkingCard = () => {
  return (
    <DashboardCard title="My Parking" icon={Car}>
      <div className="space-y-4">
        {/* Current Parking */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-4 h-4 text-success" />
            <h4 className="text-sm font-semibold text-foreground">Current Parking</h4>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-xs text-muted-foreground">Slot</span>
              </div>
              <span className="text-sm font-bold text-foreground">B2-42</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-accent" />
                <span className="text-xs text-muted-foreground">Parked at</span>
              </div>
              <span className="text-sm font-medium text-foreground">09:10 AM</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Vehicle</span>
              </div>
              <span className="text-sm font-medium text-foreground">KA-01-AB-1234</span>
            </div>
          </div>
        </div>

        {/* Parking Info */}
        <div className="p-3 bg-secondary/40 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-foreground">Zone B - Level 2</h4>
            <span className="text-xs px-2 py-1 bg-success/20 text-success rounded-full">Available</span>
          </div>
          <p className="text-xs text-muted-foreground mb-2">Near elevator, covered parking</p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>2 min walk to building entrance</span>
          </div>
        </div>

        {/* This Month */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">This Month</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2 bg-secondary/40 rounded-lg text-center">
              <p className="text-lg font-bold text-foreground">18</p>
              <p className="text-xs text-muted-foreground">Days Parked</p>
            </div>
            <div className="p-2 bg-secondary/40 rounded-lg text-center">
              <p className="text-lg font-bold text-primary">152h</p>
              <p className="text-xs text-muted-foreground">Total Duration</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button className="py-2 px-3 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all text-xs">
            Book Slot
          </button>
          <button className="py-2 px-3 bg-secondary/40 hover:bg-secondary/80 text-foreground rounded-lg transition-all text-xs">
            View Map
          </button>
        </div>
      </div>
    </DashboardCard>
  );
};
