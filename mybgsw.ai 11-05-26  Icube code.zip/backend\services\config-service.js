/**
 * Global Configuration Service
 * Manages core service keywords, descriptions, and privacy whitelists
 */

const fs = require('fs-extra');
const path = require('path');

// [FIX | Rule S5144 - SSRF]: Strict whitelist of routingConfig keys.
// Any key not in this list is dropped before merging into persisted config.
const ALLOWED_ROUTING_KEYS = Object.freeze([
  'greetingKeywords',
  'followUpPatterns',
  'subjectKeywords',
  'topicKeywords',
]);

class ConfigService {
  constructor() {
    this.configPath = path.join(__dirname, '../data/app-config.json');
    this.config = null;
    this.initialized = false;
  }

  /**
   * Initialize and load configuration
   */
  async initialize() {
    if (this.initialized) return;

    try {
      await fs.ensureDir(path.dirname(this.configPath));

      if (await fs.pathExists(this.configPath)) {
        this.config = await fs.readJson(this.configPath);
      } else {
        // Initialize with current hardcoded defaults
        this.config = this.getDefaultConfig();
        await this.saveConfig();
      }

      this.initialized = true;
      console.log('[ConfigService] Initialized and loaded');
    } catch (error) {
      console.error('[ConfigService] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * Get default configuration based on current hardcoded values
   */
  getDefaultConfig() {
    return {
      coreServices: {
        canteen: {
          name: 'Canteen Service',
          description: "Handles cafeteria menu, food items, today's menu, snacks, beverages, meal timings, food availability at Bosch canteen",
          keywords: ['menu', 'food', 'lunch', 'dinner', 'breakfast', 'snacks', 'cafeteria', 'canteen', 'meal', 'eat', 'hungry', 'beverage', 'tea', 'coffee', "today's special"]
        },
        entryexit: {
          name: 'Entry/Exit Time Tracking',
          description: 'Handles employee attendance, entry time, exit time, working hours, overtime, swipe records, punch in/out, time tracking, employee name lookup',
          keywords: ['entry', 'exit', 'attendance', 'punch', 'swipe', 'time', 'hours', 'overtime', 'in-time', 'out-time', 'working hours', 'late', 'early', 'leave', 'my name', 'employee name', 'who am i', 'what is my name']
        },
        travel: {
          name: 'Travel Agent',
          description: 'Handles travel plans, travel requests, trip booking, travel settlements, expense claims for business travel',
          keywords: ['travel', 'trip', 'flight', 'hotel', 'booking', 'expense', 'settlement', 'reimbursement', 'business trip', 'travel plan', 'itinerary']
        },
        seatbooking: {
          name: 'Seat Booking',
          description: 'Handles desk/seat booking, workspace reservation, office seat allocation, cancel desk booking',
          keywords: ['seat', 'desk', 'booking', 'reserve', 'workspace', 'office', 'book a seat', 'cancel booking', 'workstation']
        },
        community: {
          name: 'Community',
          description: 'Handles Bosch community information, community list, groups, clubs, employee communities at Bosch Associate Arena',
          keywords: ['community', 'communities', 'groups', 'clubs', 'associate arena', 'join', 'members', 'team', 'enroll', 'participate', 'bosch community', 'bosch communities', 'bosch groups', 'bosch clubs', 'bgsw community', 'bgsw communities', 'bgsw groups', 'bgsw clubs']
        },
        banner: {
          name: 'Banner Service',
          description: "Handles company banners, announcements, company events, upcoming events in BGSW, Bosch internal event highlights, news, promotional content, current promotions, office banners, what's new, latest news, event descriptions, BGSW, bgsw, events in Bosch/BGSW",
          keywords: ['banner', 'banners', 'announcement', 'new', 'announcements', 'news', 'promotion', 'events in BGSW', 'events in Bosch', 'promotions', "what's new", 'latest news', 'updates', 'event', 'events', 'upcoming', 'company events', 'bosch events', 'BGSW', 'bgsw', 'bgsw events', 'upcoming events', 'event description', 'events in bgsw', 'events in bosch', 'current events', 'current promotions', 'bosch banner', 'bgsw banner', 'company banner', 'announcements in bosch', 'announcements in bgsw']
        }
      },
      privacyConfig: {
        nonNames: [
          'the', 'what', 'when', 'where', 'who', 'which', 'how', 'show', 'get', 'tell', 'give', 'find', 'fetch', 'list',
          'today', 'yesterday', 'tomorrow', 'week', 'month', 'year', 'total', 'average', 'please', 'thanks', 'thank',
          'hello', 'hi', 'hey', 'time', 'times', 'entry', 'exit', 'late', 'early', 'morning', 'evening', 'night',
          'afternoon', 'seat', 'travel', 'it', 'that', 'this', 'there', 'here', 'let', 'can', 'could', 'would', 'should',
          'will', 'need', 'want', 'like', 'check', 'see', 'view', 'look', 'all', 'any', 'some', 'these', 'those', 'last',
          'next', 'first', 'second', 'working', 'hours', 'attendance', 'schedule', 'booking', 'details', 'information',
          'info', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
          'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
          'flight', 'flight', 'train', 'bus', 'cab', 'taxi', 'car', 'rental', 'stay', 'hotel', 'visa', 'trip', 'trips',
          'pune', 'hyderabad', 'mumbai', 'delhi', 'chennai', 'bangalore', 'coimbatore', 'india', 'bosch',
          'kolkata', 'goa', 'ahmedabad', 'kochi', 'jaipur', 'lucknow', 'patna', 'gurgaon', 'noida',
          'mysore', 'mangalore', 'hubli', 'belgaum', 'dharwad', 'shimoga', 'udupi', 'kolar', 'tumkur',
          'air', 'required', 'needed', 'accommodation', 'provision', 'arrangement', 'provide', 'provide',
          'provide', 'retrieve', 'display', 'generate', 'calculate', 'access', 'return', 'summarize', 'include',
          'share', 'pull', 'extract', 'compile', 'compute', 'present', 'load', 'read', 'query', 'search',
          'detailed', 'complete', 'full', 'specific', 'exact', 'accurate', 'recent', 'comprehensive',
          'monthly', 'daily', 'weekly', 'annual', 'yearly', 'summary', 'period', 'range', 'between', 'during',
          'employee', 'user', 'member', 'staff', 'person', 'individual',
          'attendance', 'absences', 'presence', 'duration', 'login', 'logout', 'break',
          'second', 'third', 'fourth', 'fifth', 'quarter', 'half',
          'train', 'flight', 'bus', 'cab', 'ticket', 'tickets', 'stay', 'hotel', 'visa', 'trip', 'trips',
          'start', 'end', 'date', 'dates', 'being', 'mode', 'with', 'from', 'to', 'into', 'for',
          'accommodation', 'air', 'required', 'needed', 'wants', 'needs', 
          'requires', 'regarding', 'about', 'taxi', 'car', 'rental', 'rooms', 
          'guest', 'guests', 'passenger', 'passengers', 'arrival', 'departure', 'arrive', 'depart',
          'and', 'but', 'nor', 'yet', 'yes', 'sure', 'confirm', 'confirmation', 'confirmed', 'proceed', 'proceeding', 'proceeded', 'approve', 'approved', 'approving', 'verify', 'verified', 'verification', 'cancel', 'canceled', 'cancelled', 'cancelling',
          'new', 'old', 'location', 'locations', 'city', 'cities', 'country', 'countries', 'bengaluru', 'mysuru',
          'book', 'booked', 'booking', 'planning', 'planned', 'trip', 'trips', 'traveling', 'travelling',
          'office', 'building', 'floor', 'desk', 'station', 'meeting', 'room', 'project', 'team', 'department', 'unit',
          'canteen', 'cafeteria', 'parking', 'gym', 'details', 'information', 'info', 'status', 'request', 'requests',
          'order', 'orders', 'summary', 'plan', 'plans', 'schedule', 'schedules', 'history', 'view', 'search', 'find'
        ]
      },
      routingConfig: {
        greetingKeywords: ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings', 'what up'],
        followUpPatterns: {
          whatAbout: "^(what|how) about",
          andWhat: "^and\\s+(what|how|the|for)",
          timeRef: "^(yesterday|tomorrow|today|last|next|this)\\b",
          periodRef: "^(week|month|year)\\b",
          sameRef: "^(same|similar)\\b",
          moreRef: "^(more|less|other)\\b",
          shortQuestion: "^(when|where|why|who|how much|how many)\\?*$",
          thatRef: "^that\\s",
          itRef: "^it\\s",
          theSameRef: "^the\\s+(same|other|previous|next)",
          showMeRef: "^show\\s+(me\\s+)?(more|that|this)",
          okAndRef: "^ok\\s+(and|but|what)",
          confirmAndRef: "^(yes|yeah|sure|ok)[\\s,]+(and|but|what)",
          dateShort1: "^\\d{1,2}(st|nd|rd|th)?\\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)",
          dateShort2: "^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\s*\\d{1,2}",
          dateNumeric: "^\\d{1,2}[\\/\\-]\\d{1,2}",
          onDate: "^on\\s+\\d{1,2}",
          forDate: "^for\\s+(yesterday|tomorrow|today|\\d)",
          travelSpec: "\\b(one way|return|round trip|one-way)\\b"
        },
        subjectKeywords: ['menu', 'food', 'entry', 'exit', 'attendance', 'travel', 'seat', 'booking', 'community', 'banner', 'swipe', 'punch', 'who am i', 'my name', 'what is my name', 'employee name', 'identify me'],
        topicKeywords: {
          canteen: ['menu', 'food', 'breakfast', 'lunch', 'dinner', 'snacks'],
          entryexit: ['entry time', 'exit time', 'attendance', 'working hours', 'swipe'],
          travel: ['travel plan', 'trip', 'booking', 'settlement'],
          seatbooking: ['desk', 'seat', 'workspace', 'booking'],
          community: ['community', 'group', 'club'],
          banner: ['banner', 'announcement', 'news']
        }
      },
      // ── Centralised keyword configuration ──
      // Previously hardcoded across server.js, travel-service.js, seatbooking-service.js.
      // Editable via Admin UI → Keywords tab.
      keywordConfig: {
        privacyDetection: {
          personalDataKeywords: [
            'entry', 'exit', 'attendance', 'check.?in', 'check.?out', 'swipe',
            'leave', 'payslip', 'salary', 'pay', 'compensation',
            'working hours', 'work hours', 'hours worked', 'time tracking',
            'late', 'absent', 'shift', 'overtime',
            'schedule', 'booking', 'seat', 'travel',
            'effort', 'performance', 'appraisal',
            'data', 'details', 'info', 'information', 'record', 'records'
          ],
          colleaguePatternWords: [
            'friend', 'colleague', 'coworker', 'co-worker', 'team mate', 'teammate',
            'boss', 'manager', 'reportee', 'subordinate', 'buddy', 'peer',
            'other employee', 'another employee', 'someone else',
            'other person', 'another person', 'other people'
          ],
          bulkPatternPhrases: [
            'all employee', 'everyone', 'everybody',
            'team attendance', 'team entry', 'team exit', 'department attendance',
            'who all came', 'who came', 'who left', 'who is absent',
            'list of employees', 'employee list',
            'how many employees', 'how many people',
            'all staff', 'entire team', 'full team', 'whole team', 'all members',
            'group attendance', 'others attendance', 'others entry', 'others exit'
          ],
          impersonationSkipWords: [
            'looking', 'asking', 'checking', 'wondering', 'interested',
            'trying', 'requesting', 'here', 'logged', 'the', 'a', 'an',
            'not', 'also', 'just'
          ],
          aiRewriteVerbs: [
            'provide', 'retrieve', 'display', 'generate', 'show', 'give', 'tell',
            'fetch', 'list', 'find', 'get', 'share', 'compile', 'present',
            'summarize', 'include', 'access', 'return', 'load',
            'detailed', 'complete', 'full', 'specific', 'exact', 'accurate',
            'recent', 'comprehensive', 'monthly', 'daily', 'weekly', 'annual',
            'summary', 'period', 'range', 'between', 'during',
            'employee', 'user', 'member', 'staff', 'person', 'individual',
            'duration', 'more', 'additional'
          ]
        },
        travelService: {
          travelDataKeywords: [
            'travel', 'trip', 'flight', 'booking', 'expense',
            'settlement', 'reimbursement', 'itinerary', 'ticket'
          ],
          travelEntities: [
            'indigo', 'vistara', 'spicejet', 'airindia', 'emirates', 'lufthansa', 'etihad',
            'qatar', 'turkish', 'qantas', 'delta', 'united', 'american', 'southwest', 'jetblue',
            'ryanair', 'easyjet', 'cathay', 'thai', 'japan', 'korean', 'british', 'singapore',
            'airasia', 'goair', 'akasa', 'alliance', 'oneworld', 'skyteam', 'staralliance',
            'marriott', 'hilton', 'hyatt', 'sheraton', 'westin', 'radisson', 'novotel', 'ibis',
            'oberoi', 'leela', 'taj', 'itc', 'crowne', 'ramada', 'accor', 'intercontinental',
            'houston', 'chicago', 'boston', 'seattle', 'portland', 'denver', 'dallas', 'austin',
            'atlanta', 'miami', 'orlando', 'phoenix', 'detroit', 'minneapolis', 'philadelphia',
            'london', 'paris', 'berlin', 'munich', 'frankfurt', 'amsterdam', 'rome', 'milan',
            'madrid', 'barcelona', 'vienna', 'zurich', 'geneva', 'brussels', 'prague', 'warsaw',
            'dublin', 'lisbon', 'stockholm', 'helsinki', 'oslo', 'copenhagen', 'athens', 'istanbul',
            'tokyo', 'osaka', 'seoul', 'beijing', 'shanghai', 'guangzhou', 'shenzhen', 'taipei',
            'singapore', 'bangkok', 'jakarta', 'manila', 'hanoi', 'kuala', 'lumpur', 'colombo',
            'dubai', 'doha', 'riyadh', 'muscat', 'bahrain', 'kuwait', 'jeddah', 'abu', 'dhabi',
            'sydney', 'melbourne', 'auckland', 'perth', 'brisbane', 'adelaide',
            'cairo', 'nairobi', 'capetown', 'johannesburg', 'lagos', 'casablanca', 'addis',
            'toronto', 'vancouver', 'montreal', 'ottawa', 'calgary',
            'mexico', 'bogota', 'lima', 'santiago', 'buenos', 'aires', 'sao', 'paulo',
            'airport', 'terminal', 'station', 'junction', 'central', 'metro',
            'north', 'south', 'east', 'west', 'new', 'old', 'international', 'domestic',
            'cleartrip', 'makemytrip', 'goibibo', 'yatra', 'expedia', 'kayak'
          ]
        },
        seatBookingService: {
          seatKeywords: [
            'seat', 'desk', 'booking', 'reserve', 'floor',
            'zone', 'location', 'workstation'
          ]
        },
        communityService: {
          communityDetectionKeywords: ['community', 'communities', 'associate arena'],
          communityNames: [
            'mind buddies', 'art in motion', 'cyco', 'pixture perfect',
            'pathfinders', 'cricket', 'women in tech', 'bioblitz', 'garden club'
          ],
          joinIntentKeywords: ['join', 'register', 'enroll', 'enrol', 'subscribe', 'add me', 'sign me up'],
          listIntentPhrases: [
            'show all', 'list all', 'all communities', 'all active',
            'community list', 'active communities', 'what communities',
            'which communities', 'what are the communities',
            'show me communities', 'show communities', 'list communities'
          ]
        },
        entryExitService: {
          entryExitDataKeywords: [
            'entry', 'exit', 'swipe', 'swiped', 'swiping', 'attendance',
            'hours', 'check', 'checked', 'clock', 'clocked', 'time',
            'late', 'overtime', 'shift', 'punch', 'punched',
            'working hours', 'early', 'status',
            'data', 'details', 'info', 'information', 'record', 'records'
          ]
        }
      }
    };
  }

  /**
   * Save configuration to disk
   */
  async saveConfig() {
    try {
      await fs.writeJson(this.configPath, this.config, { spaces: 2 });
    } catch (error) {
      console.error('[ConfigService] Save failed:', error);
      throw error;
    }
  }

  /**
   * Get all core services
   */
  async getCoreServices() {
    if (!this.initialized) await this.initialize();
    return this.config.coreServices;
  }

  /**
   * Get privacy whitelist (nonNames)
   */
  async getPrivacyWhitelist() {
    if (!this.initialized) await this.initialize();
    return this.config.privacyConfig.nonNames;
  }

  /**
   * Update core service configuration
   */
  async updateCoreService(serviceId, serviceConfig) {
    if (!this.initialized) await this.initialize();
    this.config.coreServices[serviceId] = { ...this.config.coreServices[serviceId], ...serviceConfig };
    await this.saveConfig();
    return this.config.coreServices[serviceId];
  }

  /**
   * Update privacy whitelist
   */
  async updatePrivacyWhitelist(nonNames) {
    if (!this.initialized) await this.initialize();
    if (Array.isArray(nonNames)) {
      this.config.privacyConfig.nonNames = nonNames;
      await this.saveConfig();
    }
    return this.config.privacyConfig.nonNames;
  }

  /**
   * Update routing configuration
   */
  async updateRoutingConfig(routingConfig) {
    if (!this.initialized) await this.initialize();
    if (!routingConfig || typeof routingConfig !== 'object' || Array.isArray(routingConfig)) {
      throw new Error('[ConfigService] updateRoutingConfig: payload must be a plain object.');
    }
    // [FIX | Rule S5144 - SSRF]: Drop any key outside the allowlist before merging.
    const safeUpdate = {};
    for (const key of Object.keys(routingConfig)) {
      if (!ALLOWED_ROUTING_KEYS.includes(key)) {
        console.warn(`[ConfigService] updateRoutingConfig: ignoring unknown key '${key}'`);
        continue;
      }
      safeUpdate[key] = routingConfig[key];
    }
    this.config.routingConfig = { ...this.config.routingConfig, ...safeUpdate };
    await this.saveConfig();
    return this.config.routingConfig;
  }

  /**
   * Get all core services (Sync)
   */
  getCoreServicesSync() {
    return this.config ? this.config.coreServices : this.getDefaultConfig().coreServices;
  }

  /**
   * Get privacy whitelist (nonNames) (Sync)
   */
  getPrivacyWhitelistSync() {
    return this.config ? this.config.privacyConfig.nonNames : this.getDefaultConfig().privacyConfig.nonNames;
  }

  /**
   * Get routing configuration (Sync)
   */
  getRoutingConfigSync() {
    return this.config ? this.config.routingConfig : this.getDefaultConfig().routingConfig;
  }

  // ── Keyword Config (centralised keyword management) ──

  /**
   * Get keyword configuration (Sync)
   * Falls back to defaults if keywordConfig missing (backward compat)
   */
  getKeywordConfigSync() {
    if (this.config && this.config.keywordConfig) return this.config.keywordConfig;
    return this.getDefaultConfig().keywordConfig;
  }

  /**
   * Get keyword configuration (Async)
   */
  async getKeywordConfig() {
    if (!this.initialized) await this.initialize();
    return this.getKeywordConfigSync();
  }

  /**
   * Update a specific section of keywordConfig.
   * @param {string} section - One of: 'privacyDetection', 'travelService', 'seatBookingService', 'communityService', 'entryExitService'
   * @param {object} data    - The updated section object (replaces the section entirely)
   */
  async updateKeywordConfig(section, data) {
    if (!this.initialized) await this.initialize();
    if (!this.config.keywordConfig) {
      this.config.keywordConfig = this.getDefaultConfig().keywordConfig;
    }
    if (!this.config.keywordConfig[section]) {
      throw new Error(`Unknown keywordConfig section: ${section}`);
    }
    this.config.keywordConfig[section] = { ...this.config.keywordConfig[section], ...data };
    await this.saveConfig();
    return this.config.keywordConfig[section];
  }

  /**
   * Get complete config (for Admin UI)
   */
  async getFullConfig() {
    if (!this.initialized) await this.initialize();
    // Ensure keywordConfig is present even for older config files
    if (!this.config.keywordConfig) {
      this.config.keywordConfig = this.getDefaultConfig().keywordConfig;
    }
    return this.config;
  }
}

module.exports = new ConfigService();
