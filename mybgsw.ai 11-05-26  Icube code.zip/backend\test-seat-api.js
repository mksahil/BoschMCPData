const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

async function testApi() {
  const url = 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io/';
  const data = {
    jsonrpc: '2.0',
    id: 'test-123',
    method: 'message/send',
    params: {
      message: {
        messageId: 'msg-123',
        role: 'user',
        parts: [{ type: 'text', text: 'book a seat' }]
      },
      // [FIX | PII]: Real employee details replaced with env vars or generic test values.
      metadata: {
        employee_id: process.env.TEST_EMPLOYEE_ID || '00000000',
        user_id: process.env.TEST_EMPLOYEE_ID || '00000000',
        user_name: process.env.TEST_USER_NAME || 'TestUser',
        user_email: process.env.TEST_USER_EMAIL || 'testuser@example.com',
        user_data: {
          id: process.env.TEST_EMPLOYEE_ID || '00000000',
          name: process.env.TEST_USER_NAME || 'TestUser',
          email: process.env.TEST_USER_EMAIL || 'testuser@example.com'
        }
      }
    }
  };

  try {
    console.log('Calling A2A Seat Booking Agent...');
    const response = await axios.post(url, data, {
      headers: { 'Content-Type': 'application/json' },
      httpsAgent
    });
    console.log('Response Status:', response.status);
    console.log('Response Data:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('Error:', error.message);
    if (error.response) {
      console.error('Error Data:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testApi();
