# MyBGSW.AI — API Rate Limiting
## Implementation Overview for Client Review

---

## 1. What Is Rate Limiting and Why It Exists

Rate limiting controls how many API requests a user or IP address can make within a given time window. For MyBGSW.AI, rate limiting serves two purposes:

1. **Cost protection** — Every message sent to the AI assistant triggers a call to Azure OpenAI (a paid cloud service billed per token). Without limits, a single user spamming requests could consume the entire monthly budget in minutes.
2. **Fair usage** — Ensures all employees get consistent, responsive performance by preventing any one user from monopolising server resources.

---

## 2. Rate Limiting Architecture

The application uses a **two-layer** approach:

```
Incoming Request
       │
       ▼
┌─────────────────────────────────────────────────┐
│  Layer 1 — Global Rate Limiter (IP-based)       │
│  100 requests / 60 seconds per IP address       │
│  Skips: /api/logs (activity logging must never  │
│          be blocked)                            │
└──────────────────┬──────────────────────────────┘
                   │ (passes through)
                   ▼
┌─────────────────────────────────────────────────┐
│  Layer 2 — Per-Route Limiters (employee-based)  │
│  Key: X-Employee-Number header                  │
│  Fallback key: IP address if header absent      │
└──────────────────┬──────────────────────────────┘
                   │
       ┌───────────┼───────────┬──────────────┐
       ▼           ▼           ▼              ▼
  /api/chat   Canteen/      /api/          /api/
  AI Chat     EntryExit/    time-tracking  auth/
              Time-track    /query         login
  [Chat        [Service     [Service       [Login
  Limiter]     Limiter]     Limiter]       Limiter]
  10 req/min   10 req/min   10 req/min     10 req/min
```

---

## 3. Rate Limiter Definitions

### 3.1 Global Rate Limiter

| Property | Value |
|---|---|
| Window | 60 seconds |
| Max requests | 100 per IP address |
| Key | Client IP address |
| Applies to | All routes EXCEPT /api/logs |
| Skipped routes | `/api/logs` (activity telemetry — must always succeed) |

This limiter protects the server from bots, scrapers, and denial-of-service attempts at the infrastructure level. A normal page load fires approximately 5–7 API calls on mount; 100 requests per minute leaves ample headroom for normal usage while blocking abuse.

### 3.2 Chat Rate Limiter

| Property | Value |
|---|---|
| Window | 60 seconds |
| Max requests | 10 per employee |
| Key | `X-Employee-Number` header (falls back to IP) |
| Applies to | `POST /api/chat` only |
| Error message | "Too many chat messages. You can send up to 10 messages per minute. Please wait before trying again." |

Applied exclusively to the main AI chat endpoint. Each employee gets their own independent 10-request bucket — one employee exhausting their quota does not affect any other employee.

### 3.3 Service Rate Limiter

| Property | Value |
|---|---|
| Window | 60 seconds |
| Max requests | 10 per employee |
| Key | `X-Employee-Number` header (falls back to IP) |
| Applies to | `POST /api/canteen/query`, `POST /api/entryexit/query`, `GET /api/community/list`, `POST /api/community/register`, and all `/api/time-tracking/*` routes |
| Error message | "Too many service requests. You can make up to 10 requests per minute. Please wait before trying again." |

This is a **separate, independent bucket** from the Chat limiter. An employee reaching the chat limit can still query the canteen or entry/exit services and vice versa.

### 3.4 Login Rate Limiter

| Property | Value |
|---|---|
| Window | 60 seconds |
| Max requests | 10 per IP address |
| Key | IP address |
| Applies to | `POST /api/auth/login` |
| Error message | "Too many login attempts. Please wait a minute before trying again." |

Protects against brute-force credential attacks on the login endpoint.

---

## 4. Standard Response Headers

When a rate-limited endpoint is called, the server returns the following headers alongside HTTP status `429 Too Many Requests`:

| Header | Example | Description |
|---|---|---|
| `RateLimit-Limit` | `10` | Maximum allowed requests in the window |
| `RateLimit-Remaining` | `0` | Requests remaining in the current window |
| `RateLimit-Reset` | `1745400060` | Unix timestamp when the window resets |
| `Retry-After` | `60` | Seconds to wait before retrying |

The frontend reads the `Retry-After` header to display a live countdown to the user.

---

## 5. Routes — What Is and Is Not Rate Limited

### Covered by Both Global + Per-Route Limiter

| Route | Method | Limiter | Key |
|---|---|---|---|
| `/api/chat` | POST | Global + Chat | IP + Employee |
| `/api/canteen/query` | POST | Global + Service | IP + Employee |
| `/api/community/list` | GET | Global + Service | IP + Employee |
| `/api/community/register`| POST | Global + Service | IP + Employee |
| `/api/entryexit/query` | POST | Global + Service | IP + Employee |
| `/api/time-tracking/*` | GET/POST | Global + Service | IP + Employee |
| `/api/auth/login` | POST | Global + Login | IP + IP |

### Covered by Global Limiter Only (100/min)

| Route | Method | Notes |
|---|---|---|
| `/api/health` | GET | Health check |
| `/api/admin/services` | GET | Service discovery |

### Completely Exempt (No Rate Limiting)

| Route | Method | Reason |
|---|---|---|
| `/api/logs` | POST / GET | Activity telemetry — must never be blocked. If logging were rate-limited, the system would lose visibility into what users are doing precisely when usage is highest. |

---

## 6. Frontend — How Each Screen Handles Rate Limiting

The frontend uses a shared React hook (`useRateLimit`) that:
- Reads the `Retry-After` response header
- Starts a live countdown timer
- Sets `isRateLimited = true` for the duration of the window
- Automatically re-enables the UI when the window expires

All user-facing UI controls that trigger rate-limited routes are disabled during the cooldown period, with the remaining seconds shown inline.

---

### 6.1 Login Screen

**Route called:** `POST /api/auth/login`
**Limiter:** Login Rate Limiter (10 attempts / 60 s per IP)

The login form protects against brute-force attacks. After 10 failed or rapid login attempts from the same IP, the server returns `429` and the UI displays an error preventing further attempts.

---

[ IMAGE PLACEHOLDER — Login screen showing normal state ]

*Caption: Login screen — standard view*

---

[ IMAGE PLACEHOLDER — Login screen showing 429 error / rate limited state ]

*Caption: Login screen after rate limit is hit — user is informed to wait*

---

### 6.2 Dashboard — Main Screen

**Routes called on load:**
- `POST /api/chat` — Company News/Banners card
- `GET /api/time-tracking/employee-name` — Entry & Exit card
- `GET /api/time-tracking/current-status` — Entry & Exit card
- `GET /api/community/list` — Community card
The dashboard auto-fetches data for visible cards when the page loads. The global limiter (100 req / minute per IP) applies to all these calls. Additionally, each call consumes quota from its respective per-employee bucket (10 req / minute):
- The Company News hook draws 1 query from the employee's **Chat Limiter** bucket.
- The Entry & Exit and Community hooks draw a combined 3 queries from the employee's **Service Limiter** bucket.

---

[ IMAGE PLACEHOLDER — Full dashboard screenshot showing all cards in normal state ]

*Caption: MyBGSW.AI Dashboard — all cards loaded normally*

---

### 6.3 Company News / Snippets Card (BannersCard)

**Route called:** `POST /api/chat` (with `service: "banner"`)
**Limiter:** Chat Rate Limiter (10 req / 60 s per employee)

The banners card fetches company announcements through the unified chat endpoint. If the chat rate limit is hit (shared with the main AI chat), an inline rate-limit error layout appears inside the card. The card remains visible but shows an alert box asking the user to wait, consistent with the rest of the dashboard panels.

**User impact:** Banners stop refreshing. The card replaces its content with a unified error/rate-limit alert box indicating the cooldown period.

---

[ IMAGE PLACEHOLDER — Company News card in normal state showing banner/announcement ]

*Caption: Company News card — normal state with announcement visible*

---

[ IMAGE PLACEHOLDER — Company News card showing inline rate-limit alert box ]

*Caption: Company News card — inline alert box replaces content when rate limit is hit*

---

### 6.4 Today's Menu — Cafeteria Card

**Route called:** `POST /api/canteen/query`
**Limiter:** Service Rate Limiter (10 req / 60 s per employee)

The user first selects a location (Bangalore or Coimbatore), which triggers a menu fetch. If the service rate limit is hit, an error message appears inside the card. The Retry button displays a live countdown (e.g., "Retry in 28s") and is disabled until the window expires. A "Change Location" button remains available so the user can reset the flow.

**User impact:** Menu is not shown. User sees a countdown and cannot retry until the window expires.

---

[ IMAGE PLACEHOLDER — Cafeteria card showing location selection (Bangalore / Coimbatore) ]

*Caption: Cafeteria card — location selection step*

---

[ IMAGE PLACEHOLDER — Cafeteria card showing today's menu successfully loaded ]

*Caption: Cafeteria card — menu loaded successfully*

---

[ IMAGE PLACEHOLDER — Cafeteria card showing 429 error with "Retry in Xs" disabled button ]

*Caption: Cafeteria card — rate limit state with countdown timer on Retry button*

---

### 6.5 Entry & Exit Card

**Routes called:** `GET /api/time-tracking/employee-name` + `GET /api/time-tracking/current-status` (parallel, via `Promise.all`)
**Limiter:** Global Rate Limiter only (100 req / 60 s per IP) — these are data lookup routes, not AI routes

The card shows the employee's current check-in/check-out status and last swipe time. Both requests are fetched in parallel on load. Because these routes are covered by the **Service Rate Limiter**, querying them too frequently will trigger a `429 Too Many Requests`:
- A consistent, inline error message box appears inside the card
- The "Retry" button shows a live countdown inside the error section (e.g. "Retry in Xs") and is disabled until the window expires.

**User impact:** Status is replaced by an inline error box. The Retry button is disabled with a countdown shown.

---

[ IMAGE PLACEHOLDER — Entry & Exit card showing employee name, check-in status, and last swipe time ]

*Caption: Entry & Exit card — normal state showing employee status*

---

[ IMAGE PLACEHOLDER — Entry & Exit card showing error/rate-limit state with disabled refresh ]

*Caption: Entry & Exit card — inline rate limit state with disabled Retry button and countdown*

---

### 6.6 Community Card

**Route called:** `GET /api/community/list` (and `POST /api/community/register`)
**Limiter:** Service Rate Limiter (10 req / 60 s per employee)

The community card fetches the list of available communities. If the service rate limit is hit on load or while attempting to register:
- The card content is replaced by the unified inline error message box.
- The "Retry" button shows a live countdown (e.g. "Retry in Xs") and is disabled.

**User impact:** Communities list is hidden. An inline error box is shown with a disabled Retry button displaying a countdown.

---

[ IMAGE PLACEHOLDER — Community card showing communities list ]

*Caption: Community card — normal state with communities visible*

---

[ IMAGE PLACEHOLDER — Community card showing rate-limit inline error box ]

*Caption: Community card — rate limited state with inline alert box and countdown*

---

### 6.7 AI Chat (Floating Chat Button)

**Route called:** `POST /api/chat`
**Limiter:** Chat Rate Limiter (10 req / 60 s per employee)

The floating AI chat widget (bottom-right of the screen) sends all messages to the unified chat endpoint. After 10 messages in 60 seconds, the server returns `429`. The frontend:
- Shows a rate-limit banner inside the chat panel with a live countdown
- Disables the message input field and send button
- Prevents the Enter key from sending a new message
- The chat history remains visible and scrollable during the cooldown

**User impact:** Cannot send new messages. Live countdown displayed. Chat re-enables automatically when the window expires.

---

[ IMAGE PLACEHOLDER — AI Chat panel open, showing a normal conversation ]

*Caption: AI Chat — normal conversation state*

---

[ IMAGE PLACEHOLDER — AI Chat panel showing rate limit banner with countdown, disabled input ]

*Caption: AI Chat — rate limited state with countdown banner and disabled input*

---

### 6.8 Seat Booking Card

**Route called:** `POST /api/chat` (with `service: "seatbooking"`)
**Limiter:** Chat Rate Limiter (10 req / 60 s per employee) — **shared bucket with AI Chat**

The Seat Booking card provides an AI assistant for booking desks. Because it calls the same `/api/chat` endpoint as the main AI Chat widget, both share the same 10-request-per-minute bucket. If a user sends 8 messages in the floating AI chat and then 2 in Seat Booking, the bucket is exhausted.

When rate limited:
- A rate-limit banner appears below the chat area with a live countdown
- The input placeholder changes to show time remaining (e.g., "Available again in 0:42...")
- The input and send button are disabled
- The Enter key is blocked

**User impact:** Cannot send seat booking queries. Countdown shown. Re-enables automatically.

---

[ IMAGE PLACEHOLDER — Seat Booking card showing AI assistant conversation ]

*Caption: Seat Booking card — normal AI assistant conversation*

---

[ IMAGE PLACEHOLDER — Seat Booking card showing rate limit banner and disabled input ]

*Caption: Seat Booking card — rate limited state with banner and disabled input*

---

### 6.9 Business Travel Card

**Route called:** `POST /api/chat` (with `service: "travel"`)
**Limiter:** Chat Rate Limiter (10 req / 60 s per employee) — **shared bucket with AI Chat and Seat Booking**

The Business Travel card provides an AI assistant for travel planning and expense management. It calls the same `/api/chat` endpoint and therefore shares the same per-employee bucket as the floating AI Chat and Seat Booking card.

Rate-limit behaviour is identical to Seat Booking:
- Rate-limit banner appears below the chat area with countdown
- Input placeholder shows time remaining
- Input and send button disabled
- Enter key blocked

**User impact:** Cannot send travel queries. Countdown shown. Re-enables automatically.

---

[ IMAGE PLACEHOLDER — Business Travel card showing AI assistant conversation ]

*Caption: Business Travel card — normal AI assistant conversation*

---

[ IMAGE PLACEHOLDER — Business Travel card showing rate limit banner and disabled input ]

*Caption: Business Travel card — rate limited state with banner and disabled input*

---

## 7. Shared Chat Bucket — Important Note

The Chat Rate Limiter applies to **all** calls to `/api/chat` from a given employee, regardless of which card or widget makes the call. The following three surfaces share one 10-request-per-minute bucket:

| Surface | Contribution to Shared Bucket |
|---|---|
| Floating AI Chat widget | Every message sent |
| Seat Booking card | Every message sent |
| Business Travel card | Every message sent |
| Company News card | 1 call on page load (banner fetch) |

This means a power user who sends 9 chat messages and then opens Seat Booking will find Seat Booking rate-limited on their first query. This is by design — the shared bucket ensures the AI cost cap is enforced across all access points.

---

## 8. User-Facing UX Summary

| Scenario | What the User Sees |
|---|---|
| Normal usage (under limits) | No interruption — all features work normally |
| Chat/Seat/Travel limit hit | Rate-limit banner + countdown + input disabled + send button disabled |
| Cafeteria limit hit | Inline error alert box in card + "Retry in Xs" button (disabled) |
| Entry & Exit limit hit | Inline error alert box in card + "Retry in Xs" button (disabled) |
| Community limit hit | Inline error alert box in card + "Retry in Xs" button (disabled) |
| Banners limit hit | Inline error alert box in card + "Retry in Xs" button (disabled) |
| Login limit hit | Error message on login form |
| Window expires (any) | UI re-enables automatically — no manual action required |

---

## 9. Test Coverage

### Backend — Jest / Supertest (`backend/tests/rateLimit.test.js`)

All four rate limiters are tested with an isolated Express app. Test groups:

| Test Group | Tests | What Is Verified |
|---|---|---|
| Chat & Service rate limiters | 20 (5 per route × 4 routes) | Allows up to limit, blocks on 4th request, 429 body has error message, RateLimit headers present, different employees get independent counters, IP fallback when header absent |
| Chat vs Service independence | 2 | Exhausting chat does not affect service routes and vice versa |
| Logs API exemption | 2 | POST and GET /api/logs succeed even when global limit is exhausted |
| Login rate limiter | 3 | Allows up to limit, blocks on 4th, body has login-specific message |
| Global rate limiter | 3 | Allows up to global limit, blocks after, AI route requests consume global budget |

**Total: 30 backend tests**

### Frontend — Jasmine / Karma / Testing Library

| Spec File | Tests | What Is Verified |
|---|---|---|
| `useRateLimit.spec.ts` | 9 | Initial state, header parsing, countdown, auto-reset after window, double-call reset, fallback to 60s |
| `AIChat.spec.tsx` | 4+ | Send/receive, history load, error handling, 429 bubble |
| `BannersCard.spec.tsx` | 6 | Loading state, banner render, empty state, unauthenticated skip, 429 no-crash |
| `CafeteriaCard.spec.tsx` | 8 | Location picker, menu render, 429 error, disabled Retry, countdown label |
| `SeatBookingCard.spec.tsx` | 7 | Greeting, send/response, 429 bubble, input disabled, button disabled, placeholder countdown, Enter blocked |
| `TravelCard.spec.tsx` | 7 | Same pattern as SeatBookingCard |
| `EntryExitCard.spec.tsx` | 8 | Loading, success render, 429 on each endpoint, Refresh disabled, tooltip countdown, Try-again label |

**Total: 49+ frontend tests**



*Document version: April 2026*
*Prepared for client review — image placeholders to be filled with screenshots before final delivery*
