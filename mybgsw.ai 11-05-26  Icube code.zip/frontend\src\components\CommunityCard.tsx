import { useState, useEffect } from "react";
import { Users, RefreshCw, Loader2, AlertCircle, MapPin, CheckCircle2, Info, ChevronDown, ChevronUp } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { API_BASE_URL } from "@/config";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { useRateLimit } from "@/hooks/useRateLimit";
import { formatCountdown } from "./RateLimitBanner";

interface CommunityLocation {
  id: number;
  name: string;
  code: string;
}

interface Community {
  id: number;
  name: string;
  description: string;
  members: number;
  color: string;
  icon: string | null;
  category: string;
  locations: CommunityLocation[];
}

export const CommunityCard = () => {
  const { user } = useAuth();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [viewAll, setViewAll] = useState(false);

  // Accordion state tracks the open community ID
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [joining, setJoining] = useState(false);
  const [joinSuccess, setJoinSuccess] = useState<string | null>(null);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  const handleJoinCommunity = async (community: Community, location: CommunityLocation) => {
    setJoining(true);
    setJoinSuccess(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
        },
        body: JSON.stringify({
          communityId: community.id,
          locationId: location.id,
        }),
      });
      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        const retry = parseInt(response.headers.get('Retry-After') || '60', 10);
        toast.error(`Too many requests. Please wait ${formatCountdown(retry)} before retrying.`);
        return;
      }

      const rawMessage: string = (data.message || data.error || '').toString();
      const alreadyMemberRegex = /already\s+(a\s+)?(member|registered|joined|part|enrolled|subscribed)|already\s+exists?|duplicate\s+registration|member\s+exists/i;
      const isAlreadyMember = alreadyMemberRegex.test(rawMessage);

      if (data.success && !isAlreadyMember) {
        setJoinSuccess(data.message || `Successfully joined ${community.name}!`);
        toast.success(data.message || `Successfully joined ${community.name}!`);

        setCommunities(prev => prev.map(c =>
          c.id === community.id
            ? { ...c, members: c.members + 1 }
            : c
        ));

      } else if (isAlreadyMember) {
        const friendlyMsg = rawMessage || `You are already a member of ${community.name}.`;
        setJoinSuccess(friendlyMsg);
        toast.info(friendlyMsg);
      } else {
        toast.error(rawMessage || 'Failed to join community');
      }
    } catch (err) {
      console.error('Error joining community:', err);
      toast.error('Unable to join community. Please try again.');
    } finally {
      setJoining(false);
      setShowLocationPicker(false);
    }
  };

  const fetchCommunities = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/api/community/list?page=1&pageSize=10`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        }
      });
      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        setError('Too many requests. Please wait before retrying.');
        return;
      }

      if (data.success && data.communities) {
        setCommunities(data.communities);
        setTotalCount(data.totalCount || data.communities.length);
      } else {
        setError('Failed to load communities');
      }
    } catch (err) {
      console.error('Error fetching communities:', err);
      setError('Unable to connect to community service');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCommunities();
  }, []);

  if (loading) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <span className="ml-2 text-sm text-muted-foreground">Loading communities...</span>
        </div>
      </DashboardCard>
    );
  }

  if (error) {
    return (
      <DashboardCard title="Community & Events" icon={Users}>
        <div className="flex flex-col items-center justify-center flex-1 h-full min-h-[256px] gap-3 p-6 text-center">
          <div className="w-12 h-12 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-2">
            <AlertCircle className="w-6 h-6 text-amber-500" />
          </div>
          <p className="text-sm text-foreground font-medium max-w-[280px]">
            {error || "Communities unavailable"}
          </p>
          {isRateLimited && (
            <p className="text-xs text-amber-500 font-medium tracking-wide">
              Available again in {formatCountdown(retryAfter)}...
            </p>
          )}
          <button
            onClick={fetchCommunities}
            disabled={isRateLimited}
            className="px-6 py-2 mt-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed w-32"
          >
            {isRateLimited ? "Paused" : "Try Again"}
          </button>
        </div>
      </DashboardCard>
    );
  }

  const displayedCommunities = viewAll ? communities : communities.slice(0, 6);

  // Group communities by their category for the Section Titles
  const groupedCommunities = displayedCommunities.reduce((acc, community) => {
    const category = community.category && community.category !== 'General' && !community.category.startsWith('#')
      ? community.category
      : 'General';
    if (!acc[category]) acc[category] = [];
    acc[category].push(community);
    return acc;
  }, {} as Record<string, Community[]>);

  return (
    <DashboardCard
      title="Community & Events"
      icon={Users}
      action={
        <button
          onClick={fetchCommunities}
          disabled={loading || isRateLimited}
          className="p-1 hover:bg-secondary/40 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          title={isRateLimited ? `Rate limited — retry in ${formatCountdown(retryAfter)}` : "Refresh"}
        >
          <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
        </button>
      }
    >
      <div className="space-y-4">
        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between pb-3">
            <span className="text-xs font-semibold text-foreground">
              {totalCount} Active Communities
            </span>
            {totalCount > 6 && (
              <button
                onClick={() => setViewAll(!viewAll)}
                className="text-xs text-[#0a84ff] hover:underline font-medium"
              >
                {viewAll ? "Show less" : `View all (${totalCount})`}
              </button>
            )}
          </div>
          <hr className="border-border/50" />
        </div>

        {/* Accordion List */}
        <div className={cn(
          "space-y-6 overflow-y-auto pr-1 transition-all duration-300 custom-scrollbar",
          viewAll ? "max-h-[450px]" : "max-h-[320px]"
        )}>
          {Object.entries(groupedCommunities).map(([category, comms]) => (
            <div key={category} className="space-y-0">
              <h4 className="text-[11px] font-bold text-muted-foreground tracking-wide mb-2 px-1">
                {category === 'General' ? '' : category}
              </h4>

              <div className="border-t border-border/50">
                {comms.map((community) => {
                  const isExpanded = expandedId === community.id;

                  return (
                    <div key={community.id} className="border-b border-border/50 flex flex-col">
                      {/* Row Header */}
                      <button
                        onClick={() => {
                          if (isExpanded) {
                            setExpandedId(null);
                            setShowLocationPicker(false);
                            setJoinSuccess(null);
                          } else {
                            setExpandedId(community.id);
                            setShowLocationPicker(false);
                            setJoinSuccess(null);
                          }
                        }}
                        className="flex items-center w-full py-3.5 px-2 hover:bg-secondary/20 transition-colors text-left relative"
                      >
                        {/* Left colored accent */}
                        <div
                          className="absolute left-0 top-0 bottom-0 w-1 bg-[#0a84ff]"
                        />

                        <div className="flex items-center gap-3 ml-3 flex-1">
                          <div className="relative flex items-center justify-center p-0.5 ">
                            <Info className="w-4 h-4 text-muted-foreground" />
                            <div className="absolute top-0 right-0 w-1.5 h-1.5 rounded-full bg-[#0a84ff]" />
                          </div>
                          <span className="text-[13px] font-medium text-foreground flex-1 pr-2 tracking-wide">
                            {community.name}
                          </span>
                        </div>

                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        )}
                      </button>

                      {/* Accordion Body */}
                      {isExpanded && (
                        <div className="px-5 py-4 bg-secondary/5  space-y-4 animate-in slide-in-from-top-2 duration-200 border-l-[4px] border-[#0a84ff]">
                          {/* Description */}
                          <div>
                            <p className="text-[11px] font-bold text-muted-foreground tracking-wide mb-1.5 uppercase">About</p>
                            <p className="text-xs text-foreground/80 leading-relaxed">
                              {community.description && !community.description.startsWith('#')
                                ? community.description
                                : 'No description available for this community.'}
                            </p>
                          </div>

                          {/* Members */}
                          <div className="flex items-center gap-2 bg-background/50 inline-flex px-3 py-1.5 rounded-full">
                            <Users className="w-3.5 h-3.5 text-[#0a84ff]" />
                            <span className="text-[11px] font-semibold text-foreground">{community.members} members</span>
                          </div>

                          {/* Join Actions */}
                          {joinSuccess ? (
                            <div className="flex items-center gap-2 p-2.5 bg-green-500/10 border border-green-500/20 rounded-lg mt-2">
                              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                              <p className="text-xs text-green-700 dark:text-green-400">{joinSuccess}</p>
                            </div>
                          ) : showLocationPicker ? (
                            <div className="space-y-2 pt-2 border-t border-border/50 mt-2">
                              <p className="text-xs font-medium text-foreground flex items-center gap-1 mb-2">
                                <MapPin className="w-3 h-3" /> Select your location
                              </p>
                              <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
                                {community.locations && community.locations.length > 0 ? (
                                  community.locations.map((loc) => (
                                    <button
                                      key={loc.id}
                                      disabled={joining}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleJoinCommunity(community, loc);
                                      }}
                                      className="w-full text-left px-3 py-2 text-xs bg-secondary/40 hover:bg-primary/10 hover:text-primary rounded-md transition-colors flex items-center justify-between disabled:opacity-50"
                                    >
                                      <span>{loc.name}</span>
                                      {joining ? (
                                        <Loader2 className="w-3 h-3 animate-spin" />
                                      ) : (
                                        <span className="text-[10px] text-muted-foreground">{loc.code}</span>
                                      )}
                                    </button>
                                  ))
                                ) : (
                                  <p className="text-xs text-muted-foreground py-2">No locations available.</p>
                                )}
                              </div>
                              <button
                                onClick={(e) => { e.stopPropagation(); setShowLocationPicker(false); }}
                                className="text-xs text-muted-foreground hover:text-foreground transition-colors mt-1"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="pt-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setJoinSuccess(null);
                                  setShowLocationPicker(true);
                                }}
                                className="w-full py-2.5 px-3 text-xs font-medium bg-[#0a84ff] text-white rounded-lg hover:bg-[#0a84ff]/90 transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-[#0a84ff]/20"
                              >
                                <Users className="w-3.5 h-3.5" />
                                Join Community
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardCard>
  );
};
