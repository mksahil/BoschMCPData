/**
 * test-seat-E.mjs
 *
 * Tests the A2A Seat-Booking agent endpoint directly.
 * Also verifies that the backend /api/chat endpoint correctly rate-limits
 * seat-booking queries via chatRateLimiter (2 req/min).
 *
 * Usage:  node test-seat-E.mjs
 */

import https from 'https';
import http from 'http';
import fs from 'fs';

// ── Config ───────────────────────────────────────────────────────────────────
const BACKEND_URL   = 'http://localhost:3001';
const EMPLOYEE_NUM  = process.env.TEST_EMPLOYEE_NUM  || '34835634';
const AUTH_TOKEN    = process.env.TEST_AUTH_TOKEN    || 'DUMMY_TOKEN';

// Remote A2A agent
const A2A_HOSTNAME  = 'host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';

// ── A2A Request (direct to remote agent) ────────────────────────────────────
const a2aPayload = JSON.stringify({
  jsonrpc: '2.0',
  id: 'test-E',
  method: 'message/send',
  params: {
    message: {
      messageId: 'msg-E',
      role: 'user',
      parts: [{ type: 'text', text: 'book a seat' }]
    },
    metadata: {
      auth: {
        token: AUTH_TOKEN,
        session_id: 'test-session-E'
      },
      employee_id: EMPLOYEE_NUM,
      user_id: EMPLOYEE_NUM,
      user_name: 'Manjunath',
      user_email: 'manjunath@bosch.com',
      booking_mode: 'seat',
      travel_mode: 'seat',
      // Candidate E uses STRINGIFIED user_data
      user_data: JSON.stringify({
        employee_id: EMPLOYEE_NUM,
        name: 'Manjunath',
        email: 'manjunath@bosch.com'
      })
    }
  }
});

function callA2AAgent() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: A2A_HOSTNAME,
      port: 443,
      path: '/',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(a2aPayload)
      },
      // [FIX #18 | Rule S5527]: rejectUnauthorized must remain true — disabling it
      // would allow MITM attacks by accepting any certificate.
      rejectUnauthorized: true
    };

    console.log('\n[Test 1] Calling A2A Seat Booking Agent (Candidate E, stringified user_data)...');
    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        console.log(`  Status: ${res.statusCode}`);
        fs.writeFileSync('test-result-utf8-E.json', body, 'utf8');
        console.log('  Result saved to test-result-utf8-E.json');
        resolve(res.statusCode);
      });
    });

    req.on('error', (e) => {
      console.error('  A2A Error:', e.message);
      resolve(null); // don't crash the test runner
    });

    req.write(a2aPayload);
    req.end();
  });
}

// ── Local backend /api/chat rate-limit check ────────────────────────────────
function backendPost(payload) {
  return new Promise((resolve) => {
    const body = JSON.stringify(payload);
    const opts = {
      hostname: 'localhost',
      port: 3001,
      path: '/api/chat',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        ...(AUTH_TOKEN   ? { 'Authorization':    `Bearer ${AUTH_TOKEN}`   } : {}),
        ...(EMPLOYEE_NUM ? { 'X-Employee-Number': EMPLOYEE_NUM            } : {}),
      }
    };

    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        resolve({ status: res.statusCode, retryAfter: res.headers['retry-after'] });
      });
    });
    req.on('error', (e) => {
      console.error('  Backend Error:', e.message);
      resolve({ status: null });
    });
    req.write(body);
    req.end();
  });
}

// ── Main ─────────────────────────────────────────────────────────────────────
async function runTests() {
  console.log('='.repeat(62));
  console.log('  Seat Booking — Agent E + Rate-Limit Test');
  console.log('='.repeat(62));
  console.log(`  A2A agent : ${A2A_HOSTNAME}`);
  console.log(`  Backend   : ${BACKEND_URL}`);
  console.log(`  Emp#      : ${EMPLOYEE_NUM}`);

  // Test 1: Direct A2A agent call
  await callA2AAgent();

  // Test 2: Rate-limit burst on /api/chat seat-booking intent
  console.log('\n[Test 2] Rate-limit burst via /api/chat (3 rapid seat-booking queries)');
  const results = [];
  for (let i = 1; i <= 3; i++) {
    const r = await backendPost({
      query: 'I want to book a seat for tomorrow',
      employeeNumber: EMPLOYEE_NUM
    });
    console.log(`  [req ${i}] Status: ${r.status}${r.status === 429 ? `  ← RATE LIMITED (Retry-After: ${r.retryAfter}s)` : ''}`);
    results.push(r.status);
  }

  const got429 = results.includes(429);
  console.log('\n--- Rate-Limit Result ---');
  console.log(`  Statuses: ${results.join(', ')}`);
  console.log(got429
    ? '  ✓ PASS — 429 fired on seat-booking chat route'
    : '  ✗ FAIL — 429 never fired; check chatRateLimiter keyGenerator in server.js');

  console.log('\n' + '='.repeat(62));
}

runTests();
