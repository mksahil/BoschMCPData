import { ReactNode, useEffect } from "react";
import { LucideIcon } from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";

interface DashboardCardProps {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
  className?: string;
  accent?: boolean;
  action?: ReactNode;
  hideHeader?: boolean;
}

export const DashboardCard = ({ title, icon: Icon, children, className, accent, action, hideHeader }: DashboardCardProps) => {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  useEffect(() => {
    // Log when card is viewed
    logger.logFeatureUsage(`dashboard-card-${title.toLowerCase().replace(/\s+/g, '-')}`, {
      cardTitle: title,
      isAccent: accent || false,
      timestamp: new Date().toISOString()
    });
  }, [title, accent]);

  return (
    <div
      className={cn("rounded-2xl transition-all duration-300 ease-out p-px shadow-lg", className)}
      style={{
        background: isDark
          ? "linear-gradient(180deg, rgba(255,255,255,0.20) 0%, rgba(255,255,255,0.06) 50%, rgba(255,255,255,0.02) 100%)"
          : "none",
      }}
    >
      <div
        // [FIX #13 | Rule S6819 - ARIA Keyboard]: Added keyboard listener and ARIA roles for accessibility
        role="button"
        tabIndex={0}
        onClick={() => {
          // Log card interactions
          logger.log('dashboard_card_click', {
            cardTitle: title,
            isAccent: accent || false
          });
        }}
        onKeyDown={(e) => {
          if ((e.key === 'Enter' || e.key === ' ') && e.target === e.currentTarget) {
            e.preventDefault();
            logger.log('dashboard_card_click', {
              cardTitle: title,
              isAccent: accent || false
            });
          }
        }}
        className={cn(
          "rounded-2xl p-6 flex flex-col h-full",
          accent && "bg-gradient-subtle"
        )}
        style={{
          background: isDark ? "rgba(18,18,24,0.65)" : "rgba(255,255,255,0.2)",
          backdropFilter: isDark ? "blur(0px) saturate(200%)" : "none",
          WebkitBackdropFilter: isDark ? "blur(0px) saturate(200%)" : "none",
          boxShadow: isDark
            ? "inset 0 1.5px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.30), 0 24px 64px rgba(0,0,0,0.60)"
            : "inset 0 1px 1px rgba(255,255,255,0.8), inset 0 -1px 1px rgba(255,255,255,0.3), 0 16px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.03)",
        }}
      >
        {/* Drag handle (grabber pill) for visual consistency */}
        <div className="flex justify-center pb-3 flex-shrink-0">
          <div 
            className="w-10 h-1 rounded-full" 
            style={{ background: isDark ? "rgba(255, 255, 255, 0.25)" : "rgba(0, 0, 0, 0.15)" }}
          />
        </div>

        {!hideHeader && (
          <div className="relative flex items-center justify-center mb-4 min-h-[32px]">
            <h3 className={cn("text-lg font-bold text-center drop-shadow-sm tracking-wide", isDark ? "text-white" : "text-black")}>{title}</h3>
            {action && <div className="absolute right-0">{action}</div>}
          </div>
        )}
        <div className="space-y-3">
          {children}
        </div>
      </div>
    </div>
  );
};
