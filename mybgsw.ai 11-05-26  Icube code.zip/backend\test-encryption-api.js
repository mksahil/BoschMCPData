const axios = require('axios');
const https = require('https');

// Disable SSL verification for verification
const httpsAgent = new https.Agent({
    rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

async function testEncryption() {
    console.log('Testing GetEncryptedPassword API...');

    const url = 'https://dev.boschassociatearena.com/api/ManageUser/GetEncryptedPassword';

    // [FIX | S6821]: Credentials loaded from env vars — set TEST_EMAIL_ID and TEST_PASSWORD locally.
    const payload = {
        "EmailId": process.env.TEST_EMAIL_ID || "00000000",
        "Password": process.env.TEST_PASSWORD || "changeme"
    };

    try {
        const response = await axios.post(
            url,
            payload,
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' // Explicitly sending empty bearer as per user example
                },
                httpsAgent
            }
        );

        console.log('Status:', response.status);
        console.log('Response Data:', response.data);

        // Check if we got something looking like an encrypted string
        if (typeof response.data === 'string' || response.data?.EncryptedPassword) {
            console.log('✅ Success: Received response (likely encrypted password)');
        } else {
            console.log('⚠️ Warning: Response format unexpected');
        }

    } catch (error) {
        console.error('❌ API Error:', error.message);
        if (error.response) {
            console.error('Response status:', error.response.status);
            console.error('Response data:', error.response.data);
        }
    }
}

testEncryption();
