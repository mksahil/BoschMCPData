import { Music, Play, Pause, SkipForward, Volume2 } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { useState } from "react";

export const MusicCard = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <DashboardCard title="My Music" icon={Music}>
      <div className="space-y-4">
        {/* Current Playing */}
        <div className="p-4 bg-gradient-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gradient-accent rounded-lg flex items-center justify-center">
              <Music className="w-6 h-6 text-accent-foreground" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-foreground">Focus Flow</h4>
              <p className="text-xs text-muted-foreground">Lofi Beats Collection</p>
            </div>
          </div>
          
          {/* Progress bar */}
          <div className="w-full bg-background/40 rounded-full h-1 mb-2">
            <div className="bg-gradient-primary h-1 rounded-full" style={{ width: '45%' }}></div>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mb-3">
            <span>2:15</span>
            <span>5:00</span>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4">
            <button className="p-2 hover:bg-secondary/40 rounded-full transition-colors">
              <SkipForward className="w-4 h-4 rotate-180 text-foreground" />
            </button>
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-3 bg-gradient-primary rounded-full hover:shadow-glow transition-all"
            >
              {isPlaying ? 
                <Pause className="w-5 h-5 text-primary-foreground" /> : 
                <Play className="w-5 h-5 text-primary-foreground" />
              }
            </button>
            <button className="p-2 hover:bg-secondary/40 rounded-full transition-colors">
              <SkipForward className="w-4 h-4 text-foreground" />
            </button>
          </div>
        </div>

        {/* Playlists */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-muted-foreground">Your Playlists</h4>
          <div className="p-2 bg-secondary/40 rounded-lg flex items-center gap-2 cursor-pointer hover:bg-secondary/80 transition-colors">
            <Volume2 className="w-4 h-4 text-primary" />
            <span className="text-xs text-foreground">Deep Work Mix</span>
            <span className="text-xs text-muted-foreground ml-auto">24 tracks</span>
          </div>
          <div className="p-2 bg-secondary/40 rounded-lg flex items-center gap-2 cursor-pointer hover:bg-secondary/80 transition-colors">
            <Volume2 className="w-4 h-4 text-accent" />
            <span className="text-xs text-foreground">Energize</span>
            <span className="text-xs text-muted-foreground ml-auto">18 tracks</span>
          </div>
          <div className="p-2 bg-secondary/40 rounded-lg flex items-center gap-2 cursor-pointer hover:bg-secondary/80 transition-colors">
            <Volume2 className="w-4 h-4 text-success" />
            <span className="text-xs text-foreground">Chill Vibes</span>
            <span className="text-xs text-muted-foreground ml-auto">32 tracks</span>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
