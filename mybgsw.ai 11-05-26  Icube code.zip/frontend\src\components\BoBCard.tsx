import { DollarSign, Upload, TrendingUp, PieChart } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const BoBCard = () => {
  const fixedPercentage = 70;
  const variablePercentage = 30;

  return (
    <DashboardCard title="BoB - Buffet of Benefits" icon={DollarSign}>
      <div className="space-y-4">
        {/* Salary Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-gradient-primary rounded-full"></div>
              <span className="text-sm text-muted-foreground">Fixed (70%)</span>
            </div>
            <span className="text-sm font-semibold text-foreground">₹85,000</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-gradient-accent rounded-full"></div>
              <span className="text-sm text-muted-foreground">Variable (30%)</span>
            </div>
            <span className="text-sm font-semibold text-foreground">₹36,000</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative h-3 bg-background/40 rounded-full overflow-hidden">
          <div 
            className="absolute h-full bg-gradient-primary rounded-full transition-all duration-300"
            style={{ width: `${fixedPercentage}%` }}
          ></div>
          <div 
            className="absolute h-full bg-gradient-accent rounded-full transition-all duration-300"
            style={{ width: `${variablePercentage}%`, left: `${fixedPercentage}%` }}
          ></div>
        </div>

        {/* Components Breakdown */}
        <div className="p-3 bg-secondary/40 rounded-lg space-y-2">
          <p className="text-xs font-semibold text-foreground mb-2">Fixed Components:</p>
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
            <span>• HRA</span>
            <span>• Hostel Allow.</span>
            <span>• Education Allow.</span>
            <span>• Basic Pay</span>
          </div>
        </div>

        {/* Bill Submission */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-foreground">Pending Bills (Due in 3 days)</p>
          <button className="w-full py-2 px-4 bg-gradient-primary hover:shadow-glow text-primary-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm">
            <Upload className="w-4 h-4" />
            Submit Bills
          </button>
          <button className="w-full py-2 px-4 bg-secondary/40 hover:bg-gradient-accent hover:text-accent-foreground rounded-lg transition-all duration-300 flex items-center justify-center gap-2 text-sm text-foreground">
            <TrendingUp className="w-4 h-4" />
            Same as Last Month
          </button>
        </div>

        {/* Quick Stats */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Auto-routed to Special Allow.</span>
          <span className="font-semibold text-primary">₹12,400</span>
        </div>
      </div>
    </DashboardCard>
  );
};
