/**
 * useSessionTimeout — unit tests
 *
 * Coverage targets:
 *   ✓ Initial state (no warning, full countdown)
 *   ✓ Warning appears after INACTIVITY_MS of idle time
 *   ✓ Countdown decrements each second once warning is visible
 *   ✓ Auto-logout when countdown reaches zero
 *   ✓ Immediate logout when elapsed > TOTAL_MS (device sleep / hibernation)
 *   ✓ Activity events reset the timer only BEFORE the warning appears
 *   ✓ Mouse/key events do NOT dismiss the warning — only "Stay Logged In" can
 *   ✓ handleStayLoggedIn resets state and calls refreshSession
 *   ✓ handleLogout calls logout
 *   ✓ Hook is dormant when user is not authenticated
 *   ✓ Cross-tab: ACTIVITY message resets the timer
 *   ✓ Cross-tab: SHOW_WARNING message shows the warning
 *   ✓ Cross-tab: RESET message resets the timer
 *   ✓ Cross-tab: LOGOUT message calls logout
 */

import { renderHook, act } from '@testing-library/react';
import { createElement } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import {
  useSessionTimeout,
  INACTIVITY_MS,
  WARNING_MS,
  TOTAL_MS,
} from '@/hooks/useSessionTimeout';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function seedUser(loginMethod: 'credential' | 'sso' = 'credential') {
  const user = {
    employeeNumber: 'EMP001',
    name: 'Test User',
    accessToken: 'tok',
    tokenType: 'Bearer',
    entityId: '1',
    entityName: 'BGSW',
    isTemporaryPassword: false,
    loginTimestamp: new Date().toISOString(),
    ntid: 'ntid01',
    expiresIn: 3600,
    issuedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 3_600_000).toISOString(),
    loginMethod,
  };
  sessionStorage.setItem('mybgsw_user', JSON.stringify(user));
}

/** Wrapper that provides the real AuthContext */
const wrapper = ({ children }: { children: React.ReactNode }) =>
  createElement(AuthProvider, null, children);

// ─── BroadcastChannel mock factory ────────────────────────────────────────────

function makeMockChannel() {
  const listeners: Array<(e: MessageEvent) => void> = [];
  const sent: Array<{ type: string }> = [];

  const channel = {
    onmessage: null as ((e: MessageEvent) => void) | null,
    postMessage: jasmine.createSpy('postMessage').and.callFake((msg: { type: string }) => {
      sent.push(msg);
    }),
    close: jasmine.createSpy('close'),
    /** Simulate an incoming message from another tab */
    receive(data: Record<string, unknown>) {
      if (channel.onmessage) {
        channel.onmessage({ data } as MessageEvent);
      }
      listeners.forEach(l => l({ data } as MessageEvent));
    },
    sent,
  };

  return channel;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('useSessionTimeout', () => {
  let mockChannel: ReturnType<typeof makeMockChannel>;

  beforeEach(() => {
    sessionStorage.clear();
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date());

    // Replace BroadcastChannel with our mock
    mockChannel = makeMockChannel();
    (window as unknown as Record<string, unknown>)['BroadcastChannel'] =
      jasmine.createSpy('BroadcastChannel').and.returnValue(mockChannel);
  });

  afterEach(() => {
    jasmine.clock().uninstall();
    sessionStorage.clear();
  });

  // ── Initial state ───────────────────────────────────────────────────────────

  it('starts with no warning and a full countdown when authenticated', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    expect(result.current.showWarning).toBeFalse();
    expect(result.current.countdown).toBe(WARNING_MS / 1000);
  });

  it('is dormant when the user is not authenticated — state never changes', async () => {
    // no seedUser — unauthenticated
    // Avoid spyOn(window, 'setInterval') while jasmine.clock() is active:
    // wrapping the clock's fake timer with a spy causes jasmine to restore the
    // fake after the spec, leaving a non-native function on window.setInterval
    // which prevents jasmine.clock().install() from working in the next beforeEach.
    // Instead we verify observable behaviour: even after TOTAL_MS the hook
    // remains in its initial (silent) state.
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      jasmine.clock().tick(TOTAL_MS + 10_000);
    });

    expect(result.current.showWarning).toBeFalse();
    expect(result.current.countdown).toBe(WARNING_MS / 1000);
  });

  // ── Warning trigger ─────────────────────────────────────────────────────────

  it('shows the warning after INACTIVITY_MS of idle time', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    expect(result.current.showWarning).toBeFalse();

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS + 1000);
    });

    expect(result.current.showWarning).toBeTrue();
  });

  it('does not show warning before INACTIVITY_MS has elapsed', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS - 5000);
    });

    expect(result.current.showWarning).toBeFalse();
  });

  // ── Countdown decrement ─────────────────────────────────────────────────────

  it('decrements the countdown each second once the warning is visible', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    // Trigger warning
    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });
    expect(result.current.showWarning).toBeTrue();

    const initialCountdown = result.current.countdown;

    await act(async () => { jasmine.clock().tick(3000); });

    expect(result.current.countdown).toBeLessThan(initialCountdown);
    expect(result.current.countdown).toBeCloseTo(initialCountdown - 3, 0);
  });

  // ── Auto-logout ─────────────────────────────────────────────────────────────

  it('calls logout when countdown reaches zero', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      jasmine.clock().tick(TOTAL_MS + 2000);
    });

    // After TOTAL_MS the user should be logged out (sessionStorage cleared)
    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── Device sleep ────────────────────────────────────────────────────────────

  it('performs immediate logout when elapsed time far exceeds TOTAL_MS (device sleep)', async () => {
    seedUser();
    renderHook(() => useSessionTimeout(), { wrapper });

    // Simulate laptop waking up after 2 hours
    await act(async () => {
      jasmine.clock().tick(TOTAL_MS + 2 * 60 * 60 * 1000);
    });

    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── Activity resets timer ───────────────────────────────────────────────────

  it('does NOT dismiss the warning on mouse movement — user must click Stay Logged In', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    // Trigger warning
    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });
    expect(result.current.showWarning).toBeTrue();

    // Simulate passive activity — warning must stay visible
    await act(async () => {
      document.dispatchEvent(new MouseEvent('mousemove'));
      document.dispatchEvent(new MouseEvent('click'));
      document.dispatchEvent(new KeyboardEvent('keydown'));
      jasmine.clock().tick(500);
    });

    expect(result.current.showWarning).toBeTrue();
  });

  it('resets the timer on user activity before the warning appears', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    // Activity before warning threshold — warning must not appear
    await act(async () => {
      jasmine.clock().tick(INACTIVITY_MS - 5000);
      document.dispatchEvent(new MouseEvent('mousemove'));
      jasmine.clock().tick(100);
    });

    // Advance past old inactivity window — warning should NOT fire because
    // activity reset lastActivityRef
    await act(async () => { jasmine.clock().tick(5000); });

    expect(result.current.showWarning).toBeFalse();
  });

  // ── handleStayLoggedIn ──────────────────────────────────────────────────────

  it('handleStayLoggedIn resets the warning and countdown', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });
    expect(result.current.showWarning).toBeTrue();

    await act(async () => {
      await result.current.handleStayLoggedIn();
    });

    expect(result.current.showWarning).toBeFalse();
    expect(result.current.countdown).toBe(WARNING_MS / 1000);
  });

  it('handleStayLoggedIn broadcasts RESET to other tabs', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });

    await act(async () => {
      await result.current.handleStayLoggedIn();
    });

    const resetMsg = mockChannel.sent.find(m => m.type === 'RESET');
    expect(resetMsg).toBeTruthy();
  });

  // ── handleLogout ────────────────────────────────────────────────────────────

  it('handleLogout clears the session', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      result.current.handleLogout();
    });

    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── Cross-tab: ACTIVITY ─────────────────────────────────────────────────────

  it('resets timer when ACTIVITY message received from another tab', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    // Advance to warning threshold
    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });
    expect(result.current.showWarning).toBeTrue();

    // Another tab sends activity with a recent timestamp
    await act(async () => {
      mockChannel.receive({ type: 'ACTIVITY', timestamp: Date.now() + 1 });
    });

    expect(result.current.showWarning).toBeFalse();
    expect(result.current.countdown).toBe(WARNING_MS / 1000);
  });

  // ── Cross-tab: SHOW_WARNING ─────────────────────────────────────────────────

  it('shows warning when SHOW_WARNING received from another tab', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      mockChannel.receive({ type: 'SHOW_WARNING' });
    });

    expect(result.current.showWarning).toBeTrue();
  });

  // ── Cross-tab: RESET ────────────────────────────────────────────────────────

  it('resets state when RESET message received from another tab', async () => {
    seedUser();
    const { result } = renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => { jasmine.clock().tick(INACTIVITY_MS + 1000); });
    expect(result.current.showWarning).toBeTrue();

    await act(async () => {
      mockChannel.receive({ type: 'RESET' });
    });

    expect(result.current.showWarning).toBeFalse();
    expect(result.current.countdown).toBe(WARNING_MS / 1000);
  });

  // ── Cross-tab: LOGOUT ───────────────────────────────────────────────────────

  it('logs out when LOGOUT message received from another tab', async () => {
    seedUser();
    renderHook(() => useSessionTimeout(), { wrapper });

    await act(async () => {
      mockChannel.receive({ type: 'LOGOUT' });
    });

    expect(sessionStorage.getItem('mybgsw_user')).toBeNull();
  });

  // ── Cleanup ─────────────────────────────────────────────────────────────────

  it('closes the BroadcastChannel on unmount', () => {
    seedUser();
    const { unmount } = renderHook(() => useSessionTimeout(), { wrapper });
    unmount();
    expect(mockChannel.close).toHaveBeenCalled();
  });
});
