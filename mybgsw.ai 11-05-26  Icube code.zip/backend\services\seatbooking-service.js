/**
 * Seat Booking Service
 * Calls the Seat Booking MCP Server (A2A Agent) for desk/workspace reservations
 * Uses A2A Protocol (Google Agent-to-Agent) - JSON-RPC 2.0
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');
const configService = require('./config-service');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: true // [FIX #23 | Rule S5527 - TLS]: restored from false — MITM risk
});

class SeatBookingService {
  constructor() {
    // A2A Host Agent URL (Seat Booking Agent)
    this.apiUrl = process.env.SEATBOOKING_API_URL || 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    this.agentCardPath = '/.well-known/agent.json';

    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.agentCard = null;
  }

  /**
   * Fetch the agent card from the Seat Booking A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) {
      return this.agentCard;
    }

    try {
      console.log(`[SeatBooking] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(
        `${this.apiUrl}${this.agentCardPath}`,
        { httpsAgent, timeout: 30000 }
      );
      this.agentCard = response.data;
      console.log('[SeatBooking] Agent card fetched successfully:', this.agentCard.name);
      return this.agentCard;
    } catch (error) {
      console.error('[SeatBooking] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Helper: Decode JWT token without external dependencies
   */
  decodeJWT(token) {
    try {
      if (!token || typeof token !== 'string') return null;
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
      return payload;
    } catch (e) {
      console.error('[SeatBooking] JWT Decode Error:', e.message);
      return null;
    }
  }

  /**
   * Call the Seat Booking A2A Agent using proper A2A protocol
   * Based on the working sba2aclient.py implementation
   */
  async callSeatBookingAPI(message, employeeNumber, userOAuthToken, files = [], explicitJwtToken = null, explicitSessionId = null, userName = null) {
    try {
      console.log(`[SeatBooking] Calling A2A Seat Booking Agent at: ${this.apiUrl}`);

      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;
      let effectiveEmpNo = employeeNumber;
      let effectiveName = userName;

      // Strategy 1: Use explicit tokens if provided (passed from login context)
      if (jwtToken && sessionId) {
        console.log('[SeatBooking] Strategy 1: Using caller-supplied credentials');
      }

      // Strategy 2: If an OAuth token was supplied, we may still have cached
      // JWT/sessionId from an earlier login.  We will only use the cache when
      // the provided OAuth token matches what was stored there.  This prevents
      // an attacker from supplying only an employee number and piggybacking on
      // another user's cached credentials.
      if (!jwtToken && userOAuthToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userOAuthToken);
        if (cachedTokens) {
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
        }
      }

      // Strategy 3: Convert OAuth to JWT
      if (!jwtToken && userOAuthToken) {
        try {
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userOAuthToken);
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
        } catch (conversionError) {
          console.log('[SeatBooking] Strategy 3: Auth conversion failed:', conversionError.message);
        }
      }

      // Strategy 4: Fallback to service account
      if (!jwtToken) {
        try {
          jwtToken = await boschAuthService.getServiceToken();
          if (!sessionId) {
            sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);
          }
        } catch (authError) {
          console.log('[SeatBooking] Strategy 4: Service account fallback failed:', authError.message);
        }
      }

      if (!jwtToken) throw new Error('AUTH_REQUIRED');
      if (!sessionId) sessionId = boschAuthService.getOrCreateSessionId(employeeNumber);

      // IDENTITY SYNC: Decode JWT to get the REAL name/ID for the metadata.
      //
      // CRITICAL: the Bosch JWT stores `name` as an encrypted AES blob
      // (base64-ish, ends with "=="). If we pass that blob to the A2A agent
      // as user_name, the downstream tool can't parse it and falls back to
      // a hardcoded test user ("Votan" on travel). We therefore filter out
      // any claim value that looks like an encrypted blob.
      const looksEncrypted = (val) => {
        if (typeof val !== 'string') return false;
        const v = val.trim();
        if (!v || v.includes(' ') || v.length < 24) return false;
        if (/[^A-Za-z0-9+/=_-]/.test(v)) return false;
        return v.endsWith('==') || v.length > 40;
      };

      const decoded = this.decodeJWT(jwtToken);
      const jwtEmpNo = decoded?.emp_number || decoded?.id || decoded?.sub || decoded?.unique_name;
      let jwtName = decoded?.name || decoded?.given_name || (decoded?.unique_name ? decoded.unique_name.split('@')[0] : null);
      if (looksEncrypted(jwtName)) jwtName = null;
      let jwtEmail = decoded?.email || null;
      if (looksEncrypted(jwtEmail)) jwtEmail = null;

      const safeId = String(effectiveEmpNo || jwtEmpNo || '34835634').replace(/[^0-9]/g, '');
      const safeName = (effectiveName && !looksEncrypted(effectiveName)) ? effectiveName : (jwtName || 'Bosch User');
      const safeEmail = jwtEmail || `${safeId}@bosch.com`;

      console.log(`[SeatBooking] A2A Sync: Identity resolved (ID length=${safeId.length})`);

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Build auth metadata as per A2A protocol (exactly matches test-system-instruction.mjs)
      // High-Saturation Identity: ensure the underlying Desk Booking tool sees the ID in every conceivable key.
      // ISOLATION FIX: We must suffix the sessionId with '_seat' so the A2A agent doesn't bleed 
      // conversation history from previous 'Travel' queries into 'Seat Booking' queries.
      const isolatedSessionId = sessionId ? `${sessionId}_seat` : `seat_${Date.now()}`;
      
      const authMetadata = {
        auth: {
          token: jwtToken,
          session_id: isolatedSessionId
        },
        booking_mode: 'seat',
        travel_mode: 'seat',
        employee_id: safeId,
        user_id: safeId,
        user_name: safeName,
        user_email: safeEmail,
        user_data: {
          id: safeId,               // Previous key
          userId: safeId,           // Likely tool match
          employee_id: safeId,      // Travel-service match
          employeeNumber: safeId,   // Bosch-auth match
          name: safeName,
          userName: safeName,
          email: safeEmail
        }
      };

      // A2A Protocol: SendMessageRequest format with DEFINITIVE PERSONA LOCK
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          // Force the agent to stay in "Office Seat Booking" persona and ask proper clarifying questions
          system_instruction: {
            parts: [{ 
              type: 'text', 
              text: "You are the Office Seat Booking agent. CRITICAL: If the user hasn't specified a Date and Office Location, you MUST ask them for these details BEFORE offering any seat numbers. Do NOT assume defaults and NEVER hallucinate example seat numbers (like L1-B003) if you haven't retrieved real availability data. Treat ALL requests as office workspace reservations. DISREGARD travel, flight, or hotel contexts entirely." 
            }]
          },
          message: {
            messageId: messageId,
            role: 'user',
            parts: [{ type: 'text', text: message }]
          },
          metadata: authMetadata
        }
      };

      const response = await axios.post(
        this.apiUrl,
        a2aRequest,
        {
          headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
          httpsAgent,
          timeout: 300000
        }
      );

      const a2aResult = response.data;
      if (a2aResult.error) throw new Error(a2aResult.error.message || 'A2A request failed');

      return a2aResult.result;
    } catch (error) {
      console.error('[SeatBooking] API error:', error.message);
      throw error;
    }
  }

  /**
   * Check if query is asking about another person's seat booking data.
   */
  /**
   * Check if query is asking about another person's seat-booking data.
   *
   * Strategy (mirrors travel-service): Instead of flagging every unknown
   * capitalised word as a person name (which false-positives on office
   * locations, building names, etc.), we detect **syntactic patterns**
   * that strongly indicate a person reference:
   *   A) Possessive:  "Rajesh's booking"
   *   B) Genitive:    "booking details of Kumar"
   *   C) Action-for:  "book a desk for Priya"
   *   D) Name-before-booking-noun: "Check Ramesh seat booking"
   *
   * Capitalised words appearing after location prepositions (in/at/on/near …)
   * are treated as places and excluded from name checks.
   */
  isQueryAboutOtherPerson(query, loggedInUserName = null) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // ── Helper: does `name` match the logged-in user? ──
    const ownNameParts = new Set();
    if (loggedInUserName) {
      const full = String(loggedInUserName).toLowerCase().trim();
      if (full) {
        ownNameParts.add(full);
        full.split(/\s+/).filter(Boolean).forEach(p => ownNameParts.add(p));
      }
    }
    const isOwnName = (name) => {
      if (!name) return false;
      const n = String(name).toLowerCase().trim();
      if (ownNameParts.has(n)) return true;
      for (const p of ownNameParts) if (p.length >= 3 && (n.includes(p) || p.includes(n))) return true;
      return false;
    };

    // ── Step 1 – Gate: must contain seat-booking keywords (from config) ──
    const seatKeywords = configService.getKeywordConfigSync().seatBookingService.seatKeywords;
    if (!seatKeywords.some(kw => q.includes(kw))) return false;

    // ── Step 2 – Self-reference → safe (unless colleague word) ──
    const hasSelfRef = /\b(my|mine|me|myself|i)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|team\s?mate|boss|manager|reportee|someone\s+else)\b/i.test(q);
    if (hasSelfRef && !hasColleagueWord) return false;

    // ── Step 3 – Colleague / role word → blocked ──
    if (hasColleagueWord) return true;

    // ── Step 4 – Third-person possessive pronoun + booking noun → blocked ──
    const bookingNounRe = '(?:seat|desk|booking|reservation|floor|zone|workstation|details?|data|records?|status|info|information)';
    if (new RegExp(`\\b(his|her|their)\\s+${bookingNounRe}`, 'i').test(q)) return true;
    if (/\bfor\s+(him|her|them)\b/i.test(q)) return true;

    // ── Step 5 – Pattern-based person-name detection ──

    // 5.0  Build location set: words after location prepositions are places
    const locationPositions = new Set();
    const prepRe = /\b(?:in|at|on|near|around|inside|within)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)/g;
    for (const m of original.matchAll(prepRe)) {
      m[1].toLowerCase().split(/\s+/).forEach(w => locationPositions.add(w));
    }

    // 5.1  Combined safe-word check: global whitelist + location context
    const whitelist = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));
    const isKnownSafe = (name) => {
      const n = name.toLowerCase();
      if (whitelist.has(n) || locationPositions.has(n)) return true;
      return n.split(/\s+/).some(w => whitelist.has(w) || locationPositions.has(w));
    };

    // Date-context helper: ignore capitalised words following ordinals
    // ("9th of April", "3rd May") — these are dates, not names.
    const dateContextRanges = [];
    const dateCtxRe = /\b(?:on\s+|from\s+|to\s+|by\s+|until\s+|till\s+)?\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?/gi;
    let dcm;
    while ((dcm = dateCtxRe.exec(original)) !== null) {
      dateContextRanges.push([dcm.index, dcm.index + dcm[0].length + 20]);
    }
    const isAfterDateContext = (pos) =>
      dateContextRanges.some(([start, end]) => pos >= start && pos <= end);

    // ── Pattern A: Possessive — "<Name>'s …" ──
    for (const m of original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)'s\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1]) && !isAfterDateContext(m.index)) {
        console.log(`[SeatBooking Privacy] Blocked: possessive "${m[1]}'s"`);
        return true;
      }
    }

    // ── Pattern B: "<booking noun> of/for <Name>" ──
    const genitiveRe = new RegExp(
      `\\b${bookingNounRe}\\s+(?:of|for)\\s+([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\b`, 'g'
    );
    for (const m of original.matchAll(genitiveRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[SeatBooking Privacy] Blocked: "of/for ${m[1]}" after booking noun`);
        return true;
      }
    }

    // ── Pattern C: "book/show/get … for <Name>" (not a known location) ──
    for (const m of original.matchAll(/\b(?:book|show|get|find|fetch|check|retrieve|reserve|cancel)\b[^.]*?\bfor\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1]) && !isAfterDateContext(m.index)) {
        console.log(`[SeatBooking Privacy] Blocked: action "for ${m[1]}"`);
        return true;
      }
    }

    // ── Pattern D: "<Name> <booking-noun>" where Name is NOT after a preposition ──
    const nameBeforeNounRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${bookingNounRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeNounRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        const before = original.substring(Math.max(0, m.index - 15), m.index).trim().toLowerCase();
        if (!/\b(?:in|at|on|near|around|inside)\s*$/.test(before)) {
          console.log(`[SeatBooking Privacy] Blocked: "${m[1]}" before booking noun`);
          return true;
        }
      }
    }

    // No person-name pattern detected → safe
    return false;
  }

  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId, userName } = context;
      const hasAuth = !!authToken;

      console.log('[SeatBooking] processQuery context:', { employeeNumber, hasAuth, userName });

      if (this.isQueryAboutOtherPerson(query, userName)) {
        return {
          success: false,
          response: "I'm sorry, but I can only provide your own personal information. For privacy reasons, I cannot share other colleagues' seat booking data."
        };
      }

      const getISTFormattedDate = (offsetDays = 0) => {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        const istTime = d.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
        const istDate = new Date(istTime);
        const yyyy = istDate.getFullYear();
        const mm = String(istDate.getMonth() + 1).padStart(2, '0');
        const dd = String(istDate.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
      };

      let explicitQuery = query.replace(/\btoday\b/gi, getISTFormattedDate(0))
        .replace(/\btomorrow\b/gi, getISTFormattedDate(1));

      // No bracketed metadata - identity is in JWT and Metadata. Raw query unlocks tools.
      const result = await this.callSeatBookingAPI(explicitQuery, employeeNumber, authToken, [], jwtToken, sessionId, userName);
      const response = this.formatSeatBookingResponse(result);

      return { success: true, response, data: result };
    } catch (error) {
      console.error('Seat Booking query error:', error.message);
      if (error.message === 'AUTH_REQUIRED') {
        return { success: false, response: "💺 **Seat Booking**\n\nYou need to be logged in to access this service." };
      }
      return { success: false, response: "💺 **Seat Booking Assistant**\n\nI'm having trouble connecting to the booking system. Please try again later." };
    }
  }

  /**
   * Enhanced Formatter - Aggregates text/data from parts, artifacts, and history.
   */
  formatSeatBookingResponse(result) {
    if (!result) return "💺 **Seat Booking Assistant**\n\nNo response received.";

    console.log('[SeatBooking] Raw A2A Result keys:', Object.keys(result));
    if (result.status) console.log('[SeatBooking] Result status keys:', Object.keys(result.status));
    if (result.artifacts) console.log('[SeatBooking] Result artifacts count:', result.artifacts.length);
    
    // DEBUG: Log the full result for deep inspection
    console.log('[SeatBooking] FULL RESULT:', JSON.stringify(result, null, 2));

    const textChunks = [];
    const collectFromParts = (parts) => {
      if (!Array.isArray(parts)) return;
      for (const p of parts) {
        if (!p) continue;
        const isText = (p.type === 'text' || p.kind === 'text');
        if (isText && typeof p.text === 'string') {
          const t = p.text.trim();
          if (t && t !== 'Processing...') textChunks.push(t);
        }
        const isData = (p.type === 'data' || p.kind === 'data');
        if (isData && p.data !== undefined) {
          textChunks.push(typeof p.data === 'string' ? p.data : JSON.stringify(p.data, null, 2));
        }
      }
    };

    if (result.status?.message?.parts) collectFromParts(result.status.message.parts);
    if (result.message?.parts) collectFromParts(result.message.parts);
    if (Array.isArray(result.artifacts)) {
      for (const art of result.artifacts) {
        if (art?.parts) collectFromParts(art.parts);
        if (art?.content) textChunks.push(typeof art.content === 'object' ? JSON.stringify(art.content, null, 2) : art.content);
        if (art?.data) textChunks.push(typeof art.data === 'object' ? JSON.stringify(art.data, null, 2) : art.data);
      }
    }
    
    // Aggressively capture any top-level or status-level data points
    if (result.status?.data) {
       textChunks.push(typeof result.status.data === 'object' ? JSON.stringify(result.status.data, null, 2) : result.status.data);
    }
    if (result.data) {
       textChunks.push(typeof result.data === 'object' ? JSON.stringify(result.data, null, 2) : result.data);
    }

    if (textChunks.length === 0 && Array.isArray(result.history)) {
      const agentMsgs = result.history.filter(h => h?.role === 'agent');
      for (let i = agentMsgs.length - 1; i >= 0; i--) {
        collectFromParts(agentMsgs[i]?.parts);
        if (textChunks.length > 0) break;
      }
    }

    const seen = new Set();
    const unique = textChunks.filter(t => { if (seen.has(t)) return false; seen.add(t); return true; });

    if (unique.length === 0) return "💺 **Seat Booking Assistant**\n\nI couldn't parse the booking details. Please try again.";
    return `💺 **Seat Booking Assistant**\n\n${unique.join('\n\n')}`;
  }

  async getMyBookings(context) { return this.processQuery('Show me my current bookings', context); }
  async cancelBooking(id, context) { return this.processQuery(`Cancel booking ${id}`, context); }
}

module.exports = new SeatBookingService();
