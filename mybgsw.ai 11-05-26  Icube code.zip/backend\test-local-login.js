const axios = require('axios');

async function testLogin() {
    console.log('Testing Local Login Proxy...');
    console.log('Target: http://localhost:3001/api/auth/login');
    const USERNAME = process.env.TEST_USERNAME;
    const PASSWORD = process.env.TEST_PASSWORD;
    if (!USERNAME || !PASSWORD) {
        console.error('TEST_USERNAME and TEST_PASSWORD environment variables must be set');
        process.exit(1);
    }
    console.log(`Payload: { username: "${USERNAME}", password: "<hidden>" }`);

    try {
        const response = await axios.post('http://localhost:3001/api/auth/login', {
            username: USERNAME,
            password: PASSWORD
        });

        console.log('\n✅ Login Successful!');
        console.log('Response Status:', response.status);
        console.log('User Name:', response.data.userName);
        console.log('Token Type:', response.data.token_type);
        console.log('Expires In:', response.data.expires_in);

        // store token for later tests
        const oauthToken = response.data.access_token;
        const empNumber = response.data.userName;

        // attempt seat-booking query without Authorization header
        console.log('\n-- testing seat booking without auth header --');
        try {
            const res2 = await axios.post('http://localhost:3001/api/chat', {
                query: 'seat booking: book a desk for tomorrow',
                employeeNumber: empNumber,
                sessionId: 'test-session'
            }, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            console.log('Booking without auth returned:', res2.data);
        } catch (err) {
            console.log('Expected failure', err.response?.data || err.message);
        }

        // now try with auth header
        console.log('\n-- testing seat booking with auth header --');
        try {
            const res3 = await axios.post('http://localhost:3001/api/chat', {
                query: 'seat booking: book a desk for tomorrow',
                employeeNumber: empNumber,
                sessionId: 'test-session'
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${oauthToken}`,
                    'X-Employee-Number': empNumber
                }
            });
            console.log('Booking with auth returned:', res3.data);
        } catch (err) {
            console.log('Unexpected error', err.response?.data || err.message);
        }

    } catch (error) {
        console.log('\n❌ Login Failed');
        if (error.response) {
            console.log('Status:', error.response.status);
            console.log('Data:', error.response.data);
        } else {
            console.log('Error:', error.message);
        }
        console.log('Skipping seat booking tests due to login failure.');
    }
}

testLogin();
