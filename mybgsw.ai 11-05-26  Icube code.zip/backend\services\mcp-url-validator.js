/**
 * MCP URL Validator
 *
 * [FIX | Rule S5144 - SSRF]: Centralised SSRF guard for the admin MCP-discovery
 * flow. Used at the SOURCE (server.js admin endpoint), MID-FLOW
 * (mcp-discovery-service.js discover) and SINK (generic-mcp-client.js
 * constructor and request paths) so the taint chain from req.body.url is
 * broken at every layer of defense in depth.
 *
 * Behaviour:
 *  - Only http: / https: are accepted
 *  - URL credentials (user:pass@host) are rejected
 *  - If MCP_ALLOWED_HOSTS env var is set (comma separated), the host
 *    must match exactly (case-insensitive, port-agnostic)
 *  - Otherwise, a private/loopback/link-local IP deny-list applies
 *  - Returns the canonicalised origin+pathname (no trailing slash) on
 *    success; throws on rejection so callers cannot silently misuse
 *    a bad URL.
 */

const PRIVATE_IPV4_PATTERNS = [
  /^127\./,                                    // loopback
  /^10\./,                                     // RFC1918
  /^192\.168\./,                               // RFC1918
  /^172\.(1[6-9]|2\d|3[01])\./,                // RFC1918
  /^169\.254\./,                               // link-local (incl. cloud metadata 169.254.169.254)
  /^0\.0\.0\.0$/,                              // unspecified
  /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./   // CGNAT 100.64.0.0/10
];

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'ip6-localhost',
  'ip6-loopback'
]);

function isPrivateOrLoopback(hostname) {
  const h = hostname.toLowerCase();
  if (BLOCKED_HOSTNAMES.has(h)) return true;
  if (h === '::1' || h === '[::1]') return true;
  // Bracketless IPv6 link-local / unique-local
  if (/^fe[89ab][0-9a-f]:/i.test(h)) return true;
  if (/^f[cd][0-9a-f]{2}:/i.test(h)) return true;
  return PRIVATE_IPV4_PATTERNS.some(p => p.test(h));
}

function getAllowedHosts() {
  const raw = process.env.MCP_ALLOWED_HOSTS;
  if (!raw) return null;
  return raw.split(',').map(h => h.trim().toLowerCase()).filter(Boolean);
}

/**
 * Validate a candidate MCP service URL.
 *
 * @param {string} rawUrl - URL supplied by an admin (untrusted)
 * @returns {string} canonical URL (origin + pathname, no trailing slash)
 * @throws {Error} on any validation failure (bad scheme, format, host, etc.)
 */
function validateMcpUrl(rawUrl) {
  if (typeof rawUrl !== 'string' || rawUrl.length === 0 || rawUrl.length > 2048) {
    throw new Error('[McpUrlValidator] SSRF guard: URL must be a non-empty string (<=2048 chars).');
  }
  // [FIX | S6324]: \s shorthand class (no literal/hex control chars) catches CR, LF, TAB, space.
  if (/\s/.test(rawUrl)) {
    throw new Error('[McpUrlValidator] SSRF guard: URL contains forbidden whitespace or control characters.');
  }

  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error('[McpUrlValidator] SSRF guard: invalid URL format.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(`[McpUrlValidator] SSRF guard: protocol '${parsed.protocol}' not allowed.`);
  }
  if (parsed.username || parsed.password) {
    throw new Error('[McpUrlValidator] SSRF guard: embedded credentials not allowed.');
  }

  const host = parsed.hostname.toLowerCase();
  if (!host) {
    throw new Error('[McpUrlValidator] SSRF guard: missing hostname.');
  }

  const allowed = getAllowedHosts();
  if (allowed) {
    if (!allowed.includes(host)) {
      throw new Error(`[McpUrlValidator] SSRF guard: host '${host}' not in MCP_ALLOWED_HOSTS.`);
    }
  } else if (isPrivateOrLoopback(host)) {
    throw new Error(`[McpUrlValidator] SSRF guard: private/loopback host '${host}' is blocked. Set MCP_ALLOWED_HOSTS to opt-in.`);
  }

  // Canonicalise: drop fragment + query, strip trailing slash
  const cleanPath = parsed.pathname.replace(/\/$/, '');
  return `${parsed.origin}${cleanPath}`;
}

module.exports = {
  validateMcpUrl,
  isPrivateOrLoopback
};
