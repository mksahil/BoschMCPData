import { Phone, Mail, AlertCircle, Ambulance, Shield } from "lucide-react";
import { DashboardCard } from "./DashboardCard";

export const VitalContactsCard = () => {
  return (
    <DashboardCard title="Vital Contacts" icon={Phone}>
      <div className="space-y-3">
        {/* Emergency Contact */}
        <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-4 h-4 text-destructive" />
            <h4 className="text-sm font-semibold text-foreground">Emergency</h4>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">24/7 Helpline</span>
            <a href="tel:+911234567890" className="text-sm font-bold text-destructive hover:underline">
              +91 123-456-7890
            </a>
          </div>
        </div>

        {/* Medical */}
        <div className="p-3 bg-secondary/40 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Ambulance className="w-4 h-4 text-success" />
            <h4 className="text-sm font-semibold text-foreground">Medical Center</h4>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-muted-foreground" />
              <a href="tel:+911234567891" className="text-xs text-primary hover:underline">
                +91 123-456-7891
              </a>
            </div>
            <p className="text-xs text-muted-foreground">Ground Floor, Building A</p>
          </div>
        </div>

        {/* Security */}
        <div className="p-3 bg-secondary/40 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-4 h-4 text-primary" />
            <h4 className="text-sm font-semibold text-foreground">Security Desk</h4>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-muted-foreground" />
              <a href="tel:+911234567892" className="text-xs text-primary hover:underline">
                +91 123-456-7892
              </a>
            </div>
            <p className="text-xs text-muted-foreground">Main Entrance</p>
          </div>
        </div>

        {/* IT Support */}
        <div className="p-3 bg-secondary/40 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Mail className="w-4 h-4 text-accent" />
            <h4 className="text-sm font-semibold text-foreground">IT Support</h4>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-muted-foreground" />
              <span className="text-xs text-primary">Ext: 1234</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3 h-3 text-muted-foreground" />
              <a href="mailto:support@company.com" className="text-xs text-primary hover:underline">
                support@company.com
              </a>
            </div>
          </div>
        </div>
      </div>
    </DashboardCard>
  );
};
