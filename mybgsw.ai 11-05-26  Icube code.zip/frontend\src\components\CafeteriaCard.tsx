import { Coffee, UtensilsCrossed, Moon, AlertCircle } from "lucide-react";
import { DashboardCard } from "./DashboardCard";
import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { API_ENDPOINTS } from "@/config";
import { useRateLimit } from "@/hooks/useRateLimit";
import { formatCountdown } from "./RateLimitBanner";

interface MenuData {
  breakfast: string;
  lunch: string;
  snacks: string;
}

export const CafeteriaCard = () => {
  const [loading, setLoading] = useState(false);
  const [menuData, setMenuData] = useState<MenuData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();

  useEffect(() => {
    // Don't auto-fetch menu, wait for location selection
    if (selectedLocation !== null) {
      fetchTodaysMenu(selectedLocation);
    }
  }, [selectedLocation]);

  const fetchTodaysMenu = async (locationId: number) => {
    try {
      setLoading(true);
      setError(null);

      // Get user from sessionStorage for auth
      const storedUser = sessionStorage.getItem('mybgsw_user');
      const userData = storedUser ? JSON.parse(storedUser) : null;

      const response = await fetch(API_ENDPOINTS.canteenQuery, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': userData?.accessToken ? `Bearer ${userData.accessToken}` : '',
          'X-Employee-Number': userData?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: "today's menu",
          locationId: locationId,
          employeeNumber: userData?.employeeNumber || ''
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        setError('Too many requests. Please wait before retrying.');
        return;
      }

      if (response.ok) {
        if (data.menuData) {
          // Use the structured menu data directly from backend
          setMenuData(data.menuData);
        } else if (data.success && data.response) {
          // Check if the response indicates no menu is available
          const responseText = data.response.toLowerCase();
          if (responseText.includes('no menu found') ||
            responseText.includes('menu not available') ||
            responseText.includes("isn't available") ||
            responseText.includes('not available') ||
            responseText.includes('not found') ||
            responseText.includes('no data') ||
            responseText.includes('not published')) {
            setError("Menu not updated for today");
          } else {
            // Fallback: Try to parse from natural language response
            const parsed = parseMenuFromResponse(data.response);
            if (parsed) {
              setMenuData(parsed);
            } else {
              setError("Menu not updated for today");
            }
          }
        } else {
          setError(data.error || "Menu not updated for today");
        }
      } else {
        setError(data.error || "Menu not updated for today");
      }
    } catch (err) {
      console.error('Failed to fetch menu:', err);
      setError("Failed to fetch menu");
    } finally {
      setLoading(false);
    }
  };

  const parseMenuFromResponse = (response: string): MenuData | null => {
    // Extract menu items from the natural language response
    // Look for patterns like "Breakfast:", "Lunch:", "Snacks:"
    const lines = response.split('\n');
    const menu: Partial<MenuData> = {};

    for (const line of lines) {
      // More flexible matching for breakfast
      if (line.toLowerCase().includes('breakfast')) {
        const match = line.match(/(?:breakfast)[:\s]*(.+)/i);
        if (match) menu.breakfast = match[1].replace(/\*+/g, '').trim();
      }
      // More flexible matching for lunch
      else if (line.toLowerCase().includes('lunch')) {
        const match = line.match(/(?:lunch)[:\s]*(.+)/i);
        if (match) menu.lunch = match[1].replace(/\*+/g, '').trim();
      }
      // More flexible matching for snacks
      else if (line.toLowerCase().includes('snack')) {
        const match = line.match(/(?:snacks?)[:\s]*(.+)/i);
        if (match) menu.snacks = match[1].replace(/\*+/g, '').trim();
      }
    }

    // Check if we found any menu items
    if (menu.breakfast || menu.lunch || menu.snacks) {
      // Default empty strings for missing meals
      return {
        breakfast: menu.breakfast || "No breakfast service",
        lunch: menu.lunch || "No lunch service",
        snacks: menu.snacks || "No snacks service"
      };
    }

    return null;
  };

  const parseMenuItems = (menuString: string): string[] => {
    if (!menuString || menuString === "No breakfast service" ||
      menuString === "No lunch service" || menuString === "No snacks service") {
      return [];
    }
    // Split by comma and clean up each item
    return menuString.split(',').map(item => item.trim()).filter(item => item);
  };

  // Show location selection if no location is selected
  if (selectedLocation === null) {
    return (
      <DashboardCard title="Today's Menu" icon={UtensilsCrossed} hideHeader>
        <div className="flex flex-col items-center justify-center h-64 space-y-6">
          <p className="text-lg font-semibold text-foreground">Select Your Location</p>
          <div className="flex gap-4">
            <button
              onClick={() => setSelectedLocation(1)}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Bangalore
            </button>
            <button
              onClick={() => setSelectedLocation(2)}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Coimbatore
            </button>
          </div>
        </div>
      </DashboardCard>
    );
  }

  if (loading) {
    return (
      <DashboardCard title="Today's Menu" icon={UtensilsCrossed}>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
      </DashboardCard>
    );
  }

  if (error || !menuData) {
    const locationName = selectedLocation === 1 ? "Bangalore" : "Coimbatore";
    return (
      <DashboardCard title={`Today's Menu - ${locationName}`} icon={UtensilsCrossed}>
        <div className="flex flex-col items-center justify-center flex-1 h-full min-h-[256px] gap-3 p-6 text-center">
          <div className="w-12 h-12 rounded-full ring-1 ring-amber-500/20 bg-amber-500/10 flex items-center justify-center mb-2">
             <AlertCircle className="w-6 h-6 text-amber-500" />
          </div>
          <p className="text-sm text-foreground font-medium max-w-[280px]">{error || "Menu not available"}</p>
          {isRateLimited && (
            <p className="text-xs text-amber-500 font-medium tracking-wide">
              Available again in {formatCountdown(retryAfter)}...
            </p>
          )}
          <div className="flex gap-3 mt-2">
            <button
              onClick={() => fetchTodaysMenu(selectedLocation!)}
              disabled={isRateLimited}
              className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed w-32"
            >
              {isRateLimited ? "Paused" : "Try Again"}
            </button>
            <button
              onClick={() => {
                setSelectedLocation(null);
                setMenuData(null);
                setError(null);
              }}
              disabled={isRateLimited}
              className="px-4 py-2 bg-secondary/40 text-foreground rounded-lg hover:bg-secondary/80 transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Change Location
            </button>
          </div>
        </div>
      </DashboardCard>
    );
  }

  const locationName = selectedLocation === 1 ? "Bangalore" : "Coimbatore";

  return (
    <DashboardCard
      title={`Today's Menu - ${locationName}`}
      icon={UtensilsCrossed}
      action={
        <button
          onClick={() => {
            setSelectedLocation(null);
            setMenuData(null);
            setError(null);
          }}
          disabled={isRateLimited}
          className="text-xs text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Change Location
        </button>
      }
    >
      <div className="space-y-6 py-2">
        {/* Breakfast */}
        <div>
          <h4 className="text-[11px] font-bold text-muted-foreground tracking-wide mb-3">Breakfast (7:30 - 9:30 AM)</h4>
          <p className="text-sm font-medium text-foreground uppercase">
            {parseMenuItems(menuData.breakfast).length > 0 
              ? parseMenuItems(menuData.breakfast).join(", ") 
              : <span className="text-muted-foreground/60 lowercase">No breakfast menu available</span>}
          </p>
        </div>

        <hr className="border-border/50" />

        {/* Lunch */}
        <div>
          <h4 className="text-[11px] font-bold text-muted-foreground tracking-wide mb-3">Lunch (12:30 - 2:30 PM)</h4>
          <p className="text-sm font-medium text-foreground uppercase">
            {parseMenuItems(menuData.lunch).length > 0 
              ? parseMenuItems(menuData.lunch).join(", ") 
              : <span className="text-muted-foreground/60 lowercase">No lunch menu available</span>}
          </p>
        </div>

        <hr className="border-border/50" />

        {/* Snacks */}
        <div>
          <h4 className="text-[11px] font-bold text-muted-foreground tracking-wide mb-3">Snacks (4:00 - 6:00 PM)</h4>
          <p className="text-sm font-medium text-foreground uppercase">
            {parseMenuItems(menuData.snacks).length > 0 
              ? parseMenuItems(menuData.snacks).join(", ") 
              : <span className="text-muted-foreground/60 lowercase">No snacks menu available</span>}
          </p>
        </div>
      </div>
    </DashboardCard>
  );
};
