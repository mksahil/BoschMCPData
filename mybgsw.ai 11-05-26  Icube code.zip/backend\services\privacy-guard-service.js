const { createOpenAIClient, getChatModelName } = require('./openai-client');

const SENSITIVE_PATTERNS = [
  // Financial PII
  { pattern: /\b(?:\d[ -]*?){13,16}\b/, category: 'Financial PII', name: 'Credit/Debit Card Number' },
  { pattern: /\b(?:salary|pay|compensation)\s+(?:is|of|details|rs|inr|\$)\b/i, category: 'Financial PII', name: 'Salary Details' },
  // Identity PII
  { pattern: /\b[A-Z]{5}[0-9]{4}[A-Z]\b/i, category: 'Identity PII', name: 'PAN Number' },
  { pattern: /\b\d{4}\s\d{4}\s\d{4}\b/, category: 'Identity PII', name: 'Aadhaar Number' },
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/, category: 'Identity PII', name: 'SSN' },
  // Authentication
  { pattern: /\b(?:password|pwd|secret|api[_\-\s]?key|token)\s*[:=]\s*\S+/i, category: 'Authentication credentials', name: 'Password/Key' },
  // Health
  { pattern: /\b(?:diagnosis|prescription|disease|illness|medical condition)\b/i, category: 'Health / Medical information', name: 'Medical Term' }
];

/**
 * Layer 1: Pattern Matching
 * Checks if the query contains any explicit sensitive patterns.
 */
function containsSensitivePattern(query) {
  for (const item of SENSITIVE_PATTERNS) {
    if (item.pattern.test(query)) {
      return { isSensitive: true, category: item.category, reason: `Matched pattern: ${item.name}` };
    }
  }
  return { isSensitive: false };
}

/**
 * Layer 2: Semantic Analysis
 * Uses LLM to detect business-critical or complex sensitive disclosures.
 */
async function checkSemanticSensitivity(query) {
  try {
    const openai = createOpenAIClient();
    const model = getChatModelName();
    const prompt = `
You are a strict Data Protection and Privacy guard for an enterprise AI chat assistant.
Analyze the following user query and determine if it contains sensitive or confidential information that should NOT be submitted or processed.

Categories of sensitive information include:
1. Financial PII: credit cards, bank account numbers, salary details, financial statements.
2. Identity PII: Aadhaar, PAN, passport number, SSN, date of birth, personal address.
3. Authentication credentials: passwords, API keys, OAuth tokens, secrets.
4. Business-critical information: revenue/profit figures, M&A (Mergers and Acquisitions) activity, NDA-covered content, unreleased products, workforce restructuring plans, proprietary algorithms or source code.
5. Health / Medical information: diagnoses, prescriptions, medical conditions, health records.

Respond with ONLY a JSON object in this exact format:
{"isSensitive": true/false, "category": "category name if true or null", "reason": "brief reason if true"}

Ensure you detect free-text disclosures (e.g., "The Q3 revenue was 50 million" or "We are acquiring Company X").
`;

    const response = await openai.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: prompt },
        { role: 'user', content: query }
      ],
      response_format: { type: 'json_object' },
      temperature: 0,
      max_tokens: 150
    });
    
    if (response && response.choices && response.choices.length > 0) {
      const content = response.choices[0].message.content;
      return JSON.parse(content);
    }
    
    return { isSensitive: false };
  } catch (err) {
    console.error('[PrivacyGuard] LLM Semantic Check Error:', err.message);
    // Fail open if the LLM check errors out, to ensure the app remains functional
    return { isSensitive: false };
  }
}

/**
 * Layer 3: Out-of-Scope Detection
 * Uses LLM to decide if the user query is completely outside the
 * 6 supported services: Canteen, Entry/Exit Tracking, Travel, Seat Booking,
 * Community, and Company Banners/News.
 *
 * Returns:
 *   { isOutOfScope: boolean, reason: string, suggestedServices: string[] }
 */
async function checkIfOutOfScope(query) {
  try {
    const openai = createOpenAIClient();
    const model = getChatModelName();

    const prompt = `You are a strict scope-checker for an enterprise workplace AI assistant (MyBGSW AI) used by Bosch employees.

The assistant ONLY supports these 6 service areas:
1. Canteen / Cafeteria – cafeteria menu, food items, today's meals, snacks, beverages, meal timings.
2. Entry/Exit Time Tracking – employee attendance, entry/exit times, working hours, punch-in/out, overtime, swipe records, employee name lookup.
3. Travel – business travel plans, trip booking, flight/hotel, travel settlements, expense claims.
4. Seat Booking – desk/workspace reservation, office seat booking, cancel/modify seat bookings.
5. Community – Bosch/BGSW communities, clubs, groups, Associate Arena, joining communities.
6. Company Banners / News – company announcements, upcoming BGSW events, internal news, promotions, company highlights.

General greetings ("hi", "hello", "how are you"), help questions ("what can you do", "how do I use this"), and any follow-up questions about the above 6 services should be classified as IN-SCOPE.

Analyze the user query below and respond with ONLY a JSON object:
{ "isOutOfScope": true/false, "reason": "brief explanation", "suggestedServices": ["list of the above service names that ARE relevant, or empty array"] }

If the query is a greeting or a meta-question about the assistant itself, set isOutOfScope to false.
Only set isOutOfScope to true for queries that are clearly about topics completely unrelated to the 6 services above (e.g., booking movie tickets, weather, stock prices, coding help, recipes, etc.).`;

    const response = await openai.chat.completions.create({
      model: model,
      messages: [
        { role: 'system', content: prompt },
        { role: 'user', content: query }
      ],
      response_format: { type: 'json_object' },
      temperature: 0,
      max_tokens: 200
    });

    if (response && response.choices && response.choices.length > 0) {
      const content = response.choices[0].message.content;
      return JSON.parse(content);
    }

    return { isOutOfScope: false, reason: '', suggestedServices: [] };
  } catch (err) {
    console.error('[ScopeGuard] LLM Out-of-Scope Check Error:', err.message);
    // Fail open — assume in-scope if the LLM call errors
    return { isOutOfScope: false, reason: '', suggestedServices: [] };
  }
}

module.exports = {
  containsSensitivePattern,
  checkSemanticSensitivity,
  checkIfOutOfScope,
  SENSITIVE_PATTERNS
};
