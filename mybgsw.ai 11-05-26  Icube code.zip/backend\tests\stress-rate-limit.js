#!/usr/bin/env node
/**
 * Rate-Limit Stress Tester
 *
 * Hits every rate-limited API endpoint with rapid requests and confirms
 * that 429 responses are returned at the right threshold.
 *
 * Usage:
 *   node tests/stress-rate-limit.js [BASE_URL] [EMPLOYEE_NUMBER]
 *
 * Examples:
 *   node tests/stress-rate-limit.js
 *   node tests/stress-rate-limit.js http://localhost:3001 30945143
 *   node tests/stress-rate-limit.js https://my-bgsw-ai-dev.azurewebsites.net 30945143
 *
 * The script does NOT require a real Azure OpenAI key — routes return 429
 * before any downstream service is called when the limit is hit.
 */

const BASE_URL = process.argv[2] || 'http://localhost:3001';
const EMPLOYEE = process.argv[3] || 'TEST_EMPLOYEE_001';
const TOTAL_REQUESTS = 14; // fires 14 — limit is 10, so last 4 must be 429

// ─── colour helpers ──────────────────────────────────────────────────────────
const GREEN  = (s) => `\x1b[32m${s}\x1b[0m`;
const RED    = (s) => `\x1b[31m${s}\x1b[0m`;
const YELLOW = (s) => `\x1b[33m${s}\x1b[0m`;
const BOLD   = (s) => `\x1b[1m${s}\x1b[0m`;
const DIM    = (s) => `\x1b[2m${s}\x1b[0m`;

// ─── request helper ──────────────────────────────────────────────────────────
async function post(path, headers = {}, body = {}) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Employee-Number': EMPLOYEE,
      ...headers,
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) {}
  return { status: res.status, headers: Object.fromEntries(res.headers), json };
}

// ─── test runner ─────────────────────────────────────────────────────────────
async function testEndpoint({ name, path, body = { query: 'test', employeeNumber: EMPLOYEE }, extraHeaders = {}, isLogin = false }) {
  console.log(`\n${BOLD(`▶ ${name}`)}  ${DIM(path)}`);
  console.log(DIM(`  Firing ${TOTAL_REQUESTS} rapid requests...`));

  const results = [];
  for (let i = 1; i <= TOTAL_REQUESTS; i++) {
    const r = await post(path, extraHeaders, body);
    const marker = r.status === 429
      ? RED(`[${i}] 429 BLOCKED`)
      : r.status === 200 || r.status === 400 || r.status === 401 // 400/401 = downstream validation, not rate limit
      ? GREEN(`[${i}] ${r.status} OK`)
      : YELLOW(`[${i}] ${r.status}`);
    process.stdout.write(`  ${marker}  `);
    if (i % 5 === 0) process.stdout.write('\n');
    results.push(r);
  }
  if (TOTAL_REQUESTS % 5 !== 0) process.stdout.write('\n');

  const blocked = results.filter((r) => r.status === 429);
  const passed  = results.filter((r) => r.status !== 429);

  // First 429 should appear at or before request 11
  const first429 = results.findIndex((r) => r.status === 429) + 1;
  const limitHit = first429 > 0 && first429 <= 11;

  if (limitHit) {
    console.log(GREEN(`  ✓ Rate limit triggered at request #${first429} (${blocked.length} blocked)`));
  } else if (blocked.length === 0) {
    console.log(RED(`  ✗ No 429 received after ${TOTAL_REQUESTS} requests — rate limit NOT working`));
  }

  // Show the 429 response body from the first blocked response
  if (blocked.length > 0 && blocked[0].json) {
    const msg = blocked[0].json.error || JSON.stringify(blocked[0].json);
    console.log(DIM(`  Message: "${msg}"`));

    // Check Retry-After header
    const retryAfter = blocked[0].headers['retry-after'] || blocked[0].headers['ratelimit-reset'];
    if (retryAfter) {
      console.log(DIM(`  Retry-After: ${retryAfter}s`));
    } else {
      console.log(YELLOW(`  ⚠ No Retry-After header in 429 response`));
    }
  }

  return { name, limitHit, first429: first429 > 0 ? first429 : null, blocked: blocked.length, passed: passed.length };
}

// ─── employee isolation test ──────────────────────────────────────────────────
async function testEmployeeIsolation(path) {
  console.log(`\n${BOLD('▶ Employee isolation test')}  ${DIM(path)}`);
  console.log(DIM('  EMP_A exhausts limit, then EMP_B should still get 200...'));

  // Exhaust EMP_A
  const empA = 'ISO_EMP_A_' + Date.now();
  for (let i = 0; i < 11; i++) {
    await post(path, { 'X-Employee-Number': empA }, { query: 'test', employeeNumber: empA });
  }

  // EMP_B fresh request
  const empB = 'ISO_EMP_B_' + Date.now();
  const r = await post(path, { 'X-Employee-Number': empB }, { query: 'test', employeeNumber: empB });

  if (r.status !== 429) {
    console.log(GREEN(`  ✓ EMP_B got ${r.status} — counters are independent`));
    return true;
  } else {
    console.log(RED(`  ✗ EMP_B got 429 — counters may be shared (check keyGenerator)`));
    return false;
  }
}

// ─── main ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(BOLD('\n════════════════════════════════════════════'));
  console.log(BOLD('  Rate-Limit Stress Test'));
  console.log(BOLD('════════════════════════════════════════════'));
  console.log(`  Base URL : ${BASE_URL}`);
  console.log(`  Employee : ${EMPLOYEE}`);
  console.log(`  Requests : ${TOTAL_REQUESTS} per endpoint`);
  console.log(BOLD('════════════════════════════════════════════'));

  // Health check
  try {
    const r = await fetch(`${BASE_URL}/api/health`);
    if (!r.ok) throw new Error(`Health check returned ${r.status}`);
    console.log(GREEN('\n  ✓ Server is reachable'));
  } catch (e) {
    console.log(RED(`\n  ✗ Cannot reach ${BASE_URL} — is the server running?`));
    console.log(RED(`    ${e.message}`));
    process.exit(1);
  }

  const endpoints = [
    {
      name: 'Canteen Query (AI)',
      path: '/api/canteen/query',
      body: { query: 'What is on the menu today?', employeeNumber: EMPLOYEE },
    },
    {
      name: 'Entry/Exit Query (AI)',
      path: '/api/entryexit/query',
      body: { query: 'When did I check in today?', employeeNumber: EMPLOYEE },
    },
    {
      name: 'Chat (AI)',
      path: '/api/chat',
      body: { query: 'Hello', employeeNumber: EMPLOYEE, sessionId: 'stress-test' },
    },
    {
      name: 'Time Tracking Query (AI)',
      path: '/api/time-tracking/query',
      body: { query: 'How many hours did I work today?', employeeNumber: EMPLOYEE },
    },
    {
      name: 'Auth Login (brute-force protection)',
      path: '/api/auth/login',
      body: { username: 'testuser', password: 'wrongpassword' },
      isLogin: true,
    },
  ];

  const summary = [];
  for (const ep of endpoints) {
    const result = await testEndpoint(ep);
    summary.push(result);
    // Small pause between endpoint groups so limits don't bleed across
    await new Promise((r) => setTimeout(r, 100));
  }

  // Employee isolation test on /api/chat
  const isolated = await testEmployeeIsolation('/api/chat');

  // ─── summary ──────────────────────────────────────────────────────────────
  console.log(`\n${BOLD('════════════════════════════════════════════')}`);
  console.log(BOLD('  SUMMARY'));
  console.log(BOLD('════════════════════════════════════════════'));

  let allPassed = true;
  for (const r of summary) {
    const icon = r.limitHit ? GREEN('✓') : RED('✗');
    const detail = r.limitHit
      ? `triggered at req #${r.first429}, ${r.blocked} blocked`
      : 'RATE LIMIT NOT TRIGGERED';
    console.log(`  ${icon}  ${r.name.padEnd(36)} ${detail}`);
    if (!r.limitHit) allPassed = false;
  }

  const isoIcon = isolated ? GREEN('✓') : RED('✗');
  console.log(`  ${isoIcon}  ${'Employee isolation'.padEnd(36)} ${isolated ? 'counters independent' : 'COUNTERS SHARED — BUG'}`);
  if (!isolated) allPassed = false;

  console.log(BOLD('════════════════════════════════════════════'));
  if (allPassed) {
    console.log(GREEN(BOLD('  ALL CHECKS PASSED — rate limiting is working correctly')));
  } else {
    console.log(RED(BOLD('  SOME CHECKS FAILED — review output above')));
    process.exitCode = 1;
  }
  console.log('');
}

main().catch((e) => {
  console.error(RED(`\nFatal: ${e.message}`));
  process.exit(1);
});
