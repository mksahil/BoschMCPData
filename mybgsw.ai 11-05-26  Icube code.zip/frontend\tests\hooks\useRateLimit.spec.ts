/**
 * useRateLimit — unit tests
 *
 * Coverage targets:
 *   ✓ Initial state — not limited, zero countdown
 *   ✓ handleRateLimitResponse sets isRateLimited and reads Retry-After header
 *   ✓ Countdown decrements each second
 *   ✓ isRateLimited resets to false after window expires
 *   ✓ Calling handleRateLimitResponse a second time resets the existing timer
 *   ✓ retryAfter clamps to 0 and never goes negative
 */

import { renderHook, act } from '@testing-library/react';
import { useRateLimit } from '@/hooks/useRateLimit';

// Build a minimal Response-like object that matches the hook's expectations
function make429Response(retryAfterSecs: number) {
  const headers = new Headers({ 'Retry-After': String(retryAfterSecs) });
  return {
    headers,
    status: 429,
  } as unknown as Response;
}

describe('useRateLimit', () => {
  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date());
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('starts not rate-limited with zero retryAfter', () => {
    const { result } = renderHook(() => useRateLimit());

    expect(result.current.isRateLimited).toBeFalse();
    expect(result.current.retryAfter).toBe(0);
    expect(result.current.rateLimitMessage).toBe('');
  });

  it('sets isRateLimited true after handleRateLimitResponse', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(60), {
        error: 'Too many requests',
      });
    });

    expect(result.current.isRateLimited).toBeTrue();
  });

  it('sets retryAfter from the Retry-After header', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(45), {});
    });

    expect(result.current.retryAfter).toBe(45);
  });

  it('uses the error field from the response body as rateLimitMessage', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(60), {
        error: 'Custom rate limit message',
      });
    });

    expect(result.current.rateLimitMessage).toBe('Custom rate limit message');
  });

  it('falls back to a default message when data.error is absent', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(60), {});
    });

    expect(result.current.rateLimitMessage.length).toBeGreaterThan(0);
  });

  it('decrements retryAfter every second', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(10), {});
    });

    expect(result.current.retryAfter).toBe(10);

    act(() => { jasmine.clock().tick(3000); });

    expect(result.current.retryAfter).toBe(7);
  });

  it('clears isRateLimited after the window expires', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(5), {});
    });

    expect(result.current.isRateLimited).toBeTrue();

    act(() => { jasmine.clock().tick(5001); });

    expect(result.current.isRateLimited).toBeFalse();
    expect(result.current.retryAfter).toBe(0);
    expect(result.current.rateLimitMessage).toBe('');
  });

  it('resets countdown correctly when called a second time', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(60), {});
    });

    act(() => { jasmine.clock().tick(30000); });
    expect(result.current.retryAfter).toBe(30);

    // Second 429 with fresh window
    act(() => {
      result.current.handleRateLimitResponse(make429Response(60), {
        error: 'Still limited',
      });
    });

    // Should reset to full 60, not continue from 30
    expect(result.current.retryAfter).toBe(60);
  });

  it('retryAfter never drops below zero', () => {
    const { result } = renderHook(() => useRateLimit());

    act(() => {
      result.current.handleRateLimitResponse(make429Response(2), {});
    });

    act(() => { jasmine.clock().tick(10000); }); // tick well past the window

    expect(result.current.retryAfter).toBeGreaterThanOrEqual(0);
  });

  it('falls back to 60 s when Retry-After header is missing', () => {
    const { result } = renderHook(() => useRateLimit());

    const responseWithNoHeader = {
      headers: new Headers(), // no Retry-After
      status: 429,
    } as unknown as Response;

    act(() => {
      result.current.handleRateLimitResponse(responseWithNoHeader, {});
    });

    expect(result.current.retryAfter).toBe(60);
  });
});
