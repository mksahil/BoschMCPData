const travelService = require('./services/travel-service');
const boschAuthService = require('./services/bosch-auth-service');

async function testSplitPrompt() {
    const sessionId = 'test-split-' + Date.now();
    const employeeNumber = '35580530';
    const context = {
        sessionId,
        employeeNumber,
        userName: 'Manjunath',
        jwtToken: 'mock-token'
    };

    console.log('\n=== STEP 1: Incomplete Booking (Pune to Delhi) ===');
    const res1 = await travelService.processQuery('Book a trip from Pune to Delhi', context);
    console.log('Response:', res1.response);
    console.log('Current State:', JSON.stringify(res1.travelState, null, 2));

    console.log('\n=== STEP 2: Split Prompt (book a ticket) ===');
    // Simulate the next turn with the same sessionId (which holds the state)
    const res2 = await travelService.processQuery('book a ticket', context);
    console.log('Response:', res2.response);
    console.log('New State (Should be reset):', JSON.stringify(res2.travelState, null, 2));

    if (res2.travelState.from === null && res2.travelState.to === null) {
        console.log('\n✅ SUCCESS: Travel state was correctly reset by the split prompt!');
    } else {
        console.log('\n❌ FAILURE: Travel state persisted despite the new "book a ticket" intent.');
    }
}

// Mocking dependencies if necessary
// travelService uses openai which needs an API key
if (!process.env.OPENAI_API_KEY) {
    console.error('ERROR: OPENAI_API_KEY is required to run this test.');
    process.exit(1);
}

testSplitPrompt().catch(err => {
    console.error('Test error:', err);
});
