/**
 * Bosch Arena Authentication Service
 * Handles OAuth login, JWT token generation, and token validation
 */

const axios = require('axios');
const https = require('https');

// Disable SSL verification for Bosch APIs
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

/**
 * Normalize an OAuth/access token passed from callers. The Express layer
 * forwards the full `Authorization` header verbatim (e.g. "Bearer eyJ..."),
 * but the Bosch `/Token/GenrateTokenDetails` endpoint expects the RAW token
 * to be prefixed with exactly one "Bearer ". Without this helper we end up
 * sending "Authorization: Bearer Bearer eyJ..." which is rejected with 401
 * "Invalid token.Authorization has been denied for this request." — the
 * symptom that broke travel booking in production.
 */
function normalizeOAuthToken(token) {
  if (!token || typeof token !== 'string') return token;
  let t = token.trim();
  // Strip any number of leading "Bearer " prefixes (case-insensitive) so
  // "Bearer Bearer xyz" and "bearer xyz" both collapse to just "xyz".
  while (/^bearer\s+/i.test(t)) {
    t = t.replace(/^bearer\s+/i, '').trim();
  }
  return t;
}

class BoschAuthService {
  constructor() {
    this.baseUrl = 'https://dev.boschassociatearena.com/api';

    // ── Per-service Bosch clientIDs ───────────────────────────────────────────
    // Each A2A agent's ValidateToken API is configured for a specific Bosch
    // clientID.  JWTs minted with the wrong clientID carry the wrong `aud`
    // claim and are always rejected by the target agent.
    //
    // BOSCH_CLIENT_ID_MyBGSWAI  — Entry/Exit MCP, Canteen, Community, and
    //                             any service that uses the main app's clientID.
    // BOSCH_CLIENT_ID_TRAVEL    — Travel A2A agent.
    // BOSCH_CLIENT_ID_SEAT      — Seat Booking A2A agent.
    //
    // Legacy fallback: if the new named vars are absent, BOSCH_CLIENT_ID is
    // used (keeps backward compatibility with existing deployments).
    this.clientId        = process.env.BOSCH_CLIENT_ID_MyBGSWAI || process.env.BOSCH_CLIENT_ID || 'B016D893-E688-46CE-B353-2151C1274C83';
    this.clientIdTravel  = process.env.BOSCH_CLIENT_ID_TRAVEL    || process.env.BOSCH_CLIENT_ID || 'BE3B36B4-ED49-490E-94BB-7F34E86499BF';
    this.clientIdSeat    = process.env.BOSCH_CLIENT_ID_SEAT      || process.env.BOSCH_CLIENT_ID || 'CD3054C5-6D98-47E9-BF73-43F26E8ED476';

    // Cache for SERVICE ACCOUNT tokens (fallback)
    this.tokenCache = {
      oauthToken: null,
      jwtToken: null,
      expiresAt: null
    };

    // Cache for USER tokens — keyed by "<employeeNumber>:<service>" so that
    // different services (travel, seatbooking, default) never share a JWT that
    // was minted for a different Bosch clientID.
    this.userTokenCache = new Map();

    // Token refresh buffer (refresh 5 minutes before expiry)
    this.refreshBuffer = 5 * 60 * 1000;

    // Session ID cache — same composite key as userTokenCache.
    this.userSessionCache = new Map();
  }

  /**
   * Return the Bosch clientID for the given service name.
   *
   * travel and seatbooking each have their own dedicated A2A-agent clientID.
   * entryexit, canteen, and community all share the MyBGSWAI clientID but are
   * given SEPARATE storeUserTokens calls so they each receive an independent
   * SessionId from /Token/GenrateTokenDetails.  This prevents session conflicts
   * when the user switches context between those three services mid-conversation.
   *
   * @param {'travel'|'seatbooking'|'entryexit'|'canteen'|'community'|'default'} service
   */
  getClientIdForService(service = 'default') {
    switch (service) {
      case 'travel':      return this.clientIdTravel;
      case 'seatbooking': return this.clientIdSeat;
      // entryexit, canteen, community all use the same Bosch clientID but get
      // their own independent SessionId (separate /Token/GenrateTokenDetails call).
      case 'entryexit':
      case 'canteen':
      case 'community':
      default:            return this.clientId;
    }
  }

  /**
   * Composite cache key: "<employeeNumber>:<service>".
   * Prevents a JWT minted for one service from being returned when a different
   * service checks the same employee's cache entry.
   */
  _cacheKey(employeeNumber, service = 'default') {
    return `${employeeNumber}:${service}`;
  }

  /**
   * Helper: Get encrypted password before login
   */
  async getEncryptedPassword(username, plainPassword) {
    try {
      console.log(`[BoschAuth] Encrypting password for user: ${username}`);
      const response = await axios.post(
        `${this.baseUrl}/ManageUser/GetEncryptedPassword`,
        {
          "EmailId": username,
          "Password": plainPassword
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' // Required header even if empty
          },
          httpsAgent,
          timeout: 10000
        }
      );

      if (response.data && response.data.IsSuccess && response.data.ResponseData && response.data.ResponseData.length > 0) {
        return response.data.ResponseData[0].Password;
      }

      throw new Error('Failed to get encrypted password from response');
    } catch (error) {
      console.error('[BoschAuth] Password encryption error:', error.message);
      throw error;
    }
  }

  /**
   * Step 1: Login to get OAuth Bearer token
   * @param {string} username - User ID
   * @param {string} password - Plain text or pre-encrypted password
   * @param {string} deviceToken - Device token
   * @param {boolean} isPreEncrypted - If true, skip encryption (password is already encrypted)
   */
  async login(username, password, deviceToken, isPreEncrypted = false) {
    try {
      console.log(`[BoschAuth] Logging in user: ${username}`);

      let encryptedPassword;
      if (isPreEncrypted) {
        console.log('[BoschAuth] Using pre-encrypted password');
        encryptedPassword = password;
      } else {
        // Encrypt the password first
        encryptedPassword = await this.getEncryptedPassword(username, password);
        console.log('[BoschAuth] Password encrypted successfully');
      }

      const loginData = [
        'grant_type=password',
        `username=${username}`,
        `password=${encodeURIComponent(encryptedPassword)}`,
        // [FIX #8 | Issue #9 - Hardcoded Secret]: Device token must come from env only — never hardcoded.
        `DeviceToken=${deviceToken || process.env.BOSCH_DEVICE_TOKEN}`,
        'IsIOS=true',
        'IsAndroid=false',
        'RequestSource=App'
      ].join('&');

      const response = await axios.post(
        `${this.baseUrl}/ManageUser/Login`,
        loginData,
        {
          headers: {
            'Content-Type': 'text/plain'
          },
          httpsAgent,
          timeout: 30000
        }
      );

      console.log('[BoschAuth] Login successful');
      console.log('[BoschAuth] OAuth Token (first 50 chars):', response.data?.access_token?.substring(0, 50) + '...');
      console.log('[BoschAuth] Session Id:', response.data);
      console.log('[BoschAuth] Token Type:', response.data?.token_type);
      console.log('[BoschAuth] Expires In:', response.data?.expires_in, 'seconds');
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] Login error:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  /**
   * Step 2: Generate JWT token using OAuth token
   * @param {string}  oauthToken     - Raw OAuth bearer token (with or without "Bearer " prefix)
   * @param {string?} employeeNumber - Employee number to embed in the token request
   * @param {string?} clientId       - Bosch clientID to use; defaults to this.clientId (MyBGSWAI)
   */
  async generateJWTToken(oauthToken, employeeNumber = null, clientId = null) {
    try {
      // Strip any leading "Bearer " prefix(es) — callers often pass the raw
      // Authorization header value from Express, so we'd otherwise produce
      // "Bearer Bearer xyz" and get a 401 back from Bosch.
      oauthToken = normalizeOAuthToken(oauthToken);

      console.log(`[BoschAuth] Generating JWT token${employeeNumber ? ' for employee: ' + employeeNumber : ''}...`);

      const params = {
        clientID: clientId || this.clientId
      };

      // If an employee number is provided, pass it to the endpoint.
      // We send multiple casing variations to be safe against API contract mismatches,
      // as it was previously returning a default "Votan" JWT.
      if (employeeNumber) {
        params.employeeNumber = employeeNumber;
        params.EmployeeNumber = employeeNumber;
        params.employeeId = employeeNumber;
        params.EmployeeId = employeeNumber;
        params.empId = employeeNumber;
        params.userId = employeeNumber;
      }

      const headers = {
        'Authorization': `Bearer ${oauthToken}`
      };

      if (employeeNumber) {
        headers['userid'] = employeeNumber;
        headers['employeeid'] = employeeNumber;
        headers['x-employee-number'] = employeeNumber;
      }

      const response = await axios.post(
        `${this.baseUrl}/Token/GenrateTokenDetails`,
        null,         // POST body is empty — API reads params from query string
        {
          params,     // serialised as ?clientID=...&employeeNumber=... in the URL
          headers,    // Authorization header
          httpsAgent, // SSL bypass — must be in config, NOT in the body
          timeout: 30000
        }
      );

      console.log('[BoschAuth] JWT token generated successfully', response.data);
      const token = response.data?.ResponseData?.Token || response.data?.token || response.data;
      console.log('[BoschAuth] JWT Token Structure:', Object.keys(response.data || {}));
      console.log('[BoschAuth] JWT Token (first 50 chars):', typeof token === 'string' ? token.substring(0, 50) + '...' : 'Not a string');
      console.log('[BoschAuth] Full JWT Response:', JSON.stringify(response.data).substring(0, 200));
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] JWT generation error:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  /**
   * Step 3: Validate JWT token
   */
  async validateToken(jwtToken) {
    try {
      console.log('[BoschAuth] Validating JWT token...');

      const response = await axios.get(
        `${this.baseUrl}/Token/ValidateToken`,
        {
          headers: {
            'Authorization': `Bearer ${jwtToken}`,
            'clientid': this.clientId
          },
          httpsAgent,
          timeout: 30000
        }
      );

      console.log('[BoschAuth] Token validated successfully');
      return response.data;
    } catch (error) {
      console.error('[BoschAuth] Token validation error:', error.message);
      return { valid: false, error: error.message };
    }
  }

  /**
   * Get a valid JWT token (with caching and auto-refresh)
   * Uses service account credentials from environment
   */
  async getServiceToken() {
    try {
      // Check if cached token is still valid
      if (this.tokenCache.jwtToken && this.tokenCache.expiresAt) {
        const now = Date.now();
        if (now < this.tokenCache.expiresAt - this.refreshBuffer) {
          console.log('[BoschAuth] Using cached JWT token');
          console.log('[BoschAuth] Cached Token (first 50 chars):', this.tokenCache.jwtToken?.substring(0, 50) + '...');
          console.log('[BoschAuth] Cache Expires At:', new Date(this.tokenCache.expiresAt).toISOString());
          return this.tokenCache.jwtToken;
        }
      }

      // Get service account credentials from env
      const username = process.env.BOSCH_SERVICE_USERNAME;
      const password = process.env.BOSCH_SERVICE_PASSWORD;
      // Check if password is pre-encrypted (set in .env)
      const isPreEncrypted = process.env.BOSCH_SERVICE_PASSWORD_ENCRYPTED === 'true';

      if (!username || !password) {
        throw new Error('Service account credentials not configured');
      }

      // Step 1: Login to get OAuth token (pass isPreEncrypted flag)
      const loginResponse = await this.login(username, password, null, isPreEncrypted);
      const oauthToken = loginResponse.access_token || loginResponse;

      // Step 2: Generate JWT token
      const jwtResponse = await this.generateJWTToken(oauthToken);
      // Extract token from ResponseData.Token structure
      const jwtToken = jwtResponse?.ResponseData?.Token || jwtResponse?.token || jwtResponse;

      // Cache the token (expires in ~30 days based on the example, but we'll refresh daily)
      this.tokenCache.jwtToken = jwtToken;
      this.tokenCache.oauthToken = oauthToken;
      this.tokenCache.expiresAt = Date.now() + (24 * 60 * 60 * 1000); // 24 hours

      console.log('[BoschAuth] New JWT token obtained and cached');
      console.log('[BoschAuth] Final JWT Token (first 80 chars):', typeof jwtToken === 'string' ? jwtToken.substring(0, 80) + '...' : 'Token is not a string: ' + typeof jwtToken);
      console.log('[BoschAuth] Token Cache Expires At:', new Date(this.tokenCache.expiresAt).toISOString());
      return jwtToken;
    } catch (error) {
      console.error('[BoschAuth] Failed to get service token:', error.message);
      throw error;
    }
  }

  /**
   * Store user tokens after successful login.
   * Mints a JWT using the Bosch clientID that corresponds to `service` so the
   * resulting token is accepted by that service's ValidateToken API.
   *
   * @param {string}  employeeNumber
   * @param {string}  oauthToken  - Raw OAuth bearer (with or without "Bearer " prefix)
   * @param {number?} expiresIn   - Token lifetime in seconds (default 24 h)
   * @param {'travel'|'seatbooking'|'default'} service - Which service this JWT is for
   */
  async storeUserTokens(employeeNumber, oauthToken, expiresIn, service = 'default') {
    try {
      // Normalize the token so the cached value never contains a stray
      // "Bearer " prefix — this keeps cache comparisons (in getUserTokens)
      // consistent regardless of how callers passed the token in.
      oauthToken = normalizeOAuthToken(oauthToken);

      const clientId   = this.getClientIdForService(service);
      const cacheKey   = this._cacheKey(employeeNumber, service);

      console.log(`[BoschAuth] Storing tokens for user: ${employeeNumber} (service: ${service}, clientId: ${clientId})`);

      // Generate JWT token from OAuth token, passing the identity so the minting
      // endpoint doesn't fall back to a default account (like "Votan").
      const jwtResponse = await this.generateJWTToken(oauthToken, employeeNumber, clientId);
      const jwtToken = jwtResponse?.ResponseData?.Token || jwtResponse?.token || jwtResponse;

      // Extract agent-generated SessionId from /Token/GenrateTokenDetails response.
      // This ID is validated by the A2A agentic layer (Travel, Seat Booking) and
      // MUST come from the Bosch API — a self-generated UUID will be rejected.
      const agentSessionId = jwtResponse?.ResponseData?.SessionId ?? null;
      console.log(`[BoschAuth] Agent SessionId from /Token/GenrateTokenDetails: ${agentSessionId}`);

      if (!agentSessionId) {
        // ⚠️  Critical: the agentic layer will reject requests without a valid SessionId.
        // Possible causes: JWT endpoint returned null, API contract change, or auth failure.
        console.error(
          `[BoschAuth] ⚠️  NULL SessionId for employee ${employeeNumber}. ` +
          'ResponseData from /Token/GenrateTokenDetails:',
          JSON.stringify(jwtResponse?.ResponseData ?? {})
        );
        console.error(
          '[BoschAuth] AI services (Travel, Seat Booking) will NOT work for this session. ' +
          'Check the /Token/GenrateTokenDetails endpoint and ensure it returns a valid SessionId.'
        );
      }

      // The JWT token and SessionId returned together by /Token/GenrateTokenDetails
      // are a validated pair — the A2A agentic layer validates the JWT *against*
      // the specific SessionId that was issued with it.  Reusing an old cached
      // SessionId with a freshly-minted JWT will cause "token validation failed"
      // once the original A2A session expires on the server side.
      // Always update the session cache so JWT + SessionId stay in sync.
      let sessionId;
      if (agentSessionId) {
        sessionId = agentSessionId;
        this.userSessionCache.set(cacheKey, agentSessionId);
        console.log(`[BoschAuth] Updated session ID for ${employeeNumber} (${service}): ${agentSessionId}`);
      } else {
        // API returned no SessionId — preserve whatever is cached to avoid
        // breaking existing sessions, but warn loudly: A2A calls will fail.
        sessionId = this.userSessionCache.get(cacheKey) || null;
        console.warn(`[BoschAuth] No SessionId in /Token/GenrateTokenDetails response for ${employeeNumber} (${service}). Using cached: ${sessionId}`);
      }

      // Calculate expiration (default to 24 hours if not provided)
      const expiresAt = Date.now() + ((expiresIn || 86400) * 1000);

      // Store in user cache under the composite key
      this.userTokenCache.set(cacheKey, {
        oauthToken,
        jwtToken,
        sessionId,
        expiresAt
      });

      console.log(`[BoschAuth] Tokens stored for user ${employeeNumber}`);
      console.log(`[BoschAuth] JWT Token (first 50 chars): ${jwtToken?.substring(0, 50)}...`);
      // console.log(`[BoschAuth] Session ID: ${sessionId}`);
      console.log(`[BoschAuth] Expires at: ${new Date(expiresAt).toISOString()}`);

      return { jwtToken, sessionId, expiresAt };
    } catch (error) {
      console.error(`[BoschAuth] Failed to store tokens for ${employeeNumber}:`, error.message);
      throw error;
    }
  }

  /**
   * Get cached tokens for a specific user + service combination.
   * Returns null if not found, expired, or if an OAuth token is provided that
   * does not match the one stored in cache.  This guards against an attacker
   * supplying only an employee number and relying on stale cached credentials.
   *
   * @param {string}  employeeNumber
   * @param {string?} userOAuthToken  - optional bearer token from the client
   * @param {'travel'|'seatbooking'|'default'} service
   */
  getUserTokens(employeeNumber, userOAuthToken = null, service = 'default') {
    // Normalize so the comparison isn't thrown off by a stray "Bearer "
    // prefix on one side and not the other.
    const normalizedProvided = normalizeOAuthToken(userOAuthToken);
    const cacheKey = this._cacheKey(employeeNumber, service);

    const cached = this.userTokenCache.get(cacheKey);
    if (!cached) {
      console.log(`[BoschAuth] No cached tokens for user: ${employeeNumber} (service: ${service})`);
      return null;
    }

    // If an OAuth token is provided ensure it matches the one in cache
    if (normalizedProvided && cached.oauthToken && normalizedProvided !== cached.oauthToken) {
      console.log(`[BoschAuth] Cached OAuth token mismatch for user: ${employeeNumber} (service: ${service})`);
      console.log(`[BoschAuth] Provided: ${normalizedProvided.substring(0, 20)}...`);
      console.log(`[BoschAuth] Cached:   ${cached.oauthToken.substring(0, 20)}...`);
      return null;
    }

    // Check if expired
    if (Date.now() > cached.expiresAt - this.refreshBuffer) {
      console.log(`[BoschAuth] Cached tokens expired for user: ${employeeNumber} (service: ${service})`);
      this.userTokenCache.delete(cacheKey);
      return null;
    }

    console.log(`[BoschAuth] Using cached tokens for user: ${employeeNumber} (service: ${service})`);
    return cached;
  }

  /**
   * Get or create session ID for a user (persists across requests).
   * Scoped to the service so travel and seat-booking sessions don't collide.
   * @param {'travel'|'seatbooking'|'default'} service
   */
  getOrCreateSessionId(employeeNumber, service = 'default') {
    const cacheKey = this._cacheKey(employeeNumber, service);
    let sessionId = this.userSessionCache.get(cacheKey);
    if (!sessionId) {
      const crypto = require('crypto');
      sessionId = crypto.randomUUID();
      this.userSessionCache.set(cacheKey, sessionId);
    }
    return sessionId;
  }

  /**
   * Get token for a specific user (after they log in).
   * First checks the service-scoped cache, then mints fresh tokens if needed.
   *
   * @param {string}  employeeNumber
   * @param {string}  userOAuthToken
   * @param {'travel'|'seatbooking'|'default'} service
   */
  async getTokenForUser(employeeNumber, userOAuthToken, service = 'default') {
    try {
      // Normalize once at the boundary so every downstream check/store uses
      // the raw token without any "Bearer " prefix.
      const normalizedOAuthToken = normalizeOAuthToken(userOAuthToken);

      // First check the service-scoped cache
      const cached = this.getUserTokens(employeeNumber, normalizedOAuthToken, service);
      if (cached) {
        return {
          jwtToken: cached.jwtToken,
          sessionId: cached.sessionId
        };
      }

      // If we fall through and an OAuth token was supplied, mint fresh tokens
      // using the clientID for this service.
      if (normalizedOAuthToken) {
        const result = await this.storeUserTokens(employeeNumber, normalizedOAuthToken, undefined, service);
        return {
          jwtToken: result.jwtToken,
          sessionId: result.sessionId
        };
      }

      throw new Error('No cached tokens and no OAuth token provided');
    } catch (error) {
      console.error('[BoschAuth] Failed to get user token:', error.message);
      throw error;
    }
  }

  /**
   * Generate JWT tokens for ALL three services in parallel at login time.
   * Returns a serviceTokens object that the frontend stores in sessionStorage
   * and sends with every chat request.  The backend then uses these directly
   * instead of performing per-request cache lookups or Bosch API round-trips.
   *
   * Shape returned:
   * {
   *   default:     { jwt: string, sessionId: string },
   *   travel:      { jwt: string, sessionId: string },
   *   seatbooking: { jwt: string, sessionId: string }
   * }
   *
   * Individual service failures return null for that slot — the backend will
   * fall back to the server-side cache / service account token for that case.
   *
   * @param {string}  employeeNumber
   * @param {string}  oauthToken  - Raw OAuth bearer (with or without "Bearer " prefix)
   * @param {number?} expiresIn   - Token lifetime in seconds (default 24 h)
   */
  async generateAllServiceTokens(employeeNumber, oauthToken, expiresIn) {
    const normalizedToken = normalizeOAuthToken(oauthToken);

    // Five independent service slots:
    //   travel      — dedicated Bosch clientID (BOSCH_CLIENT_ID_TRAVEL)
    //   seatbooking — dedicated Bosch clientID (BOSCH_CLIENT_ID_SEAT)
    //   entryexit   — MyBGSWAI clientID, own SessionId
    //   canteen     — MyBGSWAI clientID, own SessionId
    //   community   — MyBGSWAI clientID, own SessionId
    //
    // entryexit/canteen/community share the same Bosch clientID but each gets a
    // separate /Token/GenrateTokenDetails call, so they receive DIFFERENT SessionIds.
    // This prevents session conflicts when the user switches between these services.
    const services = ['travel', 'seatbooking', 'entryexit', 'canteen', 'community'];

    console.log(`[BoschAuth] Generating tokens for all 5 services for user: ${employeeNumber}`);

    const results = await Promise.allSettled(
      services.map(svc => this.storeUserTokens(employeeNumber, normalizedToken, expiresIn, svc))
    );

    const serviceTokens = {};
    services.forEach((svc, idx) => {
      const outcome = results[idx];
      if (outcome.status === 'fulfilled' && outcome.value) {
        serviceTokens[svc] = {
          jwt:       outcome.value.jwtToken,
          sessionId: outcome.value.sessionId
        };
        console.log(`[BoschAuth] ✅ Token ready for service: ${svc} (sessionId: ${outcome.value.sessionId})`);
      } else {
        serviceTokens[svc] = null;
        const reason = outcome.reason?.message || 'unknown error';
        console.error(`[BoschAuth] ❌ Failed to generate token for service: ${svc} — ${reason}`);
      }
    });

    return serviceTokens;
  }

  /**
   * Generate session ID for API calls (DEPRECATED - use getOrCreateSessionId instead)
   * Format: UUID (required by Travel API)
   */
  generateSessionId(employeeNumber) {
    // Use persistent session ID instead of generating new ones
    return this.getOrCreateSessionId(employeeNumber);
  }

  /**
   * Generate session ID in legacy format (for services that need it)
   * Format: user_<employeeNumber>_<timestamp>
   */
  generateLegacySessionId(employeeNumber) {
    const timestamp = Date.now();
    return `user_${employeeNumber}_${timestamp} `;
  }

  /**
   * Clear user tokens (on logout).
   * Clears all service-scoped entries for the employee (full logout).
   */
  clearUserTokens(employeeNumber) {
    const services = ['default', 'travel', 'seatbooking'];
    for (const svc of services) {
      this.userTokenCache.delete(this._cacheKey(employeeNumber, svc));
    }
    console.log(`[BoschAuth] Cleared tokens for user: ${employeeNumber} (all services)`);
  }

  /**
   * Clear BOTH the token cache AND the session ID cache for a user + service.
   * Call this when the A2A layer rejects the session ("token validation failed")
   * so the next request fetches a completely fresh JWT + SessionId pair for
   * the correct service clientID.
   *
   * @param {'travel'|'seatbooking'|'default'} service
   */
  clearUserSession(employeeNumber, service = 'default') {
    const cacheKey = this._cacheKey(employeeNumber, service);
    this.userTokenCache.delete(cacheKey);
    this.userSessionCache.delete(cacheKey);
    console.log(`[BoschAuth] Cleared all cached tokens and session for user: ${employeeNumber} (service: ${service})`);
  }
}

// Export singleton instance
module.exports = new BoschAuthService();
