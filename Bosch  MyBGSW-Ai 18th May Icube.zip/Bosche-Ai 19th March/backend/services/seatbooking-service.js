/**
 * Seat Booking Service
 * Calls the Seat Booking MCP Server (A2A Agent) for desk/workspace reservations
 * Uses A2A Protocol (Google Agent-to-Agent) - JSON-RPC 2.0
 */

const axios = require('axios');
const https = require('https');
const boschAuthService = require('./bosch-auth-service');
const configService = require('./config-service');
const conversationContextService = require('./conversation-context-service');
const { createOpenAIClient, getChatModelName } = require('./openai-client');

// Bosch internal MCP servers use corporate PKI (Bosch root CA) not trusted by Node.js by default.
// rejectUnauthorized: false is intentional for internal-network services — not a public-internet risk.
const httpsAgent = new https.Agent({
  rejectUnauthorized: false // [INTERNAL-CA] Bosch corporate PKI — system CA not available to Node.js
});

class SeatBookingService {
  constructor() {
    // A2A Host Agent URL (Seat Booking Agent)
    this.apiUrl = process.env.SEATBOOKING_API_URL || 'https://host-agent-seat-booking-mcp.wonderfulstone-71ba5e8f.southindia.azurecontainerapps.io';
    this.agentCardPath = '/.well-known/agent.json';

    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.agentCard = null;
    this._openai = null;
  }

  get openai() {
    if (!this._openai) {
      this._openai = createOpenAIClient();
    }
    return this._openai;
  }

  /**
   * Fetch the agent card from the Seat Booking A2A agent
   */
  async getAgentCard() {
    if (this.agentCard) {
      return this.agentCard;
    }

    try {
      console.log(`[SeatBooking] Fetching agent card from: ${this.apiUrl}${this.agentCardPath}`);
      const response = await axios.get(
        `${this.apiUrl}${this.agentCardPath}`,
        { httpsAgent, timeout: 30000 }
      );
      this.agentCard = response.data;
      console.log('[SeatBooking] Agent card fetched successfully:', this.agentCard.name);
      return this.agentCard;
    } catch (error) {
      console.error('[SeatBooking] Failed to fetch agent card:', error.message);
      return null;
    }
  }

  /**
   * Helper: Decode JWT token without external dependencies
   */
  decodeJWT(token) {
    try {
      if (!token || typeof token !== 'string') return null;
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
      return payload;
    } catch (e) {
      console.error('[SeatBooking] JWT Decode Error:', e.message);
      return null;
    }
  }

  /**
   * Call the Seat Booking A2A Agent using proper A2A protocol
   * Based on the working sba2aclient.py implementation
   */
  async callSeatBookingAPI(message, employeeNumber, userOAuthToken, files = [], explicitJwtToken = null, explicitSessionId = null, userName = null, agentSessionId = null) {
    try {
      console.log(`[SeatBooking] Calling A2A Seat Booking Agent at: ${this.apiUrl}`);

      let jwtToken = explicitJwtToken;
      let sessionId = explicitSessionId;
      let effectiveEmpNo = employeeNumber;
      let effectiveName = userName;

      // Strategy 1: Use explicit tokens if provided (passed from login context)
      if (jwtToken && sessionId) {
        console.log('[SeatBooking] Using EXPLICIT user tokens (passed from caller)');
      }

      // Strategy 2: Use cached tokens (seat-booking-scoped cache)
      if (!jwtToken && userOAuthToken) {
        const cachedTokens = boschAuthService.getUserTokens(employeeNumber, userOAuthToken, 'seatbooking');
        if (cachedTokens) {
          jwtToken = cachedTokens.jwtToken;
          sessionId = cachedTokens.sessionId;
        }
      }

      // Strategy 3: Convert OAuth to JWT using the seat booking clientId
      if (!jwtToken && userOAuthToken) {
        try {
          const tokenResult = await boschAuthService.storeUserTokens(employeeNumber, userOAuthToken, undefined, 'seatbooking');
          jwtToken = tokenResult.jwtToken;
          sessionId = tokenResult.sessionId;
        } catch (conversionError) {
          console.log('[SeatBooking] Strategy 3: Auth conversion failed:', conversionError.message);
        }
      }

      // Strategy 4: Fallback to service account
      if (!jwtToken) {
        try {
          jwtToken = await boschAuthService.getServiceToken();
          if (!sessionId) {
            sessionId = boschAuthService.getOrCreateSessionId(employeeNumber, 'seatbooking');
          }
        } catch (authError) {
          console.log('[SeatBooking] Service token fallback failed:', authError.message);
        }
      }

      if (!jwtToken) throw new Error('AUTH_REQUIRED');
      if (!sessionId) sessionId = boschAuthService.getOrCreateSessionId(employeeNumber, 'seatbooking');

      // IDENTITY SYNC: Decode JWT to get the REAL name/ID for the metadata.
      //
      // CRITICAL: the Bosch JWT stores `name` as an encrypted AES blob
      // (base64-ish, ends with "=="). If we pass that blob to the A2A agent
      // as user_name, the downstream tool can't parse it and falls back to
      // a hardcoded test user ("Votan" on travel). We therefore filter out
      // any claim value that looks like an encrypted blob.
      const looksEncrypted = (val) => {
        if (typeof val !== 'string') return false;
        const v = val.trim();
        if (!v || v.includes(' ') || v.length < 24) return false;
        if (/[^A-Za-z0-9+/=_-]/.test(v)) return false;
        return v.endsWith('==') || v.length > 40;
      };

      const decoded = this.decodeJWT(jwtToken);
      const jwtEmpNo = decoded?.emp_number || decoded?.id || decoded?.sub || decoded?.unique_name;
      let jwtName = decoded?.name || decoded?.given_name || (decoded?.unique_name ? decoded.unique_name.split('@')[0] : null);
      if (looksEncrypted(jwtName)) jwtName = null;
      let jwtEmail = decoded?.email || null;
      if (looksEncrypted(jwtEmail)) jwtEmail = null;

      const safeId = String(effectiveEmpNo || jwtEmpNo || '').replace(/[^0-9]/g, '');
      const safeName = (effectiveName && !looksEncrypted(effectiveName)) ? effectiveName : (jwtName || 'Bosch User');
      const safeEmail = jwtEmail || `${safeId}@bosch.com`;

      console.log(`[SeatBooking] A2A Sync: Using Identity from JWT: Name="${safeName}", ID=${safeId}`);

      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Use the agent-generated session ID (ResponseData.SessionId from /Token/GenrateTokenDetails)
      // as the A2A contextId. The seat-booking agentic layer validates this against the JWT token,
      // so it must match what the auth service issued. Fall back to a crypto UUID only when
      // agentSessionId is unavailable (e.g. service-account fallback path).
      const crypto = require('crypto');
      const isolatedSessionId = agentSessionId ||
        ((typeof crypto.randomUUID === 'function')
          ? crypto.randomUUID()
          : `${sessionId || Date.now()}-${Math.random().toString(36).substr(2, 9)}`);
      console.log('[SeatBooking] A2A contextId:', isolatedSessionId, agentSessionId ? '(agent-generated)' : '(fallback UUID)');

      // Build A2A request mirroring the Python SDK structure exactly:
      // contextId and metadata must be INSIDE the message object, not at params level.
      const a2aRequest = {
        jsonrpc: '2.0',
        id: requestId,
        method: 'message/send',
        params: {
          message: {
            role: 'user',
            messageId: messageId,
            contextId: isolatedSessionId,
            metadata: {
              auth: {
                session_id: isolatedSessionId,
                token: jwtToken
              }
            },
            parts: [{ type: 'text', text: message }]  // seat-booking agent uses "type" (older A2A SDK); travel agent uses "kind"
          }
        }
      };

      const response = await axios.post(
        this.apiUrl,
        a2aRequest,
        {
          headers: { 'accept': 'application/json', 'Content-Type': 'application/json' },
          httpsAgent,
          timeout: 300000
        }
      );

      const a2aResult = response.data;

      // ── Level 1: JSON-RPC protocol error ──────────────────────────────────
      if (a2aResult.error) {
        const msg = a2aResult.error.message || 'A2A request failed';
        const err = new Error(msg);
        if (/token validation failed/i.test(msg) || /request rejected/i.test(msg)) {
          err.isTokenValidationFailure = true;
        }
        throw err;
      }

      // ── Level 2: Task-level failure (state: "failed") ─────────────────────
      // The seat booking agent returns auth errors as a completed task whose
      // status.state is "failed" and the error text is in status.message.parts.
      // Our retry wrapper only catches thrown errors, so we must detect this
      // shape here and throw before returning the result to the formatter.
      const taskResult = a2aResult.result;
      if (taskResult?.status?.state === 'failed') {
        const parts = taskResult.status?.message?.parts || [];
        const errorText = parts
          .filter(p => p.kind === 'text' || p.type === 'text')
          .map(p => p.text)
          .join(' ')
          .trim() || 'A2A task failed with state=failed';
        console.error('[SeatBooking] Task-level failure:', errorText);
        const err = new Error(errorText);
        if (/invalid.?token|token.?rejected|authentication.?failed|unauthorized|token.?validation/i.test(errorText)) {
          err.isTokenValidationFailure = true;
        }
        throw err;
      }

      return taskResult;
    } catch (error) {
      console.error('[SeatBooking] API error:', error.message);
      throw error;
    }
  }

  /**
   * Wrapper around callSeatBookingAPI that handles token-validation failures
   * with a two-stage retry strategy:
   *
   * Stage 1 — Fresh user JWT:
   *   Clear stale credentials, call /Token/GenrateTokenDetails again to get
   *   a new JWT + SessionId, and retry.  This fixes transient A2A session
   *   expiry (same root cause as the travel service fix).
   *
   * Stage 2 — Pre-authenticated env token (SEATBOOKING_JWT_TOKEN):
   *   The seat booking A2A agent calls Bosch's own ValidateToken API which
   *   is configured for a specific clientID (different from BOSCH_CLIENT_ID).
   *   If Stage 1 also fails, fall back to the pre-authenticated JWT stored in
   *   SEATBOOKING_JWT_TOKEN.  The real user identity (employeeNumber, userName)
   *   is still sent in the A2A message metadata so the agent books for the
   *   correct person, not the service account embedded in the token.
   */
  async callSeatBookingAPIWithRetry(message, employeeNumber, authToken, files, jwtToken, sessionId, userName, agentSessionId) {
    try {
      return await this.callSeatBookingAPI(message, employeeNumber, authToken, files, jwtToken, sessionId, userName, agentSessionId);
    } catch (err) {
      if (!err.isTokenValidationFailure) throw err;

      // ── Stage 1: Refresh user JWT (using seatbooking clientId) ─────────────
      console.warn('[SeatBooking] ⚠️ Token validation failed — clearing session and retrying with fresh credentials');
      boschAuthService.clearUserSession(employeeNumber, 'seatbooking');

      if (authToken) {
        try {
          const freshTokens = await boschAuthService.storeUserTokens(employeeNumber, authToken, undefined, 'seatbooking');
          console.log('[SeatBooking] 🔄 Stage 1: Retrying with fresh JWT, SessionId:', freshTokens.sessionId);
          return await this.callSeatBookingAPI(
            message, employeeNumber, authToken, files,
            freshTokens.jwtToken, sessionId, userName, freshTokens.sessionId
          );
        } catch (stage1Err) {
          if (!stage1Err.isTokenValidationFailure) throw stage1Err;
          console.warn('[SeatBooking] Stage 1 retry also rejected — user JWT audience not accepted by seat booking ValidateToken API');
        }
      }

      // ── Stage 2: Pre-authenticated env token fallback ────────────────────
      // The seat booking A2A agent validates tokens against a Bosch clientID
      // that is different from the general BOSCH_CLIENT_ID used for /Token/
      // GenrateTokenDetails. SEATBOOKING_JWT_TOKEN holds a JWT minted for
      // the correct clientID and is accepted by ValidateToken.
      const preAuthJwt = process.env.SEATBOOKING_JWT_TOKEN;
      if (preAuthJwt) {
        const crypto = require('crypto');

        // ── Multi-turn context: reuse a stable A2A contextId per frontend session ──
        //
        // Generating crypto.randomUUID() on every Stage-2 call gives the A2A
        // agent a brand-new session each turn, so it loses all slot-fill state
        // accumulated in prior turns (building name, floor, date, etc.) and
        // asks the user to repeat themselves.
        //
        // Fix: store the contextId on the conversationContextService context
        // object (keyed by the frontend sessionId).  The context object is a
        // live in-memory reference, so mutations persist across calls within
        // the same browser session.  When the user starts a new chat session
        // a new sessionId is generated by the frontend, so the stored contextId
        // is naturally scoped to one conversation.
        let preAuthSession;
        if (sessionId) {
          const convContext = conversationContextService.getContext(sessionId);
          if (convContext.seatbookingContextId) {
            // Reuse the same contextId so the A2A agent sees a continuous session
            preAuthSession = convContext.seatbookingContextId;
            console.log('[SeatBooking] Stage 2: Reusing stable A2A contextId for session', sessionId, '→', preAuthSession);
          } else {
            // First Stage-2 call in this conversation — mint a new UUID and store it
            preAuthSession = crypto.randomUUID();
            convContext.seatbookingContextId = preAuthSession;
            console.log('[SeatBooking] Stage 2: Minted new stable A2A contextId for session', sessionId, '→', preAuthSession);
          }
        } else {
          // No frontend sessionId available (e.g. direct API call) — fall back
          // to a per-call UUID so different users never accidentally share state.
          preAuthSession = crypto.randomUUID();
          console.log('[SeatBooking] Stage 2: No sessionId — using ephemeral A2A contextId:', preAuthSession);
        }

        console.warn('[SeatBooking] 🔄 Stage 2: Falling back to SEATBOOKING_JWT_TOKEN (pre-auth). User identity still forwarded via metadata.');
        return await this.callSeatBookingAPI(
          message, employeeNumber, authToken, files,
          preAuthJwt, sessionId, userName, preAuthSession
        );
      }

      // No fallback available — surface the original token validation error
      throw err;
    }
  }

  /**
   * Check if query is asking about another person's seat booking data.
   */
  /**
   * Check if query is asking about another person's seat-booking data.
   *
   * Strategy (mirrors travel-service): Instead of flagging every unknown
   * capitalised word as a person name (which false-positives on office
   * locations, building names, etc.), we detect **syntactic patterns**
   * that strongly indicate a person reference:
   *   A) Possessive:  "Rajesh's booking"
   *   B) Genitive:    "booking details of Kumar"
   *   C) Action-for:  "book a desk for Priya"
   *   D) Name-before-booking-noun: "Check Ramesh seat booking"
   *
   * Capitalised words appearing after location prepositions (in/at/on/near …)
   * are treated as places and excluded from name checks.
   */
  isQueryAboutOtherPerson(query, loggedInUserName = null) {
    const q = query.toLowerCase().trim();
    const original = query.trim();

    // ── Helper: does `name` match the logged-in user? ──
    const ownNameParts = new Set();
    if (loggedInUserName) {
      const full = String(loggedInUserName).toLowerCase().trim();
      if (full) {
        ownNameParts.add(full);
        full.split(/\s+/).filter(Boolean).forEach(p => ownNameParts.add(p));
      }
    }
    const isOwnName = (name) => {
      if (!name) return false;
      const n = String(name).toLowerCase().trim();
      if (ownNameParts.has(n)) return true;
      for (const p of ownNameParts) if (p.length >= 3 && (n.includes(p) || p.includes(n))) return true;
      return false;
    };

    // ── Step 1 – Gate: must contain seat-booking keywords (from config) ──
    const seatKeywords = configService.getKeywordConfigSync().seatBookingService.seatKeywords;
    if (!seatKeywords.some(kw => q.includes(kw))) return false;

    // ── Step 2 – Self-reference → safe (unless colleague word) ──
    const hasSelfRef = /\b(my|mine|me|myself|i)\b/i.test(q);
    const hasColleagueWord = /\b(friend|colleague|coworker|team\s?mate|boss|manager|reportee|someone\s+else)\b/i.test(q);
    if (hasSelfRef && !hasColleagueWord) return false;

    // ── Step 3 – Colleague / role word → blocked ──
    if (hasColleagueWord) return true;

    // ── Step 4 – Third-person possessive pronoun + booking noun → blocked ──
    const bookingNounRe = '(?:seat|desk|booking|reservation|floor|zone|workstation|details?|data|records?|status|info|information)';
    if (new RegExp(`\\b(his|her|their)\\s+${bookingNounRe}`, 'i').test(q)) return true;
    if (/\bfor\s+(him|her|them)\b/i.test(q)) return true;

    // ── Step 5 – Pattern-based person-name detection ──

    // 5.0  Build location set: words after location prepositions are places
    const locationPositions = new Set();
    const prepRe = /\b(?:in|at|on|near|around|inside|within)\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)/g;
    for (const m of original.matchAll(prepRe)) {
      m[1].toLowerCase().split(/\s+/).forEach(w => locationPositions.add(w));
    }

    // 5.1  Combined safe-word check: global whitelist + location context
    const whitelist = new Set(configService.getPrivacyWhitelistSync().map(w => w.toLowerCase()));
    const isKnownSafe = (name) => {
      const n = name.toLowerCase();
      if (whitelist.has(n) || locationPositions.has(n)) return true;
      return n.split(/\s+/).some(w => whitelist.has(w) || locationPositions.has(w));
    };

    // Date-context helper: ignore capitalised words following ordinals
    // ("9th of April", "3rd May") — these are dates, not names.
    const dateContextRanges = [];
    const dateCtxRe = /\b(?:on\s+|from\s+|to\s+|by\s+|until\s+|till\s+)?\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?/gi;
    let dcm;
    while ((dcm = dateCtxRe.exec(original)) !== null) {
      dateContextRanges.push([dcm.index, dcm.index + dcm[0].length + 20]);
    }
    const isAfterDateContext = (pos) =>
      dateContextRanges.some(([start, end]) => pos >= start && pos <= end);

    // ── Pattern A: Possessive — "<Name>'s …" ──
    for (const m of original.matchAll(/\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)'s\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1]) && !isAfterDateContext(m.index)) {
        console.log(`[SeatBooking Privacy] Blocked: possessive "${m[1]}'s"`);
        return true;
      }
    }

    // ── Pattern B: "<booking noun> of/for <Name>" ──
    const genitiveRe = new RegExp(
      `\\b${bookingNounRe}\\s+(?:of|for)\\s+([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\b`, 'g'
    );
    for (const m of original.matchAll(genitiveRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        console.log(`[SeatBooking Privacy] Blocked: "of/for ${m[1]}" after booking noun`);
        return true;
      }
    }

    // ── Pattern C: "book/show/get … for <Name>" (not a known location) ──
    for (const m of original.matchAll(/\b(?:book|show|get|find|fetch|check|retrieve|reserve|cancel)\b[^.]*?\bfor\s+([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b/g)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1]) && !isAfterDateContext(m.index)) {
        console.log(`[SeatBooking Privacy] Blocked: action "for ${m[1]}"`);
        return true;
      }
    }

    // ── Pattern D: "<Name> <booking-noun>" where Name is NOT after a preposition ──
    const nameBeforeNounRe = new RegExp(
      `\\b([A-Z][a-z]{2,}(?:\\s+[A-Z][a-z]{2,})?)\\s+${bookingNounRe}\\b`, 'g'
    );
    for (const m of original.matchAll(nameBeforeNounRe)) {
      if (!isOwnName(m[1]) && !isKnownSafe(m[1])) {
        const before = original.substring(Math.max(0, m.index - 15), m.index).trim().toLowerCase();
        if (!/\b(?:in|at|on|near|around|inside)\s*$/.test(before)) {
          console.log(`[SeatBooking Privacy] Blocked: "${m[1]}" before booking noun`);
          return true;
        }
      }
    }

    // No person-name pattern detected → safe
    return false;
  }

  /**
   * Classify the user's seat-booking query intent using few-shot LLM prompting.
   * Returns one of: 'book' | 'cancel' | 'list' | 'general'
   * Falls back to keyword matching if the LLM call fails.
   * All intents are currently handled by the A2A agent; the classification is
   * logged and available for future routing without regex.
   */
  async classifyQueryIntent(query) {
    const examples = configService.getFewShotConfigSync().seatbooking || [];
    const exampleLines = examples.map(e => `Q: "${e.query}" → {"intent":"${e.intent}"}`).join('\n');

    const systemPrompt = `You are an intent classifier for a workplace seat and desk booking assistant at Bosch.
Classify the user query into exactly one of these intents:
- "book"    : user wants to book, reserve, or schedule a seat or desk
- "cancel"  : user wants to cancel or remove an existing seat/desk booking
- "list"    : user wants to view, check, or list their existing seat/desk bookings
- "general" : any other seat-booking related query

Few-shot examples (cover every tricky case):
${exampleLines}

Respond with ONLY valid JSON, no explanation: {"intent":"book"|"cancel"|"list"|"general"}`;

    try {
      const response = await this.openai.chat.completions.create({
        model: getChatModelName('gpt-4o-mini'),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        max_tokens: 20,
        temperature: 0
      });

      const raw = response.choices[0].message.content.trim();
      const parsed = JSON.parse(raw);
      const valid = ['book', 'cancel', 'list', 'general'];
      if (valid.includes(parsed.intent)) {
        console.log(`[SeatBooking] LLM intent: "${parsed.intent}" for query: "${query}"`);
        return parsed.intent;
      }
    } catch (e) {
      console.warn('[SeatBooking] LLM intent classification failed, using keyword fallback:', e.message);
    }

    return this.classifyQueryIntentFallback(query);
  }

  /**
   * Keyword-based intent fallback used when the LLM call fails.
   */
  classifyQueryIntentFallback(query) {
    const q = query.toLowerCase();
    if (/\b(cancel|remove|delete)\b/i.test(q)) return 'cancel';
    if (/\b(show|list|view|display|check|do i have|my)\b.*\b(booking|seat|desk|reservation)\b/i.test(q)
      || /\b(booking|seat|desk|reservation)\b.*\b(today|tomorrow|this week|monday|tuesday|wednesday|thursday|friday)\b/i.test(q)) return 'list';
    if (/\b(book|reserve|schedule|need a seat|need a desk)\b/i.test(q)) return 'book';
    return 'general';
  }

  /**
   * Extract the first past date found in a booking query (IST-aware).
   *
   * Checks (in order):
   *   1. "yesterday" keyword               → always past
   *   2. "last <weekday>"                  → always past
   *   3. ISO date YYYY-MM-DD               → compare with today IST
   *   4. Numeric date DD/MM/YYYY or similar → compare with today IST
   *   5. Natural "15th April" / "April 15" → compare with today IST (assumes current year if none given)
   *
   * Returns the matched date string, or null if none found or all are today/future.
   */
  /**
   * Extract the first invalid or past date from a booking query (IST-aware).
   *
   * Returns { dateStr, isInvalidCalendarDay } or null if no such date found.
   *  - dateStr              : the matched text from the query
   *  - isInvalidCalendarDay : true when the day does not exist in that month
   *                           (e.g. "31st April", "30th February")
   */
  extractPastDateFromQuery(query) {
    const istNow  = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    istNow.setHours(0, 0, 0, 0);

    // 1. "yesterday" — unconditionally past
    if (/\byesterday\b/i.test(query)) return { dateStr: 'yesterday', isInvalidCalendarDay: false };

    // 2. "last <weekday>" — unconditionally past
    const lastDayMatch = query.match(/\blast\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i);
    if (lastDayMatch) return { dateStr: lastDayMatch[0], isInvalidCalendarDay: false };

    // Helper: parse a string and return a Date at midnight, or null if invalid
    const toMidnight = (str) => {
      const d = new Date(str);
      if (isNaN(d.getTime())) return null;
      d.setHours(0, 0, 0, 0);
      return d;
    };

    // Capitalize first letter so "april" → "April" (JS Date requires it)
    const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();

    // 3. ISO YYYY-MM-DD
    const isoMatches = query.match(/\b(\d{4}-\d{2}-\d{2})\b/g) || [];
    for (const ds of isoMatches) {
      const d = toMidnight(ds);
      if (d && d < istNow) return { dateStr: ds, isInvalidCalendarDay: false };
    }

    // 4. Numeric dates: DD/MM/YYYY, DD-MM-YYYY (treat as day/month/year for India locale)
    const numericMatches = query.match(/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})\b/g) || [];
    for (const ds of numericMatches) {
      const parts = ds.split(/[\/\-]/);
      const d = toMidnight(`${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`);
      if (d && d < istNow) return { dateStr: ds, isInvalidCalendarDay: false };
    }

    // 5. Natural language: "15th April", "15th of April", "April 15", "15 April 2024"
    const monthNames = 'january|february|march|april|may|june|july|august|september|october|november|december';
    const monthList  = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    // "of" is optional between day and month ("30th of April" = "30th April")
    const dmyRe = new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${monthNames})(?:\\s+(\\d{4}))?\\b`, 'gi');
    const mdyRe = new RegExp(`\\b(${monthNames})\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:[,\\s]+(\\d{4}))?\\b`, 'gi');

    let m;
    while ((m = dmyRe.exec(query)) !== null) {
      const year     = m[3] ? parseInt(m[3], 10) : istNow.getFullYear();
      const day      = parseInt(m[1], 10);
      const monthCap = capitalize(m[2]);
      const monthIdx = monthList.indexOf(m[2].toLowerCase());
      const d = toMidnight(`${monthCap} ${day}, ${year}`);
      if (!d) continue;
      // JS rolls invalid days (e.g. April 31 → May 1) — detect by checking if
      // the parsed month no longer matches the requested month.
      const isInvalidCalendarDay = d.getMonth() !== monthIdx;
      if (isInvalidCalendarDay || d < istNow) return { dateStr: m[0], isInvalidCalendarDay };
    }
    while ((m = mdyRe.exec(query)) !== null) {
      const year     = m[3] ? parseInt(m[3], 10) : istNow.getFullYear();
      const day      = parseInt(m[2], 10);
      const monthCap = capitalize(m[1]);
      const monthIdx = monthList.indexOf(m[1].toLowerCase());
      const d = toMidnight(`${monthCap} ${day}, ${year}`);
      if (!d) continue;
      const isInvalidCalendarDay = d.getMonth() !== monthIdx;
      if (isInvalidCalendarDay || d < istNow) return { dateStr: m[0], isInvalidCalendarDay };
    }

    return null;
  }

  async processQuery(query, context = {}) {
    try {
      const { authToken, employeeNumber, jwtToken, sessionId, agentSessionId, userName, originalQuery } = context;

      // LLM-based intent classification with few-shot examples.
      // All intents are handled by the A2A agent today; classification is
      // logged for observability and ready for routing without regex.
      const intent = await this.classifyQueryIntent(query);
      console.log('[SeatBooking] processQuery context:', { employeeNumber, hasAuth: !!authToken, userName, intent });

      if (this.isQueryAboutOtherPerson(query, userName)) {
        return {
          success: false,
          response: "I'm sorry, but I can only provide your own personal information. For privacy reasons, I cannot share other colleagues' seat booking data."
        };
      }

      const getISTFormattedDate = (offsetDays = 0) => {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        const istTime = d.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
        const istDate = new Date(istTime);
        const yyyy = istDate.getFullYear();
        const mm = String(istDate.getMonth() + 1).padStart(2, '0');
        const dd = String(istDate.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
      };

      let explicitQuery = query.replace(/\btoday\b/gi, getISTFormattedDate(0))
        .replace(/\btomorrow\b/gi, getISTFormattedDate(1));

      // ── Previous Date Booking Validation ───────────────────────────────────
      // Only run for booking intent; listing / cancellations are allowed on any date.
      // Validate past/invalid dates for every intent EXCEPT 'list' and 'cancel'.
      // 'list' and 'cancel' legitimately operate on past dates (e.g. "show last
      // week's bookings", "cancel yesterday's desk"). Any other intent — including
      // 'book', 'general', and unexpected LLM values — must not allow past dates.
      // This makes the guard robust against LLM misclassification.
      if (intent !== 'list' && intent !== 'cancel') {
        const bookingCfg = configService.getBookingConfigSync();
        if (bookingCfg?.seatbooking?.allowPreviousDateBooking === false) {
          // Check rewritten query first; if the context rewriter omitted the date
          // (e.g. produced "update the booking to the corrected date"), fall back to
          // scanning the raw user query so corrections like "I meant 30th April" are caught.
          const pastDateResult = this.extractPastDateFromQuery(explicitQuery)
            || (originalQuery && originalQuery !== query ? this.extractPastDateFromQuery(originalQuery) : null);
          if (pastDateResult) {
            const { dateStr, isInvalidCalendarDay } = pastDateResult;
            console.log(`[SeatBooking] ❌ Date check blocked: "${dateStr}", invalidCalendarDay=${isInvalidCalendarDay}`);
            let message;
            if (isInvalidCalendarDay) {
              // Extract month name from dateStr for the hint
              const monthMatch = dateStr.match(/january|february|march|april|may|june|july|august|september|october|november|december/i);
              const monthName = monthMatch ? monthMatch[0].charAt(0).toUpperCase() + monthMatch[0].slice(1).toLowerCase() : null;
              const daysInMonth = monthName
                ? new Date(new Date().getFullYear(), ['january','february','march','april','may','june','july','august','september','october','november','december'].indexOf(monthName.toLowerCase()) + 1, 0).getDate()
                : null;
              const hintLine = monthName && daysInMonth
                ? ` Note that **${monthName}** only has **${daysInMonth} days**.`
                : '';
              message = `💺 **Seat Booking**\n\nThe date **${dateStr}** does not exist.${hintLine}\n\nPlease provide a valid future date and I will book your seat right away.`;
            } else {
              message = `💺 **Seat Booking**\n\nSorry, seat bookings for past dates are not allowed. The date **${dateStr}** has already passed.\n\nPlease provide today's date or a future date and I will book your seat right away.`;
            }
            return { success: false, response: message };
          }
        }
      }
      // ───────────────────────────────────────────────────────────────────────

      // No bracketed metadata - identity is in JWT and Metadata. Raw query unlocks tools.
      const result = await this.callSeatBookingAPIWithRetry(explicitQuery, employeeNumber, authToken, [], jwtToken, sessionId, userName, agentSessionId);
      const response = this.formatSeatBookingResponse(result);

      return { success: true, response, data: result };
    } catch (error) {
      console.error('Seat Booking query error:', error.message);
      if (error.message === 'AUTH_REQUIRED') {
        return { success: false, response: "💺 **Seat Booking**\n\nYou need to be logged in to access this service." };
      }
      return { success: false, response: "💺 **Seat Booking Assistant**\n\nI'm having trouble connecting to the booking system. Please try again later." };
    }
  }

  /**
   * Enhanced Formatter - Aggregates text/data from parts, artifacts, and history.
   */
  formatSeatBookingResponse(result) {
    if (!result) return "💺 **Seat Booking Assistant**\n\nNo response received.";

    console.log('[SeatBooking] Raw A2A Result keys:', Object.keys(result));
    if (result.status) console.log('[SeatBooking] Result status keys:', Object.keys(result.status));
    if (result.artifacts) console.log('[SeatBooking] Result artifacts count:', result.artifacts.length);
    
    // DEBUG: Log the full result for deep inspection
    console.log('[SeatBooking] FULL RESULT:', JSON.stringify(result, null, 2));

    const textChunks = [];
    const collectFromParts = (parts) => {
      if (!Array.isArray(parts)) return;
      for (const p of parts) {
        if (!p) continue;
        const isText = (p.type === 'text' || p.kind === 'text');
        if (isText && typeof p.text === 'string') {
          const t = p.text.trim();
          if (t && t !== 'Processing...') textChunks.push(t);
        }
        const isData = (p.type === 'data' || p.kind === 'data');
        if (isData && p.data !== undefined) {
          textChunks.push(typeof p.data === 'string' ? p.data : JSON.stringify(p.data, null, 2));
        }
      }
    };

    if (result.status?.message?.parts) collectFromParts(result.status.message.parts);
    if (result.message?.parts) collectFromParts(result.message.parts);
    if (Array.isArray(result.artifacts)) {
      for (const art of result.artifacts) {
        if (art?.parts) collectFromParts(art.parts);
        if (art?.content) textChunks.push(typeof art.content === 'object' ? JSON.stringify(art.content, null, 2) : art.content);
        if (art?.data) textChunks.push(typeof art.data === 'object' ? JSON.stringify(art.data, null, 2) : art.data);
      }
    }
    
    // Aggressively capture any top-level or status-level data points
    if (result.status?.data) {
       textChunks.push(typeof result.status.data === 'object' ? JSON.stringify(result.status.data, null, 2) : result.status.data);
    }
    if (result.data) {
       textChunks.push(typeof result.data === 'object' ? JSON.stringify(result.data, null, 2) : result.data);
    }

    if (textChunks.length === 0 && Array.isArray(result.history)) {
      const agentMsgs = result.history.filter(h => h?.role === 'agent');
      for (let i = agentMsgs.length - 1; i >= 0; i--) {
        collectFromParts(agentMsgs[i]?.parts);
        if (textChunks.length > 0) break;
      }
    }

    const seen = new Set();
    const unique = textChunks.filter(t => { if (seen.has(t)) return false; seen.add(t); return true; });

    if (unique.length === 0) return "💺 **Seat Booking Assistant**\n\nI couldn't parse the booking details. Please try again.";
    return `💺 **Seat Booking Assistant**\n\n${unique.join('\n\n')}`;
  }

  async getMyBookings(context) { return this.processQuery('Show me my current bookings', context); }
  async cancelBooking(id, context) { return this.processQuery(`Cancel booking ${id}`, context); }
}

module.exports = new SeatBookingService();
