const { createOpenAIClient, getChatModelName, isAzureOpenAI } = require('./services/openai-client');

// Initialize OpenAI/Azure OpenAI
const openai = createOpenAIClient();

// OpenAI model configuration
const OPENAI_MODEL = getChatModelName();
console.log(`Using ${isAzureOpenAI() ? 'Azure OpenAI' : 'OpenAI'} model: ${OPENAI_MODEL}`);

// Location mapping
const LOCATIONS = {
  'bangalore': 1,
  'bengaluru': 1,
  'blr': 1,
  'coimbatore': 2,
  'cbe': 2
};

// Date parsing utilities
function parseDate(dateStr) {
  const months = {
    'jan': 'Jan', 'january': 'Jan',
    'feb': 'Feb', 'february': 'Feb',
    'mar': 'Mar', 'march': 'Mar',
    'apr': 'Apr', 'april': 'Apr',
    'may': 'May',
    'jun': 'Jun', 'june': 'Jun',
    'jul': 'Jul', 'july': 'Jul',
    'aug': 'Aug', 'august': 'Aug',
    'sep': 'Sep', 'september': 'Sep',
    'oct': 'Oct', 'october': 'Oct',
    'nov': 'Nov', 'november': 'Nov',
    'dec': 'Dec', 'december': 'Dec'
  };

  // Convert to lowercase and remove ordinal suffixes
  let lowerStr = dateStr.toLowerCase();
  lowerStr = lowerStr.replace(/(\d+)(st|nd|rd|th)/gi, '$1');

  // Handle relative dates
  if (lowerStr.includes('today')) {
    const today = new Date();
    return formatDateForDB(today);
  }

  if (lowerStr.includes('tomorrow')) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return formatDateForDB(tomorrow);
  }

  if (lowerStr.includes('yesterday')) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return formatDateForDB(yesterday);
  }

  // Parse formats like "14 nov", "14nov", "14 november", "14 november 2025"
  const patterns = [
    /(\d{1,2})\s*([a-z]+)\s*(\d{2,4})?/i,
    /(\d{1,2})[-\/](\d{1,2})[-\/](\d{2,4})/
  ];

  for (const pattern of patterns) {
    const match = lowerStr.match(pattern);
    if (match) {
      if (pattern.source.includes('[a-z]+')) {
        // Month name pattern
        const day = parseInt(match[1]);
        const monthStr = match[2];
        const yearInput = match[3];

        // Find month
        let monthAbbr = null;
        for (const [monthName, abbr] of Object.entries(months)) {
          if (monthStr.startsWith(monthName.substring(0, 3))) {
            monthAbbr = abbr;
            break;
          }
        }

        if (monthAbbr) {
          // Handle year - if not provided or 4-digit, need to determine 2-digit year
          let yearSuffix;
          if (!yearInput) {
            // No year provided, use current year in 2-digit format
            yearSuffix = new Date().getFullYear().toString().slice(-2);
          } else if (yearInput.length === 4) {
            // 4-digit year provided, convert to 2-digit
            yearSuffix = yearInput.slice(-2);
          } else {
            // 2-digit year provided, use as is
            yearSuffix = yearInput;
          }

          return `${day.toString().padStart(2, '0')}-${monthAbbr}-${yearSuffix}`;
        }
      } else {
        // Numeric date pattern (DD/MM/YYYY or DD-MM-YYYY)
        const day = match[1].padStart(2, '0');
        const month = match[2].padStart(2, '0');
        const year = match[3] || new Date().getFullYear();
        const yearSuffix = year.toString().slice(-2);
        return `${day}-${getMonthName(parseInt(month))}-${yearSuffix}`;
      }
    }
  }

  return null;
}

function getMonthName(monthNum) {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return monthNames[monthNum - 1];
}

function formatDateForDB(date) {
  const day = date.getDate().toString().padStart(2, '0');
  const month = getMonthName(date.getMonth() + 1);
  const year = date.getFullYear().toString().slice(-2); // Get last 2 digits
  return `${day}-${month}-${year}`;
}

/**
 * Extract menu data from natural language text response
 */
function extractMenuFromText(text) {
  if (!text || typeof text !== 'string') return null;

  // Check for "no menu" type responses
  if (text.toLowerCase().includes('no menu found') ||
    text.toLowerCase().includes('menu not available') ||
    text.toLowerCase().includes('not found')) {
    return null;
  }

  const menu = {
    breakfast: null,
    lunch: null,
    snacks: null
  };

  const lines = text.split('\n');

  for (const line of lines) {
    const lowerLine = line.toLowerCase();

    // Extract breakfast
    if (lowerLine.includes('breakfast')) {
      const match = line.match(/breakfast[:\s-]*(.+)/i);
      if (match) {
        menu.breakfast = match[1].replace(/[*🌅]/g, '').trim();
      }
    }
    // Extract lunch
    else if (lowerLine.includes('lunch')) {
      const match = line.match(/lunch[:\s-]*(.+)/i);
      if (match) {
        menu.lunch = match[1].replace(/[*🍽️]/g, '').trim();
      }
    }
    // Extract snacks
    else if (lowerLine.includes('snack')) {
      const match = line.match(/snacks?[:\s-]*(.+)/i);
      if (match) {
        menu.snacks = match[1].replace(/[*🍪]/g, '').trim();
      }
    }
  }

  // Return null if we didn't find any menu items
  if (!menu.breakfast && !menu.lunch && !menu.snacks) {
    return null;
  }

  return menu;
}

async function analyzeQuery(query) {
  try {
    const systemPrompt = `You are an intelligent assistant helping to understand canteen menu queries. Analyze the user's query and extract:

1. Query Type: One of ['menu_by_date', 'weekly_menu', 'search_item', 'general_query']
2. Date: Extract any date mentioned (could be "today", "tomorrow", "14 nov", "next monday", etc.)
3. Location: Look for Bangalore/Bengaluru/BLR (location_id: 1) or Coimbatore/CBE (location_id: 2)
4. Food Item: Any specific food item mentioned
5. Meal Type: breakfast, lunch, or snacks

IMPORTANT: The canteen menu is ONLY available for Bangalore (location_id: 1) and Coimbatore (location_id: 2).
If the user mentions any other city (e.g. Hyderabad, Chennai, Pune, Delhi, Mumbai, etc.), set "unsupported_location" to the city name they mentioned and do NOT set a location_id.

Return a JSON object with these fields. If location is not specified at all, set location_needs_clarification to true.

Examples:
"What's for lunch today in Bangalore?" -> 
{
  "query_type": "menu_by_date",
  "date": "today",
  "location": "bangalore",
  "location_id": 1,
  "meal_type": "lunch"
}

"Is dosa available tomorrow?" ->
{
  "query_type": "search_item",
  "date": "tomorrow",
  "food_item": "dosa",
  "location_needs_clarification": true
}

"Menu for today in Hyderabad" ->
{
  "query_type": "menu_by_date",
  "date": "today",
  "unsupported_location": "Hyderabad"
}`;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: query }
      ],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('OpenAI analysis error:', error);
    // Fallback to simple keyword matching
    return fallbackAnalysis(query);
  }
}

function fallbackAnalysis(query) {
  const lowerQuery = query.toLowerCase();
  const result = {
    query_type: 'general_query'
  };

  // Check for dates
  if (lowerQuery.includes('today') || lowerQuery.includes('tomorrow') || lowerQuery.includes('yesterday')) {
    result.date = lowerQuery.includes('today') ? 'today' :
      lowerQuery.includes('tomorrow') ? 'tomorrow' : 'yesterday';
    result.query_type = 'menu_by_date';
  } else if (lowerQuery.includes('week') || lowerQuery.includes('weekly')) {
    result.query_type = 'weekly_menu';
  }

  // Check for supported locations first
  for (const [location, id] of Object.entries(LOCATIONS)) {
    if (lowerQuery.includes(location)) {
      result.location = location;
      result.location_id = id;
      break;
    }
  }

  // If no supported location matched, check if user mentioned an unsupported city
  if (!result.location_id) {
    const unsupportedCities = ['hyderabad', 'hyd', 'chennai', 'pune', 'mumbai', 'delhi', 'noida', 'gurgaon', 'gurugram', 'kolkata', 'ahmedabad', 'jaipur', 'lucknow', 'kochi', 'trivandrum', 'indore', 'chandigarh'];
    for (const city of unsupportedCities) {
      if (lowerQuery.includes(city)) {
        result.unsupported_location = city.charAt(0).toUpperCase() + city.slice(1);
        break;
      }
    }
    if (!result.unsupported_location) {
      result.location_needs_clarification = true;
    }
  }

  // Check for meal type
  if (lowerQuery.includes('breakfast')) result.meal_type = 'breakfast';
  else if (lowerQuery.includes('lunch')) result.meal_type = 'lunch';
  else if (lowerQuery.includes('snack')) result.meal_type = 'snacks';

  return result;
}

async function generateNaturalResponse(data, originalQuery) {
  try {
    const systemPrompt = `You are a friendly canteen assistant. Generate a natural, conversational response based on the canteen menu data provided. 
    
    Guidelines:
    - Be warm and friendly
    - Format the menu items nicely
    - Add helpful suggestions or comments
    - If no menu is available, be empathetic
    - Keep responses concise but informative
    - Use emojis sparingly but appropriately
    
    Current context:
    - User query: "${originalQuery}"
    - Data type: ${data.type || 'menu'}`;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify(data) }
      ]
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error('OpenAI response generation error:', error);
    // Fallback to simple formatting
    return formatSimpleResponse(data);
  }
}

function formatSimpleResponse(data) {
  console.log('formatSimpleResponse input:', JSON.stringify(data, null, 2));

  if (data.error) {
    return `I couldn't find that information. ${data.error}`;
  }

  if (!data.success && data.message) {
    return data.message;
  }

  if (data.menu) {
    let response = `Here's the menu for ${data.date || 'today'}:\n\n`;
    if (data.menu.breakfast) response += `🌅 Breakfast: ${data.menu.breakfast}\n`;
    if (data.menu.lunch) response += `🍽️ Lunch: ${data.menu.lunch}\n`;
    if (data.menu.snacks) response += `🍪 Snacks: ${data.menu.snacks}\n`;
    return response;
  }

  if (data.items && data.items.length > 0) {
    let response = `Found ${data.items.length} item(s):\n\n`;
    data.items.forEach(item => {
      response += `📅 ${item.date} (${item.day})\n`;
      if (item.meal_type) response += `   ${item.meal_type}: ${item.menu}\n`;
      response += '\n';
    });
    return response;
  }

  return "I couldn't understand your query. Please try asking about today's menu, tomorrow's menu, or search for specific items.";
}

async function processIntelligentQuery(query, mcpClient, conversationContext = {}) {
  try {
    // Analyse the query using OpenAI
    const analysis = await analyzeQuery(query);
    console.log('Query analysis:', analysis);

    // JWT token passed in from server.js (obtained via boschAuthService.getTokenForUser)
    const authToken = conversationContext.authToken || null;
    console.log(`[Canteen] Auth token present for MCP calls: ${!!authToken}`);

    // Block unsupported locations — never fall through to MCP with a wrong id
    if (analysis.unsupported_location) {
      const cityName = analysis.unsupported_location;
      return {
        response: `I'm sorry, the canteen menu service is currently only available for **Bangalore** and **Coimbatore**. We don't have menu data for ${cityName} at this time.\n\nWould you like to check the menu for Bangalore or Coimbatore instead? 🏢`,
        needs_location: false,
        analysis
      };
    }

    // Check if we need location clarification
    if (analysis.location_needs_clarification && !conversationContext.location_id) {
      return {
        response: "I'd be happy to help! Which location are you asking about - Bangalore or Coimbatore? 🏢",
        needs_location: true,
        analysis
      };
    }

    // Use conversation context if location wasn't specified in this query
    if (!analysis.location_id && conversationContext.location_id) {
      analysis.location_id = conversationContext.location_id;
      analysis.location = conversationContext.location;
    }

    // Parse dates if needed
    if (analysis.date && !['today', 'tomorrow', 'yesterday'].includes(analysis.date.toLowerCase())) {
      analysis.parsed_date = parseDate(analysis.date);
      console.log(`Parsed date "${analysis.date}" to "${analysis.parsed_date}"`);
    }

    // Call appropriate MCP tool based on analysis — pass authToken so the
    // canteen MCP server can authenticate against the Bosch Arena API.
    let mcpResult;
    switch (analysis.query_type) {
      case 'menu_by_date':
        const date = analysis.parsed_date || analysis.date;
        console.log(`Calling get_menu_by_date with date: "${date}", location: ${analysis.location_id || 1}`);
        mcpResult = await mcpClient.callTool('get_menu_by_date', {
          date: date,
          locationId: analysis.location_id || 1
        }, authToken);
        console.log('MCP Result:', JSON.stringify(mcpResult, null, 2));
        break;

      case 'weekly_menu':
        mcpResult = await mcpClient.callTool('get_weekly_menu', {
          locationId: analysis.location_id || 1
        }, authToken);
        break;

      case 'search_item':
        mcpResult = await mcpClient.callTool('search_menu_item', {
          search_term: analysis.food_item,
          locationId: analysis.location_id || 1,
          meal_type: analysis.meal_type
        }, authToken);
        break;

      default:
        // For general queries, try to get today's menu
        mcpResult = await mcpClient.callTool('get_menu_by_date', {
          date: 'today',
          locationId: analysis.location_id || 1
        }, authToken);
    }

    // Generate natural response
    const naturalResponse = await generateNaturalResponse(mcpResult, query);

    // Parse menu data from MCP result if available
    let menuData = null;

    // Try to extract menuData from different response formats
    if (mcpResult) {
      // Format 1: MCP protocol response with content array
      if (mcpResult.content && mcpResult.content[0]) {
        try {
          const parsedResult = JSON.parse(mcpResult.content[0].text);
          if (parsedResult.success && parsedResult.menu) {
            menuData = parsedResult.menu;
          }
        } catch (e) {
          console.error('Failed to parse menu data from content:', e);
        }
      }
      // Format 2: Chat endpoint response with answer field
      else if (mcpResult.answer) {
        // Try to extract menu from the answer text
        const answer = mcpResult.answer;
        menuData = extractMenuFromText(answer);
      }
      // Format 3: Direct response format
      else if (mcpResult.response) {
        menuData = extractMenuFromText(mcpResult.response);
      }
      // Format 4: Direct menu object
      else if (mcpResult.menu) {
        menuData = mcpResult.menu;
      }
    }

    return {
      response: naturalResponse,
      location_id: analysis.location_id,
      location: analysis.location,
      menuData: menuData, // Include structured menu data
      analysis
    };
  } catch (error) {
    console.error('Intelligent query processing error:', error);
    return {
      response: "I'm having trouble understanding your request. Could you please rephrase it? You can ask about today's menu, search for specific dishes, or check the weekly menu.",
      error: error.message
    };
  }
}

module.exports = {
  processIntelligentQuery,
  parseDate,
  analyzeQuery
};
