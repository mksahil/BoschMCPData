import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { useTheme } from "next-themes";
import {
  User, DollarSign, Briefcase, BookOpen, Coffee, Plane, FileText,
  Calendar, Award, MessageSquare, GraduationCap, Music, Armchair,
  LogIn, Gift, Dumbbell, Navigation as NavigationIcon, Car, Eye, Megaphone, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import logger from "@/lib/logger";
import { useAuth } from "@/context/AuthContext";
import { BoBCard } from "./BoBCard";
import { LeaveCard } from "./LeaveCard";
import { EffortBookingCard } from "./EffortBookingCard";
import { JKLCard } from "./JKLCard";
import { TravelCard } from "./TravelCard";
import { CafeteriaCard } from "./CafeteriaCard";
import { PayslipCard } from "./PayslipCard";
import { ProjectsCard } from "./ProjectsCard";
import { MeetingsCard } from "./MeetingsCard";
import { CoursesCard } from "./CoursesCard";
import { CertificationsCard } from "./CertificationsCard";
import { CommunityCard } from "./CommunityCard";
import { MusicCard } from "./MusicCard";
import { SeatBookingCard } from "./SeatBookingCard";
import { VitalContactsCard } from "./VitalContactsCard";
import { EntryExitCard } from "./EntryExitCard";
import { HolidayCalendarCard } from "./HolidayCalendarCard";
import { GymCard } from "./GymCard";
import { WayFinderCard } from "./WayFinderCard";
import { BlogsCard } from "./BlogsCard";
import { ParkingCard } from "./ParkingCard";
import { WatchlistCard } from "./WatchlistCard";
import { BannersCard } from "./BannersCard";
import { API_BASE_URL } from "@/config";

// Planet-positioning ellipse params derived from Figma Orbit.svg path bounding boxes.
// Each orbit has its own perspective-shifted center (cx, cy) — the 3D projection means
// larger rings shift right and downward. rx/ry computed from bbox + TILT_DEG=-15° formula.
const ORBITS = [
  { rx: 116, ry: 12, cx: 760, cy: 256 },  // orbit 0 — innermost
  { rx: 212, ry: 22, cx: 795, cy: 251 },  // orbit 1
  { rx: 300, ry: 32, cx: 801, cy: 256 },  // orbit 2
  { rx: 366, ry: 51, cx: 786, cy: 269 },  // orbit 3
  { rx: 452, ry: 63, cx: 777, cy: 282 },  // orbit 4
  { rx: 550, ry: 83, cx: 782, cy: 298 },  // orbit 5
  { rx: 659, ry: 103, cx: 785, cy: 316 },  // orbit 6
  { rx: 782, ry: 133, cx: 795, cy: 341 },  // orbit 7 — outermost
];

// Exact bezier paths from Figma Orbit.svg — innermost (path7) → outermost (path0)
// These produce the correct 3D-perspective depth and ellipse proportions
const ORBIT_PATH_DATA = [
  "M755.703 236.604C786.862 229.377 815.572 225.101 836.79 224.021C847.407 223.481 856.1 223.744 862.27 224.818C865.36 225.355 867.757 226.087 869.434 226.983C871.117 227.882 871.938 228.869 872.17 229.868C872.402 230.867 872.099 232.115 870.983 233.663C869.871 235.206 868.041 236.918 865.504 238.76C860.436 242.44 852.746 246.502 842.975 250.69C823.447 259.06 795.786 267.856 764.627 275.082C733.468 282.308 704.759 286.585 683.541 287.664C672.924 288.205 664.231 287.942 658.061 286.868C654.971 286.33 652.574 285.598 650.897 284.703C649.214 283.804 648.391 282.817 648.16 281.818C647.928 280.819 648.232 279.571 649.348 278.023C650.459 276.48 652.29 274.768 654.827 272.925C659.895 269.245 667.585 265.183 677.356 260.995C696.884 252.625 724.544 243.829 755.703 236.604Z",
  "M786.552 214.841C843.589 201.613 896.161 193.78 935.041 191.802C954.49 190.812 970.463 191.291 981.841 193.271C987.534 194.262 992.016 195.618 995.195 197.316C998.379 199.017 1000.12 200.983 1000.62 203.139C1001.12 205.295 1000.42 207.826 998.311 210.755C996.204 213.679 992.777 216.87 988.101 220.265C978.756 227.051 964.624 234.51 946.725 242.182C910.942 257.518 860.289 273.625 803.252 286.852C746.215 300.08 693.643 307.912 654.762 309.89C635.313 310.88 619.34 310.402 607.963 308.422C602.269 307.431 597.787 306.075 594.609 304.377C591.424 302.676 589.684 300.71 589.184 298.553C588.684 296.397 589.381 293.867 591.492 290.938C593.599 288.014 597.027 284.824 601.703 281.428C611.047 274.642 625.18 267.182 643.079 259.51C678.861 244.174 729.515 228.068 786.552 214.841Z",
  "M789.593 204.862C869.744 186.274 943.631 175.265 998.287 172.484C1025.62 171.093 1048.1 171.763 1064.13 174.552C1072.15 175.948 1078.49 177.864 1083.01 180.278C1087.54 182.695 1090.1 185.534 1090.84 188.724C1091.58 191.914 1090.53 195.59 1087.53 199.752C1084.53 203.909 1079.68 208.423 1073.09 213.205C1059.93 222.765 1040.04 233.26 1014.88 244.042C964.581 265.602 893.39 288.237 813.239 306.825C733.089 325.412 659.203 336.421 604.546 339.202C577.21 340.593 554.733 339.923 538.704 337.134C530.685 335.738 524.341 333.822 519.822 331.408C515.296 328.99 512.736 326.151 511.996 322.961C511.257 319.771 512.306 316.096 515.305 311.933C518.301 307.777 523.154 303.263 529.74 298.481C542.905 288.921 562.793 278.426 587.951 267.643C638.253 246.084 709.443 223.449 789.593 204.862Z",
  "M769.648 200.058C867.647 177.331 958.161 164.61 1025.27 162.405C1058.83 161.303 1086.49 162.832 1106.29 167.033C1116.19 169.133 1124.07 171.89 1129.72 175.28C1135.38 178.669 1138.71 182.628 1139.75 187.111C1140.79 191.594 1139.54 196.617 1135.95 202.149C1132.37 207.682 1126.51 213.625 1118.54 219.87C1102.61 232.355 1078.45 245.902 1047.83 259.684C986.6 287.243 899.726 315.659 801.728 338.386C703.729 361.112 613.215 373.834 546.104 376.038C512.54 377.141 484.883 375.611 465.086 371.411C455.185 369.31 447.308 366.552 441.652 363.163C435.998 359.774 432.66 355.815 431.62 351.332C430.581 346.849 431.835 341.825 435.421 336.294C439.008 330.761 444.867 324.818 452.833 318.574C468.76 306.089 492.921 292.542 523.544 278.76C584.775 251.201 671.65 222.784 769.648 200.058Z",
  "M757.356 196.605C878.212 168.578 989.834 152.845 1072.59 150.055C1113.98 148.661 1148.1 150.505 1172.53 155.644C1184.75 158.214 1194.48 161.598 1201.48 165.771C1208.48 169.944 1212.64 174.844 1213.94 180.428C1215.23 186.012 1213.65 192.245 1209.2 199.072C1204.76 205.9 1197.5 213.223 1187.66 220.908C1167.99 236.275 1138.17 252.948 1100.39 269.913C1024.85 303.834 917.696 338.837 796.84 366.864C675.984 394.891 564.361 410.625 481.601 413.415C440.213 414.809 406.095 412.964 381.666 407.825C369.449 405.255 359.713 401.872 352.714 397.699C345.715 393.526 341.551 388.625 340.256 383.041C338.961 377.458 340.544 371.225 344.991 364.398C349.439 357.57 356.692 350.246 366.531 342.561C386.204 327.194 416.027 310.522 453.805 293.557C529.346 259.635 636.499 224.632 757.356 196.605Z",
  "M756.72 189.953C903.724 155.861 1039.6 137.165 1140.45 134.488C1190.88 133.148 1232.49 135.817 1262.33 142.544C1277.26 145.908 1289.18 150.275 1297.79 155.623C1306.38 160.969 1311.58 167.238 1313.24 174.394C1314.9 181.55 1312.99 189.465 1307.62 198.051C1302.25 206.639 1293.47 215.808 1281.55 225.398C1257.71 244.574 1221.52 265.287 1175.65 286.28C1083.92 328.261 953.681 371.28 806.677 405.372C659.673 439.463 523.793 458.159 422.951 460.837C372.522 462.176 330.908 459.506 301.064 452.779C286.14 449.415 274.215 445.049 265.613 439.701C257.013 434.355 251.82 428.085 250.16 420.929C248.501 413.773 250.405 405.859 255.773 397.273C261.144 388.685 269.929 379.515 281.849 369.925C305.687 350.749 341.878 330.037 387.749 309.044C479.476 267.063 609.716 224.044 756.72 189.953Z",
  "M754.831 184.006C931.159 143.114 1094.22 120.975 1215.29 118.228C1275.84 116.854 1325.83 120.331 1361.72 128.711C1379.67 132.902 1394.03 138.307 1404.41 144.904C1414.79 151.498 1421.11 159.228 1423.16 168.065C1425.21 176.902 1422.94 186.627 1416.52 197.117C1410.1 207.61 1399.58 218.785 1385.31 230.447C1356.77 253.768 1313.41 278.895 1258.44 304.31C1148.52 355.134 992.362 407.023 816.034 447.915C639.707 488.807 476.65 510.945 355.576 513.692C295.03 515.066 245.036 511.589 209.146 503.208C191.2 499.018 176.836 493.614 166.452 487.017C156.073 480.423 149.751 472.691 147.702 463.854C145.652 455.018 147.926 445.293 154.344 434.804C160.764 424.31 171.283 413.135 185.553 401.473C214.091 378.151 257.452 353.025 312.422 327.61C422.347 276.787 578.504 224.897 754.831 184.006Z",
  "M756.848 176.44C965.734 127.998 1159.1 102.62 1302.86 100.74C1374.75 99.7997 1434.17 104.736 1476.92 115.575C1498.29 120.994 1515.44 127.876 1527.88 136.197C1540.32 144.515 1547.98 154.223 1550.55 165.294C1553.12 176.366 1550.51 188.457 1543 201.399C1535.49 214.346 1523.12 228.073 1506.32 242.347C1472.71 270.893 1421.52 301.482 1356.55 332.278C1226.64 393.864 1041.84 456.186 832.957 504.628C624.07 553.07 430.703 578.448 286.945 580.328C215.057 581.269 155.63 576.333 112.886 565.494C91.512 560.075 74.3635 553.193 61.923 544.872C49.488 536.555 41.8225 526.846 39.2548 515.775C36.6872 504.703 39.2975 492.612 46.8023 479.671C54.3105 466.723 66.6797 452.996 83.4862 438.722C117.097 410.176 168.286 379.587 233.249 348.79C363.161 287.205 547.961 224.883 756.848 176.44Z",
];

const ORBIT_DELAYS = [0, 0.35, 0.70, 1.05, 1.40, 1.75, 2.10, 2.45];
const ORBIT_DURATIONS = [0.45, 0.5, 0.6, 0.65, 0.75, 0.85, 0.95, 1.05];
const PLANETS_APPEAR_MS = 3700;

// Figma canvas — matches Orbit.svg exactly
const SVG_W = 1590;
const SVG_H = 682;
// Orbit center: innermost path7 bounding-box midpoint in Figma space
const CX = 760;
const CY = 256;
interface PlanetDef {
  id: string;
  name: string;
  color: string;
  size: number;
  orbitIndex: number;
  // 0–1 fraction along the actual SVG path stroke.
  // Near (visible) arc is roughly 0.05–0.45 for all orbits.
  // 0.05 ≈ right side, 0.25 ≈ bottom, 0.40 ≈ lower-left.
  // Tune this value to slide the planet along its ring.
  pathOffset: number;
  icon: React.ComponentType<{ className?: string }>;
}

const planets: PlanetDef[] = [
  // pathOffset: 0–1 along the actual orbit path stroke.
  // Right arc  ≈ 0.05–0.42  (bottom-right visible arc)
  // Left arc   ≈ 0.58–0.88  (bottom-left visible arc)
  // Tune per planet to slide it along its ring.

  // Orbit 1: 2 planets — one each side
  { id: 'cafeteria', name: 'Cafeteria', color: '#ef4444', size: 50, orbitIndex: 1, pathOffset: 0.22, icon: Coffee },
  { id: 'payslip', name: 'Payslip', color: 'hsl(280 70% 55%)', size: 48, orbitIndex: 1, pathOffset: 0.72, icon: FileText },

  // Orbit 2: 1 planet — right side, pulled down
  { id: 'effort', name: 'Effort', color: 'hsl(142 76% 42%)', size: 50, orbitIndex: 2, pathOffset: 0.28, icon: Briefcase },

  // Orbit 3: 4 planets — 2 right (lower), 2 left
  { id: 'gym', name: 'Gym', color: 'hsl(10 80% 58%)', size: 50, orbitIndex: 3, pathOffset: 0.36, icon: Dumbbell },
  { id: 'courses', name: 'Courses', color: 'hsl(320 75% 58%)', size: 50, orbitIndex: 6, pathOffset: 0.80, icon: BookOpen },
  { id: 'parking', name: 'Parking', color: 'hsl(240 75% 58%)', size: 48, orbitIndex: 3, pathOffset: 0.80, icon: Car },

  // Orbit 4: 3 planets — 2 right (lower), 1 left
  { id: 'jkl', name: 'JKL', color: 'hsl(260 80% 58%)', size: 52, orbitIndex: 4, pathOffset: 0.28, icon: GraduationCap },
  { id: 'projects', name: 'Projects', color: 'hsl(30 85% 52%)', size: 52, orbitIndex: 4, pathOffset: 0.46, icon: Briefcase },
  { id: 'banner', name: 'News', color: 'hsl(20 85% 58%)', size: 46, orbitIndex: 5, pathOffset: 0.54, icon: Megaphone },

  // Orbit 5: 4 planets — 2 right (lower), 2 left
  { id: 'certifications', name: 'Badges', color: 'hsl(40 90% 55%)', size: 48, orbitIndex: 5, pathOffset: 0.20, icon: Award },
  { id: 'watchlist', name: 'Watchlist', color: 'hsl(180 75% 50%)', size: 48, orbitIndex: 4, pathOffset: 0.72, icon: Eye },
  { id: 'music', name: 'Music', color: 'hsl(340 80% 58%)', size: 46, orbitIndex: 7, pathOffset: 0.59, icon: Music },
  { id: 'blogs', name: 'Blogs', color: 'hsl(100 70% 50%)', size: 50, orbitIndex: 5, pathOffset: 0.80, icon: FileText },

  // Orbit 6: 5 planets — 3 right (spread lower), 2 left
  { id: 'bob', name: 'Benefits', color: 'hsl(205 100% 40%)', size: 52, orbitIndex: 6, pathOffset: 0.28, icon: DollarSign },
  { id: 'seatbooking', name: 'Seat', color: 'hsl(220 75% 58%)', size: 52, orbitIndex: 6, pathOffset: 0.28, icon: Armchair },
  { id: 'travel', name: 'Travel', color: 'hsl(55 85% 52%)', size: 48, orbitIndex: 6, pathOffset: 0.40, icon: Plane },
  { id: 'holidays', name: 'Holidays', color: 'hsl(280 75% 58%)', size: 48, orbitIndex: 6, pathOffset: 0.66, icon: Gift },
  { id: 'community', name: 'Community', color: 'hsl(160 70% 50%)', size: 48, orbitIndex: 3, pathOffset: 0.65, icon: MessageSquare },

  // Orbit 7 — outermost: 3 planets — 2 right (lower), 1 left
  { id: 'meetings', name: 'Meetings', color: 'hsl(200 75% 52%)', size: 50, orbitIndex: 7, pathOffset: 0.45, icon: Calendar },
  { id: 'wayfinder', name: 'WayFinder', color: 'hsl(120 70% 50%)', size: 50, orbitIndex: 7, pathOffset: 0.22, icon: NavigationIcon },
  { id: 'entryexit', name: 'Entry/Exit', color: 'hsl(160 75% 48%)', size: 50, orbitIndex: 7, pathOffset: 0.38, icon: LogIn },
  { id: 'contacts', name: 'Contacts', color: 'hsl(200 80% 55%)', size: 48, orbitIndex: 7, pathOffset: 0.74, icon: MessageSquare },
];

export const SolarSystem = ({
  isShifted = false,
  onPlanetSelect,
}: {
  isShifted?: boolean;
  onPlanetSelect?: () => void;
}) => {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const [selectedPlanet, setSelectedPlanet] = useState<string | null>(null);
  const [activePlanets, setActivePlanets] = useState<string[]>([]);
  const [planetsVisible, setPlanetsVisible] = useState(false);

  // Responsive scale: fit the 1590×682 canvas to the available space.
  // Scales DOWN on small screens, UP on large ones (capped at 1.5×).
  // Uses whichever axis is tighter — width or viewport height — so it
  // never overflows either dimension.
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [topOffset, setTopOffset] = useState(0);
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const w = el.getBoundingClientRect().width;
      const h = window.innerHeight;
      const byWidth = (w / SVG_W) * 0.88;   // 0.88 leaves ~6% breathing room each side
      const byHeight = h / SVG_H;
      const s = Math.min(byWidth, byHeight, 1.5);
      setScale(s);
      // Keep avatar centred and ensure the name text never gets clipped at the top.
      // TEXT_Y  = canvas y of the name line (CY - 216 = 40 px from canvas top)
      // AVATAR_Y = canvas y of avatar centre after upward shift (CY - 82)
      const TEXT_Y = CY - 216;
      const AVATAR_Y = CY - 82;
      const byCentering = (SVG_H * s) * 0.5 - AVATAR_Y * s;  // centres avatar in container
      const byTextMargin = 20 - TEXT_Y * s;                    // keeps ≥20 px above text
      setTopOffset(Math.round(Math.max(0, byCentering, byTextMargin)));
    };
    update();
    const obs = new ResizeObserver(update);
    obs.observe(el);
    window.addEventListener("resize", update);
    return () => { obs.disconnect(); window.removeEventListener("resize", update); };
  }, []);

  // Refs to the 8 rendered orbit <path> elements so we can call getPointAtLength().
  const orbitRefs = useRef<(SVGPathElement | null)[]>(Array(8).fill(null));

  // Exact pixel positions of each planet, sampled from the real SVG path geometry.
  // Default to orbit center until the DOM is mounted and refs are available.
  const [planetPositions, setPlanetPositions] = useState<{ x: number; y: number }[]>(
    () => planets.map(p => ({ x: ORBITS[p.orbitIndex].cx, y: ORBITS[p.orbitIndex].cy }))
  );

  useEffect(() => {
    setPlanetPositions(
      planets.map(p => {
        const el = orbitRefs.current[p.orbitIndex];
        if (!el) return { x: ORBITS[p.orbitIndex].cx, y: ORBITS[p.orbitIndex].cy };
        // getPointAtLength uses actual geometric length regardless of pathLength="1"
        const len = el.getTotalLength();
        const pt = el.getPointAtLength(p.pathOffset * len);
        return { x: pt.x, y: pt.y };
      })
    );
  }, []);

  useEffect(() => {
    const fetchServices = async () => {
      try {

        const res = await fetch(`${API_BASE_URL}/api/services`);
        const data = await res.json();
        if (data.services) {
          setActivePlanets(data.services.map((s: { id: string }) => s.id));
        }
      } catch {
        setActivePlanets(["cafeteria", "entryexit", "community", "travel", "seatbooking", "banner"]);
      }
    };
    fetchServices();
  }, []);

  // Reveal planets after orbit draw-in animation finishes
  useEffect(() => {
    const t = setTimeout(() => setPlanetsVisible(true), PLANETS_APPEAR_MS);
    return () => clearTimeout(t);
  }, []);

  // Lock background scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = selectedPlanet ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [selectedPlanet]);

  const displayName = user?.name || `Employee ${user?.employeeNumber || ""}`;
  const employeeId = user?.employeeNumber || "";
  const entityName = user?.entityName || "Bosch";

  const renderPlanetCard = () => {
    switch (selectedPlanet) {
      case "bob": return <BoBCard />;
      case "leave": return <LeaveCard />;
      case "effort": return <EffortBookingCard />;
      case "jkl": return <JKLCard />;
      case "travel": return <TravelCard />;
      case "cafeteria": return <CafeteriaCard />;
      case "payslip": return <PayslipCard />;
      case "projects": return <ProjectsCard />;
      case "meetings": return <MeetingsCard />;
      case "courses": return <CoursesCard />;
      case "certifications": return <CertificationsCard />;
      case "community": return <CommunityCard />;
      case "music": return <MusicCard />;
      case "seatbooking": return <SeatBookingCard />;
      case "contacts": return <VitalContactsCard />;
      case "entryexit": return <EntryExitCard />;
      case "holidays": return <HolidayCalendarCard />;
      case "gym": return <GymCard />;
      case "wayfinder": return <WayFinderCard />;
      case "blogs": return <BlogsCard />;
      case "parking": return <ParkingCard />;
      case "watchlist": return <WatchlistCard />;
      case "banner": return <BannersCard />;
      default: return null;
    }
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative w-full overflow-hidden transition-transform duration-500",
        isShifted && "-translate-x-48"
      )}
      style={{ height: Math.round(SVG_H * scale + topOffset) + "px" }}
    >
      {/* Scaled inner wrapper — SVG + planet layer share the same transform so
          they always stay in pixel-perfect sync at every container width.
          topOffset shifts the wrapper down on small screens so the avatar
          stays at the vertical midpoint instead of drifting to the top.   */}
      <div
        style={{
          position: "absolute",
          top: topOffset - 90,
          left: "50%",
          width: SVG_W + "px",
          height: SVG_H + "px",
          transform: `translateX(-50%) scale(${scale})`,
          transformOrigin: "top center",
        }}
      >

        {/* ── Orbit lines — exact Figma paths (1590×682 coordinate space) ── */}
        <svg
          width={SVG_W}
          height={SVG_H}
          viewBox={`0 0 ${SVG_W} ${SVG_H}`}
          style={{ position: "absolute", top: 0, left: 0, pointerEvents: "none" }}
          aria-hidden="true"
        >
          <defs>
            {/* Exact gradients from Orbit.svg — paint7 = innermost, paint0 = outermost */}
            <linearGradient id="og7" x1="714.735" y1="238.937" x2="850.469" y2="262.89" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og6" x1="826.516" y1="201.676" x2="863.777" y2="378.663" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og5" x1="877.084" y1="195.023" x2="911.683" y2="269.543" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og4" x1="716.066" y1="226.96" x2="733.365" y2="346.726" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og3" x1="759.98" y1="233.614" x2="813.209" y2="364.025" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og2" x1="696.105" y1="217.645" x2="717.396" y2="454.515" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.430233" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og1" x1="416.651" y1="269.543" x2="476.534" y2="515.729" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.25" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            <linearGradient id="og0" x1="669.49" y1="197.684" x2="950.274" y2="704.692" gradientUnits="userSpaceOnUse">
              <stop stopColor="#16335E" stopOpacity="0" /><stop offset="0.42189" stopColor="#16335E" /><stop offset="1" stopColor="#42758E" />
            </linearGradient>
            {/* Subtle bloom behind each orbit line */}
            <filter id="orbitGlow" x="-10%" y="-50%" width="120%" height="200%">
              <feGaussianBlur stdDeviation="1.2" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            {/* Radial glow: dark pool at avatar center, falls off steeply to near-zero at outer ring */}
            <radialGradient id="orbitGradFill" cx={CX} cy={CY} r="680" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#0d1f3c" stopOpacity="0.80" />
              <stop offset="12%" stopColor="#16335E" stopOpacity="0.60" />
              <stop offset="30%" stopColor="#16335E" stopOpacity="0.32" />
              <stop offset="55%" stopColor="#16335E" stopOpacity="0.10" />
              <stop offset="78%" stopColor="#16335E" stopOpacity="0.02" />
              <stop offset="100%" stopColor="#16335E" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Glow fill — dark mode only; held invisible until all orbit strokes finish (3.5 s) */}
          {isDark && (
            <path d={ORBIT_PATH_DATA[7]} fill="url(#orbitGradFill)" stroke="none" opacity="0">
              <animate attributeName="opacity" from="0" to="1"
                dur="1s" begin="3.5s" fill="freeze" />
            </path>
          )}

          {/* 8 exact Figma paths — innermost first (rendered behind), draw-in via pathLength=1 */}
          <g filter="url(#orbitGlow)">
            {ORBIT_PATH_DATA.map((d, i) => (
              <path
                key={i}
                ref={(el) => { orbitRefs.current[i] = el; }}
                d={d}
                stroke={`url(#og${7 - i})`}
                fill="none"
                strokeWidth="2"
                pathLength="1"
                strokeDasharray="1"
                strokeDashoffset="1"
                opacity="0"
              >
                <animate attributeName="stroke-dashoffset" from="1" to="0"
                  dur={`${ORBIT_DURATIONS[i]}s`} begin={`${ORBIT_DELAYS[i]}s`} fill="freeze" />
                <animate attributeName="opacity" from="0" to="1"
                  dur="0.3s" begin={`${ORBIT_DELAYS[i]}s`} fill="freeze" />
              </path>
            ))}
          </g>
        </svg>

        {/* ── Planets + center avatar — same 1590×682 coordinate space ── */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: SVG_W + "px",
            height: SVG_H + "px",
          }}
        >
          {/* User info — sits just above the profile circle (CY - half avatar - gap) */}
          <div
            className="absolute z-30 text-center whitespace-nowrap"
            style={{ top: (CY - 44 - 52 - 153) + "px", left: CX + "px", transform: "translateX(-50%)" }}
          >
            <h2 className={cn("text-[2.3rem] font-bold tracking-wide", isDark ? "text-[#E0E2E5]" : "text-black")}>{displayName}</h2>
            <p className={cn("text-base mt-1", isDark ? "text-green-400" : "text-green-700")}>{employeeId} | {entityName} • Bangalore</p>
          </div>

          {/* Center: Eclipse + profile avatar */}
          <div
            className="absolute z-20"
            style={{
              left: CX + "px",
              top: (CY - 82) + "px",
              transform: "translate(-50%, -50%)",
              pointerEvents: "none",
            }}
          >
            {/* Upper-right corona burst */}
            <img
              src="/Glow.png"
              alt=""
              aria-hidden="true"
              style={{
                position: "absolute",
                width: "160px",
                height: "160px",
                minWidth: "160px",
                minHeight: "160px",
                top: "-83px",
                left: "-78px",
                mixBlendMode: "screen",
                pointerEvents: "none",
                animation: "glowFadeIn 1.2s ease-out 0.8s both",
              }}
            />

            {/* Profile avatar — gold base ring + liquid glass dark overlay */}
            <div
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                width: "108px",
                height: "108px",
                borderRadius: "50%",
                // Gold conic gradient — the warm base that shows through the glass
                background: "conic-gradient(from 205deg at 50% 50%, #5c3800 0deg, #8a5500 30deg, #c98500 65deg, #e9aa28 98deg, #ffd96a 122deg, #e9aa28 146deg, #c48200 178deg, #8a5800 215deg, #6a4200 252deg, #5c3800 288deg, #6a4200 322deg, #8a5500 352deg, #5c3800 360deg)",
                boxShadow: "0 0 32px rgba(220,135,0,0.75), 0 0 80px rgba(180,85,0,0.32)",
                zIndex: 2,
                animation: "eclipseAppear 1.2s cubic-bezier(0.34,1.56,0.64,1) both",
              }}
            >
              {/* Inner avatar circle — sits behind the glass overlay via z-index */}
              <div
                style={{
                  position: "absolute",
                  inset: "12px",           // 12 px ring on every side
                  borderRadius: "50%",
                  background: isDark ? "#0a0a0a" : "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  // Thin gold seam at the ring/circle junction
                  border: "1px solid rgba(200,140,20,0.50)",
                  boxShadow: "inset 0 2px 10px rgba(0,0,0,0.88)",
                  zIndex: 1,
                }}
              >
                <User
                  style={{
                    width: "44px",
                    height: "44px",
                    color: isDark ? "rgba(255,255,255,0.90)" : "rgba(0,0,0,0.80)",
                    strokeWidth: 1.5,
                  }}
                />
              </div>

              {/* Liquid glass overlay — covers the ring only (transparent over avatar).
                Dark semi-transparent black sits on top of gold → liquid glass look.
                Specular highlight arc at top-left simulates glass catching light. */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  borderRadius: "50%",
                  background: [
                    // Primary specular: bright arc top-left (glass catching light)
                    "radial-gradient(circle at 30% 26%, rgba(255,248,200,0.30) 0%, transparent 42%)",
                    // Secondary specular: faint sweep on right edge
                    "radial-gradient(circle at 78% 68%, rgba(255,220,80,0.10) 0%, transparent 35%)",
                    // Dark glass on ring: transparent center, dark from 74% outward
                    "radial-gradient(circle at 50% 50%, transparent 73%, rgba(0,0,0,0.82) 76%, rgba(2,1,0,0.70) 100%)",
                  ].join(", "),
                  border: "1px solid rgba(255,255,255,0.14)",   // glass edge definition
                  boxShadow: [
                    "inset 0 0 0 1.5px rgba(255,210,80,0.22)", // outer rim gold seam
                    "inset 0 6px 12px rgba(255,235,140,0.28)", // top inner glass glow
                    "inset 0 -6px 10px rgba(0,0,0,0.90)",      // bottom depth shadow
                    "inset 0 0 18px rgba(0,0,0,0.40)",         // ambient inner darkness
                  ].join(", "),
                  pointerEvents: "none",
                  zIndex: 3,
                }}
              />
            </div>
          </div>

          <style>{`
          @keyframes glowFadeIn {
            0%   { opacity: 0; transform: scale(0.7); }
            100% { opacity: 0.95; transform: scale(1); }
          }
          @keyframes glowFadeInBelow {
            0%   { opacity: 0; transform: scale(0.7); }
            100% { opacity: 0.60; transform: scale(1); }
          }
          @keyframes eclipseAppear {
            0%   { opacity: 0; transform: translate(-50%, -50%) scale(0.3); }
            60%  { opacity: 1; transform: translate(-50%, -50%) scale(1.08); }
            100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
          }
          @keyframes planetFloat {
            0%, 100% { transform: translate(-50%, -50%) translateY(0px); }
            50%       { transform: translate(-50%, -50%) translateY(-5px); }
          }
        `}</style>

          {/* Planets — fixed positions, fade in after orbits draw */}
          {planets.map((planet, idx) => {
            const pos = planetPositions[idx];
            const isActive = activePlanets.includes(planet.id) ||
              (planet.id === "cafeteria" && activePlanets.includes("canteen")) ||
              (planet.id === "canteen" && activePlanets.includes("cafeteria"));
            const Icon = planet.icon;
            const floatDelay = (idx * 0.7) % 6;

            return (
              <div
                key={planet.id}
                className={cn(
                  "absolute group z-10",
                  isActive ? "cursor-pointer" : "cursor-not-allowed"
                )}
                style={{
                  left: pos.x + "px",
                  top: pos.y + "px",
                  transform: "translate(-50%, -50%)",
                  opacity: planetsVisible ? (isActive ? 1 : 0.32) : 0,
                  transition: "opacity 0.8s ease",
                  overflow: "visible",
                  animation: planetsVisible && isActive
                    ? `planetFloat ${5 + (idx % 3)}s ease-in-out ${floatDelay}s infinite`
                    : undefined,
                }}
                onClick={() => {
                  if (!isActive) return;
                  logger.logButtonClick(`planet-${planet.id}`, planet.name, {
                    planetId: planet.id,
                    planetName: planet.name,
                    action: "planet-click",
                  });
                  setSelectedPlanet(planet.id);
                  onPlanetSelect?.();
                }}
                onKeyDown={(e) => {
                  if ((e.key === "Enter" || e.key === " ") && isActive) {
                    setSelectedPlanet(planet.id);
                    onPlanetSelect?.();
                  }
                }}
                tabIndex={isActive ? 0 : -1}
                role="button"
                aria-label={planet.name}
              >
                {/* Glow.png corona — renders behind planet via DOM order, shown on hover */}
                {isActive && (
                  <img
                    src="/Glow.png"
                    alt=""
                    aria-hidden="true"
                    className="absolute pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      width: planet.size * 2 + "px",
                      height: planet.size * 2 + "px",
                      minWidth: planet.size * 2 + "px",
                      minHeight: planet.size * 2 + "px",
                      left: "50%",
                      top: "50%",
                      transform: "translate(-50%, -50%)",
                      mixBlendMode: "screen",
                      flexShrink: 0,
                    }}
                  />
                )}

                {/* Planet button — active: conic arc border; inactive: simple border */}
                {isActive ? (
                  <div
                    className={cn(
                      "rounded-full transition-all duration-300",
                      "group-hover:scale-125 group-focus:scale-125",
                      selectedPlanet === planet.id && "scale-125"
                    )}
                    style={{
                      // Two opposing arcs: bright upper-left (~310°) + dim lower-right (~125°)
                      // Non-arc zones use planet.color so no dark gap shows through the 2px wrapper
                      background: `conic-gradient(from 0deg, ${planet.color} 0deg, ${planet.color} 85deg, rgba(255,255,255,0.45) 110deg, rgba(255,255,255,0.45) 155deg, ${planet.color} 180deg, ${planet.color} 265deg, rgba(255,255,255,0.90) 290deg, rgba(255,255,255,0.90) 335deg, ${planet.color} 360deg)`,
                      padding: "2px",
                      width: (planet.size + 4) + "px",
                      height: (planet.size + 4) + "px",
                      // boxShadow: `0 0 10px rgba(255,255,255,0.4), 0 4px 20px ${planet.color}55`,
                      zIndex: 1,
                    }}
                  >
                    <div
                      className="rounded-full flex items-center justify-center"
                      style={{
                        background: planet.color,
                        backdropFilter: "blur(10px) saturate(150%)",
                        WebkitBackdropFilter: "blur(10px) saturate(150%)",
                        width: planet.size + "px",
                        height: planet.size + "px",
                      }}
                    >
                      <Icon className="w-5 h-5 text-white drop-shadow" />
                    </div>
                  </div>
                ) : (
                  <div
                    className="rounded-full"
                    style={{
                      background: "conic-gradient(from 0deg, rgba(70,70,80,0.45) 0deg, rgba(70,70,80,0.45) 85deg, rgba(255,255,255,0.28) 110deg, rgba(255,255,255,0.28) 155deg, rgba(70,70,80,0.45) 180deg, rgba(70,70,80,0.45) 265deg, rgba(255,255,255,0.55) 290deg, rgba(255,255,255,0.55) 335deg, rgba(70,70,80,0.45) 360deg)",
                      padding: "2px",
                      width: (planet.size + 4) + "px",
                      height: (planet.size + 4) + "px",
                      zIndex: 1,
                    }}
                  >
                    <div
                      className="rounded-full flex items-center justify-center"
                      style={{
                        background: "rgba(70,70,80,0.45)",
                        backdropFilter: "blur(10px) saturate(150%)",
                        WebkitBackdropFilter: "blur(10px) saturate(150%)",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.4)",
                        width: planet.size + "px",
                        height: planet.size + "px",
                      }}
                    >
                      <Icon className="w-5 h-5 text-white drop-shadow" />
                    </div>
                  </div>
                )}

                {/* Hover-only label above planet */}
                <div className="absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 whitespace-nowrap pointer-events-none z-30 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <span
                    className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                    style={{
                      color: "rgba(255,255,255,0.9)",
                      background: "rgba(0,0,0,0.55)",
                      backdropFilter: "blur(8px)",
                      WebkitBackdropFilter: "blur(8px)",
                    }}
                  >
                    {planet.name}{!isActive && " (Soon)"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>{/* end scaled inner wrapper */}

      {/* ── Planet card modal ── */}
      {selectedPlanet &&
        createPortal(
          ["travel", "seatbooking"].includes(selectedPlanet) ? (
            // Fixed bottom panel — same position/height as ChatWindow
            <>
              {/* Transparent backdrop — click outside to close */}
              <div
                className="fixed inset-0 z-[199]"
                role="button"
                tabIndex={0}
                onClick={() => setSelectedPlanet(null)}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setSelectedPlanet(null); }}
              />
              <div
                style={{
                  position: "fixed",
                  bottom: "70px",
                  left: 0,
                  right: 0,
                  display: "flex",
                  justifyContent: "center",
                  zIndex: 200,
                  padding: "0 16px",
                  pointerEvents: "none",
                }}
                onKeyDown={(e) => e.key === "Escape" && setSelectedPlanet(null)}
              >
                <div
                  className="animate-scale-in relative"
                  style={{
                    width: "clamp(620px, 55vw, 1080px)",
                    height: "clamp(420px, calc(100svh - 150px), 860px)",
                    pointerEvents: "auto",
                  }}
                >
                  <button
                    onClick={() => setSelectedPlanet(null)}
                    className="absolute top-3 right-3 z-30 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 backdrop-blur-sm shadow-sm"
                    style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}
                    aria-label="Close card"
                  >
                    <X
                      className="w-3.5 h-3.5"
                      style={{ color: isDark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)" }}
                    />
                  </button>
                  {renderPlanetCard()}
                </div>
              </div>
            </>
          ) : (
            // Centered modal — all other cards
            <div
              className="fixed inset-0 flex items-center justify-center z-[200] p-4 transition-colors duration-300"

              onClick={() => setSelectedPlanet(null)}
              onKeyDown={(e) => e.key === "Escape" && setSelectedPlanet(null)}
            >
              <div
                className="relative max-w-2xl w-full max-h-[85vh] overflow-y-auto animate-scale-in custom-scrollbar rounded-3xl"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
                role="presentation"
              >
                <div className="sticky top-2 right-2 z-20 flex justify-end px-[1.5rem] pointer-events-none mb-[-2rem]">
                  <button
                    onClick={() => setSelectedPlanet(null)}
                    className="w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 pointer-events-auto backdrop-blur-sm shadow-sm"
                    style={{ background: isDark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}
                    aria-label="Close card"
                  >
                    <X
                      className="w-3.5 h-3.5"
                      style={{ color: isDark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)" }}
                    />
                  </button>
                </div>
                {renderPlanetCard()}
              </div>
            </div>
          ),
          document.body
        )}
    </div>
  );
};
