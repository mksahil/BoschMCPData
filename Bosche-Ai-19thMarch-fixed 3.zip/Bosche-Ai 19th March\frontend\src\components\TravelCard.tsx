import { useState, useRef, useEffect, useCallback } from "react";
import { useTheme } from "next-themes";
import { Plane, Send, Sparkles, MicOff, ThumbsUp, ThumbsDown, ShieldAlert, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { API_ENDPOINTS } from "@/config";
import { useAuth } from "@/context/AuthContext";
import { cn, generateUUID, renderMarkdown } from "@/lib/utils";
import { checkSensitivity } from "@/lib/privacy-utils";
import { useRateLimit } from "@/hooks/useRateLimit";
import { RateLimitBanner } from "./RateLimitBanner";
import {
  getGlassContainerStyles,
  getGlassArcBorderStyles,
  getGlassSpecularStyles,
} from "@/lib/glassStyles";
import { useViewportWidth } from "@/hooks/useViewportWidth";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  feedback?: 1 | -1;
  isOutOfScope?: boolean;
  isBlocked?: boolean;
}

export const TravelCard = () => {
  const { user } = useAuth();
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Hi! I'm your AI Travel Assistant. I can help you with:\n\n• Plan business trips and book travel\n• Check travel expense status\n• Submit settlement for completed trips\n• View travel history and upcoming trips\n\nWhat would you like to do today?", timestamp: new Date() }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => `travel-${generateUUID()}`);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const { isRateLimited, retryAfter, handleRateLimitResponse } = useRateLimit();
  const [isListening, setIsListening] = useState(false);
  const [isSpeechRecognitionSupported, setIsSpeechRecognitionSupported] = useState(true);
  const [sensitivityWarning, setSensitivityWarning] = useState<{ isSensitive: boolean, level: 'high' | 'low' | 'none', category: string | null }>({ isSensitive: false, level: 'none', category: null });

  useEffect(() => {
    if (chatInput.trim().length > 0) {
      setSensitivityWarning(checkSensitivity(chatInput));
    } else {
      setSensitivityWarning({ isSensitive: false, level: 'none', category: null });
    }
  }, [chatInput]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setIsSpeechRecognitionSupported(false);
    }
  }, []);

  const toggleVoice = useCallback(() => {
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
      return;
    }
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const isFirefox = typeof window !== 'undefined' && /Firefox/.test(navigator.userAgent);
      toast.error(isFirefox ? 'Voice input is not supported in Firefox.' : 'Speech recognition is not supported in your browser.');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setChatInput(prev => prev ? prev + ' ' + transcript : transcript);
      toast.success('Voice captured!');
    };
    recognition.onerror = (event: any) => {
      toast.error(event.error === 'not-allowed' ? 'Microphone access denied.' : 'Voice input failed.');
      setIsListening(false);
    };
    recognition.onend = () => {
      setIsListening(false);
      recognitionRef.current = null;
    };
    recognitionRef.current = recognition;
    recognition.start();
  }, [isListening]);

  const handleFeedback = (index: number, value: 1 | -1) => {
    setChatMessages(prev => prev.map((msg, i) =>
      i === index ? { ...msg, feedback: value } : msg
    ));
    toast.success(value === 1 ? 'Thanks for the positive feedback!' : 'Thanks for your feedback, we will improve.');
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSendMessage = async () => {
    if (!chatInput.trim() || isLoading) return;

    const userMessage = chatInput.trim();
    setChatMessages(prev => [...prev, { role: "user", content: userMessage, timestamp: new Date() }]);
    setChatInput("");
    setIsLoading(true);

    // Build conversation history for context
    const conversationHistory = chatMessages.slice(1).map(msg => ({
      role: msg.role,
      content: `travel: ${msg.content}` // Prefix both user and assistant
    }));

    try {
      const response = await fetch(API_ENDPOINTS.chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': user?.accessToken ? `Bearer ${user.accessToken}` : '',
          'X-Employee-Number': user?.employeeNumber || '',
        },
        body: JSON.stringify({
          query: `travel: I am providing details for my own travel booking: ${userMessage}`,
          service: "travel", // Explicit service hint
          sessionId,
          employeeNumber: user?.employeeNumber || '',
          userName: user?.name || '',
          conversationHistory
        })
      });

      const data = await response.json();

      if (response.status === 429) {
        handleRateLimitResponse(response, data);
        // RateLimitBanner renders below the chat area — no message push needed
      } else {
        setChatMessages(prev => [...prev, {
          role: "assistant",
          content: data.response || "I couldn't process that request. Please try again.",
          timestamp: new Date(),
          isOutOfScope: !!data.isOutOfScope,
          isBlocked: data.service === 'privacy_guard'
        }]);
      }
    } catch (error) {
      setChatMessages(prev => [...prev, {
        role: "assistant",
        content: "Sorry, I'm having trouble connecting. Please try again.",
        timestamp: new Date()
      }]);
    }

    setIsLoading(false);
  };

  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const viewportWidth = useViewportWidth();

  return (
    <div
      className="rounded-3xl transition-all duration-300 ease-out"
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
      }}
    >
      {isDark && <div style={getGlassArcBorderStyles()} />}
      <div
        className="flex flex-col rounded-3xl overflow-hidden shadow-2xl"
        style={{
          height: "100%",
          position: "relative",
          zIndex: 2,
          ...getGlassContainerStyles(isDark, viewportWidth),
        }}
      >
        {/* Specular top-reflection — dark mode only */}
        {isDark && <div style={getGlassSpecularStyles()} />}

        {/* Drag handle (grabber pill) for visual consistency */}
        <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
          <div
            className="w-10 h-1 rounded-full"
            style={{ background: isDark ? "rgba(255, 255, 255, 0.25)" : "rgba(0, 0, 0, 0.15)" }}
          />
        </div>

        {/* Header */}
        <div className="relative flex items-center justify-center px-5 py-4 flex-shrink-0  min-h-[56px]">
          <h3 className="font-bold text-sm tracking-wide text-foreground text-center drop-shadow-sm">
            AI Travel Assistant
          </h3>
        </div>

        {/* Messages */}
        <div className="flex-1 px-4 py-4 overflow-y-auto space-y-5 custom-scrollbar min-h-0">
          {chatMessages.map((msg, idx) => (
            <div key={idx} className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}>
              {msg.role === "assistant" && (
                <div className={cn(
                  "w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5",
                  msg.isOutOfScope ? "bg-amber-500/20 ring-1 ring-amber-500/50" : "bg-black"
                )}>
                  {msg.isOutOfScope
                    ? <ShieldAlert className="w-4 h-4 text-amber-500" />
                    : <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
                  }
                </div>
              )}
              <div className="flex flex-col max-w-[78%]">
                <div className="relative">
                  <div style={msg.role === "assistant" ? {
                    position: "absolute", left: "-7px", top: "12px", width: 0, height: 0,
                    borderTop: "6px solid transparent", borderBottom: "6px solid transparent",
                    borderRight: msg.isOutOfScope ? (isDark ? "8px solid rgba(120,53,15,0.3)" : "8px solid rgba(254,243,199,0.9)") : "8px solid rgba(0,0,0,1)",
                  } : {
                    position: "absolute", right: "-7px", top: "12px", width: 0, height: 0,
                    borderTop: "6px solid transparent", borderBottom: "6px solid transparent",
                    borderLeft: "8px solid #0a84ff",
                  }} />
                  <div className="rounded-2xl px-4 py-3" style={
                    msg.role === "user"
                      ? { background: "#0a84ff", color: "#fff" }
                      : msg.isOutOfScope
                        ? { background: isDark ? "rgba(120,53,15,0.3)" : "rgba(254,243,199,0.9)", border: "1px solid rgba(245,158,11,0.5)", color: isDark ? "#fff" : "#000" }
                        : { background: "rgba(0,0,0,1)", color: "#fff" }
                  }>
                    {msg.isOutOfScope && (
                      <div className="flex items-center gap-1.5 mb-2 px-2 py-1 rounded-md bg-amber-500/20 border border-amber-500/30 w-fit">
                        <ShieldAlert className="w-3 h-3 text-amber-500 flex-shrink-0" />
                        <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wide">
                          Outside Supported Scope
                        </span>
                      </div>
                    )}
                    <p className="text-sm leading-relaxed whitespace-pre-line" dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />

                    {(msg.isOutOfScope || msg.isBlocked) && (
                      <div className="mt-3 pt-3 border-t border-white/10 text-xs text-white/60">
                        <span className="font-medium text-amber-500/80">Hint:</span> Don't enter any sensitive personal/ Business critical information.
                      </div>
                    )}

                    <div className={cn(
                      "flex items-center gap-2 mt-2",
                      msg.role === "user" ? "justify-end" : "justify-start"
                    )}>
                      <span className="text-[11px]" style={{ color: "rgba(255,255,255,0.4)" }}>
                        {msg.timestamp?.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                      {msg.role === "assistant" && idx > 0 && !msg.isOutOfScope && (
                        <>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleFeedback(idx, 1); }}
                            disabled={msg.feedback === 1}
                            title="Helpful"
                            className={cn("p-0.5 rounded transition-all duration-200", msg.feedback === 1 ? "text-green-400" : "text-white/30 hover:text-green-400")}
                          >
                            <ThumbsUp className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleFeedback(idx, -1); }}
                            disabled={msg.feedback === -1}
                            title="Not helpful"
                            className={cn("p-0.5 rounded transition-all duration-200", msg.feedback === -1 ? "text-red-400" : "text-white/30 hover:text-red-400")}
                          >
                            <ThumbsDown className="w-3 h-3" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              {msg.role === "user" && (
                <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: "#0a84ff" }}>
                  <img src="/user.svg" alt="You" className="w-5 h-5" />
                </div>
              )}
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3 items-start">
              <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#000000" }}>
                <img src="/chat-bubble-robot.svg" alt="AI" className="w-5 h-5" />
              </div>
              <div className="rounded-2xl px-4 py-3" style={{ background: "rgba(0,0,0,0.90)" }}>
                <div className="flex gap-1 items-center h-4">
                  {[0, 150, 300].map((delay) => (
                    <div key={delay} className="w-2 h-2 rounded-full animate-bounce" style={{ background: "rgba(255,255,255,0.5)", animationDelay: `${delay}ms` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          {isRateLimited && <RateLimitBanner retryAfter={retryAfter} />}
          <div ref={chatEndRef} />
        </div>

        {/* INPUT PILL */}
        <div className="flex-shrink-0 px-4 py-4 relative">
          {sensitivityWarning.isSensitive && sensitivityWarning.level === 'high' && (
            <div className="text-xs text-red-400 font-medium px-4 mb-2 animate-in slide-in-from-bottom-1">
              ⚠️ Sensitive data detected ({sensitivityWarning.category}). Please remove before sending.
            </div>
          )}
          <div className="rounded-full relative z-20" style={{
            background: isDark ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.45)",
            backdropFilter: isDark ? "blur(20px) saturate(160%)" : undefined,
            WebkitBackdropFilter: "blur(20px) saturate(160%)",
            boxShadow: isDark
              ? "0 0 16px rgba(89,83,255,0.22), 0 0 32px rgba(208,38,217,0.12), inset 0 1px 0 rgba(255,255,255,0.10)"
              : "0 0 12px rgba(89,83,255,0.10), 0 0 24px rgba(208,38,217,0.06), inset 0 1px 1px rgba(255,255,255,0.8)",
          }}>
            <div style={{
              position: "absolute", inset: 0, borderRadius: "9999px", padding: "1px",
              background: isDark
                ? "linear-gradient(160deg, rgba(255,255,255,0.28) 0%, rgba(89,83,255,0.35) 40%, rgba(208,38,217,0.18) 70%, rgba(255,255,255,0.04) 100%)"
                : "linear-gradient(160deg, rgba(255,255,255,0.70) 0%, rgba(89,83,255,0.25) 40%, rgba(208,38,217,0.20) 70%, rgba(200,200,215,0.15) 100%)",
              WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
              WebkitMaskComposite: "xor",
              mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
              maskComposite: "exclude",
              pointerEvents: "none",
            }} />
            <div className={cn("flex items-center gap-2 px-4 py-2.5 rounded-full transition-all duration-300", sensitivityWarning.level === 'high' ? "bg-destructive/10 ring-1 ring-destructive/30" : "")} style={{
                background: "transparent",
              }}>
              <div className="flex-shrink-0 flex items-center justify-center opacity-60">
                <img src="/input-chat-star.svg" alt="" className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <input
                  ref={inputRef}
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !isRateLimited && sensitivityWarning.level !== 'high' && handleSendMessage()}
                  placeholder={isRateLimited ? "Too many requests. Please wait…" : "Ask about travel..."}
                  className="w-full border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 focus:outline-none text-sm"
                  style={{ color: isDark ? "rgba(255,255,255,0.9)" : "rgba(0,0,0,0.85)" }}
                  disabled={isLoading || isRateLimited || isListening}
                />
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={toggleVoice}
                  disabled={!isSpeechRecognitionSupported || sensitivityWarning.level === 'high'}
                  title={!isSpeechRecognitionSupported ? "Voice not supported" : isListening ? "Stop listening" : "Voice input"}
                  className={cn(
                    "flex items-center justify-center transition-all duration-200",
                    !isSpeechRecognitionSupported && "opacity-30 cursor-not-allowed",
                    isListening && "animate-pulse"
                  )}
                >
                  {isListening
                    ? <MicOff className="w-5 h-5" style={{ color: "rgba(255,59,48,0.9)" }} />
                    : <img src="/microphone.svg" alt="mic" className="w-5 h-5 opacity-55" />
                  }
                </button>
                <button
                  onClick={handleSendMessage}
                  disabled={!chatInput.trim() || isLoading || isRateLimited || sensitivityWarning.level === 'high'}
                  title={sensitivityWarning.level === 'high' ? "Cannot send sensitive content" : "Send message"}
                  className="flex items-center justify-center transition-all duration-200 hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  <img src="/send.svg" alt="send" className="w-5 h-5" style={{ opacity: chatInput.trim() && !isLoading && sensitivityWarning.level !== 'high' ? 1 : 0.45, filter: chatInput.trim() && !isLoading && sensitivityWarning.level !== 'high' ? "drop-shadow(0 0 4px rgba(89,83,255,0.8))" : "none" }} />
                </button>
              </div>
            </div>
          </div>
          <div className="text-[10px] text-muted-foreground/60 text-center mt-2 pointer-events-none select-none">
            Don't enter any sensitive personal/ Business critical information.
          </div>
        </div>
      </div>
    </div>
  );
};
