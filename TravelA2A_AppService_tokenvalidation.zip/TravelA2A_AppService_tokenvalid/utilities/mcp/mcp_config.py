{
    "mcpservers": {
        "Test_MCP": {
            "command": "streamable-http",
                "args": [
                "http://127.0.0.1:8000/mcp"
            ]
        }
    }
}