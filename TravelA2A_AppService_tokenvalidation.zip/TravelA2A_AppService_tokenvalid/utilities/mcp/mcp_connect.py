"""
MCP Connector - Updated to support auth headers for FastMCP servers
"""

from utilities.mcp.mcp_discovery import MCPDiscovery
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams
from mcp import StdioServerParameters


class MCPConnector:
    """
    Discover MCP servers from a JSON config and return ADK-compatible tool objects.
    
    Supports:
    - Stdio-based MCP servers (local processes)
    - Streamable HTTP MCP servers (like FastMCP with SSE transport)
    - Auth header injection for HTTP-based servers
    """

    def __init__(self, config_file: str = None):
        self.discovery = MCPDiscovery(config_file)
        self._toolsets: list[MCPToolset] = []
        self._tools: list = []

    async def get_tools(
        self, auth: dict | None = None, force_reload: bool = False
    ) -> list:
        """
        Return a flat list of tool objects.
        
        Note: Tools are cached after first load. Auth is only used on initial load
        to avoid anyio task scope issues with reconnecting.
        """
        if force_reload:
            print("🔁 Forcing MCP tool reload to refresh auth headers.")
            await self.close_all()

        # Return cached tools if available (don't reconnect)
        if self._tools:
            return self._tools.copy()

        # First time load
        tools = await self._load_all_tools(auth=auth)
        return tools

    def _build_streamable_http_connection(
        self, 
        url: str, 
        auth: dict | None = None
    ) -> StreamableHTTPConnectionParams:
        """
        Build StreamableHTTP connection params with auth headers.
        
        The FastMCP server expects:
        - Authorization: Bearer <token>
        - X-Session-Id: <session_id>
        """
        headers = {}
        
        if auth:
            # Extract token (support multiple key names)
            token = auth.get("token") or auth.get("auth_token") or auth.get("authorization")
            if token:
                normalized = token.strip()
                if normalized.lower().startswith("bearer "):
                    headers["Authorization"] = normalized
                else:
                    headers["Authorization"] = f"Bearer {normalized}"
            
            # Extract session ID (support multiple key names)
            session = auth.get("session_id") or auth.get("session")
            if session:
                headers["X-Session-Id"] = str(session).strip()

            if headers:
                masked_token = "<present>" if headers.get("Authorization") else "missing"
                print(
                    f"   🔧 MCP auth headers prepared: Authorization={masked_token}, "
                    f"X-Session-Id={headers.get('X-Session-Id', 'missing')}"
                )
        
        try:
            # Try to create connection with headers
            if headers:
                conn = StreamableHTTPConnectionParams(url=url, headers=headers)
                print("   ✅ Created StreamableHTTPConnectionParams with headers")
            else:
                conn = StreamableHTTPConnectionParams(url=url)
                print("   ✅ Created StreamableHTTPConnectionParams without headers (no auth)")
        except TypeError:
            print("   ⚠️ StreamableHTTPConnectionParams does not support 'headers' param. Using fallback.")
            # Fallback: ADK version doesn't support headers param
            # Append auth as query params instead
            if auth:
                params = []
                token = auth.get("token") or auth.get("auth_token")
                session = auth.get("session_id") or auth.get("session")
                
                if token:
                    params.append(f"token={token}")
                if session:
                    params.append(f"session_id={session}")
                
                if params:
                    sep = "&" if "?" in url else "?"
                    url = url + sep + "&".join(params)
            
            conn = StreamableHTTPConnectionParams(url=url)
        
        return conn

    async def _load_all_tools(self, auth: dict | None = None) -> list:
        """
        Load tools from all discovered MCP servers.
        
        Args:
            auth: Optional authentication dictionary
            
        Returns:
            Flat list of tool objects from all MCP servers
        """
        try:
            # Clear previous toolsets and tools
            await self.close_all()

            servers = self.discovery.list_all_servers()
            
            for server_name, server_info in servers.items():
                print(f"🔌 Connecting to MCP server: {server_name}")
                
                try:
                    if server_info.get("command") == "streamable-http":
                        # HTTP-based MCP server (FastMCP with SSE)
                        url = server_info["args"][0]
                        conn = self._build_streamable_http_connection(url, auth)
                        print(f"   URL: {url}")
                        print(f"   Auth provided: {bool(auth)}")
                    else:
                        # Stdio-based MCP server (local process)
                        conn = StdioConnectionParams(
                            StdioServerParameters(
                                command=server_info["command"],
                                args=server_info.get("args", []),
                                env=server_info.get("env", {})
                            ),
                            timeout=10,
                        )
                        print(f"   Command: {server_info['command']}")

                    # Create toolset and fetch tools
                    toolset = MCPToolset(connection_params=conn)
                    tools = await toolset.get_tools()
                    
                    # Log discovered tools
                    tool_names = [getattr(tool, "name", str(tool)) for tool in tools]
                    print(f"   ✅ Loaded {len(tools)} tools: {tool_names}")

                    # Cache toolset and tools
                    self._toolsets.append(toolset)
                    self._tools.extend(tools)
                    
                except Exception as e:
                    print(f"   ❌ Failed to load tools from {server_name}: {e}")
                    continue

            print(f"🎯 Total tools loaded: {len(self._tools)}")
            return self._tools.copy()
            
        except Exception as e:
            print(f"💥 Error in _load_all_tools: {e}")
            return []

    async def close_all(self) -> None:
        """Close all cached MCP toolsets and clear caches."""
        for ts in list(self._toolsets):
            try:
                await ts.close()
            except Exception as e:
                print(f"⚠️ Error closing MCP toolset: {e}")
        
        self._toolsets.clear()
        self._tools.clear()