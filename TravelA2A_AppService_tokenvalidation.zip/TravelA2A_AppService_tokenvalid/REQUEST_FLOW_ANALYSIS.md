# Request Flow Analysis - Travel MCP A2A Agent

## Overview
This document explains how the agent receives and processes requests in the Travel MCP A2A Agent system.

## Request Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CLIENT LAYER                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  1. Streamlit UI (chat_ai.py)                                           │
│     - User enters message in chat interface                              │
│     - Optional: Auth token & session ID from sidebar                     │
│     - Line 106: asyncio.run(host_connector.send_task(...))              │
│                                                                           │
│  2. CLI Client (cmd.py)                                                  │
│     - Command-line interface for testing                                 │
│     - Line 54/71: connector.send_task() or send_task_streaming()        │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        A2A CLIENT LAYER                                  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  AgentConnector (utilities/a2a/agent_connector.py)                      │
│  ────────────────────────────────────────────────────────────────────   │
│                                                                           │
│  send_task() method (Lines 27-117):                                     │
│    1. Creates A2AClient with agent card                                  │
│    2. Builds Message with:                                               │
│       - TextPart containing user query                                   │
│       - metadata = {"auth": auth} if auth provided (Line 47)            │
│       - contextId = session_id                                           │
│    3. Creates SendStreamingMessageRequest                                │
│    4. Calls client.send_message_streaming() (Line 71)                   │
│                                                                           │
│  Key Code:                                                               │
│    msg = Message(                                                        │
│        role="user",                                                      │
│        parts=[text_part],                                                │
│        messageId=message_id,                                             │
│        contextId=session_id,                                             │
│        metadata=metadata  # ← Auth passed here                          │
│    )                                                                     │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP POST to /messages
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         A2A SERVER LAYER                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  A2AStarletteApplication (agents/Travel_host_agent/__main__.py)         │
│  ────────────────────────────────────────────────────────────────────   │
│                                                                           │
│  Server Setup (Lines 42-49):                                            │
│    server = A2AStarletteApplication(                                     │
│        agent_card=card,                                                  │
│        http_handler=request_handler  # ← DefaultRequestHandler          │
│    )                                                                     │
│                                                                           │
│  • Listens on: localhost:8000 (or configured port)                      │
│  • Endpoint: POST /messages                                              │
│  • Framework: Starlette (ASGI)                                           │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      REQUEST HANDLER LAYER                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  DefaultRequestHandler (from a2a.server.request_handlers)               │
│  ────────────────────────────────────────────────────────────────────   │
│                                                                           │
│  • Receives HTTP request                                                 │
│  • Parses A2A protocol message                                           │
│  • Creates RequestContext containing:                                    │
│    - message (with metadata.auth)                                        │
│    - current_task                                                        │
│  • Calls agent_executor.execute(request_context, event_queue)           │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      AGENT EXECUTOR LAYER                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  HostAgentExecutor (agents/Travel_host_agent/agent_executor.py)         │
│  ────────────────────────────────────────────────────────────────────   │
│                                                                           │
│  🔑 KEY ENTRY POINT: execute() method (Lines 82-161)                    │
│  ═══════════════════════════════════════════════════════════════════   │
│                                                                           │
│  Step 1: Extract User Query (Line 97)                                   │
│    query = request_context.get_user_input()                             │
│                                                                           │
│  Step 2: Extract Auth (Line 98)                                         │
│    auth = self._extract_auth(request_context)                           │
│                                                                           │
│  _extract_auth() method (Lines 29-80):                                  │
│    Looks for auth in multiple places:                                    │
│    1. request_context.message.metadata.auth (Line 51)                   │
│    2. request_context.message.params.auth (Line 58)                     │
│    3. request_context.message.parts[].metadata.auth (Line 67)           │
│    4. Direct attributes: auth_token, session_id (Lines 72-75)           │
│                                                                           │
│    Returns: dict with keys like:                                         │
│      - token / auth_token / authorization                                │
│      - session_id / session                                              │
│                                                                           │
│  Step 3: Get/Create Task (Lines 104-108)                                │
│    task = request_context.current_task or new_task()                    │
│                                                                           │
│  Step 4: Invoke Agent (Lines 115-141)                                   │
│    async for item in self.agent.invoke(                                 │
│        query=query,                                                      │
│        session_id=task.context_id,                                       │
│        auth=auth  # ← Auth passed to agent                              │
│    ):                                                                    │
│        # Process streaming updates                                       │
│        # Send task status updates via event_queue                        │
│        # Return final result                                             │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         AGENT LOGIC LAYER                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  HostAgent (agents/Travel_host_agent/agent.py)                          │
│  ────────────────────────────────────────────────────────────────────   │
│                                                                           │
│  invoke() method (Lines 172-236):                                       │
│  ═══════════════════════════════════════════════════════════════════   │
│                                                                           │
│  Step 1: Store Auth (Line 181)                                          │
│    self._current_auth = auth or {}                                       │
│                                                                           │
│  Step 2: Ensure MCP Tools (Line 182)                                    │
│    await self._ensure_mcp_tools(self._current_auth)                     │
│                                                                           │
│    _ensure_mcp_tools() method (Lines 129-156):                          │
│      • Checks if auth signature changed                                  │
│      • Reloads MCP tools with new auth if needed                         │
│      • Calls mcp_connector.get_tools(auth=auth) (Line 143)              │
│      • Updates agent.tools with authenticated MCP tools                  │
│                                                                           │
│  Step 3: Get/Create Session (Lines 185-196)                             │
│    session = await runner.session_service.get_session(...)              │
│                                                                           │
│  Step 4: Run Agent (Lines 206-228)                                      │
│    async for event in self.runner.run_async(                            │
│        user_id=self.user_id,                                             │
│        session_id=session_id,                                            │
│        new_message=user_content                                          │
│    ):                                                                    │
│        # Agent processes with Google ADK                                 │
│        # Uses Gemini 2.5 Flash model                                     │
│        # Has access to:                                                  │
│        #   - MCP tools (authenticated with user's auth)                  │
│        #   - delegate_task() for A2A agent calls                         │
│        #   - list_agents() for agent discovery                           │
│                                                                           │
│  Available Tools:                                                        │
│    1. MCP Tools (from MCP server, authenticated)                         │
│    2. delegate_task(agent_name, message) - Line 80                      │
│       • Forwards requests to other A2A agents                            │
│       • Uses stored _current_auth for authentication                     │
│    3. list_agents() - Line 73                                            │
│       • Returns available A2A agents                                     │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

## Key Components

### 1. **Entry Point: HostAgentExecutor.execute()**
**File:** `agents/Travel_host_agent/agent_executor.py`  
**Lines:** 82-161

This is where the agent **receives the request** from the A2A framework.

```python
async def execute(
    self, 
    request_context: RequestContext,  # ← Contains the incoming request
    event_queue: EventQueue
) -> str:
    # Extract user query
    query = request_context.get_user_input()
    
    # Extract authentication
    auth = self._extract_auth(request_context)
    
    # Invoke the agent
    async for item in self.agent.invoke(
        query=query,
        session_id=task.context_id,
        auth=auth
    ):
        # Process and return results
```

### 2. **Authentication Extraction**
**Method:** `HostAgentExecutor._extract_auth()`  
**Lines:** 29-80

Extracts auth from multiple possible locations in the request:

```python
def _extract_auth(self, request_context: RequestContext) -> dict:
    # Priority order:
    # 1. request_context.message.metadata.auth
    # 2. request_context.message.params.auth
    # 3. request_context.message.parts[].metadata.auth
    # 4. Direct attributes (auth_token, session_id)
```

### 3. **Agent Processing**
**Method:** `HostAgent.invoke()`  
**File:** `agents/Travel_host_agent/agent.py`  
**Lines:** 172-236

```python
async def invoke(self, query: str, session_id: str = None, auth=None):
    # 1. Store auth for tool use
    self._current_auth = auth or {}
    
    # 2. Reload MCP tools with auth if needed
    await self._ensure_mcp_tools(self._current_auth)
    
    # 3. Run agent with Google ADK
    async for event in self.runner.run_async(...):
        yield results
```

## Authentication Flow

```
Client Request
    │
    ├─ metadata: {"auth": {"token": "...", "session_id": "..."}}
    │
    ▼
A2AStarletteApplication
    │
    ▼
DefaultRequestHandler
    │
    ├─ Creates RequestContext
    │
    ▼
HostAgentExecutor.execute()
    │
    ├─ Calls _extract_auth(request_context)
    │   └─ Returns: {"token": "...", "session_id": "..."}
    │
    ▼
HostAgent.invoke(query, session_id, auth)
    │
    ├─ Stores in self._current_auth
    │
    ├─ Calls _ensure_mcp_tools(auth)
    │   └─ Passes auth to MCP connector
    │       └─ MCP tools get authenticated
    │
    └─ delegate_task() uses self._current_auth
        └─ Forwards auth to other A2A agents
```

## Request Data Structure

### Incoming Request (from client)
```python
Message(
    role="user",
    parts=[TextPart(text="Book a flight to Paris")],
    messageId="abc123",
    contextId="session-xyz",
    metadata={
        "auth": {
            "token": "jwt-token-here",
            "session_id": "session-xyz"
        }
    }
)
```

### RequestContext (in executor)
```python
RequestContext(
    message=Message(...),  # Contains metadata.auth
    current_task=Task(...),
    # ... other fields
)
```

### Extracted Auth
```python
{
    "token": "jwt-token-here",
    "session_id": "session-xyz"
}
```

## Server Startup

**File:** `agents/Travel_host_agent/__main__.py`

```python
# 1. Create agent card
card = AgentCard(
    name="Travel_HostAgent",
    description="Host agent that manages travel agent tasks",
    capabilities=AgentCapabilities(streaming=True, multi_turn=True),
    url="https://travel-host.thankfulground-23b51839.centralindia.azurecontainerapps.io"
)

# 2. Create executor
host_agent_executor = HostAgentExecutor()
await host_agent_executor.create()

# 3. Create request handler
request_handler = DefaultRequestHandler(
    agent_executor=host_agent_executor,
    task_store=InMemoryTaskStore()
)

# 4. Create and start server
server = A2AStarletteApplication(
    agent_card=card,
    http_handler=request_handler
)

# 5. Run with Uvicorn
uvicorn.Config(server.build(), host=host, port=port)
```

## Summary

**The agent receives requests at:**
1. **HTTP Level:** `A2AStarletteApplication` (Starlette ASGI server)
2. **Protocol Level:** `DefaultRequestHandler` (A2A protocol handler)
3. **Execution Level:** `HostAgentExecutor.execute()` ← **MAIN ENTRY POINT**
4. **Logic Level:** `HostAgent.invoke()` (actual agent processing)

**The request flow is:**
```
HTTP POST → A2AStarletteApplication → DefaultRequestHandler → 
HostAgentExecutor.execute() → HostAgent.invoke() → Google ADK Runner
```

**Authentication is extracted in:**
- `HostAgentExecutor._extract_auth()` (Lines 29-80)
- Used by `HostAgent._ensure_mcp_tools()` (Lines 129-156)
- Stored in `HostAgent._current_auth` for tool use
