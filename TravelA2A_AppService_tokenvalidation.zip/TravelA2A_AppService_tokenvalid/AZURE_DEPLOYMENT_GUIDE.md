# Azure Container Apps Deployment Guide
## Travel MCP + A2A Agentic AI System

**Document Version:** 1.0  
**Last Updated:** November 2025  
**Author:** Deployment Team

---

## Table of Contents
1. [System Overview](#system-overview)
2. [Architecture](#architecture)
3. [Prerequisites](#prerequisites)
4. [Code Preparation](#code-preparation)
5. [Azure Resource Setup](#azure-resource-setup)
6. [Building and Pushing Docker Images](#building-and-pushing-docker-images)
7. [Deploying Container Apps](#deploying-container-apps)
8. [Environment Configuration](#environment-configuration)
9. [Testing the Deployment](#testing-the-deployment)
10. [Troubleshooting](#troubleshooting)
11. [Common Issues and Solutions](#common-issues-and-solutions)

---

## System Overview

This system is a Travel Agentic AI application built using:
- **MCP (Model Context Protocol)**: For tool/service integration
- **A2A (Agent-to-Agent)**: For agent communication
- **Google ADK**: For the orchestrator agent
- **FastMCP**: For the MCP server
- **Streamlit**: For the user interface

### Components
1. **MCP Server** (`travel-mcp`): Provides tools to interact with the Travel API
2. **Host Agent** (`travel-host`): Orchestrates requests and calls MCP tools
3. **UI** (`travel-ui`): Streamlit web interface for users

---

## Architecture

```
User → Streamlit UI → Host Agent → MCP Server → External Travel API
         (8501)         (8080)        (8000)
```

**Communication Flow:**
1. User sends a message via Streamlit UI
2. UI forwards to Host Agent via A2A protocol
3. Host Agent processes and calls MCP Server tools
4. MCP Server executes tools (calls Travel API)
5. Response flows back to user

---

## Prerequisites

### Required Tools
- **Azure CLI** (version 2.50+)
- **Docker** (optional, for local testing)
- **Azure Subscription** with permissions to create:
  - Resource Groups
  - Container Registries
  - Container Apps
  - Container Apps Environments

### Required Credentials
- **Google API Key** (from https://aistudio.google.com/apikey)
- **Azure OpenAI credentials** (if using Azure OpenAI instead of Gemini)
- **Travel API credentials** (Session ID and Auth Token)

### Azure Resources Needed
- Resource Group
- Azure Container Registry (ACR)
- Container Apps Environment

---

## Code Preparation

### Critical Code Changes for Cloud Deployment

#### 1. Configuration Management (`config.py`)
The application must read URLs from environment variables instead of hardcoded `localhost`:

```python
class Config:
    GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
    HOST_AGENT_PORT: int = int(os.getenv("HOST_AGENT_PORT", 8080))
    HOST_AGENT_URL: str = os.getenv("HOST_AGENT_URL")  # Must be set in Azure
    MCP_SERVER_URL: str = os.getenv("MCP_SERVER_URL")  # Must be set in Azure
```

**Key Points:**
- `HOST_AGENT_URL` and `MCP_SERVER_URL` must NOT have default values pointing to localhost
- These will be set as environment variables in Azure Container Apps

#### 2. MCP Server Binding (`mcp_server/travel_agent_mcp.py`)
The MCP server must bind to `0.0.0.0` to accept connections from other containers:

```python
# BEFORE (won't work in Azure):
mcp.run(transport="streamable-http", port=port)

# AFTER (works in Azure):
mcp.run(transport="streamable-http", host="0.0.0.0", port=port)
```

**Why:** By default, FastMCP binds to `127.0.0.1` (localhost only), which prevents other containers from connecting.

#### 3. Host Agent URL Configuration (`agents/Travel_host_agent/__main__.py`)
The agent card must advertise the correct cloud URL:

```python
# BEFORE:
card = AgentCard(
    url=f"http://{host}:{port}/",
    # ...
)

# AFTER:
from config import config

card = AgentCard(
    url=config.HOST_AGENT_URL,  # Reads from environment variable
    # ...
)
```

#### 4. Variable Naming Conflict Fix
Avoid shadowing the global `config` module:

```python
# BEFORE (causes UnboundLocalError):
config = uvicorn.Config(server.build(), host=host, port=port)
server_instance = uvicorn.Server(config)

# AFTER:
uvicorn_config = uvicorn.Config(server.build(), host=host, port=port)
server_instance = uvicorn.Server(uvicorn_config)
```

#### 5. Event Loop Fix (`agents/Travel_host_agent/__main__.py`)
Remove conflicting `asyncio.run()` wrapper:

```python
# BEFORE (causes crash):
if __name__ == "__main__":
    asyncio.run(main())

# AFTER:
if __name__ == "__main__":
    main()  # asyncclick handles the event loop
```

#### 6. MCP Discovery (`utilities/mcp/mcp_discovery.py`)
Allow environment variable override for MCP server URL:

```python
def list_all_servers(self) -> dict[str, any]:
    servers = self.config.get("mcpservers", {})
    
    # Override with env var if present (for Cloud deployment)
    mcp_url = os.getenv("MCP_SERVER_URL")
    if mcp_url and "Test_MCP" in servers:
        servers["Test_MCP"]["args"] = [mcp_url]
    
    return servers
```

---

## Azure Resource Setup

### Step 1: Login to Azure
```bash
az login
```

### Step 2: Set Variables
```bash
# Set your resource details
RESOURCE_GROUP="BoschMyPlanet"
LOCATION="Central India"
ACA_ENV="travel-cae"
ACR_NAME="travelacr1"
```

### Step 3: Create Resources (if they don't exist)

#### Create Resource Group
```bash
az group create \
  --name $RESOURCE_GROUP \
  --location "$LOCATION"
```

#### Create Azure Container Registry
```bash
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true
```

#### Get ACR Credentials
```bash
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query "username" -o tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
ACR_SERVER="${ACR_NAME}.azurecr.io"
```

#### Create Container Apps Environment
```bash
az containerapp env create \
  --name $ACA_ENV \
  --resource-group $RESOURCE_GROUP \
  --location "$LOCATION"
```

---

## Building and Pushing Docker Images

### Using Azure Container Registry Build (Recommended)

This method builds images in Azure, so you don't need Docker installed locally.

```bash
# Navigate to project root
cd /path/to/Travel_mcp_a2a_agent

# Build MCP Server
az acr build \
  --registry $ACR_NAME \
  --image travel-mcp:v1 \
  --file Dockerfile.mcp \
  .

# Build Host Agent
az acr build \
  --registry $ACR_NAME \
  --image travel-host:v1 \
  --file Dockerfile.host \
  .

# Build UI
az acr build \
  --registry $ACR_NAME \
  --image travel-ui:v1 \
  --file Dockerfile.ui \
  .
```

**Build Time:** Each build takes approximately 1-2 minutes.

### Alternative: Local Docker Build

If you prefer to build locally:

```bash
# Login to ACR
az acr login --name $ACR_NAME

# Build and push
docker build -t $ACR_SERVER/travel-mcp:v1 -f Dockerfile.mcp .
docker push $ACR_SERVER/travel-mcp:v1

docker build -t $ACR_SERVER/travel-host:v1 -f Dockerfile.host .
docker push $ACR_SERVER/travel-host:v1

docker build -t $ACR_SERVER/travel-ui:v1 -f Dockerfile.ui .
docker push $ACR_SERVER/travel-ui:v1
```

---

## Deploying Container Apps

### Deployment Order
Deploy in this specific order due to dependencies:
1. MCP Server (no dependencies)
2. Host Agent (depends on MCP Server URL)
3. UI (depends on Host Agent URL)

### 1. Deploy MCP Server

```bash
az containerapp create \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-mcp:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8000 \
  --ingress external \
  --env-vars \
    TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net"
```

**Get MCP Server URL:**
```bash
MCP_FQDN=$(az containerapp show \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn \
  -o tsv)

echo "MCP Server URL: https://$MCP_FQDN/mcp"
```

**Important:** Note the `/mcp` path at the end!

### 2. Deploy Host Agent

```bash
az containerapp create \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-host:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8080 \
  --ingress external \
  --env-vars \
    MCP_SERVER_URL="https://$MCP_FQDN/mcp" \
    HOST_AGENT_URL="https://travel-host.<your-env-domain>" \
    GOOGLE_API_KEY="<YOUR_GOOGLE_API_KEY>"
```

**Get Host Agent URL:**
```bash
HOST_FQDN=$(az containerapp show \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn \
  -o tsv)

echo "Host Agent URL: https://$HOST_FQDN"
```

**Update HOST_AGENT_URL:**
```bash
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars \
    HOST_AGENT_URL="https://$HOST_FQDN"
```

### 3. Deploy UI

```bash
az containerapp create \
  --name travel-ui \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-ui:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8501 \
  --ingress external \
  --env-vars \
    HOST_AGENT_URL="https://$HOST_FQDN"
```

**Get UI URL:**
```bash
UI_FQDN=$(az containerapp show \
  --name travel-ui \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn \
  -o tsv)

echo "UI URL: https://$UI_FQDN"
```

---

## Environment Configuration

### Required Environment Variables

#### MCP Server (`travel-mcp`)
| Variable | Value | Description |
|----------|-------|-------------|
| `TRAVEL_API_URL` | `https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net` | External Travel API endpoint |

#### Host Agent (`travel-host`)
| Variable | Value | Description |
|----------|-------|-------------|
| `HOST_AGENT_URL` | `https://travel-host.<domain>` | Public URL of this service |
| `MCP_SERVER_URL` | `https://travel-mcp.<domain>/mcp` | MCP Server endpoint (note `/mcp` path) |
| `GOOGLE_API_KEY` | `<your-key>` | Google AI Studio API key |

#### UI (`travel-ui`)
| Variable | Value | Description |
|----------|-------|-------------|
| `HOST_AGENT_URL` | `https://travel-host.<domain>` | Host Agent endpoint |

### Updating Environment Variables

```bash
az containerapp update \
  --name <container-app-name> \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars \
    KEY1="value1" \
    KEY2="value2"
```

**Note:** Updating environment variables automatically creates a new revision and restarts the container.

---

## Testing the Deployment

### 1. Test MCP Server
```bash
curl https://$MCP_FQDN/mcp
```

Expected: MCP protocol response (JSON)

### 2. Test Host Agent
```bash
curl https://$HOST_FQDN/.well-known/agent-card.json
```

Expected: Agent card JSON with agent details

### 3. Test UI
Open in browser:
```
https://<ui-fqdn>
```

Expected: Streamlit interface loads

### 4. End-to-End Test

Using the provided `test_client.py`:

```python
# Update BASE_URL in test_client.py
BASE_URL = "https://travel-host.<your-domain>"

# Run test
python test_client.py
```

Expected output:
```json
{
  "result": {
    "status": {
      "message": {
        "parts": [
          {
            "text": "Agent response here..."
          }
        ]
      }
    }
  }
}
```

---

## Troubleshooting

### Viewing Logs

#### Via Azure CLI
```bash
# View recent logs
az containerapp logs show \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --tail 50

# Follow logs in real-time
az containerapp logs show \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --follow
```

#### Via Azure Portal
1. Navigate to Container App
2. Click "Log stream" in the left menu
3. View real-time logs

### Common Log Locations
- **Startup errors**: Check the first 10-20 lines
- **Runtime errors**: Look for Python tracebacks
- **Connection errors**: Search for "timeout", "refused", "404"

### Restarting Containers

```bash
# Get current revision name
REVISION=$(az containerapp revision list \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  -o tsv)

# Restart
az containerapp revision restart \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --revision $REVISION
```

---

## Common Issues and Solutions

### Issue 1: "UnboundLocalError: cannot access local variable 'config'"

**Symptom:** Host Agent crashes on startup

**Cause:** Variable name conflict - local variable `config` shadows the global `config` module

**Solution:** Rename the local variable:
```python
# In agents/Travel_host_agent/__main__.py
uvicorn_config = uvicorn.Config(...)  # Not 'config'
```

### Issue 2: "404 Not Found" on `/.well-known/agent-card.json`

**Symptom:** Test client cannot fetch agent card

**Causes:**
1. Host Agent not running
2. Ingress not enabled
3. Wrong URL

**Solutions:**
```bash
# Check if container is running
az containerapp show \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --query properties.runningStatus

# Ensure ingress is enabled
az containerapp ingress enable \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --type external \
  --target-port 8080
```

### Issue 3: "504 Gateway Timeout" when calling Host Agent

**Symptom:** Requests to Host Agent time out

**Causes:**
1. MCP Server not reachable
2. Wrong `MCP_SERVER_URL`
3. MCP Server bound to `127.0.0.1` instead of `0.0.0.0`

**Solutions:**
1. Verify MCP Server is running:
```bash
curl https://$MCP_FQDN/mcp
```

2. Check `MCP_SERVER_URL` environment variable:
```bash
az containerapp show \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --query "properties.template.containers[0].env"
```

3. Rebuild MCP Server with correct binding (see Code Preparation section)

### Issue 4: MCP Server shows "Uvicorn running on http://127.0.0.1:8000"

**Symptom:** MCP Server logs show localhost binding

**Cause:** Code not updated to bind to `0.0.0.0`

**Solution:**
1. Update `mcp_server/travel_agent_mcp.py`:
```python
mcp.run(transport="streamable-http", host="0.0.0.0", port=port)
```

2. Rebuild and redeploy:
```bash
az acr build --registry $ACR_NAME --image travel-mcp:v1 --file Dockerfile.mcp .
```

3. Restart container app

### Issue 5: "TargetPort 8080 does not match listening ports: [8000]"

**Symptom:** Container app fails health checks

**Cause:** Ingress target port doesn't match the port the application listens on

**Solution:**
```bash
az containerapp ingress update \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --target-port 8000  # Match the actual port
```

### Issue 6: Environment variables not taking effect

**Symptom:** Application still uses old values after updating env vars

**Cause:** Container hasn't restarted with new revision

**Solution:**
1. Verify new revision was created:
```bash
az containerapp revision list \
  --name travel-host \
  --resource-group $RESOURCE_GROUP
```

2. If needed, manually restart:
```bash
az containerapp revision restart \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --revision <revision-name>
```

### Issue 7: "No response text received from the agent"

**Symptom:** Streamlit UI shows this error

**Cause:** Response parsing looking in wrong path

**Solution:** Ensure `streamlit_app.py` extracts text from `result.status.message.parts`:
```python
status = result_dict.get("status") or {}
message = status.get("message") or {}
parts_list = list(message.get("parts") or [])
```

---

## Security Best Practices

### 1. Use Internal Ingress Where Possible
- **MCP Server**: Can be internal if only accessed by Host Agent
- **Host Agent**: Can be internal if only accessed by UI
- **UI**: Must be external for user access

```bash
# Change to internal
az containerapp ingress update \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --type internal
```

### 2. Store Secrets Securely
Use Azure Key Vault for sensitive values:

```bash
# Create Key Vault
az keyvault create \
  --name <vault-name> \
  --resource-group $RESOURCE_GROUP

# Store secret
az keyvault secret set \
  --vault-name <vault-name> \
  --name google-api-key \
  --value "<your-key>"

# Reference in Container App
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --secrets google-api-key=keyvaultref:<vault-uri>,identityref:<identity>
```

### 3. Enable Managed Identity
```bash
az containerapp identity assign \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --system-assigned
```

---

## Scaling Configuration

### Manual Scaling
```bash
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --min-replicas 1 \
  --max-replicas 5
```

### Auto-scaling Rules
```bash
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --scale-rule-name http-rule \
  --scale-rule-type http \
  --scale-rule-http-concurrency 50
```

---

## Monitoring and Alerts

### Enable Application Insights
```bash
# Create Application Insights
az monitor app-insights component create \
  --app travel-insights \
  --location "$LOCATION" \
  --resource-group $RESOURCE_GROUP

# Get instrumentation key
INSTRUMENTATION_KEY=$(az monitor app-insights component show \
  --app travel-insights \
  --resource-group $RESOURCE_GROUP \
  --query instrumentationKey \
  -o tsv)

# Add to container app
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars \
    APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=$INSTRUMENTATION_KEY"
```

---

## Cleanup

### Delete All Resources
```bash
# Delete entire resource group (CAUTION!)
az group delete --name $RESOURCE_GROUP --yes --no-wait
```

### Delete Individual Container Apps
```bash
az containerapp delete --name travel-mcp --resource-group $RESOURCE_GROUP --yes
az containerapp delete --name travel-host --resource-group $RESOURCE_GROUP --yes
az containerapp delete --name travel-ui --resource-group $RESOURCE_GROUP --yes
```

---

## Appendix

### A. Complete Deployment Script

```bash
#!/bin/bash
set -e

# Variables
RESOURCE_GROUP="BoschMyPlanet"
LOCATION="Central India"
ACA_ENV="travel-cae"
ACR_NAME="travelacr1"
GOOGLE_API_KEY="<your-key>"

# Get ACR credentials
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query "username" -o tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
ACR_SERVER="${ACR_NAME}.azurecr.io"

# Build images
echo "Building images..."
az acr build --registry $ACR_NAME --image travel-mcp:v1 --file Dockerfile.mcp .
az acr build --registry $ACR_NAME --image travel-host:v1 --file Dockerfile.host .
az acr build --registry $ACR_NAME --image travel-ui:v1 --file Dockerfile.ui .

# Deploy MCP Server
echo "Deploying MCP Server..."
az containerapp create \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-mcp:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8000 \
  --ingress external \
  --env-vars TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net"

MCP_FQDN=$(az containerapp show --name travel-mcp --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn -o tsv)

# Deploy Host Agent
echo "Deploying Host Agent..."
az containerapp create \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-host:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8080 \
  --ingress external \
  --env-vars \
    MCP_SERVER_URL="https://$MCP_FQDN/mcp" \
    GOOGLE_API_KEY="$GOOGLE_API_KEY"

HOST_FQDN=$(az containerapp show --name travel-host --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn -o tsv)

# Update HOST_AGENT_URL
az containerapp update \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars HOST_AGENT_URL="https://$HOST_FQDN"

# Deploy UI
echo "Deploying UI..."
az containerapp create \
  --name travel-ui \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-ui:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8501 \
  --ingress external \
  --env-vars HOST_AGENT_URL="https://$HOST_FQDN"

UI_FQDN=$(az containerapp show --name travel-ui --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn -o tsv)

echo "Deployment complete!"
echo "MCP Server: https://$MCP_FQDN"
echo "Host Agent: https://$HOST_FQDN"
echo "UI: https://$UI_FQDN"
```

### B. Environment Variable Reference

Complete list of all environment variables used:

| Service | Variable | Required | Default | Description |
|---------|----------|----------|---------|-------------|
| travel-mcp | `TRAVEL_API_URL` | Yes | - | External Travel API endpoint |
| travel-mcp | `TRAVEL_AGENT_MCP_SERVER_PORT` | No | 8000 | Port to listen on |
| travel-host | `HOST_AGENT_URL` | Yes | - | Public URL of this service |
| travel-host | `MCP_SERVER_URL` | Yes | - | MCP Server endpoint |
| travel-host | `GOOGLE_API_KEY` | Yes | - | Google AI API key |
| travel-host | `HOST_AGENT_PORT` | No | 8080 | Port to listen on |
| travel-ui | `HOST_AGENT_URL` | Yes | - | Host Agent endpoint |

---

## Support and Contact

For issues or questions:
- Check logs first using Azure Portal or CLI
- Review the Troubleshooting section
- Verify all environment variables are set correctly
- Ensure all code changes from "Code Preparation" section are applied

---

**End of Document**
