from a2a.types import AgentSkill, AgentCard, AgentCapabilities
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from agents.Travel_host_agent.agent_executor import HostAgentExecutor
from a2a.server.apps import A2AStarletteApplication
import uvicorn
import asyncio
import asyncclick as click
from config import config
import os

@click.command()
@click.option('--host', default='localhost', help='Host for the agent server.')
@click.option('--port', default=int(config.HOST_AGENT_PORT), help='Port for the agent server.')
async def main(host: str, port: int):
    skill = AgentSkill(
        name="Travel_HostAgent",
        id="host_agent",
        description="Host agent that manages travel agent tasks via MCP server.",
        tags =["travel agent", "host agent", "A2A", "MCP server"],
        examples=[""""""],
    )
    
    HOST_AGENT_URL = os.getenv("HOST_AGENT_URL")

    card = AgentCard(
        name="Travel_HostAgent",
        description="Host agent that manages travel agent tasks via MCP server.",
        skills=[skill],
        capabilities=AgentCapabilities(streaming=True, multi_turn=True),
        url=HOST_AGENT_URL,
        version="1.0",
        default_input_modes=["text"],
        default_output_modes=["text"]
    )
    
    host_agent_executor = HostAgentExecutor()
    await host_agent_executor.create()
    
    request_handler = DefaultRequestHandler(
        agent_executor=host_agent_executor,
        task_store=InMemoryTaskStore(),
    )
    
    server = A2AStarletteApplication(
        agent_card=card,
        http_handler=request_handler
    )
    
    uvicorn_config = uvicorn.Config(server.build(), host =host, port=port)
    server_instance = uvicorn.Server(uvicorn_config)
    await server_instance.serve()
    
if __name__ == "__main__":
    main()