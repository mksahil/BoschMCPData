"""
Host Agent Executor - Updated with proper auth extraction and token/session validation
"""

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.utils import new_task, new_agent_text_message
from agents.Travel_host_agent.agent import HostAgent
from a2a.server.tasks import TaskUpdater
from a2a.types import TaskState
import asyncio
import uuid
import httpx
import os
from dotenv import load_dotenv

load_dotenv()

_VALIDATE_TOKEN_URL = os.getenv("_VALIDATE_TOKEN_URL", "")
_VALIDATE_TOKEN_CLIENT_ID = os.getenv("_VALIDATE_TOKEN_CLIENT_ID", "")


class HostAgentExecutor(AgentExecutor):
    """
    Executor for the Host Agent that handles:
    - A2A protocol communication
    - Auth extraction from requests for MCP tool calls
    - Task state management
    """
    
    def __init__(self):
        self.agent = HostAgent()
        
    async def create(self):
        """Initialize the underlying agent."""
        await self.agent.create()
    
    def _extract_auth(self, request_context: RequestContext) -> dict:
        """
        Extract authentication info from the incoming A2A request.
        
        Looks for auth in multiple places:
        - request_context.message.metadata.auth
        - request_context.message.params.auth
        - HTTP headers passed through the request
        
        Returns:
            dict with keys: token/auth_token, session_id
        """
        auth = {}
        
        try:
            msg = getattr(request_context, "message", None)
            if msg is None:
                return auth
            
            # Try metadata first
            meta = getattr(msg, "metadata", None)
            if isinstance(meta, dict):
                auth = meta.get("auth", {}) or meta.get("authorization", {}) or {}
                if auth:
                    return auth
            
            # Try params
            params = getattr(msg, "params", None)
            if isinstance(params, dict):
                auth = params.get("auth", {}) or params.get("authorization", {}) or {}
                if auth:
                    return auth
            
            # Try extracting from parts/content if structured
            parts = getattr(msg, "parts", None)
            if parts and isinstance(parts, list):
                for part in parts:
                    if hasattr(part, "metadata") and isinstance(part.metadata, dict):
                        part_auth = part.metadata.get("auth", {})
                        if part_auth:
                            return part_auth
            
            # Try direct attributes on message
            if hasattr(msg, "auth_token"):
                auth["auth_token"] = msg.auth_token
            if hasattr(msg, "session_id"):
                auth["session_id"] = msg.session_id
                
        except Exception as e:
            print(f"⚠️ Error extracting auth: {e}")
        
        return auth

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def _is_valid_guid(self, value: str) -> bool:
        """Return True only if *value* is a well-formed UUID/GUID string."""
        try:
            uuid.UUID(str(value))
            return True
        except (ValueError, AttributeError):
            return False

    async def _validate_token(self, token: str) -> bool:
        """
        Call the external ValidateToken API.

        Returns True when the API confirms the token is valid,
        False for any invalid-token response or network error.
        """
        if not _VALIDATE_TOKEN_URL or not _VALIDATE_TOKEN_CLIENT_ID:
            print("⚠️ Token validation env vars not set – skipping remote check")
            return False

        headers = {
            "authorization": f"Bearer {token}",
            "clientid": _VALIDATE_TOKEN_CLIENT_ID,
        }
        try:
            async with httpx.AsyncClient(timeout=10,verify=False) as client:
                response = await client.get(_VALIDATE_TOKEN_URL, headers=headers)
            data = response.json()
            is_success = str(data.get("IsSuccess", "")).lower() == "true"
            if is_success:
                print("✅ Token validated successfully")
                return True
            else:
                print(f"❌ Token validation failed: {data.get('Message', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"❌ Token validation request error: {e}")
            return False
        
    async def execute(
        self, 
        request_context: RequestContext, 
        event_queue: EventQueue
    ) -> str:
        """
        Execute the agent with the user's query.
        
        Args:
            request_context: Contains the user input and task info
            event_queue: Queue for sending status updates
            
        Returns:
            Final response string from the agent
        """
        query = request_context.get_user_input()
        auth = self._extract_auth(request_context)

        # ── Session-ID validation ──────────────────────────────────────────────
        session_id = auth.get("session_id") or auth.get("sessionId", "")
        if not session_id or not self._is_valid_guid(session_id):
            print(f"❌ Invalid or missing session_id: '{session_id}'")
            raise ValueError("Request rejected: session_id is missing or not a valid GUID.")
        print(f"✅ Session ID is valid GUID: {session_id}")

        # ── Token validation ───────────────────────────────────────────────────
        token = auth.get("auth_token") or auth.get("token", "")
        if not token:
            print("❌ Auth token is missing from request")
            raise ValueError("Request rejected: auth token is missing.")

        token_valid = await self._validate_token(token)
        if not token_valid:
            raise ValueError("Request rejected: token validation failed.")

        # ── Proceed ───────────────────────────────────────────────────────────
        print(f"🔐 Auth extracted: session_id={session_id[:20]}...")

        # Get or create task
        task = request_context.current_task
        if not task:
            task = new_task(request_context.message)
            await event_queue.enqueue_event(task)
        
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        
        try:
            # Invoke agent with auth for MCP tool authentication
            final_result = None
            
            async for item in self.agent.invoke(
                query=query,
                session_id=task.context_id,
                auth=auth
            ):
                is_task_complete = item.get("is_task_complete", False)
                
                if not is_task_complete:
                    message = item.get("updates", "Processing your request...")
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(message, task.context_id, task.id)
                    )
                else:
                    final_result = item.get("content", "")
                    
                    # Debug: print what we got
                    print(f"📤 Final result received: {final_result[:100] if final_result else 'EMPTY'}...")
                    
                    if not final_result:
                        final_result = "I processed your request but no text response was generated."
                    
                    await updater.update_status(
                        TaskState.completed,
                        new_agent_text_message(final_result, task.context_id, task.id)
                    )
                    return final_result
                
                await asyncio.sleep(0.1)
            
            # If we exit the loop without returning, something went wrong
            if final_result is None:
                final_result = "Agent completed but no response was captured."
                await updater.update_status(
                    TaskState.completed,
                    new_agent_text_message(final_result, task.context_id, task.id)
                )
                return final_result
                
        except Exception as e:
            error_message = f"Error during agent execution: {e}"
            print(f"❌ {error_message}")
            await updater.update_status(
                TaskState.failed,
                new_agent_text_message(error_message, task.context_id, task.id)
            )
            raise
        
    async def cancel(self):
        """Handle cleanup when execution is cancelled."""
        try:
            if hasattr(self.agent, "shutdown"):
                await self.agent.shutdown()
        except Exception as e:
            print(f"⚠️ Error during cancel: {e}")