
"""
Test Client for Host Agent with MCP Travel Agent
Uses the same AgentConnector pattern as your existing CLI
"""

from uuid import uuid4
import asyncclick as click
from utilities.a2a import agent_connector
from a2a.client import A2ACardResolver
import httpx
import asyncio
from config import config

# MCP Auth Configuration - These will be passed to the Host Agent
# which will forward them to the MCP Travel Server
MCP_SESSION_ID = "0ade26c3-5f4a-425c-85f7-18035c78dabb"
MCP_AUTH_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJWYVBaSzJYZmtUcmFqU0J6bTl2c2ZnPT0iLCJhdWQiOlsicEplZGJ3YTJkRkNKNUNLNXpnRjl5MWdZcUNDZkI4bU1YNjYveXMyZGpKYXp3Zlk4L0o3V0IzYUxJOGFESWkySSIsInBKZWRid2EyZEZDSjVDSzV6Z0Y5eTFnWXFDQ2ZCOG1NWDY2L3lzMmRqSmF6d2ZZOC9KN1dCM2FMSThhRElpMkkiXSwibmFtZSI6InZTOVQ2alVyU2RrSHF0WlM0NFFVL1FrZmlVa25POUVNbUdldU95c2VmMW89IiwiZ2l2ZW5fbmFtZSI6IkdaWGxSeWZPMi9wMEVNN1dGNnpMYmM3SU11dG1zcFFyT3cwY2ZLalpVcTQ9IiwiaWF0IjoxNzYzNjIwMTE2LCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL2V4cGlyYXRpb24iOiIxMi8yMS8yMDI1IDY6Mjg6MzYgQU0iLCJleHAiOjE3NjYyOTg1MTZ9.PW19glLgmxVkBPP3ytY-wnZ-6xS2XzTqj05RNaAxwpAFuhXuM-eCCuppV2zv88nZ_Wji5cFTzulpZYoNKKchn1lF78QfUZwMHLBNpkwllprHXzUZc3jGax4866AIzSiDvvmnrufS2NvdMpfuqKeKoyO8DGbfbZnwXyIa9kitq_KpNRjCP9vzFrzFLoqgmq4mn25Ae0oeb5tNQZIwwz8ePi5aAm_WrTlOJh6OvVP3Z5RXc5uCynU7NbpXFZziNpZcgJX8gdzes2OeyVtX80-UzJEUyKXDGBH70WLXQDIReeXQNXQsW5_-LdkOsD5E7XYctEKTqlzN_ZyYpkhJmdoXkA"

@click.command()
@click.option("--agent_url", default=f"https://travel-host.thankfulground-23b51839.centralindia.azurecontainerapps.io", help="Base URL of A2A host agent.")
@click.option("--session", default=0, help="Session ID (use 0 to generate a new ID)")
@click.option("--test", is_flag=True, help="Run automated tests instead of interactive mode")
async def cli(agent_url: str, session: int, test: bool):
    """
    CLI to send messages to the Host Agent with MCP auth support.
    
    The auth credentials are passed through to MCP tools for calling
    the Travel Agent API.
    """
    
    session_id = uuid4().hex if not session else str(session)
    
    # Step 1: Discover the host agent
    host_agent_card = None
    async with httpx.AsyncClient(timeout=300) as httpx_client:
        try:
            resolver = A2ACardResolver(base_url=agent_url, httpx_client=httpx_client)
            host_agent_card = await resolver.get_agent_card()
            print("host_agent_card: ", host_agent_card)
            if host_agent_card:
                print(f"🌳🌳🌳 Discovered agent: {host_agent_card.name} at {agent_url}")
                print(f"    Description: {host_agent_card.description}")
                if host_agent_card.skills:
                    print(f"    Skills: {[s.name for s in host_agent_card.skills]}")
            else:
                print(f"⭐️⭐️⭐️ No AgentCard found at {agent_url}")
                return
        except Exception as e:
            print(f"💥💥💥 Error retrieving AgentCard from {agent_url}: {e}")
            return
    
    # Step 2: Create connector with auth
    connector = agent_connector.AgentConnector(host_agent_card)
    
    # Auth dict to pass to MCP tools
    auth = {
        "session_id": MCP_SESSION_ID,
        "auth_token": MCP_AUTH_TOKEN
    }
    
    if test:
        # Run automated tests
        await run_tests(connector, session_id, auth)
    else:
        # Interactive mode
        await interactive_mode(connector, session_id, auth)


async def run_tests(connector: agent_connector.AgentConnector, session_id: str, auth: dict):
    """Run automated test scenarios."""
    
    print("\n" + "="*60)
    print("AUTOMATED TESTS: Host Agent + MCP Travel Agent")
    print("="*60)
    
    test_cases = [
        ("Get Help", "What can you help me with?"),
        # ("Travel Capabilities", "What travel services are available?"),
        # ("Create Plan", "Create a travel plan to Mumbai from January 15-18, 2025 for a client meeting. Need hotel near BKC."),
        # ("Submit Settlement", "Submit travel settlement for trip TRIP-12345 with expenses: Flight $500, Hotel $300"),
    ]
    
    for name, prompt in test_cases:
        print(f"\n{'='*60}")
        print(f"TEST: {name}")
        print(f"{'='*60}")
        print(f"📤 Prompt: {prompt[:80]}...")
        
        try:
            response = await connector.send_task(
                message=prompt,
                session_id=session_id,
                auth=auth
            )
            print(f"📥 Response: {response}")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        await asyncio.sleep(1)  # Small delay between tests
    
    print("\n" + "="*60)
    print("✅ All tests completed")
    print("="*60)


async def interactive_mode(connector: agent_connector.AgentConnector, session_id: str, auth: dict):
    """Interactive chat mode."""
    
    print("\n" + "="*60)
    print("INTERACTIVE MODE")
    print("="*60)
    print(f"Session ID: {session_id}")
    print(f"MCP Auth: session_id={MCP_SESSION_ID[:20]}...")
    print("Type 'q:' or 'quit' to exit")
    print("="*60)
    
    while True:
        prompt = click.prompt("\n👤 You")
        
        if prompt.strip().lower() in ["q:", "quit", "exit"]:
            print("Goodbye!")
            break
        
        if not prompt.strip():
            continue
        
        try:
            print("🤖 Agent: ", end="", flush=True)
            response = await connector.send_task(
                message=prompt,
                session_id=session_id,
                auth=auth
            )
            print(response)
        except Exception as e:
            print(f"❌ Error: {e}")


if __name__ == "__main__":
    asyncio.run(cli())