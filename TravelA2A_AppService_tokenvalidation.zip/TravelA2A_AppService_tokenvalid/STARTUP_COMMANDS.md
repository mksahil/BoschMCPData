# Azure App Service Startup Commands - Quick Reference

This document provides the correct startup commands for deploying to Azure App Service using `uv`.

## ⚠️ IMPORTANT: Azure App Service Working Directory Issue

**Error:** `No pyproject.toml found in current directory`

**Cause:** Azure App Service may run the startup command from a different directory than where your code is deployed.

**Solution:** Always `cd` to `/home/site/wwwroot` first in your startup command!

---

## 🎯 Why Use `uv`?

Your project uses `uv` as the package manager (see `pyproject.toml` and `uv.lock`). Using `uv` in Azure App Service ensures:
- ✅ Consistent dependency resolution
- ✅ Faster installation
- ✅ Matches your Dockerfiles and local development
- ✅ Uses the exact versions from `uv.lock`

---

## 📋 Startup Commands (FIXED for Azure)

### 1. MCP Server (`travel-mcp-service`)

```bash
cd /home/site/wwwroot && pip install uv && uv sync && uv run python -m mcp_server.travel_agent_mcp
```

**What it does:**
1. Changes to the deployment directory
2. Installs `uv` using pip
3. Syncs dependencies from `pyproject.toml` and `uv.lock`
4. Runs the MCP server on port 8000

---

### 2. Host Agent (`travel-host-service`)

```bash
cd /home/site/wwwroot && pip install uv && uv sync && uv run python -m agents.Travel_host_agent --host 0.0.0.0 --port 8000
```

**What it does:**
1. Changes to the deployment directory
2. Installs `uv` using pip
3. Syncs dependencies
4. Runs the host agent on port 8000 (Azure default)

**Note:** Changed from port 8080 to 8000 to match Azure App Service expectations.

---

### 3. UI Service (`travel-ui-service`)

```bash
cd /home/site/wwwroot && pip install uv && uv sync && uv run streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true
```

**What it does:**
1. Changes to the deployment directory
2. Installs `uv` using pip
3. Syncs dependencies
4. Runs Streamlit on port 8000 in headless mode

**Note:** Changed from port 8501 to 8000 to match Azure App Service expectations.

---

## 🔧 How to Set Startup Command

Use the Azure CLI:

```bash
az webapp config set \
  --name <app-service-name> \
  --resource-group <resource-group> \
  --startup-file "<startup-command-from-above>"
```

**Example:**

```bash
az webapp config set \
  --name travel-mcp-service \
  --resource-group BoschMyPlanet \
  --startup-file "pip install uv && uv sync && uv run python -m mcp_server.travel_agent_mcp"
```

---

## 📦 Required Files

Make sure these files are in your deployment package:

- ✅ `pyproject.toml` - Project dependencies
- ✅ `uv.lock` - Locked dependency versions
- ✅ `requirements.txt` - Optional, for fallback to pip
- ✅ All source code files

---

## 🐛 Troubleshooting

### Issue: `uv: command not found`

**Solution:** The startup command installs `uv` first with `pip install uv`

### Issue: Dependencies not installing

**Check:**
1. `pyproject.toml` and `uv.lock` are in the deployment package
2. Startup command includes `uv sync`
3. Check logs: `az webapp log tail --name <app-name> --resource-group <rg>`

### Issue: Port binding errors

**Solution:** Ensure your app listens on port 8000 (Azure default) or set the PORT environment variable

---

## 🆚 Alternative: Using Standard pip (EASIER for Azure)

If you're having issues with `uv` or want a simpler approach, use standard `pip` with `requirements.txt`:

### ✅ Advantages:
- No working directory issues
- Azure handles dependency installation automatically
- Simpler startup commands
- Still uses exact versions from `requirements.txt`

### 📋 Steps:

#### 1. Ensure requirements.txt exists (already done ✅)

Your `requirements.txt` is already generated with all dependencies locked.

#### 2. Enable automatic build during deployment

```bash
az webapp config appsettings set \
  --name <app-name> \
  --resource-group BoschMyPlanet \
  --settings SCM_DO_BUILD_DURING_DEPLOYMENT=true
```

This tells Azure to automatically run `pip install -r requirements.txt` during deployment.

#### 3. Use simpler startup commands (no cd needed!)

**MCP Server:**
```bash
python -m mcp_server.travel_agent_mcp
```

**Host Agent:**
```bash
python -m agents.Travel_host_agent --host 0.0.0.0 --port 8000
```

**UI:**
```bash
streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true
```

### 🎯 Full Example (MCP Server):

```bash
# Enable auto-build
az webapp config appsettings set \
  --name travel-mcp-service \
  --resource-group BoschMyPlanet \
  --settings \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true \
    TRAVEL_AGENT_MCP_SERVER_PORT=8000 \
    TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net"

# Set simple startup command
az webapp config set \
  --name travel-mcp-service \
  --resource-group BoschMyPlanet \
  --startup-file "python -m mcp_server.travel_agent_mcp"

# Deploy
az webapp deployment source config-zip \
  --name travel-mcp-service \
  --resource-group BoschMyPlanet \
  --src deploy.zip
```

Azure will automatically:
1. Extract your code to `/home/site/wwwroot`
2. Find `requirements.txt`
3. Run `pip install -r requirements.txt`
4. Execute your startup command

---

## ✅ Recommended Approach for Azure App Service

**Use standard pip** (Option 2 above) because:
- ✅ No working directory issues
- ✅ Simpler commands
- ✅ Azure handles everything automatically
- ✅ Still uses exact versions from `requirements.txt`

**Use `uv`** only if you need exact parity with local development and are comfortable with the `cd` workaround.

---

## ✅ Recommended Approach

**Use `uv`** for consistency with your project setup. The startup commands are slightly longer but ensure exact dependency matching with your development environment.

---

## 📚 Related Files

- `AZURE_APP_SERVICE_DEPLOYMENT.md` - Full deployment guide
- `DEPLOYMENT.md` - Container Apps deployment
- `pyproject.toml` - Project dependencies
- `requirements.txt` - Generated pip requirements
