# Deployment Guide: Azure Container Apps

This guide outlines the steps to deploy the Travel Agentic AI system to Azure Container Apps.

## Architecture
We will deploy 3 separate container apps in the same Azure Container Apps Environment:
1. **travel-mcp**: The MCP Server (Backend Tool)
2. **travel-host**: The Host Agent (Orchestrator)
3. **travel-ui**: The Streamlit UI (Frontend)

## Prerequisites
- Azure CLI installed and logged in (`az login`)
- Docker installed (for building images)
- An Azure Container Registry (ACR) or Docker Hub account

## Step 1: Create Azure Resources

```bash
# Set variables
RESOURCE_GROUP="BoschMyPlanet"
LOCATION="Central India"
ACA_ENV="travel-cae"
ACR_NAME="travelacr1" 

# Resources already exist, so we can skip creation or verify them
# az group create --name $RESOURCE_GROUP --location "$LOCATION"
# az acr create --resource-group $RESOURCE_GROUP --name $ACR_NAME --sku Basic --admin-enabled true
# az containerapp env create --name $ACA_ENV --resource-group $RESOURCE_GROUP --location "$LOCATION"

# Get ACR Credentials
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query "username" -o tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
ACR_SERVER="${ACR_NAME}.azurecr.io"
```

## Step 2: Build and Push Images

Run these commands from the root of your project:

```bash
# Login to ACR (Optional for az acr build, but good practice)
# az acr login --name $ACR_NAME

# 1. Build MCP Server (Builds in Azure)
az acr build --registry $ACR_NAME --image travel-mcp:v1 --file Dockerfile.mcp .

# 2. Build Host Agent (Builds in Azure)
az acr build --registry $ACR_NAME --image travel-host:v1 --file Dockerfile.host .

# 3. Build UI (Builds in Azure)
az acr build --registry $ACR_NAME --image travel-ui:v1 --file Dockerfile.ui .
```

## Step 3: Deploy Container Apps

### 1. Deploy MCP Server
This is an internal service.

```bash
az containerapp create \
  --name travel-mcp \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-mcp:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8000 \
  --ingress internal \
  --env-vars TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net"
```

**Note the FQDN**: After creation, get the Fully Qualified Domain Name (FQDN).
```bash
MCP_FQDN=$(az containerapp show --name travel-mcp --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn -o tsv)
echo "MCP URL: https://$MCP_FQDN"
```

### 2. Deploy Host Agent
This is also an internal service (or external if you want to access it directly, but usually internal is safer if only UI talks to it). We'll make it internal.

It needs to know where the MCP server is.

```bash
az containerapp create \
  --name travel-host \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-host:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8080 \
  --ingress internal \
  --env-vars \
    MCP_SERVER_URL="https://$MCP_FQDN/mcp" \
    GOOGLE_API_KEY="<YOUR_GOOGLE_API_KEY>" \
    AZURE_API_KEY="<YOUR_AZURE_API_KEY>" \
    AZURE_API_BASE="<YOUR_AZURE_API_BASE>" \
    AZURE_API_VERSION="<YOUR_AZURE_API_VERSION>"
```
*Note: Replace `<YOUR_...>` with your actual API keys.*

**Note the FQDN**:
```bash
HOST_FQDN=$(az containerapp show --name travel-host --resource-group $RESOURCE_GROUP --query properties.configuration.ingress.fqdn -o tsv)
echo "Host URL: https://$HOST_FQDN"
```

### 3. Deploy UI
This is the public facing service.

```bash
az containerapp create \
  --name travel-ui \
  --resource-group $RESOURCE_GROUP \
  --environment $ACA_ENV \
  --image $ACR_SERVER/travel-ui:v1 \
  --registry-server $ACR_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8501 \
  --ingress external \
  --env-vars \
    HOST_AGENT_URL="https://$HOST_FQDN"
```

## Step 4: Verify
1. Go to the URL of the `travel-ui` container app (printed in the output of the last command).
2. You should see the Streamlit interface.
3. The UI will connect to the Host Agent (using `HOST_AGENT_URL`).
4. The Host Agent will connect to the MCP Server (using `MCP_SERVER_URL`).

## Step 5: Post-Deployment Configuration

The `test_client.py` script tries to connect to the Host Agent using the A2A protocol. 

1. **Update `test_client.py`**:
   - Set `BASE_URL` to your Host Agent's URL (e.g., `https://travel-host....azurecontainerapps.io`).
   - Ensure the Host Agent is actually running and serving the A2A endpoints.

2. **Environment Variables**:
   - Ensure you have set `GOOGLE_API_KEY` in your Host Agent container.
   - Ensure `MCP_SERVER_URL` is set correctly in the Host Agent container.

## Troubleshooting 404 Errors
If you get a 404 on `/.well-known/agent-card.json`:
- Check if the Host Agent application (`agents/Travel_host_agent`) is correctly mounting the A2A routes.
- Verify the container logs for `travel-host` to see if it started successfully.

