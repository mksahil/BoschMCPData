# Azure App Service Deployment Guide

This guide explains how to deploy the Travel MCP A2A Agent system to **Azure App Service** (instead of Azure Container Apps).

## 📋 Prerequisites

- Azure CLI installed and logged in (`az login`)
- Python 3.11
- Git repository (optional, for deployment)
- `requirements.txt` file (already generated ✅)

---

## 🏗️ Architecture Overview

You will deploy **3 separate Azure App Services**:

1. **travel-mcp-service** - MCP Server (Port 8000)
2. **travel-host-service** - Host Agent (Port 8080)
3. **travel-ui-service** - Streamlit UI (Port 8501)

---

## 📦 Step 1: Create Azure Resources

```bash
# Set variables
RESOURCE_GROUP="BoschMyPlanet"
LOCATION="centralindia"
APP_SERVICE_PLAN="travel-app-plan"

# Create App Service Plan (Linux, Python 3.11)
az appservice plan create \
  --name $APP_SERVICE_PLAN \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --is-linux \
  --sku B1

# Note: B1 is Basic tier. For production, consider S1 or P1V2
```

---

## 🚀 Step 2: Deploy MCP Server

### 2.1 Create the App Service

```bash
az webapp create \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --runtime "PYTHON:3.11"
```

### 2.2 Configure Environment Variables

```bash
az webapp config appsettings set \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --settings \
    TRAVEL_AGENT_MCP_SERVER_PORT=8000 \
    TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net" \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true \
    WEBSITE_HTTPLOGGING_RETENTION_DAYS=7
```

### 2.3 Configure Startup Command

**Option A: Using `uv` (Recommended - matches your project setup)**

```bash
az webapp config set \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "pip install uv && uv sync && uv run python -m mcp_server.travel_agent_mcp"
```

**Option B: Using standard pip**

```bash
az webapp config set \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "python -m mcp_server.travel_agent_mcp"
```

**Note**: Option A is recommended as it matches your Dockerfiles and local development setup.

### 2.4 Deploy Code

**Option A: Deploy from Local Directory (Zip Deploy)**

```bash
# Create deployment package (from project root)
cd "d:\BSHMyPlanet\Travel_mcp_a2a_agent - Copy"

# Create a zip file excluding unnecessary files
powershell Compress-Archive -Path * -DestinationPath deploy-mcp.zip -Force

# Deploy
az webapp deployment source config-zip \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --src deploy-mcp.zip
```

**Option B: Deploy from Git**

```bash
# If you have a Git repository
az webapp deployment source config \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --repo-url <YOUR_GIT_REPO_URL> \
  --branch main \
  --manual-integration
```

### 2.5 Get MCP Service URL

```bash
MCP_URL=$(az webapp show \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --query "defaultHostName" -o tsv)

echo "MCP Service URL: https://$MCP_URL"
```

---

## 🚀 Step 3: Deploy Host Agent

### 3.1 Create the App Service

```bash
az webapp create \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --runtime "PYTHON:3.11"
```

### 3.2 Configure Environment Variables

```bash
az webapp config appsettings set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --settings \
    HOST_AGENT_PORT=8080 \
    MCP_SERVER_URL="https://$MCP_URL/mcp" \
    GOOGLE_API_KEY="<YOUR_GOOGLE_API_KEY>" \
    AZURE_API_KEY="<YOUR_AZURE_API_KEY>" \
    AZURE_API_BASE="<YOUR_AZURE_API_BASE>" \
    AZURE_API_VERSION="2024-12-01-preview" \
    AZURE_MODEL="gpt-4o-mini" \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true \
    WEBSITE_HTTPLOGGING_RETENTION_DAYS=7
```

**Important**: Replace `<YOUR_*>` with your actual API keys!

### 3.3 Configure Startup Command

**Using `uv` (Recommended)**

```bash
az webapp config set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "pip install uv && uv sync && uv run python -m agents.Travel_host_agent --host 0.0.0.0 --port 8080"
```

**Using standard pip**

```bash
az webapp config set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "python -m agents.Travel_host_agent --host 0.0.0.0 --port 8080"
```

### 3.4 Deploy Code

```bash
# Create deployment package
powershell Compress-Archive -Path * -DestinationPath deploy-host.zip -Force

# Deploy
az webapp deployment source config-zip \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --src deploy-host.zip
```

### 3.5 Get Host Service URL

```bash
HOST_URL=$(az webapp show \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --query "defaultHostName" -o tsv)

echo "Host Service URL: https://$HOST_URL"
```

---

## 🚀 Step 4: Deploy UI Service

### 4.1 Create the App Service

```bash
az webapp create \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --runtime "PYTHON:3.11"
```

### 4.2 Configure Environment Variables

```bash
az webapp config appsettings set \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --settings \
    HOST_AGENT_PORT=8080 \
    HOST_AGENT_URL="https://$HOST_URL" \
    AGENT_PUBLIC_URL="https://$HOST_URL" \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true \
    WEBSITE_HTTPLOGGING_RETENTION_DAYS=7
```

### 4.3 Configure Startup Command

**Using `uv` (Recommended)**

```bash
az webapp config set \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "pip install uv && uv sync && uv run streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true"
```

**Using standard pip**

```bash
az webapp config set \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true"
```

**Note**: Azure App Service expects apps to listen on port 8000 by default, so we use `--server.port=8000` for Streamlit.

### 4.4 Deploy Code

```bash
# Create deployment package
powershell Compress-Archive -Path * -DestinationPath deploy-ui.zip -Force

# Deploy
az webapp deployment source config-zip \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --src deploy-ui.zip
```

### 4.5 Get UI Service URL

```bash
UI_URL=$(az webapp show \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --query "defaultHostName" -o tsv)

echo "UI Service URL: https://$UI_URL"
echo ""
echo "🎉 Access your application at: https://$UI_URL"
```

---

## 🔧 Important Configuration Notes

### Port Configuration

Azure App Service expects your application to listen on the port specified by the `PORT` environment variable (default: 8000). However, our apps use different ports:

- **MCP Server**: Uses port 8000 ✅ (matches Azure default)
- **Host Agent**: Uses port 8080 ⚠️ (needs adjustment)
- **UI**: Uses port 8501 ⚠️ (needs adjustment)

### Solution: Update Startup Commands

For services that don't use port 8000, you have two options:

**Option 1: Modify startup command to use port 8000 (with uv)**

```bash
# For Host Agent
az webapp config set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "pip install uv && uv sync && uv run python -m agents.Travel_host_agent --host 0.0.0.0 --port 8000"

# For UI
az webapp config set \
  --name travel-ui-service \
  --resource-group $RESOURCE_GROUP \
  --startup-file "pip install uv && uv sync && uv run streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true"
```

**Option 2: Set PORT environment variable**

```bash
az webapp config appsettings set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --settings PORT=8080
```

---

## 📊 Monitoring and Logs

### View Application Logs

```bash
# Enable logging
az webapp log config \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --application-logging filesystem \
  --level information

# Stream logs
az webapp log tail \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP
```

### Check Deployment Status

```bash
az webapp deployment list-publishing-profiles \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP
```

---

## 🔐 Security Considerations

### 1. Enable HTTPS Only

```bash
az webapp update \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --https-only true
```

### 2. Configure CORS (if needed)

```bash
az webapp cors add \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --allowed-origins "https://travel-ui-service.azurewebsites.net"
```

### 3. Use Managed Identity (Recommended)

Instead of storing API keys in environment variables, use Azure Key Vault with Managed Identity.

---

## 🐛 Troubleshooting

### Issue: Application not starting

**Check logs:**
```bash
az webapp log tail --name travel-mcp-service --resource-group $RESOURCE_GROUP
```

**Common issues:**
- Missing `requirements.txt`
- Wrong Python version
- Incorrect startup command
- Port mismatch

### Issue: Dependencies not installing

**Enable build during deployment:**
```bash
az webapp config appsettings set \
  --name travel-mcp-service \
  --resource-group $RESOURCE_GROUP \
  --settings SCM_DO_BUILD_DURING_DEPLOYMENT=true
```

### Issue: Import errors

**Set PYTHONPATH:**
```bash
az webapp config appsettings set \
  --name travel-host-service \
  --resource-group $RESOURCE_GROUP \
  --settings PYTHONPATH=/home/site/wwwroot
```

---

## 📝 Complete Deployment Script

Here's a complete PowerShell script to deploy all services:

```powershell
# Variables
$RESOURCE_GROUP = "BoschMyPlanet"
$LOCATION = "centralindia"
$APP_SERVICE_PLAN = "travel-app-plan"

# Create App Service Plan
az appservice plan create `
  --name $APP_SERVICE_PLAN `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --is-linux `
  --sku B1

# Deploy MCP Service
az webapp create --name travel-mcp-service --resource-group $RESOURCE_GROUP --plan $APP_SERVICE_PLAN --runtime "PYTHON:3.11"
az webapp config appsettings set --name travel-mcp-service --resource-group $RESOURCE_GROUP --settings TRAVEL_AGENT_MCP_SERVER_PORT=8000 TRAVEL_API_URL="https://bgsw-travelai-quality-as-q-si-001.azurewebsites.net" SCM_DO_BUILD_DURING_DEPLOYMENT=true
az webapp config set --name travel-mcp-service --resource-group $RESOURCE_GROUP --startup-file "python -m mcp_server.travel_agent_mcp"
Compress-Archive -Path * -DestinationPath deploy-mcp.zip -Force
az webapp deployment source config-zip --name travel-mcp-service --resource-group $RESOURCE_GROUP --src deploy-mcp.zip

# Get MCP URL
$MCP_URL = az webapp show --name travel-mcp-service --resource-group $RESOURCE_GROUP --query "defaultHostName" -o tsv

# Deploy Host Service
az webapp create --name travel-host-service --resource-group $RESOURCE_GROUP --plan $APP_SERVICE_PLAN --runtime "PYTHON:3.11"
az webapp config appsettings set --name travel-host-service --resource-group $RESOURCE_GROUP --settings HOST_AGENT_PORT=8000 MCP_SERVER_URL="https://$MCP_URL/mcp" GOOGLE_API_KEY="YOUR_KEY" SCM_DO_BUILD_DURING_DEPLOYMENT=true
az webapp config set --name travel-host-service --resource-group $RESOURCE_GROUP --startup-file "python -m agents.Travel_host_agent --host 0.0.0.0 --port 8000"
az webapp deployment source config-zip --name travel-host-service --resource-group $RESOURCE_GROUP --src deploy-mcp.zip

# Get Host URL
$HOST_URL = az webapp show --name travel-host-service --resource-group $RESOURCE_GROUP --query "defaultHostName" -o tsv

# Deploy UI Service
az webapp create --name travel-ui-service --resource-group $RESOURCE_GROUP --plan $APP_SERVICE_PLAN --runtime "PYTHON:3.11"
az webapp config appsettings set --name travel-ui-service --resource-group $RESOURCE_GROUP --settings HOST_AGENT_URL="https://$HOST_URL" AGENT_PUBLIC_URL="https://$HOST_URL" SCM_DO_BUILD_DURING_DEPLOYMENT=true
az webapp config set --name travel-ui-service --resource-group $RESOURCE_GROUP --startup-file "streamlit run app/chat_ai.py --server.address=0.0.0.0 --server.port=8000 --server.headless=true"
az webapp deployment source config-zip --name travel-ui-service --resource-group $RESOURCE_GROUP --src deploy-mcp.zip

# Get UI URL
$UI_URL = az webapp show --name travel-ui-service --resource-group $RESOURCE_GROUP --query "defaultHostName" -o tsv

Write-Host "🎉 Deployment Complete!"
Write-Host "Access your application at: https://$UI_URL"
```

---

## 🆚 App Service vs Container Apps

| Feature | App Service | Container Apps |
|---------|-------------|----------------|
| **Ease of Use** | ✅ Simpler | More complex |
| **Cost** | Fixed pricing | Pay per use |
| **Scaling** | Vertical/Horizontal | Auto-scaling |
| **Container Support** | Limited | Native |
| **Best For** | Traditional web apps | Microservices |

---

## ✅ Verification

After deployment, verify each service:

1. **MCP Service**: `https://travel-mcp-service.azurewebsites.net`
2. **Host Service**: `https://travel-host-service.azurewebsites.net`
3. **UI Service**: `https://travel-ui-service.azurewebsites.net`

Test the UI by opening the UI Service URL in your browser.

---

## 📚 Additional Resources

- [Azure App Service Documentation](https://docs.microsoft.com/en-us/azure/app-service/)
- [Python on Azure App Service](https://docs.microsoft.com/en-us/azure/app-service/quickstart-python)
- [Streamlit Deployment Guide](https://docs.streamlit.io/deploy/streamlit-community-cloud)
